const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const lab_slot_booking_service = require('../services/lab_slot_booking_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const { log } = require('winston');
// const AddCheck = require('../../services/doctor_addCheck_service');

const FetchSlotBooking = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        await lab_slot_booking_service.GetbyId(lab_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {

        await lab_slot_booking_service.Get()
            .then(data => {
                // cache.SET(req.user.id + '_lab_slot_booking_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}

const NewLabSlotBooking = async (req, res, next) => {
    const { day, active, lab_name_id, day_id } = req.body;

    var data = req.body;

    data.forEach((element) => {

        created_by = req.user.id;
        updated_by = req.user.id;
        data = element.day;

        Object.keys(data).forEach((day) => {

            const timings = data[day];
            const fnTimings = timings.fn;
            const anTimings = timings.an;
            const day_ids = timings.day_id;

            sl_data = {
                lab_name_id: parseInt(element.lab_name_id),
                day: `${day}`,
                fn: `${fnTimings.join(', ')}`,
                an: `${anTimings.join(', ')}`,
                day_id: day_ids,

                active: element.active,
                created_by: created_by,
                updated_by: updated_by
            }
            lab_slot_booking_service.CreateLabSlotBookingInfo(sl_data);
        });

    })
    msg = "Created Successfully"
    res.status(200).json(success_func(msg))

}

const UpdateLabSlotBooking = async (req, res, next) => {

    const id = req.params.lab_name_id;

    if (id) {

        lab_name_ids = req.params.lab_name_id;
        const v = lab_slot_booking_service.DestroyLabSlot(lab_name_ids);
        var customerFeedback2 = await v;

        const { day, active, lab_name_id, day_id } = req.body;

        var data = req.body;
        data.forEach((element) => {

            created_by = req.user.id;
            updated_by = req.user.id;
            data = element.day;
            Object.keys(data).forEach((day) => {

                const timings = data[day];
                const fnTimings = timings.fn;
                const anTimings = timings.an;
                const day_ids = timings.day_id;

                sl_data = {
                    lab_name_id: parseInt(element.lab_name_id),
                    day: `${day}`,
                    fn: `${fnTimings.join(', ')}`,
                    an: `${anTimings.join(', ')}`,
                    day_id: day_ids,
                    active: element.active,
                    created_by: created_by,
                    updated_by: updated_by
                }

                lab_slot_booking_service.CreateLabSlotBookingInfo(sl_data)

            });

        })
        msg = "Updated Successfully"
        res.status(200).json(success_func(msg))

    }
}

// const DeleteLabSlotBooking = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await lab_slot_booking_service.DestroyLabSlotBooking(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     // cache.DEL(req.user.id + '_slot_booking_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


module.exports = {
    NewLabSlotBooking,
    FetchSlotBooking,
    UpdateLabSlotBooking,
    // DeleteLabSlotBooking
}