const LabSlotBookingInfo = require('../models/LabSlotBookingModel');

const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const Get = async () => {
    try {
        


        const query = `select * from lab_availability_slot `;
        await db1.query(query, { type: Sequelize.QueryTypes })
            .then((result) => {
                res = result
                
            })
            .catch((err) => {
                res = err
            });
    }
    catch (err) {
        
        throw Error('Error while getting slot virtual and slot walking data', err);
    }
    return res;
};

const GetbyId = async (lab_name_id) => {
    
        if (lab_name_id) {
            const query = `select * from lab_availability_slot  where lab_name_id=${lab_name_id}`;
            await db1.query(query, { type: Sequelize.QueryTypes })
                .then((result) => {
                    res = result
                    
                })
                .catch((err) => {
                    res = err
                });
        }
    
    return res;
}

const CreateLabSlotBookingInfo = async (sl_data) => {

    try {
        
            const newSlot = await LabSlotBookingInfo.SlotOnline.create(sl_data);
            
            return newSlot;
        
    } catch (err) {
        
        console.error('Error saving slot to the database:', err);
        throw err;
    }
};

const UpdateLabSlotBookingInfo = async (id, sl_data) => {
    
    await LabSlotBookingInfo.SlotOnline.update(sl_data, { where: { lab_name_id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res

  
};



const DestroyLabSlot = async (lab_name_id) => {

    
    const check=`select * from lab_availability_slot where lab_name_id = ${lab_name_id}`;
    var chk_vir = await db1.query(check);
    if(chk_vir){
            const query1 = `delete from lab_availability_slot where lab_name_id = ${lab_name_id}`
            var customerFeedback1 = await db1.query(query1);
    }
    return customerFeedback1
}

module.exports = {
    Get,
    GetbyId,
    CreateLabSlotBookingInfo,
     UpdateLabSlotBookingInfo,
    //  DestroyLabSlotBooking,
    DestroyLabSlot
};