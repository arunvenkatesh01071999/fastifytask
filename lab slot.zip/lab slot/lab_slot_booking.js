const express = require('express');
const router = express();
const LabSlotBookingController = require('../../LabApp/controller/LabSlotBookingController');
const verify_token = require('../../services/verify_token');

 router.get('/', verify_token, LabSlotBookingController.FetchSlotBooking);
 router.get('/:lab_name_id', verify_token, LabSlotBookingController.FetchSlotBooking);
router.post('/', verify_token, LabSlotBookingController.NewLabSlotBooking);
 router.put('/:lab_name_id', verify_token, LabSlotBookingController.UpdateLabSlotBooking);
// router.delete('/:id', verify_token, LabSlotBookingController.DeleteSlotBooking);

module.exports = router;