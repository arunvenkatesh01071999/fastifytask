const patchCategoryImageSchema = require("./patchCategoryImage");

module.exports = { patchCategoryImageSchema };
