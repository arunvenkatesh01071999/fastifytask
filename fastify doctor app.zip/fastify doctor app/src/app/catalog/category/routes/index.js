const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "PATCH",
    url: "/categories/:category_id/images",
    schema: schemas.patchCategoryImageSchema,
    handler: handlers.patchCategoryImage(fastify)
  });
};
