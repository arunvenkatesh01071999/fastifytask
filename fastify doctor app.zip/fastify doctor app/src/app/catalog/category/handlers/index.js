const patchCategoryImage = require("./patchCategoryImage");

module.exports = {
  patchCategoryImage
};
