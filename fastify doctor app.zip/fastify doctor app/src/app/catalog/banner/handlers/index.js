const getBanners = require("./getBanners");

module.exports = {
  getBanners
};
