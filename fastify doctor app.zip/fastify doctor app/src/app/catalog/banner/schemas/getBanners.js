const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getBannersSchema = {
  tags: ["BANNER"],
  summary: "This API is to get banners",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          banner_image: { type: "string" },
          banner_title: { type: "string" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = getBannersSchema;
