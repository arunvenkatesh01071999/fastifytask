const getBannersSchema = require("./getBanners");

module.exports = {
  getBannersSchema
};
