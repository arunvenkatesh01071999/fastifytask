const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { DEPARTMENT } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function departmentInfoRepo(fastify) {
  async function getdepartmentInfo({ logTrace }) {
    const knex = this;
 
    const query = knex(DEPARTMENT.NAME)
      .where(DEPARTMENT.COLUMNS.ACTIVE, "1");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get department Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "department info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getdepartmentInfo
  };
}

module.exports = departmentInfoRepo;
