const departmentInfoService = require("../services/departmentInfoService");

function getdepartmentInfoHandler(fastify) {
  const genderInfo = departmentInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await genderInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getdepartmentInfoHandler;
