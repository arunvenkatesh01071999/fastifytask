const getdepartmentInfoHandler = require("./getdepartmentInfoHandler");

module.exports = {
  getdepartmentInfoHandler
};
