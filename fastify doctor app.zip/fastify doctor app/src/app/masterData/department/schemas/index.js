const departmentSchema = require("./departmentSchema");

module.exports = {
  departmentSchema
};
