const departmentInfoRepo = require("../repository/departmentInfoRepo");

function departmentInfoService(fastify) {
  const { getdepartmentInfo } = departmentInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getdepartmentInfo.call(knex, {
      logTrace
    });

    return response;
  };
}

module.exports = departmentInfoService;
