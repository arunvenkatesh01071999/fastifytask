const citiesSchema = require("./citiesSchema");

module.exports = {
  citiesSchema
};
