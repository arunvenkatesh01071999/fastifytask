const cityInfoRepo = require("../repository/cityInfoRepo");

function cityInfoService(fastify) {
  const { getCityInfo } = cityInfoRepo(fastify);

  return async ({ body,logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getCityInfo.call(knex, {
      state_id: body.state_id,
      logTrace
    });

    return response;
  };
}

module.exports = cityInfoService;
