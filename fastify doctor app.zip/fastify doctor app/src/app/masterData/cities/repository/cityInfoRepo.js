const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { CITIES } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function cityInfoRepo(fastify) {
  async function getCityInfo({ state_id, logTrace }) {
    const knex = this;
 
    const query = knex(CITIES.NAME)
    .where(CITIES.COLUMNS.STATEID, state_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Cities Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Cities info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getCityInfo
  };
}

module.exports = cityInfoRepo;
