const getscitiesInfoHandler = require("./getscitiesInfoHandler");

module.exports = {
  getscitiesInfoHandler
};
