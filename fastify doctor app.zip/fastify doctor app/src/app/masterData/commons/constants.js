const GENDER = {
  NAME: "gender",
  COLUMNS: {
    ID: "id",
    GENDER_NAME: "gender_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const SPECIALITIES = {
  NAME: "specialities",
  COLUMNS: {
    ID: "id",
    SPECIALITIY_NAME: "speciality_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const QUALIFICATIONMASTER = {
  NAME: "qualification_master",
  COLUMNS: {
    ID: "id",
    QUALIFICATION: "qualification",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const CITIES = {
  NAME: "cities",
  COLUMNS: {
    ID: "id",
    CITYNAME: "city_name",
    STATEID: "state_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const STATES = {
  NAME: "states",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    COUNTRYID: "country_id"
  }
};
const COUNTRIES = {
  NAME: "countries",
  COLUMNS: {
    ID: "id",
    SHORTNAME: "shortname",
    NAME: "name",
    PHONECODE: "phonecode",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LANGUAGES = {
  NAME: "languages",
  COLUMNS: {
    ID: "id",
    LANGUAGENAME: "language_name",
    NATIVENAME: "native_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const COUNCIL = {
  NAME: "council",
  COLUMNS: {
    ID: "id",
    COUNCIL_NAME: "council_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DEPARTMENT = {
  NAME: "department_master",
  COLUMNS: {
    ID: "id",
    DEPARTMENT_NAME: "department_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const MARITALINFO = {
  NAME: "marital_status_master",
  COLUMNS: {
    ID: "id",
    MNAME: "m_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const BLOODGROUPINFO = {
  NAME: "blood_group_master",
  COLUMNS: {
    ID: "id",
    MNAME: "group_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const BANKMASTER = {
  NAME: "bank_master",
  COLUMNS: {
    ID: "id",
    MNAME: "bank_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const ILLNESSTYPE = {
  NAME: "illness_types",
  COLUMNS: {
    ID: "id",
    ILLNESS_TYPE_NAME: "illness_type_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    LOGO_IMAGE: "logo_image"
  }
};

const ILLNESSSYMPTOM = {
  NAME: "illness_symptoms_master",
  COLUMNS: {
    ID: "id",
    ILLNESS_SYMPTOM_NAME: "illness_symptom_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    LOGO_IMAGE: "logo_image"
  }
};

const ABOUTUS = {
  NAME: "about_healthuno",
  COLUMNS: {
    ID: "id",
    HEALTHUNO_CONTENT: "healthuno_content",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
  }
}

const ALLOPATHY = {
  NAME: "ehr_allopathy_list_master",
  COLUMNS: {
    ID: "id",
    EHR_LIST_NAME: "ehr_list_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
  }
}

const AYURVEDIC = {
  NAME: "ehr_ayurvedic_list_master",
  COLUMNS: {
    ID: "id",
    EHR_LIST_NAME: "ehr_list_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
  }
}

module.exports = {
  GENDER,
  SPECIALITIES,
  QUALIFICATIONMASTER,
  CITIES,
  STATES,
  COUNTRIES,
  LANGUAGES,
  COUNCIL,
  DEPARTMENT,
  MARITALINFO,
  BLOODGROUPINFO,
  BANKMASTER,
  ILLNESSTYPE,
  ILLNESSSYMPTOM,
  ABOUTUS,
  ALLOPATHY,
  AYURVEDIC

};
