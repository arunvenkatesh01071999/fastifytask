const listInfoRepo = require("../repository/listInfoRepo");

function listInfoService(fastify) {
  const { getListInfo } = listInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getListInfo.call(knex, {
      logTrace
    });

    return response;
  };
}

module.exports = listInfoService;
