const listInfoService = require("../services/listinfoService");

function getListInfoHandler(fastify) {
  const listInfo = listInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await listInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getListInfoHandler;
