const getListInfoHandler = require("./getListInfoHandler");

module.exports = {
    getListInfoHandler
};
