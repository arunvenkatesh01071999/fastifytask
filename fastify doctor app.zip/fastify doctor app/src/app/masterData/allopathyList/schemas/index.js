const alloListSchema = require("./listInfoSchema");

module.exports = {
    alloListSchema
};
