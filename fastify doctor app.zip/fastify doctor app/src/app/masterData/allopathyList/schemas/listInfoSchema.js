const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const alloListSchema = {
  tags: ["Fetch List"],
  summary: "This API is used to fetch allopathy list",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          ehr_list_name: { type: "string" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = alloListSchema;
