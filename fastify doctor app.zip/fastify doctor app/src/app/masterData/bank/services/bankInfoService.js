const bankInfoRepo = require("../repository/bankInfoRepo");

function bankInfoService(fastify) {
  const { getbankInfo } = bankInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getbankInfo.call(knex, {
      logTrace
    });

    return response;
  };
}



module.exports = bankInfoService;
