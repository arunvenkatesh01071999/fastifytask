const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { BANKMASTER } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function bankInfoRepo(fastify) {
  async function getbankInfo({ logTrace }) {
    const knex = this;
 
    const query = knex(BANKMASTER.NAME);
    
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Bank Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Bank info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getbankInfo
  };
}

module.exports = bankInfoRepo;
