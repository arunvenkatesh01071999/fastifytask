const aboutusSchema = require("./aboutusSchema");

module.exports = {
  aboutusSchema
};
