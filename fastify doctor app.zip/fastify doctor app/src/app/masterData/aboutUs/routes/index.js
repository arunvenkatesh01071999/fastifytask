const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/aboutus",
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    schema: schemas.aboutusSchema,
    handler: handlers.getAboutUsInfoHandler(fastify)
  });
};
