const getAboutUsInfoHandler = require("./getAboutUsHandler");

module.exports = {
    getAboutUsInfoHandler
};
