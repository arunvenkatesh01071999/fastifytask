const aboutusInfoService = require("../services/getAboutUsService");

function getAboutUsInfoHandler(fastify) {
  const bankInfo = aboutusInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await bankInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getAboutUsInfoHandler;
