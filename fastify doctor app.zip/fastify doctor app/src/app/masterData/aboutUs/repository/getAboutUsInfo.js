const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { ABOUTUS } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function bankInfoRepo(fastify) {
  async function aboutusInfo({ logTrace }) {
    const knex = this;
 
    const query = knex(ABOUTUS.NAME);
    // console.log(query,"query");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get About us Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "About us info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    aboutusInfo
  };
}

module.exports = bankInfoRepo;
