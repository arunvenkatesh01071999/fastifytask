const aboutUsInfoRepo = require("../repository/getAboutUsInfo");

function aboutusInfoService(fastify) {
  const { aboutusInfo } = aboutUsInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await aboutusInfo.call(knex, {
      logTrace
    });

    return response;
  };
}

module.exports = aboutusInfoService;
