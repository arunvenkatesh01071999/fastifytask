const getbloodGroupInfoHandler = require("./getbloodGroupInfoHandler");

module.exports = {
  getbloodGroupInfoHandler
};
