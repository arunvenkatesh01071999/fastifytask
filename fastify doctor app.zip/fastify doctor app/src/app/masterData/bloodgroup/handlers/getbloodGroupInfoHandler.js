const getbloodGroupInfoService = require("../services/getbloodGroupInfoService");

function getbloodGroupInfoHandler(fastify) {
  const genderInfo = getbloodGroupInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await genderInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getbloodGroupInfoHandler;
