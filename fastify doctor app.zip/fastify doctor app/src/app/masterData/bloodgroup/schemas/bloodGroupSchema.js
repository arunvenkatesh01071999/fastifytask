const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const genderSchema = {
  tags: ["FETCH LANGUAGES"],
  summary: "This API is used to fetch languages",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          group_name: { type: "string" }, 
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = genderSchema;
