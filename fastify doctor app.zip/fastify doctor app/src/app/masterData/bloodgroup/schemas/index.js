const bloodGroupSchema = require("./bloodGroupSchema");

module.exports = {
  bloodGroupSchema
};
