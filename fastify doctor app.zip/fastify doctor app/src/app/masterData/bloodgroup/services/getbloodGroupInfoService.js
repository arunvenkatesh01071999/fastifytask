const getbloodGroupInfoRepo = require("../repository/getbloodGroupInfoRepo");

function getbloodGroupInfoService(fastify) {
  const { getbloodGroupInfo } = getbloodGroupInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getbloodGroupInfo.call(knex, {
      logTrace
    });

    return response;
  };
}

module.exports = getbloodGroupInfoService;
