const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { BLOODGROUPINFO } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function getbloodGroupInfoRepo(fastify) {
  async function getbloodGroupInfo({ logTrace }) {
    const knex = this;
 
    const query = knex(BLOODGROUPINFO.NAME)
      .where(BLOODGROUPINFO.COLUMNS.ACTIVE, "1");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Blood group Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Blood group info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getbloodGroupInfo
  };
}

module.exports = getbloodGroupInfoRepo;
