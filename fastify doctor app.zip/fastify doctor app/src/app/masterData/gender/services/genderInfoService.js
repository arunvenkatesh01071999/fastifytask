const genderInfoRepo = require("../repository/genderInfoRepo");

function genderInfoService(fastify) {
  const { getGenderInfo } = genderInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getGenderInfo.call(knex, {
      logTrace
    });

    return response;
  };
}

module.exports = genderInfoService;
