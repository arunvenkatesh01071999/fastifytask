const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const genderSchema = {
  tags: ["FETCH GENDER"],
  summary: "This API is used to fetch genders",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          gender_name: { type: "string" }, 
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = genderSchema;
