const genderSchema = require("./genderSchema");

module.exports = {
  genderSchema
};
