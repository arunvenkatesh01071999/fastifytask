const genderInfoService = require("../services/genderInfoService");

function getGenderInfoHandler(fastify) {
  const genderInfo = genderInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await genderInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getGenderInfoHandler;
