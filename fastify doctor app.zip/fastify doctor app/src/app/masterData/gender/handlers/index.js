const getGenderInfoHandler = require("./getlanguageInfoHandler");

module.exports = {
  getGenderInfoHandler
};
