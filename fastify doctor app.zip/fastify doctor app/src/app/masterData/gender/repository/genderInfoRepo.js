const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { GENDER } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function genderInfoRepo(fastify) {
  async function getGenderInfo({ logTrace }) {
    const knex = this;
 
    const query = knex(GENDER.NAME)
      .where(GENDER.COLUMNS.ACTIVE, "1");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Gender Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Genders info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getGenderInfo
  };
}

module.exports = genderInfoRepo;
