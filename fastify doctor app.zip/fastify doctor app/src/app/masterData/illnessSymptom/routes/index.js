const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/illnessSymptomsMaster",
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    schema: schemas.illnessSymptomsMasterSchema,
    handler: handlers.getsillnessSymptomsMasterInfoHandler(fastify)
  });
};
