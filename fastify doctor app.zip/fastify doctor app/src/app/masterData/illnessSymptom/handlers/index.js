const getsillnessSymptomsMasterInfoHandler = require("./getsillnessSymptomsMasterInfoHandler");

module.exports = {
  getsillnessSymptomsMasterInfoHandler
};
