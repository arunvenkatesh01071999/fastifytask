const illnessSymptomsMasterInfoService = require("../services/illnessSymptomsMasterInfoService");

function getsillnessSymptomsMasterInfoHandler(fastify) {
  const illnessSymptomsMasterInfo = illnessSymptomsMasterInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await illnessSymptomsMasterInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getsillnessSymptomsMasterInfoHandler;
