const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { SPECIALITIES } = require("../../commons/constants");

const { CustomError } = require("../../../errorHandler");

function getSpecialitiesInfoRepo(fastify) {

  async function getSpecialitiesInfo({ logTrace }) {
    const emptyArray = [];
    const knex = this;

    const query = knex.select(`*`).from(`dbo.specialities as s`);

    const response = await query;

    const resultss = await Promise.all(
      response.map(async (specialityData) => {
        const id = specialityData.id

        const result = await knex('dbo.d_doctor_basic_info as d')
          .where('d.speciality_id', id)
          .count('* as total')

        var counts = result[0].total

        emptyArray.push({
          "count": counts,
          "specialityID": id
        })
      })

    )

    return emptyArray;

  }

  return {
    getSpecialitiesInfo
  };
}

module.exports = getSpecialitiesInfoRepo;
