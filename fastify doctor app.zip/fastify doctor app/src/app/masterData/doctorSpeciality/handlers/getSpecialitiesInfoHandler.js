const getSpecialitiesInfoService = require("../services/getSpecialitiesInfoService");

function getSpecialitiesInfoHandler(fastify) {
  const getSpecialitiesInfo = getSpecialitiesInfoService(fastify);
  return async (request, reply) => {

    const { body, logTrace } = request;

    const response = await getSpecialitiesInfo({ logTrace });
    return reply.code(200).send(response);
  };
}





module.exports = getSpecialitiesInfoHandler;
