const getSpecialitiesInfoHandler = require("./getSpecialitiesInfoHandler");

module.exports = {
  getSpecialitiesInfoHandler
};
