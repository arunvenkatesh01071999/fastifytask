const councilInfoRepo = require("../repository/councilInfoRepo");

function councilInfoService(fastify) {
  const { getcouncilInfo } = councilInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getcouncilInfo.call(knex, {
      logTrace
    });

    return response;
  };
}

module.exports = councilInfoService;
