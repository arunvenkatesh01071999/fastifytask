const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const genderSchema = {
  tags: ["Fetch Councils"],
  summary: "This API is used to fetch Councils",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          council_name: { type: "string" }, 
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = genderSchema;
