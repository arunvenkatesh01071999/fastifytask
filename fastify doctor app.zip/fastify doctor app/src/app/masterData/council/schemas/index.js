const councilSchema = require("./councilSchema");

module.exports = {
  councilSchema
};
