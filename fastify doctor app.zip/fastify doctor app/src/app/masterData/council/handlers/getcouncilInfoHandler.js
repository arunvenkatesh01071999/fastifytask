const councilInfoService = require("../services/councilInfoService");

function getcouncilInfoHandler(fastify) {
  const councilInfo = councilInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await councilInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getcouncilInfoHandler;
