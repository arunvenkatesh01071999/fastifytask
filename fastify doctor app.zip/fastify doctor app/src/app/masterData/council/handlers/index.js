const getcouncilInfoHandler = require("./getcouncilInfoHandler");

module.exports = {
  getcouncilInfoHandler
};
