const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { COUNCIL } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function councilInfoRepo(fastify) {
  async function getcouncilInfo({ logTrace }) {
    const knex = this;
 
    const query = knex(COUNCIL.NAME)
      .where(COUNCIL.COLUMNS.ACTIVE, "1");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Council Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Council info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getcouncilInfo
  };
}

module.exports = councilInfoRepo;
