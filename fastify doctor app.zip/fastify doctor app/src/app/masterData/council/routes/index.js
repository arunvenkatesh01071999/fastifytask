const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/council",
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    schema: schemas.councilSchema,
    handler: handlers.getcouncilInfoHandler(fastify)
  });
};
