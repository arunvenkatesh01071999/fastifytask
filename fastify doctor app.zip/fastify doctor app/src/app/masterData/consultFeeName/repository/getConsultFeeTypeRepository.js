const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../app/commons/helpers");
const { CONSULTFEETYPE } = require("../commons/constants");
// const { CustomError } = require("../../../errorHandler");

function postConsultFeeTypeRepositoryBasic(fastify) {
  async function ConsultFeeTypeAdd({ logTrace, body }) {
    const knex = this;
    const query = await knex(`${CONSULTFEETYPE.NAME}`).insert({
      [CONSULTFEETYPE.COLUMNS.FEES_TYPE_NAME]: body.fees_type_name,
      [CONSULTFEETYPE.COLUMNS.PERCENTAGE]: body.percentage,
      [CONSULTFEETYPE.COLUMNS.ACTIVE]: body.active,
      [CONSULTFEETYPE.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    ConsultFeeTypeAdd

  };
}

function updateConsultFeeTypeRepository(fastify) {
  async function ConsultFeeTypeUpdate({ logTrace, body, params }) {
    const knex = this;
    const { id } = params;
    console.log(body, "body");
    const query = await knex(`${CONSULTFEETYPE.NAME}`)
      .where(`${CONSULTFEETYPE.COLUMNS.ID}`, id)
      .update({
        [CONSULTFEETYPE.COLUMNS.FEES_TYPE_NAME]: body.fees_type_name,
        [CONSULTFEETYPE.COLUMNS.PERCENTAGE]: body.percentage,
        [CONSULTFEETYPE.COLUMNS.ACTIVE]: body.active,
        [CONSULTFEETYPE.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    ConsultFeeTypeUpdate,
  };
}

function getConsultFeeTypeRepository(fastify) {

  async function ConsultFeeTypeGetAlls({ logTrace }) {

    const knex = this;
    const query = knex.select('*').from(`${CONSULTFEETYPE.NAME}`);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get OTHER_articles details",
    //   logTrace
    // });

    const response = await query;

    const output = {};
    response.forEach(item => {
      output[item.fees_type_name] = item.percentage;
    });

    console.log(output)



    // if (!response.length) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "OTHER_articles info not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }


    return output;
  }

  return {
    ConsultFeeTypeGetAlls
  };

}


function getConsultFeeTypeRepositoryId(fastify) {

  async function ConsultFeeTypeGetOne({ logTrace, params }) {

    const knex = this;
    const { id } = params;
    const query = knex.select('*').from(`${CONSULTFEETYPE.NAME}`).where(`${CONSULTFEETYPE.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get OTHER_articles details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "OTHER_articles info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    ConsultFeeTypeGetOne
  };

}

function deleteConsultFeeTypeRepositoryId(fastify) {
  async function ConsultFeeTypeDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${CONSULTFEETYPE.NAME}`).where(`${CONSULTFEETYPE.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    ConsultFeeTypeDelete
  };
}


module.exports = {
  postConsultFeeTypeRepositoryBasic,
  updateConsultFeeTypeRepository,
  getConsultFeeTypeRepository,
  getConsultFeeTypeRepositoryId,
  deleteConsultFeeTypeRepositoryId

};
