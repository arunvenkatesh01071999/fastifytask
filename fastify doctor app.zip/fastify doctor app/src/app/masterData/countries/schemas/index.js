const countriesSchema = require("./countriesSchema");

module.exports = {
  countriesSchema
};
