const countryInfoRepo = require("../repository/countryInfoRepo");

function countryInfoService(fastify) {
  const { getCountryInfo } = countryInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getCountryInfo.call(knex, {
      logTrace
    });

    return response;
  };
}

module.exports = countryInfoService;
