const getscountriesInfoHandler = require("./getscountriesInfoHandler");

module.exports = {
  getscountriesInfoHandler
};
