const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");

const { AYURVEDIC } = require("../../commons/constants");
const { CustomError } = require("../../../errorHandler");

function listInfoRepo(fastify) {
  async function getListInfo({ logTrace }) {
    const knex = this;
 
    const query = knex(AYURVEDIC.NAME);
    // console.log(query,"query");
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Bank Info details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Bank info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getListInfo
  };
}

module.exports = listInfoRepo;
