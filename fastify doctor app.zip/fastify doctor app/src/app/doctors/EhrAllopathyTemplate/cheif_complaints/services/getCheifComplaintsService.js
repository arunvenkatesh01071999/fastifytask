const getCheifComplaintsRepository = require("../repository/getCheifComplaintsRepository");

function createCheifComplaintsServiceBasic(fastify) {
  const { CheifComplaintsAdd } = getCheifComplaintsRepository.postCheifComplaintsRepositoryBasic(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsAdd.call(knex, {
      logTrace,
      body
    });

    const [CheifComplaintsAddData] = await Promise.all([promise1]);

    return CheifComplaintsAddData;
  };
}

function updateCheifComplaintsServiceBasic(fastify) {
  const { CheifComplaintsUpdate } = getCheifComplaintsRepository.updateCheifComplaintsRepository(fastify);

  return async ({ body, params, logTrace, }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedCheifComplaintsData] = await Promise.all([promise1]);

    return updatedCheifComplaintsData;
  };
}



function getCheifComplaintsInfoService(fastify) {

  const { CheifComplaintsGetAlls } = getCheifComplaintsRepository.getCheifComplaintsRepository(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsGetAlls.call(knex, {
      logTrace
    });
    const [getCheifComplaintsAlldata] = await Promise.all([promise1]);
    return getCheifComplaintsAlldata;
  }
}

function getCheifComplaintsInfoServiceId(fastify) {

  const { CheifComplaintsGetOne } = getCheifComplaintsRepository.getCheifComplaintsRepositoryId(fastify);

  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsGetOne.call(knex, {
      logTrace,
      params
    });
    const [getCheifComplaintsOnedata] = await Promise.all([promise1]);
    return getCheifComplaintsOnedata;
  }
}

function deleteCheifComplaintsServiceId(fastify) {

  const { CheifComplaintsDelete } = getCheifComplaintsRepository.deleteCheifComplaintsRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = CheifComplaintsDelete.call(knex, {
      logTrace,
      params
    });

    const [deleteCheifComplaintsdata] = await Promise.all([promise1]);

    return deleteCheifComplaintsdata;
  };
}


module.exports = {

  createCheifComplaintsServiceBasic,
  updateCheifComplaintsServiceBasic,
  getCheifComplaintsInfoService,
  getCheifComplaintsInfoServiceId,
  deleteCheifComplaintsServiceId
};
