const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { CHEIFCOMPLAINTS } = require("../commons/constants");
const { ILLNESSTYPE } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");




function postCheifComplaintsRepositoryBasic(fastify) {
  async function CheifComplaintsAdd({ logTrace, body }) {
    const knex = this;
    const cheif = body.cheif_complients;
    const processedDiseases = [];

    const illnessNames = await knex.raw(`select illness_type_name from illness_types`)
      .then(response => response.map(illness => illness.illness_type_name));


    for (let disease of cheif) {
      if (!illnessNames.includes(disease)) {
        try {
          await knex(`${ILLNESSTYPE.NAME}`).insert({
            [ILLNESSTYPE.COLUMNS.ILLNESS_TYPE_NAME]: disease,
            [ILLNESSTYPE.COLUMNS.LOGO_IMAGE]: null,
            [ILLNESSTYPE.COLUMNS.ACTIVE]: body.active,
            [ILLNESSTYPE.COLUMNS.CREATED_BY]: body.created_by,
            [ILLNESSTYPE.COLUMNS.UPDATED_BY]: body.created_by,
            [ILLNESSTYPE.COLUMNS.CREATED_AT]: new Date(),
            [ILLNESSTYPE.COLUMNS.UPDATED_AT]: new Date()

          });
        } catch (error) {
          console.error("Error Inserting Disease:", error);
        }
      }
      processedDiseases.push(disease);
    }

    const result = processedDiseases.join(', ');

    try {
      await knex(`${CHEIFCOMPLAINTS.NAME}`).insert({
        [CHEIFCOMPLAINTS.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID]: body.patient_id,
        [CHEIFCOMPLAINTS.COLUMNS.ISALLO_OR_AUYR]: body.isallo_or_auyr,
        [CHEIFCOMPLAINTS.COLUMNS.APPOINT_ID]: body.appoint_id,
        [CHEIFCOMPLAINTS.COLUMNS.CHEIF_COMPLIENTS]: result,
        [CHEIFCOMPLAINTS.COLUMNS.ACTIVE]: body.active,
        [CHEIFCOMPLAINTS.COLUMNS.CREATED_BY]: body.created_by
      });
    }
     catch (error) {
      console.error("Error Inserting Chief Complaints:", error);
    }

    return { success: true, message: "Insert successfully" };
  }

  return {
    CheifComplaintsAdd
  };
}





function updateCheifComplaintsRepository(fastify) {
  async function CheifComplaintsUpdate({ logTrace, body, params }) {

    
    const knex = this;
    var patient_id = params.patient_id;

    const cheif = body.cheif_complients;

    const cheifComplientPost = await knex.raw(`select cheif_complients from e_cheif_complaints where patient_id = ${patient_id}`)
      .then(response => response.map(illness => illness.cheif_complients));

    const difference = cheif.filter(item => !cheifComplientPost.includes(item));


    if (difference.length === 0) {

      const query = await knex(`${CHEIFCOMPLAINTS.NAME}`).where(`${CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID}`, patient_id)
        .del();

      result = cheif.join(', ');

      try {
        await knex(`${CHEIFCOMPLAINTS.NAME}`).insert({
          [CHEIFCOMPLAINTS.COLUMNS.DOCTOR_ID]: body.doctor_id,
          [CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID]: body.patient_id,
          [CHEIFCOMPLAINTS.COLUMNS.ISALLO_OR_AUYR]: body.isallo_or_auyr,
          [CHEIFCOMPLAINTS.COLUMNS.APPOINT_ID]: body.appoint_id,
          [CHEIFCOMPLAINTS.COLUMNS.CHEIF_COMPLIENTS]: result,
          [CHEIFCOMPLAINTS.COLUMNS.ACTIVE]: body.active,
          [CHEIFCOMPLAINTS.COLUMNS.CREATED_BY]: body.created_by
        });
      } catch (error) {
        console.error("Error Inserting Chief Complaints:", error);
      }

    }
    else {

      const query = await knex(`${CHEIFCOMPLAINTS.NAME}`).where(`${CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID}`, patient_id)
        .del();

      result = cheif.join(', ');

      try {
        await knex(`${CHEIFCOMPLAINTS.NAME}`).insert({
          [CHEIFCOMPLAINTS.COLUMNS.DOCTOR_ID]: body.doctor_id,
          [CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID]: body.patient_id,
          [CHEIFCOMPLAINTS.COLUMNS.ISALLO_OR_AUYR]: body.isallo_or_auyr,
          [CHEIFCOMPLAINTS.COLUMNS.APPOINT_ID]: body.appoint_id,
          [CHEIFCOMPLAINTS.COLUMNS.CHEIF_COMPLIENTS]: result,
          [CHEIFCOMPLAINTS.COLUMNS.ACTIVE]: body.active,
          [CHEIFCOMPLAINTS.COLUMNS.CREATED_BY]: body.created_by
        });
      } catch (error) {
        console.error("Error Inserting Chief Complaints:", error);
      }


      const illnessNames = await knex.raw(`select illness_type_name from illness_types`)
        .then(response => response.map(illness => illness.illness_type_name));


      for (let disease of difference) {
        if (!illnessNames.includes(disease)) {
          try {
            await knex(`${ILLNESSTYPE.NAME}`).insert({
              [ILLNESSTYPE.COLUMNS.ILLNESS_TYPE_NAME]: disease,
              [ILLNESSTYPE.COLUMNS.LOGO_IMAGE]: null,
              [ILLNESSTYPE.COLUMNS.ACTIVE]: body.active,
              [ILLNESSTYPE.COLUMNS.CREATED_BY]: body.created_by,
              [ILLNESSTYPE.COLUMNS.UPDATED_BY]: body.created_by,
              [ILLNESSTYPE.COLUMNS.CREATED_AT]: new Date(),
              [ILLNESSTYPE.COLUMNS.UPDATED_AT]: new Date()

            });
          } catch (error) {
            console.error("Error Inserting Disease:", error);
          }
        }

      }

    }


    return { success: true, message: "Update successfully" };
  }

  return {
    CheifComplaintsUpdate,
  };
}

function getCheifComplaintsRepository(fastify) {

  async function CheifComplaintsGetAlls({ logTrace }) {

    const knex = this;

    const query = knex.raw(`select * from e_cheif_complaints`)

    logQuery({
      logger: fastify.log,
      query,
      context: "Get Cheif Complaints Details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Cheif Complaints info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    CheifComplaintsGetAlls
  };

}



function getCheifComplaintsRepositoryId(fastify) {

  async function CheifComplaintsGetOne({ logTrace, params }) {

    const knex = this;
    patient_id = params.patient_id;

    const query = knex.raw(`select * from e_cheif_complaints  where patient_id= ${patient_id}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Cheif Complaints Details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Cheif Complaints info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    CheifComplaintsGetOne
  };

}

function deleteCheifComplaintsRepositoryId(fastify) {
  async function CheifComplaintsDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const { patient_id } = params.patient_id;

    const query = await knex(`${CHEIFCOMPLAINTS.NAME}`).where(`${CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID}`, patient_id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    CheifComplaintsDelete
  };
}


module.exports = {
  postCheifComplaintsRepositoryBasic,
  updateCheifComplaintsRepository,
  getCheifComplaintsRepository,
  getCheifComplaintsRepositoryId,
  deleteCheifComplaintsRepositoryId

};
