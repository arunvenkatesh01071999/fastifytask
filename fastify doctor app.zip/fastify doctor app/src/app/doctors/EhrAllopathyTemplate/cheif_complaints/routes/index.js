const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/cheif-complaints",
    preHandler: fastify.authenticate,
    schema: schemas.getCheifComplaintsSchema.createCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.createCheifComplaintsHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/cheif-complaints/:patient_id",
    preHandler: fastify.authenticate,
    schema: schemas.getCheifComplaintsSchema.updateCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.updateCheifComplaintsHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/cheif-complaints",
    preHandler: fastify.authenticate,
    schema: schemas.getCheifComplaintsSchema.getCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.getCheifComplaintsHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/cheif-complaints/:patient_id",
    preHandler: fastify.authenticate,
    schema: schemas.getCheifComplaintsSchema.getCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.getCheifComplaintsHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/cheif-complaints/:patient_id",
    preHandler: fastify.authenticate,
    schema: schemas.getCheifComplaintsSchema.deleteCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.deleteCheifComplaintsHandler(fastify)
  });

};
