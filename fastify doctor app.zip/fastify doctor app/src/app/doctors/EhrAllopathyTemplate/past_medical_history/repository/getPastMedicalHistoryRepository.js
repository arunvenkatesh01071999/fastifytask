const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { PASTMEDICALHISTORY } = require("../commons/constants");

const { ILLNESSTYPE } = require("../commons/constants");

const { CustomError } = require("../../../../errorHandler");

const UploadImageService=require("../../../../commons/imageupload");

function postPastMedicalHistoryRepositoryBasic(fastify) {
  async function PastMedicalHistoryAdd({ logTrace, body }) {
    const knex = this;

    const processedDiseases = [];


    const health_record_details = body.health_record_details;

    if(health_record_details.filename != ''){
    
      const img = UploadImageService(health_record_details, fastify);
      var imgurl = img.image_url;
    }else{
        var imgurl = null;
    }






    const medicine = JSON.parse(body.past_medicine.value);
    let medicineResult = medicine.join(",");

    const surgery = JSON.parse(body.past_surgeries.value);
    let surgeryResult = surgery.join(",");

    const allergy = JSON.parse(body.history_of_allergy.value);
    let allergyResult = allergy.join(",");

    const vacination = JSON.parse(body.previous_vacination.value);
    let vacinationResult = vacination.join(",");

     var past_illness = JSON.parse(body.past_illness.value);

    

   





    const illnessNames = await knex.raw(`select illness_type_name from illness_types`)
    .then(response => response.map(illness => illness.illness_type_name));

    
    

    for (let disease of past_illness) {
      if (!illnessNames.includes(disease)) {
        
        try {
          await knex(`${ILLNESSTYPE.NAME}`).insert({
            [ILLNESSTYPE.COLUMNS.ILLNESS_TYPE_NAME]: disease,
            [ILLNESSTYPE.COLUMNS.LOGO_IMAGE]: null,
            [ILLNESSTYPE.COLUMNS.ACTIVE]: body.active.value,
            [ILLNESSTYPE.COLUMNS.CREATED_BY]: body.created_by.value,
            [ILLNESSTYPE.COLUMNS.UPDATED_BY]: body.created_by.value,
            [ILLNESSTYPE.COLUMNS.CREATED_AT]: new Date(),
            [ILLNESSTYPE.COLUMNS.UPDATED_AT]: new Date()

          });
        } catch (error) {
          console.error("Error Inserting Disease:", error);
        }
      }
      processedDiseases.push(disease);
    }

    const result = processedDiseases.join(',');

try{

    const query = await knex(`${PASTMEDICALHISTORY.NAME}`).insert({


      [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: body.doctor_id.value,
      [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: body.patient_id.value,
      [PASTMEDICALHISTORY.COLUMNS.HEALTH_RECORD_DETAILS]: imgurl,
      [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: result,
      [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: medicineResult,
      [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERIES]: surgeryResult,
      [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: allergyResult,
      [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: vacinationResult,
      [PASTMEDICALHISTORY.COLUMNS.PREGNANCY]: body.pregnancy.value,
      [PASTMEDICALHISTORY.COLUMNS.IS_TRIMESTER]: body.is_trimester.value,
      [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: body.is_lactation.value,
      [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: body.created_by.value,
      [PASTMEDICALHISTORY.COLUMNS.ACTIVE]: body.active.value,

    });
  }
  catch (error) {
    console.error("Error Inserting Past medical history:", error);
  }

    return { success: true, message: "Insert successfully" };
  }


  return {
    PastMedicalHistoryAdd

  };
}

function updatePastMedicalHistoryRepository(fastify) {
  async function PastMedicalHistoryUpdate({ logTrace, body, params }) {
    const knex = this;

    var patient_id = params.patient_id;

    const health_record_details = body.health_record_details;

    if(health_record_details.filename != ''){
    
      const img = UploadImageService(health_record_details, fastify);
      var imgurl = img.image_url;
    }else{
        var imgurl = null;
    }


    // const processedDiseases = [];

    const medicine = JSON.parse(body.past_medicine.value);
    let medicineResult = medicine.join(",");

    const surgery = JSON.parse(body.past_surgeries.value);
    let surgeryResult = surgery.join(",");

    const allergy = JSON.parse(body.history_of_allergy.value);
    let allergyResult = allergy.join(",");

    const vacination = JSON.parse(body.previous_vacination.value);
    let vacinationResult = vacination.join(",");

    var past_illness = JSON.parse(body.past_illness.value);



     const past_illnessDb = await knex.raw(`select past_illness from e_past_medical_history where patient_id = ${patient_id}`)
     .then(response => response.map(illness => illness.past_illness));

    //  console.log(past_illnessDb,"pastillness");



     const difference = past_illness.filter(item => !past_illnessDb.includes(item));



     if (difference.length === 0) {

      const query = await knex(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.PATIENT_ID}`, patient_id)
        .del();

      result = past_illness.join(', ');

      try {



        const query = await knex(`${PASTMEDICALHISTORY.NAME}`).insert({


          [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: body.doctor_id.value,
          [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: body.patient_id.value,
          [PASTMEDICALHISTORY.COLUMNS.HEALTH_RECORD_DETAILS]: imgurl,
          [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: result,
          [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: medicineResult,
          [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERIES]: surgeryResult,
          [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: allergyResult,
          [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: vacinationResult,
          [PASTMEDICALHISTORY.COLUMNS.PREGNANCY]: body.pregnancy.value,
          [PASTMEDICALHISTORY.COLUMNS.IS_TRIMESTER]: body.is_trimester.value,
          [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: body.is_lactation.value,
          [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: body.created_by.value,
          [PASTMEDICALHISTORY.COLUMNS.ACTIVE]: body.active.value,

        });

      } catch (error) {
        console.error("Error Inserting Past Medical History:", error);
      }

    }
    else {

      const query = await knex(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.PATIENT_ID}`, patient_id)
      .del();

      result = past_illness.join(', ');

      try {


        const query = await knex(`${PASTMEDICALHISTORY.NAME}`).insert({


          [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: body.doctor_id.value,
          [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: body.patient_id.value,
          [PASTMEDICALHISTORY.COLUMNS.HEALTH_RECORD_DETAILS]: imgurl,
          [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: result,
          [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: medicineResult,
          [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERIES]: surgeryResult,
          [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: allergyResult,
          [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: vacinationResult,
          [PASTMEDICALHISTORY.COLUMNS.PREGNANCY]: body.pregnancy.value,
          [PASTMEDICALHISTORY.COLUMNS.IS_TRIMESTER]: body.is_trimester.value,
          [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: body.is_lactation.value,
          [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: body.created_by.value,
          [PASTMEDICALHISTORY.COLUMNS.ACTIVE]: body.active.value,

        });


      } catch (error) {
        console.error("Error Inserting Chief Complaints:", error);
      }


      const illnessNames = await knex.raw(`select illness_type_name from illness_types`)
        .then(response => response.map(illness => illness.illness_type_name));


      for (let disease of difference) {
        if (!illnessNames.includes(disease)) {
          try {
            await knex(`${ILLNESSTYPE.NAME}`).insert({

              [ILLNESSTYPE.COLUMNS.ILLNESS_TYPE_NAME]: disease,
              [ILLNESSTYPE.COLUMNS.LOGO_IMAGE]: null,
              [ILLNESSTYPE.COLUMNS.ACTIVE]: body.active.value,
              [ILLNESSTYPE.COLUMNS.CREATED_BY]: body.created_by.value,
              [ILLNESSTYPE.COLUMNS.UPDATED_BY]: body.created_by.value,
              [ILLNESSTYPE.COLUMNS.CREATED_AT]: new Date(),
              [ILLNESSTYPE.COLUMNS.UPDATED_AT]: new Date()

            });
          } catch (error) {
            console.error("Error Inserting Disease:", error);
          }
        }

      }

    }
 

    return { success: true, message: "Update successfully" };
  }

  return {
    PastMedicalHistoryUpdate,
  };
}

function getPastMedicalHistoryRepository(fastify) {

  async function PastMedicalHistoryGetAlls({ logTrace }) {

    const knex = this;
    const query = knex.select('*').from(`${PASTMEDICALHISTORY.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get PastMedicalHistory Details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "PastMedicalHistory info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    PastMedicalHistoryGetAlls
  };

}


function getPastMedicalHistoryRepositoryId(fastify) {

  async function PastMedicalHistoryGetOne({ logTrace, params }) {

    const knex = this;
    var patient_id = params.patient_id;
    
    const query = knex.select('*').from(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.PATIENT_ID}`, patient_id);

    logQuery({
      logger: fastify.log,
      query,
      params,
      context: "Get PastMedicalHistory details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "PastMedicalHistory info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }

  return {
    PastMedicalHistoryGetOne
  };

}

function deletePastMedicalHistoryRepositoryId(fastify) {
  async function PastMedicalHistoryDelete({
    logTrace,
    params
  }) {
    const knex = this;

    var patient_id = params.patient_id;

    const query = await knex(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.PATIENT_ID}`, patient_id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    PastMedicalHistoryDelete
  };
}


module.exports = {
  postPastMedicalHistoryRepositoryBasic,
  updatePastMedicalHistoryRepository,
  getPastMedicalHistoryRepository,
  getPastMedicalHistoryRepositoryId,
  deletePastMedicalHistoryRepositoryId

};
