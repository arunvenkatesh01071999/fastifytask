const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/past-medical-history",
    preHandler: fastify.authenticate,
    // schema: schemas.getPastMedicalHistorySchema.createPastMedicalHistorySchema,
    handler: handlers.getPastMedicalHistoryHandler.createPastMedicalHistoryHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/past-medical-history/:patient_id",
    preHandler: fastify.authenticate,
    // schema: schemas.getPastMedicalHistorySchema.updatePastMedicalHistorySchema,
    handler: handlers.getPastMedicalHistoryHandler.updatePastMedicalHistoryHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/past-medical-history",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPastMedicalHistorySchema.getPastMedicalHistorySchema,
    handler: handlers.getPastMedicalHistoryHandler.getPastMedicalHistoryHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/past-medical-history/:patient_id",
    preHandler: fastify.authenticate,
    // schema: schemas.getPastMedicalHistorySchema.getPastMedicalHistorySchema,
    handler: handlers.getPastMedicalHistoryHandler.getPastMedicalHistoryHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/past-medical-history/:id",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPastMedicalHistorySchema.deletePastMedicalHistorySchema,
    handler: handlers.getPastMedicalHistoryHandler.deletePastMedicalHistoryHandler(fastify)
  });

};
