const getPastMedicalHistoryService = require("../services/getPastMedicalHistoryService");



function createPastMedicalHistoryHandler(fastify) {
  
  const createPastMedicalHistory =
  getPastMedicalHistoryService.createPastMedicalHistoryServiceBasic(fastify);

  return async (request, reply) => {
    const { body, logTrace } = request;
    
    const response = await createPastMedicalHistory({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
  
}

function updatePastMedicalHistoryHandler(fastify) {
  const updatePastMedicalHistory = getPastMedicalHistoryService.updatePastMedicalHistoryServiceBasic(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await updatePastMedicalHistory({
      body,
      params,
      logTrace
      
    });
    return reply.code(200).send(response);
  };
}

function getPastMedicalHistoryHandler(fastify) {

  const getPastMedicalHistory = getPastMedicalHistoryService.getPastMedicalHistoryInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getPastMedicalHistory({
      logTrace
    });
    return reply.code(200).send(response);
  };

}

function getPastMedicalHistoryHandlerId(fastify) {

  const getPastMedicalHistory = getPastMedicalHistoryService.getPastMedicalHistoryInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getPastMedicalHistory({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}

function deletePastMedicalHistoryHandler(fastify) {

  const deletePastMedicalHistory = getPastMedicalHistoryService.deletePastMedicalHistoryServiceId(fastify);
  return async (request, reply) => {
    const {  params, logTrace } = request;
  
    const response = await deletePastMedicalHistory({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}

module.exports = {

  createPastMedicalHistoryHandler,
  updatePastMedicalHistoryHandler,
  getPastMedicalHistoryHandler,
  getPastMedicalHistoryHandlerId,
  deletePastMedicalHistoryHandler
};
