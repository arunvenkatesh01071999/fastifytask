const getClinicalExamHandler = require("./getClinicalExamHandler.js");

module.exports = {
  getClinicalExamHandler
};
