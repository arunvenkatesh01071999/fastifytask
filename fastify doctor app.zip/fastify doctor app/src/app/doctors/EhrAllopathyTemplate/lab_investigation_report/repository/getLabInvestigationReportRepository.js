const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { LABINVESTIGATION } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");

function postLabInvestigationReportRepositoryBasic(fastify) {
  async function getLabInvestigationReportAdd({ logTrace, body }) {
    const knex = this;

    const investigation = body.lab_investigation;
    
    let investigationResult = investigation.join(",");

    const link = body.lab_link;
    
    let linkResult = link.join(",");

    const scan = body.scan_investigation;
    
    let scanResult = scan.join(",");

    const scanCenter = body.scan_center_link;
    
    let scanCenterResult = scanCenter.join(",");


    const query = await knex(`${LABINVESTIGATION.NAME}`).insert({

      [LABINVESTIGATION.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [LABINVESTIGATION.COLUMNS.PATIENT_ID]: body.patient_id,
      [LABINVESTIGATION.COLUMNS.ACTIVE]: body.active,

      [LABINVESTIGATION.COLUMNS.LAB_INVESTIGATION]: investigationResult,
      [LABINVESTIGATION.COLUMNS.LAB_LINK]: linkResult,
      [LABINVESTIGATION.COLUMNS.SCAN_INVESTIGATION]: scanResult,
      [LABINVESTIGATION.COLUMNS.SCAN_CENTER_LINK]: scanCenterResult,
      [LABINVESTIGATION.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    getLabInvestigationReportAdd

  };
}

function updateLabInvestigationReportRepository(fastify) {
  async function getLabInvestigationReportUpdate({ logTrace, body, params }) {
    const knex = this;
    const { patient_id } = params;

    const investigation = body.lab_investigation;
    
    let investigationResult = investigation.join(",");

    const link = body.lab_link;
    
    let linkResult = link.join(",");

    const scan = body.scan_investigation;
    
    let scanResult = scan.join(",");

    const scanCenter = body.scan_center_link;
    
    let scanCenterResult = scanCenter.join(",");


    const query = await knex(`${LABINVESTIGATION.NAME}`)
      .where(`${LABINVESTIGATION.COLUMNS.PATIENT_ID}`, patient_id)
      .update({
        
      [LABINVESTIGATION.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [LABINVESTIGATION.COLUMNS.PATIENT_ID]: body.patient_id,
      [LABINVESTIGATION.COLUMNS.ACTIVE]: body.active,
        [LABINVESTIGATION.COLUMNS.LAB_INVESTIGATION]: investigationResult,
        [LABINVESTIGATION.COLUMNS.LAB_LINK]: linkResult,
        [LABINVESTIGATION.COLUMNS.SCAN_INVESTIGATION]: scanResult,
        [LABINVESTIGATION.COLUMNS.SCAN_CENTER_LINK]: scanCenterResult,
        [LABINVESTIGATION.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    getLabInvestigationReportUpdate
  };
}

function getLabInvestigationReportRepository(fastify) {
  
  async function getLabInvestigationReportGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.select('*').from(`${LABINVESTIGATION.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get lab_investigation_report details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "lab_investigation_report info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getLabInvestigationReportGetAlls
  };

}


function getLabInvestigationReportRepositoryId(fastify) {
  
  async function getLabInvestigationReportGetOne({ logTrace, params }) {
    
    const knex = this;
    const { patient_id } = params;
    const query = knex.select('*').from(`${LABINVESTIGATION.NAME}`).where(`${LABINVESTIGATION.COLUMNS.PATIENT_ID}`, patient_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get lab_investigation_report details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "lab_investigation_report info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getLabInvestigationReportGetOne
  };

}

function deleteLabInvestigationReportRepositoryId(fastify) {
  async function getLabInvestigationReportDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const { patient_id } = params;

    const query = await knex(`${LABINVESTIGATION.NAME}`).where(`${LABINVESTIGATION.COLUMNS.PATIENT_ID}`, patient_id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    getLabInvestigationReportDelete
  };
}


module.exports = {
  postLabInvestigationReportRepositoryBasic,
  updateLabInvestigationReportRepository,
  getLabInvestigationReportRepository,
  getLabInvestigationReportRepositoryId,
  deleteLabInvestigationReportRepositoryId

};
