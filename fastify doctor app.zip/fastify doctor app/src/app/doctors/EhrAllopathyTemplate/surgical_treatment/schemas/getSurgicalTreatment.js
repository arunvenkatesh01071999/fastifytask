const { errorSchemas } = require("../../../../../app/commons/schemas/errorSchemas");


const createSurgicalTreatmentSchema = {
  tags: ["POST Surgical_Treatment"],
  summary: "This API is to Post Surgical_Treatment ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "surgical_treatment",
      "surgical_hospital_link",
      "doctor_id",
      "patient_id",
      "active"
    ],
    additionalProperties: false,
    properties: {
      surgical_treatment: { type: "string" },
      surgical_hospital_link: { type: "string" },
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updateSurgicalTreatmentSchema = {
  tags: ["PUT Surgical_Treatment"],
  summary: "This API is to Update Surgical_Treatment ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      patient_id: { type: 'integer' },
    },
    required: ['patient_id'],
  },
  body: {
    type: "object",
    required: [
      "surgical_treatment",
      "surgical_hospital_link",
      "doctor_id",
      "patient_id",
      "active"
    ],
    additionalProperties: false,
    properties: {
      surgical_treatment: { type: "string" },
      surgical_hospital_link: { type: "string" },
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getSurgicalTreatmentSchema = {

  tags: ["GET Surgical_Treatment"],
  summary: "This API is to get Surgical_Treatment ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          surgical_treatment: { type: "string" },
          surgical_hospital_link: { type: "string" },
          doctor_id: { type: "integer" },
          patient_id: { type: "integer" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const deleteSurgicalTreatmentSchema = {
  tags: ["DELETE Surgical_Treatment"],
  summary: "This API is to delete Surgical_Treatment ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createSurgicalTreatmentSchema,
  updateSurgicalTreatmentSchema,
  getSurgicalTreatmentSchema,
  deleteSurgicalTreatmentSchema
};
