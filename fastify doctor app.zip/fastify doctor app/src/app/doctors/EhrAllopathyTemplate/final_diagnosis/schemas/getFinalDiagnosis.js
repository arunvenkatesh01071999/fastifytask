
const { errorSchemas } = require("../../../../../app/commons/schemas/errorSchemas");

const createFinalDiagnosisSchema = {
  tags: ["POST FinalDiagnosis"],
  summary: "This API is to Post FinalDiagnosis ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "final_diagnosis",
      "doctor_id",
      "patient_id",
      "active"
    ],
    additionalProperties: false,
    properties: {
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      final_diagnosis: { type: "array",
      
    items:{
      type:"string"
    } },
    active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updateFinalDiagnosisSchema = {
  tags: ["PUT FinalDiagnosis"],
  summary: "This API is to Update FinalDiagnosis ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      patient_id: { type: 'integer' },
    },
    required: ['patient_id'],
  },
  body: {
    type: "object",
    required: [
      "final_diagnosis",
      "doctor_id",
      "patient_id",
      "active"
    ],
    additionalProperties: false,
    properties: {

      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "integer" },
      final_diagnosis: { type: "array",
      items:{
        type:"string"
      } }
      

    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getFinalDiagnosisSchema = {

  tags: ["GET FinalDiagnosis"],
  summary: "This API is to get FinalDiagnosis ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          final_diagnosis: { type: "string" },
          doctor_id: { type: "integer" },
          patient_id: { type: "integer" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const deleteFinalDiagnosisSchema = {
  tags: ["DELETE FinalDiagnosis"],
  summary: "This API is to delete FinalDiagnosis ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createFinalDiagnosisSchema,
  updateFinalDiagnosisSchema,
  getFinalDiagnosisSchema,
  deleteFinalDiagnosisSchema
};
