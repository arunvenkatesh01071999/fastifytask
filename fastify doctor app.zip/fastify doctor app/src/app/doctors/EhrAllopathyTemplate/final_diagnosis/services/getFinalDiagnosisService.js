const getFinalDiagnosisRepository = require("../repository/getFinalDiagnosisRepository");

function createFinalDiagnosisServiceBasic(fastify) {
  const { FinalDiagnosisAdd } = getFinalDiagnosisRepository.postFinalDiagnosisRepositoryBasic(fastify);

  return async ({ body, logTrace}) => {
    const knex = fastify.knexMaster;
    const promise1 = FinalDiagnosisAdd.call(knex, {
      logTrace,
      body
    });

    const [FinalDiagnosisAddData] = await Promise.all([promise1]);

    return FinalDiagnosisAddData;
  };
}

function updateFinalDiagnosisServiceBasic(fastify) {
  const { FinalDiagnosisUpdate } = getFinalDiagnosisRepository.updateFinalDiagnosisRepository(fastify);

  return async ({ body, params, logTrace, }) => {
    const knex = fastify.knexMaster;
    const promise1 = FinalDiagnosisUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedFinalDiagnosisData] = await Promise.all([promise1]);

    return updatedFinalDiagnosisData;
  };
}

function getFinalDiagnosisInfoService(fastify) {
  
  const { FinalDiagnosisGetAlls } = getFinalDiagnosisRepository.getFinalDiagnosisRepository(fastify);
  
  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = FinalDiagnosisGetAlls.call(knex, {
      logTrace
    });
    const [getFinalDiagnosisAlldata] = await Promise.all([promise1]);
    return getFinalDiagnosisAlldata;
  }
}

function getFinalDiagnosisInfoServiceId(fastify) {
  
  const { FinalDiagnosisGetOne } = getFinalDiagnosisRepository.getFinalDiagnosisRepositoryId(fastify);
  
  return async ({ params,logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = FinalDiagnosisGetOne.call(knex, {
      logTrace,
      params
    });
    const [getFinalDiagnosisOnedata] = await Promise.all([promise1]);
    return getFinalDiagnosisOnedata;
  }
}

function deleteFinalDiagnosisServiceId(fastify) {
 
  const { FinalDiagnosisDelete } = getFinalDiagnosisRepository.deleteFinalDiagnosisRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = FinalDiagnosisDelete.call(knex, {
      logTrace,
      params
    });

    const [deleteFinalDiagnosisdata] = await Promise.all([promise1]);

    return deleteFinalDiagnosisdata;
  };
}


module.exports = {

 createFinalDiagnosisServiceBasic,
 updateFinalDiagnosisServiceBasic,
 getFinalDiagnosisInfoService,
 getFinalDiagnosisInfoServiceId,
 deleteFinalDiagnosisServiceId
};
