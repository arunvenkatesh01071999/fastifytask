const doctorLoginService = require("../services/getDoctorlogin");

function doctorLoginHandler(fastify) {
    const doctorLogin = doctorLoginService.doctorLoginService(fastify);
    return async (request, reply) => {
        const { body, logTrace } = request;

        const response = await doctorLogin({ body, logTrace });
        return reply.code(200).send(response);
    };
}

function doctorcheckLoginHandler(fastify) {
    const doctorLogincheck = doctorLoginService.doctorLogincheckService(fastify);
    return async (request, reply) => {
        const { body, logTrace } = request;

        const response = await doctorLogincheck({ body, logTrace });
        return reply.code(200).send(response);
    };
}

module.exports = {
    doctorLoginHandler,
    doctorcheckLoginHandler
};
