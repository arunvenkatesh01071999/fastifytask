const getHandWrittenHandler = require("./getHandWrittenHandler.js");

module.exports = {
  getHandWrittenHandler
};
