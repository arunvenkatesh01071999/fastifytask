const AppBasicInfo = require("../repository/AppoinmentInfoRespo");



function getPostAppoinmentRescheduleService(fastify) {
  const { getappadd } = AppBasicInfo.AppoinmentReschedulePostRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexPatient;
    const promise1 = getappadd.call(knex, {
      logTrace, params,
      body
    });
    const [getappadddata] = await Promise.all([promise1]);
    return getappadddata;
  };
}

function getPostAppoinmentAddFollowService(fastify) {
  const { getappadd } = AppBasicInfo.AppoinmentAddFollowPostRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexPatient;
    const promise1 = getappadd.call(knex, {
      logTrace, params,
      body
    });
    const [getappadddata] = await Promise.all([promise1]);
    return getappadddata;
  };
}

module.exports = {
 
  getPostAppoinmentRescheduleService,
  getPostAppoinmentAddFollowService

};