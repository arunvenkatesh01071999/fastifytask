const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {


  fastify.route({
    method: "POST",
    url: "/reschedule",
    preHandler: fastify.authenticate,
    schema: schemas.getappoinmentBasicInfo.getpatiendappoinment,
    handler: handlers.getAppoinmentBasicInfo.getAppoinmentReschedulepostInfoHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/add-follow-up",
    preHandler: fastify.authenticate,
    schema: schemas.getappoinmentBasicInfo.getAppoinmentFollowUp,
    handler: handlers.getAppoinmentBasicInfo.getAppoinmentAddFollowpostInfoHandler(fastify)
  });

};
