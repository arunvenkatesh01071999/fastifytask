const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { PAITENTBOOKINGINFO } = require("../commons/constants");
const moment = require('moment');
const sms = require("../../../notification/repository/sms");
const nodemailer = require('nodemailer');
const previewEmail = require('preview-email');
const { CustomError } = require("../../../errorHandler");




function AppoinmentReschedulePostRepo(fastify) {
  async function getappadd({ logTrace, body, params }) {
    const knex = this;

    const doctor_id = body.doctor_id;
    const patient_id = body.patient_id;

    const reason = body.reason;
    const appointment_date = body.appointment_date
    const appointment_from_time = body.appointment_from_time
    const appointment_to_time = body.appointment_to_time
    const appointment_status = 4
    const created_by = body.created_by



  const query =  knex.raw(`select * from HealthUno_Patient.dbo.patient_booking where doctor_id = ${doctor_id} and patient_id = ${patient_id}`)

    const response = await query;

    const date = new Date (appointment_date)

    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const dayIndex = date.getDay();
    const dayOfWeek = daysOfWeek[dayIndex];



    const rescheduleObject = {
      doctor_id_db : response[0].doctor_id,
      patient_id_db : response[0].patient_id,
      reason_post : reason,
      appointment_date_post : appointment_date,
      appointment_day_post : dayOfWeek,
      appointment_from_time_post : appointment_from_time,
      appointment_to_time_post : appointment_to_time,
      appointment_status_post : appointment_status,
      appointment_duartion_db : response[0].appointment_duartion,
      clinical_id_db : response[0].clinical_id,
      hospital_id_db : response[0].hospital_id,
      confirmation_status_db : response[0].confirmation_status,
      is_followup_db : response[0].is_followup,
      hospitalcounsul_or_videoconsul_db : response[0].hospitalcounsul_or_videoconsul,
      created_by : created_by

    }


    const query1 = await knex(`${PAITENTBOOKINGINFO.NAME}`).insert({
      [PAITENTBOOKINGINFO.COLUMNS.DOTOR_ID]: rescheduleObject.doctor_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.PATIENT_ID]: rescheduleObject.patient_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DATE]: rescheduleObject.appointment_date_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DAY]: rescheduleObject.appointment_day_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_FROM_TIME]: rescheduleObject.appointment_from_time_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_TO_TIME]: rescheduleObject.appointment_to_time_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_STATUS]: rescheduleObject.appointment_status_post,// "booked," "available," "cancelled," or "attended.","3-completed", 4-rescheduled
      [PAITENTBOOKINGINFO.COLUMNS.REASON]: rescheduleObject.reason_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DURATION]: rescheduleObject.appointment_duartion_db,
      [PAITENTBOOKINGINFO.COLUMNS.CLINICAL_ID]: rescheduleObject.clinical_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.HOSPITAL_ID]: rescheduleObject.hospital_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.CONFIRMATION_STATUS]: rescheduleObject.confirmation_status_db,//1 for confirmed ,0-booked 
      [PAITENTBOOKINGINFO.COLUMNS.IS_FOLLOWUP]: rescheduleObject.is_followup_db,//1 for followup, 0 un followup
      [PAITENTBOOKINGINFO.COLUMNS.HOSPITALCONSUl_OR_VIDEOCONSUL]: rescheduleObject.hospitalcounsul_or_videoconsul_db,
      [PAITENTBOOKINGINFO.COLUMNS.CREATED_AT]: new Date(),
      [PAITENTBOOKINGINFO.COLUMNS.CREATED_BY]: rescheduleObject.created_by

    });

    

    return { success: true, message: "Insert successfully" };
  }

  return {
    getappadd
  };
}

function AppoinmentAddFollowPostRepo(fastify) {
  async function getappadd({ logTrace, body, params }) {
    const knex = this;

    const doctor_id = body.doctor_id;
    const patient_id = body.patient_id;

    

    const reason = body.reason;
    const is_followup = body.is_followup;
    const appointment_date = body.appointment_date
    const appointment_from_time = body.appointment_from_time
    const appointment_to_time = body.appointment_to_time
    const appointment_status = 4
    const created_by = body.created_by



  const query =  knex.raw(`select * from HealthUno_Patient.dbo.patient_booking where doctor_id = ${doctor_id} and patient_id = ${patient_id}`)

    const response = await query;

    console.log(response,"response");

    const date = new Date (appointment_date)

    const daysOfWeek = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];

    const dayIndex = date.getDay();
    const dayOfWeek = daysOfWeek[dayIndex];



    const rescheduleObject = {
      doctor_id_db : doctor_id,
      patient_id_db : patient_id,
      reason_post : reason,
      appointment_date_post : appointment_date,
      appointment_day_post : dayOfWeek,
      appointment_from_time_post : appointment_from_time,
      appointment_to_time_post : appointment_to_time,
      appointment_status_post : appointment_status,
      appointment_duartion_db : response[0].appointment_duartion,
      clinical_id_db : response[0].clinical_id,
      hospital_id_db : response[0].hospital_id,
      confirmation_status_db : response[0].confirmation_status,
      is_followup_db : is_followup,
      hospitalcounsul_or_videoconsul_db : response[0].hospitalcounsul_or_videoconsul,
      created_by : created_by

    }


    const query1 = await knex(`${PAITENTBOOKINGINFO.NAME}`).insert({
      [PAITENTBOOKINGINFO.COLUMNS.DOTOR_ID]: rescheduleObject.doctor_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.PATIENT_ID]: rescheduleObject.patient_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DATE]: rescheduleObject.appointment_date_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DAY]: rescheduleObject.appointment_day_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_FROM_TIME]: rescheduleObject.appointment_from_time_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_TO_TIME]: rescheduleObject.appointment_to_time_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_STATUS]: rescheduleObject.appointment_status_post,// "booked," "available," "cancelled," or "attended.","3-completed", 4-rescheduled
      [PAITENTBOOKINGINFO.COLUMNS.REASON]: rescheduleObject.reason_post,
      [PAITENTBOOKINGINFO.COLUMNS.APPOINMENT_DURATION]: rescheduleObject.appointment_duartion_db,
      [PAITENTBOOKINGINFO.COLUMNS.CLINICAL_ID]: rescheduleObject.clinical_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.HOSPITAL_ID]: rescheduleObject.hospital_id_db,
      [PAITENTBOOKINGINFO.COLUMNS.CONFIRMATION_STATUS]: rescheduleObject.confirmation_status_db,//1 for confirmed ,0-booked 
      [PAITENTBOOKINGINFO.COLUMNS.IS_FOLLOWUP]: rescheduleObject.is_followup_db,//1 for followup, 0 un followup
      [PAITENTBOOKINGINFO.COLUMNS.HOSPITALCONSUl_OR_VIDEOCONSUL]: rescheduleObject.hospitalcounsul_or_videoconsul_db,
      [PAITENTBOOKINGINFO.COLUMNS.CREATED_AT]: new Date(),
      [PAITENTBOOKINGINFO.COLUMNS.CREATED_BY]: rescheduleObject.created_by

    });

    

    return { success: true, message: "Insert successfully" };
  }

  return {
    getappadd
  };
}

module.exports = {
 
  AppoinmentReschedulePostRepo,
  AppoinmentAddFollowPostRepo
};
