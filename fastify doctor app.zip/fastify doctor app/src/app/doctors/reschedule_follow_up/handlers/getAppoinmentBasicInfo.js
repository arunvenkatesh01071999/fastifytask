const getappInfos = require("../services/getAppoinmentInfoservices");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream");
const { log } = require("console");
const pump = util.promisify(pipeline);



function getAppoinmentReschedulepostInfoHandler(fastify) {
  const getAppoinmentInfo =
  getappInfos.getPostAppoinmentRescheduleService(fastify);

    return async (request, reply) => {
  
      const { body, params, logTrace } = request;
      const { userDetails } = request;
      const response = await getAppoinmentInfo({
        body,
        params,
        logTrace,
        userDetails
      });
      return reply.code(200).send(response);
    };
}

function getAppoinmentAddFollowpostInfoHandler(fastify) {
  const getAppoinmentInfo =
  getappInfos.getPostAppoinmentAddFollowService(fastify);

    return async (request, reply) => {
  
      const { body, params, logTrace } = request;
      const { userDetails } = request;
      const response = await getAppoinmentInfo({
        body,
        params,
        logTrace,
        userDetails
      });
      return reply.code(200).send(response);
    };
}

module.exports = {
 
  getAppoinmentReschedulepostInfoHandler,
  getAppoinmentAddFollowpostInfoHandler
  

};
