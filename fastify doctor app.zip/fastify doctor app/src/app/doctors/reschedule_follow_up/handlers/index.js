const getAppoinmentBasicInfo = require("./getAppoinmentBasicInfo");

module.exports = {
  getAppoinmentBasicInfo
};
