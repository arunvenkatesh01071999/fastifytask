const { errorSchemas } = require("../../../commons/schemas/errorSchemas");


const getpatiendappoinment = {
  tags: ["POST Service INFO"],
  summary: "This API is to Post Reschedule ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      'doctor_id',
      'patient_id',
      'appointment_date',
      'appointment_from_time',
      'appointment_to_time',
      'appointment_status',
      'reason',
      'created_by'
    ],
    // additionalProperties: false,
    // properties: {
    //   doctor_id: { type: 'integer' },
    //   patient_id: { type: 'integer' },
    //   appointment_date: { type: 'string' },
    //   appointment_from_time: { type: 'string'},
    //   appointment_to_time: { type: 'string'},
    //   appointment_status: { type: 'integer' },
    //   reason: { type: 'string' },
    //   appointment_duartion: { type: 'string' },
    //   clinical_id: { type: 'integer' },
    //   hospitalcounsul_or_videoconsul: { type: 'integer' },
    //   hospital_id: { type: 'integer' },
    //   confirmation_status: { type: 'integer' },
    //   is_followup: { type: 'integer' },
    //   created_by: { type: 'integer' },
    // },
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getAppoinmentFollowUp = {
  tags: ["POST Service INFO"],
  summary: "This API is to Post Reschedule ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      'doctor_id',
      'patient_id',
      'appointment_date',
      'appointment_from_time',
      'appointment_to_time',
      'is_followup',
      'reason',
      'created_by'
    ],
    // additionalProperties: false,
    // properties: {
    //   doctor_id: { type: 'integer' },
    //   patient_id: { type: 'integer' },
    //   appointment_date: { type: 'string' },
    //   appointment_from_time: { type: 'string'},
    //   appointment_to_time: { type: 'string'},
    //   appointment_status: { type: 'integer' },
    //   reason: { type: 'string' },
    //   appointment_duartion: { type: 'string' },
    //   clinical_id: { type: 'integer' },
    //   hospitalcounsul_or_videoconsul: { type: 'integer' },
    //   hospital_id: { type: 'integer' },
    //   confirmation_status: { type: 'integer' },
    //   is_followup: { type: 'integer' },
    //   created_by: { type: 'integer' },
    // },
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {
  
  getpatiendappoinment,
  getAppoinmentFollowUp
};
