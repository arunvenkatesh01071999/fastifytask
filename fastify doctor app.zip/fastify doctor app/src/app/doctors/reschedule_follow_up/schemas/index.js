const getappoinmentBasicInfo = require("./getappoinmentBasicInfo");

module.exports = {
  getappoinmentBasicInfo
};
