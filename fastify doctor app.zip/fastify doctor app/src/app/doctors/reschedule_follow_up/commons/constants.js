const PAITENTBOOKINGINFO = {
  NAME: "patient_booking",
  COLUMNS: {
    ID: "id",
    DOTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    APPOINMENT_DATE: "appointment_date",
    APPOINMENT_DAY: "appointment_day",
    APPOINMENT_FROM_TIME: "appointment_from_time",
    APPOINMENT_TO_TIME: "appointment_to_time",
    APPOINMENT_STATUS: "appointment_status",
    REASON: "reason",
    HOSPITALCONSUl_OR_VIDEOCONSUL: "hospitalcounsul_or_videoconsul",
    APPOINMENT_DURATION: "appointment_duartion",
    CLINICAL_ID: "clinical_id",
    HOSPITAL_ID: "hospital_id",
    CONFIRMATION_STATUS: "confirmation_status",
    IS_FOLLOWUP: "is_followup",
    REASON: "reason",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }

};

module.exports = {
  PAITENTBOOKINGINFO
};

