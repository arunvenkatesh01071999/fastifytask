const CONSULTFEETYPE = {
  NAME: "consult_fees_type",
  COLUMNS: {
    ID: "id",
    FEES_TYPE_NAME: "fees_type_name",
    PERCENTAGE: "percentage",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  CONSULTFEETYPE
};
