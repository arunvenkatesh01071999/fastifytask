const getConsultFeeTypeService = require("../services/getConsultFeeTypeService");



function createConsultFeeTypeHandler(fastify) {
  
  const createConsultFeeType =
  getConsultFeeTypeService.createConsultFeeTypeServiceBasic(fastify);

  return async (request, reply) => {
    const { body, logTrace } = request;
    
    const response = await createConsultFeeType({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
  
}

function updateConsultFeeTypeHandler(fastify) {
  const updateConsultFeeType = getConsultFeeTypeService.updateConsultFeeTypeServiceBasic(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await updateConsultFeeType({
      body,
      params,
      logTrace
      
    });
    return reply.code(200).send(response);
  };
}

function getConsultFeeTypeHandler(fastify) {

  const getConsultFeeType = getConsultFeeTypeService.getConsultFeeTypeInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getConsultFeeType({
      logTrace
    });
    return reply.code(200).send(response);
  };

}

function getConsultFeeTypeHandlerId(fastify) {

  const getConsultFeeType = getConsultFeeTypeService.getConsultFeeTypeInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getConsultFeeType({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}

function deleteConsultFeeTypeHandler(fastify) {

  const deleteConsultFeeType = getConsultFeeTypeService.deleteConsultFeeTypeServiceId(fastify);
  return async (request, reply) => {
    const {  params, logTrace } = request;
  
    const response = await deleteConsultFeeType({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}

module.exports = {

  createConsultFeeTypeHandler,
  updateConsultFeeTypeHandler,
  getConsultFeeTypeHandler,
  getConsultFeeTypeHandlerId,
  deleteConsultFeeTypeHandler
};
