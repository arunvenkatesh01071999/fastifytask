const getConsultFeeTypeHandler = require("./getConsultFeeTypeHandler.js");

module.exports = {
  getConsultFeeTypeHandler
};
