const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/consult-fee-type",
    schema: schemas.getConsultFeeTypeSchema.createConsultFeeTypeSchema,
    handler: handlers.getConsultFeeTypeHandler.createConsultFeeTypeHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/consult-fee-type/:id",
    schema: schemas.getConsultFeeTypeSchema.updateConsultFeeTypeSchema,
    handler: handlers.getConsultFeeTypeHandler.updateConsultFeeTypeHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fee-type",
    // schema: schemas.getConsultFeeTypeSchema.getConsultFeeTypeSchema,
    handler: handlers.getConsultFeeTypeHandler.getConsultFeeTypeHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fee-type/:id",
   schema: schemas.getConsultFeeTypeSchema.getConsultFeeTypeSchema,
    handler: handlers.getConsultFeeTypeHandler.getConsultFeeTypeHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/consult-fee-type/:id",
   schema: schemas.getConsultFeeTypeSchema.deleteConsultFeeTypeSchema,
    handler: handlers.getConsultFeeTypeHandler.deleteConsultFeeTypeHandler(fastify)
  });

};
