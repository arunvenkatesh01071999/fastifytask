const getConsultFeeTypeRepository = require("../repository/getConsultFeeTypeRepository");

function createConsultFeeTypeServiceBasic(fastify) {
  const { ConsultFeeTypeAdd } = getConsultFeeTypeRepository.postConsultFeeTypeRepositoryBasic(fastify);

  return async ({ body, logTrace}) => {
    const knex = fastify.knexMaster;
    const promise1 = ConsultFeeTypeAdd.call(knex, {
      logTrace,
      body
    });

    const [ConsultFeeTypeAddData] = await Promise.all([promise1]);

    return ConsultFeeTypeAddData;
  };
}

function updateConsultFeeTypeServiceBasic(fastify) {
  const { ConsultFeeTypeUpdate } = getConsultFeeTypeRepository.updateConsultFeeTypeRepository(fastify);

  return async ({ body, params, logTrace, }) => {
    const knex = fastify.knexMaster;
    const promise1 = ConsultFeeTypeUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedConsultFeeTypeData] = await Promise.all([promise1]);

    return updatedConsultFeeTypeData;
  };
}

function getConsultFeeTypeInfoService(fastify) {
  
  const { ConsultFeeTypeGetAlls } = getConsultFeeTypeRepository.getConsultFeeTypeRepository(fastify);
  
  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = ConsultFeeTypeGetAlls.call(knex, {
      logTrace
    });
    const [getConsultFeeTypeAlldata] = await Promise.all([promise1]);
    return getConsultFeeTypeAlldata;
  }
}

function getConsultFeeTypeInfoServiceId(fastify) {
  
  const { ConsultFeeTypeGetOne } = getConsultFeeTypeRepository.getConsultFeeTypeRepositoryId(fastify);
  
  return async ({ params,logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = ConsultFeeTypeGetOne.call(knex, {
      logTrace,
      params
    });
    const [getConsultFeeTypeOnedata] = await Promise.all([promise1]);
    return getConsultFeeTypeOnedata;
  }
}

function deleteConsultFeeTypeServiceId(fastify) {
 
  const { ConsultFeeTypeDelete } = getConsultFeeTypeRepository.deleteConsultFeeTypeRepositoryId(fastify);
  return async ({ params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = ConsultFeeTypeDelete.call(knex, {
      logTrace,
      params
    });

    const [deleteConsultFeeTypedata] = await Promise.all([promise1]);

    return deleteConsultFeeTypedata;
  };
}


module.exports = {

 createConsultFeeTypeServiceBasic,
 updateConsultFeeTypeServiceBasic,
 getConsultFeeTypeInfoService,
 getConsultFeeTypeInfoServiceId,
 deleteConsultFeeTypeServiceId
};
