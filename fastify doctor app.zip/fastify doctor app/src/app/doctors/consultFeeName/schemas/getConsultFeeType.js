const { errorSchemas } = require("../../../commons/schemas/errorSchemas");


const createConsultFeeTypeSchema = {
  tags: ["POST ConsultFeeType"],
  summary: "This API is to Post ConsultFeeType ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "fees_type_name",
      "percentage",
      "active"
    ],
    additionalProperties: false,
    properties: {
      fees_type_name: { type: "string" },
      percentage: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updateConsultFeeTypeSchema = {
  tags: ["PUT ConsultFeeType"],
  summary: "This API is to Update ConsultFeeType ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      id: { type: 'integer' },
    },
    required: ['id'],
  },
  body: {
    type: "object",
    required: [
      "fees_type_name",
      "percentage",
      "active"
    ],
    additionalProperties: false,
    properties: {
      fees_type_name: { type: "string" },
      percentage: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getConsultFeeTypeSchema = {

  tags: ["GET ConsultFeeType"],
  summary: "This API is to get ConsultFeeType ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          fees_type_name: { type: "string" },
          percentage: { type: "integer" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const deleteConsultFeeTypeSchema = {
  tags: ["DELETE ConsultFeeType"],
  summary: "This API is to delete ConsultFeeType ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createConsultFeeTypeSchema,
  updateConsultFeeTypeSchema,
  getConsultFeeTypeSchema,
  deleteConsultFeeTypeSchema
};
