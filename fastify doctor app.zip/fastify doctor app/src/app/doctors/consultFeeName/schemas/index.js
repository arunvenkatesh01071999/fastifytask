const getConsultFeeTypeSchema = require("./getConsultFeeType");

module.exports = {
  getConsultFeeTypeSchema
};
