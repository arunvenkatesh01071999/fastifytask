const getHospitalSearchInfo = require('./getHospitalSearch');

module.exports = {
    getHospitalSearchInfo
}