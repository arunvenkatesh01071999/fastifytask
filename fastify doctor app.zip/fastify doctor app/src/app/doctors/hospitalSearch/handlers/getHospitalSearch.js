const getHospitalSearchInfoService = require('../services/getHospitalSearch');

function getHospitalSearchInfoHandler(fastify) {
    const getHospitalSearch = getHospitalSearchInfoService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const response = await getHospitalSearch({
            body,
            params,
            logTrace
        });
        return reply.code(200).send(response)
    };
}

module.exports = getHospitalSearchInfoHandler;