const schemas = require('../schemas');
const handlers = require('../handlers');

module.exports = async fastify => {
    fastify.route({
        method: "POST",
        url: "/hospitalsearch",
        preHandler: fastify.authenticate,
        schema: schemas.getHospitalSearchInfoSchema,
        handler: handlers.getHospitalSearchInfo(fastify)
    });
};