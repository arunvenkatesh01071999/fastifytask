const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getHospitalSearchInfoSchema = {
    tags: ["HOSPITAL BASIC INFO"],
    summary: "This API is to get hospital search info ",
    headers: { $ref: "request-headers#" },
    response: {
        200: {
            type: "object",
            properties: {
                hospital_name: { type: "string" },
                hospital_type_id: { type: "integer" },
                sector_id: { type: "integer" },
                accredation_id: { type: "integer" },
                regNo: { type: "string" },
                about: { type: "string" },
                certicate_path: { type: "string" },
                hospital_image: { type: "string" },
                reason: { type: "string" },
                addCheck: { type: "integer" },
                isApproved: { type: "integer" },
                approve_date: { type: "string" },
                approved_by: { type: "integer" },
                active: { type: "integer" },
                created_at: { type: "string" },
                updated_at: { type: "string" },
                created_by: { type: "integer" },
                updated_by: { type: "integer" },

                illness_info: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            id: { type: "integer" },
                            illness_type_name: { type: "string" },
                            logo_image: { type: "string" },
                            active: { type: "boolean" },
                            created_at: { type: "string" },
                            updated_at: { type: "string" },
                            created_by: { type: "integer" },
                            updated_by: { type: "integer" }
                        }
                    }
                },
                symptoms_info: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            id: { type: "integer" },
                            illness_symptom_name: { type: "string" },
                            logo_image: { type: "string" },
                            active: { type: "boolean" },
                            created_at: { type: "string" },
                            updated_at: { type: "string" },
                            created_by: { type: "integer" },
                            updated_by: { type: "integer" }
                        }
                    }
                },
                speciality_info: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            id: { type: "integer" },
                            speciality_name: { type: "string" },
                            logo_image: { type: "string" },
                            active: { type: "boolean" },
                            created_at: { type: "string" },
                            updated_at: { type: "string" },
                            created_by: { type: "integer" },
                            updated_by: { type: "integer" }
                        }
                    }
                },
            }
        },
        ...errorSchemas
    }
};

module.exports = getHospitalSearchInfoSchema;