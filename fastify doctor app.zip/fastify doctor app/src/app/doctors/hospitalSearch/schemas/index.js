const getHospitalSearchInfoSchema = require('./getHospitalSearch');

module.exports = {
    getHospitalSearchInfoSchema
}