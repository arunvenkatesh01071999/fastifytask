const getTransformSearchInfo = ({
    hospitalInfo,
    illnessInfoList,
    illnessSymptomsList,
    specialityList
}) => {
    return {
        id: hospitalInfo.id,
        hospital_name: hospitalInfo.hospital_name,
        hospital_type_id: hospitalInfo.hospital_type_id,
        sector_id: hospitalInfo.sector_id,
        accredation_id: hospitalInfo.accredation_id,
        regNo: hospitalInfo.regNo,
        about: hospitalInfo.about,
        certicate_path: hospitalInfo.certicate_path,
        hospital_image: hospitalInfo.hospital_image,
        reason: hospitalInfo.reason,
        addCheck: hospitalInfo.addCheck,
        isApproved: hospitalInfo.isApproved,
        approve_date: hospitalInfo.approve_date,
        approved_by: hospitalInfo.approved_by,
        active: hospitalInfo.active,
        created_at: hospitalInfo.created_at,
        updated_at: hospitalInfo.updated_at,
        created_by: hospitalInfo.created_by,
        updated_by: hospitalInfo.updated_by,
        illness_type: illnessInfoList,
        illness_symptoms: illnessSymptomsList,
        speciality: specialityList
    }
}

module.exports = { getTransformSearchInfo };