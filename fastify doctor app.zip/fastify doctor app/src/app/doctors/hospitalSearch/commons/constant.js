const HOSPITALBASICINFO = {
    NAME: "h_hospital_basic_info",
    COLUMNS: {
        ID: 'id',
        HOSPITAL_NAME: "hospital_name",
        HOSPITAL_TYPE_ID: "hospital_type_id",
        SECTOR_ID: "sector_id",
        ACCREDATION_ID: "accredation_id",
        REGNO: "regNo",
        ABOUT: "about",
        CERTICATE_PATH: "certicate_path",
        HOSPITAL_IMAGE: "hospital_image",
        ISAPPROVED: "isApproved",
        APPROVE_DATE: "approve_date",
        APPROVED_BY: "approved_by",
        ADDCHECK: "addCheck",
        REASON: "reason",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const ILLNESSINFO = {
    NAME: "illness_types",
    COLUMNS: {
        ID: "id",
        ILLNESS_TYPE_NAME: "illness_type_name",
        LOGO_IMAGE: "logo_image",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const ILLNESSSYMPTOMSMASTER = {
    NAME: "illness_symptoms_master",
    COLUMNS: {
        ID: "id",
        ILLNESS_SYMPTOM_NAME: "illness_symptom_name",
        LOGO_IMAGE: "logo_image",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const SPECIALITY = {
    NAME: "specialities",
    COLUMNS: {
        ID: "id",
        SPECIALITY_NAME: "speciality_name",
        LOGO_IMAGE: "logo_image",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

module.exports = {
    HOSPITALBASICINFO,
    ILLNESSINFO,
    ILLNESSSYMPTOMSMASTER,
    SPECIALITY
}