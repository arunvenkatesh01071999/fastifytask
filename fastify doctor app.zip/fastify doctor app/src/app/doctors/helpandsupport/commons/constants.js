const HelpINFO = {
  NAME: "FAQ_doctors",
  COLUMNS: {
    ID: "id",
    QUESTION: "question",
    ANSWER: "Answer",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }


};

const CompanyINFO = {
  NAME: "company_info",
  COLUMNS: {
    ID: "id",
    ADDRESS: "address",
    MOBILE: "mobile",
    EMAIL: "email",
    GST: "gst",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }


};
module.exports = {
  HelpINFO,
  CompanyINFO
};

