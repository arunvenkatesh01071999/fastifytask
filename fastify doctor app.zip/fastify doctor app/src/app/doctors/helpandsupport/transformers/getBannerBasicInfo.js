const getBannerBasicInfodata = ({ getBannerBasicInfodata }) => {
  return {
    id: getBannerBasicInfodata.id,
    doctor_name_id: getBannerBasicInfodata.doctor_name_id,
    //   gender_id: doctorInfo.gender_id,
    //   gender_name: doctorInfo.gender_name,
    //   speciality_id: doctorInfo.speciality_id,
    //   speciality_name: doctorInfo.speciality_name,
    //   email: doctorInfo.email,
    //   phone_no: doctorInfo.phone_no,
    //   dob: doctorInfo.dob,
    //   age: doctorInfo.age,
    //   about: doctorInfo.about,
    //   image_path: doctorInfo.image_path,
    //   signature_path: doctorInfo.signature_path,
    //   active: doctorInfo.active,
    created_at: getBannerBasicInfodata.created_at,
    updated_at: getBannerBasicInfodata.updated_at,
    created_by: getBannerBasicInfodata.created_by,
    updated_by: getBannerBasicInfodata.updated_by
  };
};

module.exports = { getBannerBasicInfodata };
