const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const createhelpBasicInfo = {
  tags: ["POST help "],
  summary: "This API is to Post help ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "question",
      "Answer",
      "active",
    ],
    additionalProperties: false,
    properties: {
      question: { type: "string" },
      Answer: { type: "string" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const createCompanyBasicInfo = {
  tags: ["POST Company "],
  summary: "This API is to Post Company ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "address",
      "mobile",
      "email",
      "gst",
      "active"
    ],
    additionalProperties: false,
    properties: {
      address: { type: "string" },
      mobile: { type: "string" },
      email: { type: "string" },
      gst: { type: "integer" },
      active: { type: "integer" },
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const updatehelpSchema = {
  tags: ["PUT help"],
  summary: "This API is to Update help ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      id: { type: 'integer' },
    },
    required: ['id'],
  },
  body: {
    type: "object",
    required: [
      "question",
      "Answer",
      "active",
    ],
    additionalProperties: false,
    properties: {
      question: { type: "string" },
      Answer: { type: "string" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updatecompanySchema = {
  tags: ["PUT help"],
  summary: "This API is to Update help ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      id: { type: 'integer' },
    },
    required: ['id'],
  },
  body: {
    type: "object",
    required: [
      "address",
      "mobile",
      "email",
      "gst",
      "active"
    ],
    additionalProperties: false,
    properties: {
      address: { type: "string" },
      mobile: { type: "string" },
      email: { type: "string" },
      gst: { type: "integer" },
      active: { type: "integer" },
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};
// const getservicedeleteBasicInfoSchema = {
//   tags: ["DELETE Service INFO"],
//   summary: "This API is to delete Service basic info ",
//   headers: { $ref: "request-headers#" },
//   response: {
//     200: {
//       type: "object",
//       properties: {
//         success: { type: "boolean" },
//         message: { type: "string" }
//       }
//     },
//     ...errorSchemas
//   }
// };

module.exports = {

  createhelpBasicInfo,
  createCompanyBasicInfo,
  updatehelpSchema,
  updatecompanySchema
  // getservicedeleteBasicInfoSchema
};
