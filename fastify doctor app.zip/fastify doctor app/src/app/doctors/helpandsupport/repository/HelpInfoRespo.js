const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { HelpINFO } = require("../commons/constants");
const { CompanyINFO } = require("../commons/constants");

const sms  = require("../../../notification/repository/sms");
const nodemailer = require('nodemailer');
const previewEmail = require('preview-email');

const { CustomError } = require("../../../errorHandler");

function HelpAllRepo(fastify) {
  async function gethelpall({ logTrace }) {
    const knex = this;
    const query = knex.select(`*`).from(`${HelpINFO.NAME}`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Help details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Help info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    gethelpall
  };
}


function CompanyAllRepo(fastify) {
  async function getcompanyall({ logTrace }) {
    const knex = this;
    const query = knex.select(`*`).from(`${CompanyINFO.NAME}`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Company details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Help Company not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getcompanyall
  };
}




function HelppostRepo(fastify) {
  async function gethelpall({ logTrace ,body}) {
    const knex = this;
    
    const query = await knex(`${HelpINFO.NAME}`).insert({
      [HelpINFO.COLUMNS.QUESTION]: body.question,
      [HelpINFO.COLUMNS.ANSWER]: body.Answer,
      [HelpINFO.COLUMNS.ACTIVE]: body.active,
      [HelpINFO.COLUMNS.CREATED_BY]: body.created_by,
    });



    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get Help details",
    //   logTrace
    // });

    const response = await query;
    return { success: true, message: "Insert successfully" };
    // if (!response.length) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "Help info not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }
    // return response;
  }

  return {
    gethelpall
  };
}


function CompanyAllpostRepo(fastify) {
  async function getcompanyall({ logTrace,body }) {
    const knex = this;
    const query = await knex(`${CompanyINFO.NAME}`).insert({
      [CompanyINFO.COLUMNS.ADDRESS]: body.address,
      [CompanyINFO.COLUMNS.MOBILE]: body.mobile,
      [CompanyINFO.COLUMNS.EMAIL]: body.email,
      [CompanyINFO.COLUMNS.GST]: body.gst,
      [CompanyINFO.COLUMNS.ACTIVE]: body.active,
      [CompanyINFO.COLUMNS.CREATED_BY]: body.created_by,
    });


    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get Company details",
    //   logTrace
    // });

    const response = await query;


    // if (!response.length) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "Help Company not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }


    return { success: true, message: "Insert successfully" };
  }

  return {
    getcompanyall
  };
}


function HelpputRepo(fastify) {
  async function gethelpall({ logTrace ,params,body}) {
    const knex = this;
    const { id } = params;

    const query = await knex(`${HelpINFO.NAME}`)
    .where(`${HelpINFO.COLUMNS.ID}`, id)
    .update({
      [HelpINFO.COLUMNS.QUESTION]: body.question,
      [HelpINFO.COLUMNS.ANSWER]: body.Answer,
      [HelpINFO.COLUMNS.ACTIVE]: body.active,
      [HelpINFO.COLUMNS.CREATED_BY]: body.created_by,
    });



    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get Help details",
    //   logTrace
    // });

    const response = await query;
    return { success: true, message: "Updated successfully" };
    // if (!response.length) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "Help info not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }
    // return response;
  }

  return {
    gethelpall
  };
}

function CompanyAllputRepo(fastify) {
  async function getcompanyall({ logTrace,body ,params}) {
    const knex = this;
    const { id } = params;
    const query = await knex(`${CompanyINFO.NAME}`)
    .where(`${CompanyINFO.COLUMNS.ID}`, id)
    .update({
      [CompanyINFO.COLUMNS.ADDRESS]: body.address,
      [CompanyINFO.COLUMNS.MOBILE]: body.mobile,
      [CompanyINFO.COLUMNS.EMAIL]: body.email,
      [CompanyINFO.COLUMNS.GST]: body.gst,
      [CompanyINFO.COLUMNS.ACTIVE]: body.active,
      [CompanyINFO.COLUMNS.CREATED_BY]: body.created_by,
    });


    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get Company details",
    //   logTrace
    // });

    const response = await query;


    // if (!response.length) {
    //   throw CustomError.create({
    //     httpCode: StatusCodes.NOT_FOUND,
    //     message: "Help Company not found",
    //     property: "",
    //     code: "NOT_FOUND"
    //   });
    // }


    return { success: true, message: "Updated successfully" };
  }

  return {
    getcompanyall
  };
}

module.exports = {
  HelpAllRepo,
  CompanyAllRepo,
  HelppostRepo,
  CompanyAllpostRepo,
  HelpputRepo,
  CompanyAllputRepo
};
