const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/doc_edu",
    // schema: schemas.geteduBasicInfo.getEduGetInfoSchema,
    handler: handlers.geteduBasicInfo.geteduInfoHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/doc_edu/:id",
    // schema: schemas.geteduBasicInfo.getEduGetInfoSchema,
    handler: handlers.geteduBasicInfo.geteduInfoByIdHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/doc_edu",
    // schema: schemas.geteduBasicInfo.getEduPostInfoSchema,
    handler: handlers.geteduBasicInfo.getedupostInfoHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/doc_edu/:id",
    // schema: schemas.geteduBasicInfo.getEduPutInfoSchema,
    handler: handlers.geteduBasicInfo.geteduputInfoHandler(fastify)
  });

  // fastify.route({
  //   method: "DELETE",
  //   url: "/doc_edu/delete/:id",
  //   schema: schemas.geteduBasicInfo.getservicedeleteBasicInfoSchema,
  //   handler: handlers.geteduBasicInfo.getedudeleteInfoHandler(fastify)
  // });

  fastify.route({
    method: "POST",
    url: "/doc_edu/generateotp",
    // schema: schemas.geteduBasicInfo.getservicedeleteBasicInfoSchema,
    handler: handlers.geteduBasicInfo.getGenerateotp(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/doc_edu/checkotp",
    // schema: schemas.geteduBasicInfo.getservicedeleteBasicInfoSchema,
    handler: handlers.geteduBasicInfo.checkotp(fastify)
  });

};
