const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getEduGetInfoSchema = {
  tags: ["GET Service INFO"],
  summary: "This API is to get Education info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          qualification_name_id: { type: 'string' },
          qua_certificate_path: { type: 'string' },
          doctor_name_id: { type: 'string' },
          created_by: { type: 'string' },
          experience: { type: 'string' },
          speaclity_id: { type: 'string' },
          specialized_file: { type: 'string' },
          department_id: { type: 'string' },
          council_id: { type: 'string' },
          registration_no: { type: 'string' },
          certificate_path: { type: 'string' },
          reg_date: { type: 'string' },
          renewal_date: { type: 'string' },
          active: { type: 'integer' }
        }
      }
    },
    ...errorSchemas
  }
};

const getEduPostInfoSchema = {
  tags: ["POST Service INFO"],
  summary: "This API is to Post Education info ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      'qualification_name_id',
      'qua_certificate_path',
      'doctor_name_id',
      'created_by',
      'experience',
      'speaclity_id',
      'specialized_file',
      'department_id',
      'council_id',
      'registration_no',
      'certificate_path',
      'reg_date',
      'renewal_date',
      'active'
    ],
    additionalProperties: false,
    properties: {
      qualification_name_id: { type: 'string' },
      qua_certificate_path: { type: 'string' },
      doctor_name_id: { type: 'string' },
      created_by: { type: 'string' },
      experience: { type: 'string' },
      speaclity_id: { type: 'string' },
      specialized_file: { type: 'string' },
      department_id: { type: 'string' },
      council_id: { type: 'string' },
      registration_no: { type: 'string' },
      certificate_path: { type: 'string' },
      reg_date: { type: 'string' },
      renewal_date: { type: 'string' },
      active: { type: 'integer' }

    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getEduPutInfoSchema = {
  tags: ["PUT Service INFO"],
  summary: "This API is to Put Education info ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "name",
      "email",
      "gender_id",
      "dob",
      "mobile",
      "blood_group_id",
      "is_verified",
      "profile_image",
      "completion_percentage",
      "martial_status_id",
      "logitute",
      "latitdue",
      "active",
      "created_by"
    ],
    additionalProperties: false,
    properties: {
      qualification_name_id: { type: 'string' },
      qua_certificate_path: { type: 'string' },
      doctor_name_id: { type: 'string' },
      created_by: { type: 'string' },
      experience: { type: 'string' },
      speaclity_id: { type: 'string' },
      specialized_file: { type: 'string' },
      department_id: { type: 'string' },
      council_id: { type: 'string' },
      registration_no: { type: 'string' },
      certificate_path: { type: 'string' },
      reg_date: { type: 'string' },
      renewal_date: { type: 'string' },
      active: { type: 'integer' }

    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getservicedeleteBasicInfoSchema = {
  tags: ["DELETE Service INFO"],
  summary: "This API is to delete Education info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {
  getEduGetInfoSchema,
  getEduPostInfoSchema,
  getEduPutInfoSchema,
  getservicedeleteBasicInfoSchema
};
