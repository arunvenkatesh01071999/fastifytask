const geteduBasicInfo = require("./geteduBasicInfo");

module.exports = {
  geteduBasicInfo
};
