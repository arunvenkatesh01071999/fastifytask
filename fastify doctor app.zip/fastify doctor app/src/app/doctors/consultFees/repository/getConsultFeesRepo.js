const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../app/commons/helpers");
const { PAYMENTINFO } = require("../common/constant");
const { CustomError } = require("../../../errorHandler");
const fastify = require("fastify");

function getConsultFeesReposCreate(fastify) {
  async function getConsultAdd({ logTrace, body, params }) {
    const knex = this;

    doctor_id = body.doctor_id;

    video_consulting_fee = body.video_consulting_fee;
    v_display_amt = body.v_display_amt;
    v_platform_charge = body.v_platform_charge;
    v_how_mouch_you_get = body.v_how_mouch_you_get;
    walk_consulting_fee = body.walk_consulting_fee;
    w_display_amt = body.w_display_amt;
    w_platform_charge = body.w_platform_charge;
    w_how_mouch_you_get = body.w_how_mouch_you_get;

    instant_consulting_fee = body.instant_consulting_fee;

    i_display_amt = body.i_display_amt;
    i_platform_charge = body.i_platform_charge;
    i_how_mouch_you_get = body.i_how_mouch_you_get;

    second_opinion_fee = body.second_opinion_fee

    s_display_amt = body.s_display_amt;
    s_platform_charge = body.s_platform_charge;
    s_how_mouch_you_get = body.s_how_mouch_you_get;

    chat_consulting_fee = body.chat_consulting_fee;

    c_display_amt = body.c_display_amt;
    c_platform_charge = body.c_platform_charge;
    c_how_mouch_you_get = body.c_how_mouch_you_get;


    check = body.check;
    active = body.active;


    consultData = {
      doctor_id: doctor_id,

      video_consulting_fee: video_consulting_fee,
      v_display_amt: v_display_amt,
      v_platform_charge: v_platform_charge,
      v_how_mouch_you_get: v_how_mouch_you_get,
      walk_consulting_fee: walk_consulting_fee,
      w_display_amt: w_display_amt,
      w_platform_charge: w_platform_charge,
      w_how_mouch_you_get: w_how_mouch_you_get,
      instant_consulting_fee: instant_consulting_fee,
      i_display_amt: i_display_amt,
      i_platform_charge: i_platform_charge,
      i_how_mouch_you_get: i_how_mouch_you_get,
      second_opinion_fee: second_opinion_fee,
      s_display_amt: s_display_amt,
      s_platform_charge: s_platform_charge,
      s_how_mouch_you_get: s_how_mouch_you_get,
      chat_consulting_fee: chat_consulting_fee,
      c_display_amt: c_display_amt,
      c_platform_charge: c_platform_charge,
      c_how_mouch_you_get: c_how_mouch_you_get,
      check: check,
      active: active

    }



    const query = knex(`${PAYMENTINFO.NAME}`).insert({
      [PAYMENTINFO.COLUMNS.DOCTOR_ID]: consultData.doctor_id,
      [PAYMENTINFO.COLUMNS.VIDEO_CONSULTING_FEE]: consultData.video_consulting_fee,
      [PAYMENTINFO.COLUMNS.V_DISPLAY_AMT]: consultData.v_display_amt,
      [PAYMENTINFO.COLUMNS.V_PLATFORM_CHARGE]: consultData.v_platform_charge,
      [PAYMENTINFO.COLUMNS.V_HOW_MOUCH_TOU_GET]: consultData.v_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.WALK_CONSULTING_FEE]: consultData.walk_consulting_fee,
      [PAYMENTINFO.COLUMNS.W_DISPLAY_AMT]: consultData.w_display_amt,
      [PAYMENTINFO.COLUMNS.W_PLATFORM_CHARGE]: consultData.w_platform_charge,
      [PAYMENTINFO.COLUMNS.W_HOW_MOUCH_TOU_GET]: consultData.w_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.INSTTANT_CONSULTING_FEE]: consultData.instant_consulting_fee,
      [PAYMENTINFO.COLUMNS.I_DISPLAY_AMT]: consultData.i_display_amt,
      [PAYMENTINFO.COLUMNS.I_PLATFORM_CHARGE]: consultData.i_platform_charge,
      [PAYMENTINFO.COLUMNS.I_HOW_MOUCH_TOU_GET]: consultData.i_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.SECOND_OPINION_FEE]: consultData.second_opinion_fee,
      [PAYMENTINFO.COLUMNS.S_DISPLAY_AMT]: consultData.s_display_amt,
      [PAYMENTINFO.COLUMNS.S_PLATFORM_CHARGE]: consultData.s_platform_charge,
      [PAYMENTINFO.COLUMNS.S_HOW_MOUCH_TOU_GET]: consultData.s_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.CHAT_CONSULTING_FEE]: consultData.chat_consulting_fee,
      [PAYMENTINFO.COLUMNS.C_DISPLAY_AMT]: consultData.c_display_amt,
      [PAYMENTINFO.COLUMNS.C_PLATFORM_CHARGE]: consultData.c_platform_charge,
      [PAYMENTINFO.COLUMNS.C_HOW_MOUCH_TOU_GET]: consultData.c_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.CHECK]: consultData.check,
      [PAYMENTINFO.COLUMNS.ACTIVE]: consultData.active,

    });
    const response = await query;

    console.log(response, "d_consulted_fees");
    return { success: true, message: "Insert successfully" };

  }
  return {
    getConsultAdd
  };
}


function getConsultFeesReposGet(fastify) {
  async function getConsultFeesall({ logTrace }) {
    const knex = this;

    const query = knex.select(`*`).from(`${PAYMENTINFO.NAME}`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get consultFee details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "consultFee info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getConsultFeesall
  };
}


function getConsultFeesReposGetId(fastify) {
  async function getConsultFeesById({ logTrace, body, params }) {
    const knex = this;
    doctor_id = params.doctor_id;


    const query = knex.select(`*`).from(`${PAYMENTINFO.NAME}`).where(`${PAYMENTINFO.COLUMNS.DOCTOR_ID}`, doctor_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get consultFee details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "consultFee info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getConsultFeesById

  };
}



function getConsultFeesReposPut(fastify) {
  async function getConsultAdd({ logTrace, body, params }) {
    const knex = this;

    doctor_id = params;

    doctor_id = body.doctor_id;


    video_consulting_fee = body.video_consulting_fee;
    v_display_amt = body.v_display_amt;
    v_platform_charge = body.v_platform_charge;
    v_how_mouch_you_get = body.v_how_mouch_you_get;

    walk_consulting_fee = body.walk_consulting_fee;
    w_display_amt = body.w_display_amt;
    w_platform_charge = body.w_platform_charge;
    w_how_mouch_you_get = body.w_how_mouch_you_get;

    instant_consulting_fee = body.instant_consulting_fee;
    i_display_amt = body.i_display_amt;
    i_platform_charge = body.i_platform_charge;
    i_how_mouch_you_get = body.i_how_mouch_you_get;

    second_opinion_fee = body.second_opinion_fee
    s_display_amt = body.s_display_amt;
    s_platform_charge = body.s_platform_charge;
    s_how_mouch_you_get = body.s_how_mouch_you_get;

    chat_consulting_fee = body.chat_consulting_fee;
    c_display_amt = body.c_display_amt;
    c_platform_charge = body.c_platform_charge;
    c_how_mouch_you_get = body.c_how_mouch_you_get;

    check = body.check;
    active = body.active;









    consultData = {
      doctor_id: doctor_id,
      video_consulting_fee: video_consulting_fee,
      v_display_amt: v_display_amt,
      v_platform_charge: v_platform_charge,
      v_how_mouch_you_get: v_how_mouch_you_get,
      walk_consulting_fee: walk_consulting_fee,
      w_display_amt: w_display_amt,
      w_platform_charge: w_platform_charge,
      w_how_mouch_you_get: w_how_mouch_you_get,
      instant_consulting_fee: instant_consulting_fee,
      i_display_amt: i_display_amt,
      i_platform_charge: i_platform_charge,
      i_how_mouch_you_get: i_how_mouch_you_get,
      second_opinion_fee: second_opinion_fee,
      s_display_amt: s_display_amt,
      s_platform_charge: s_platform_charge,
      s_how_mouch_you_get: s_how_mouch_you_get,
      chat_consulting_fee: chat_consulting_fee,
      c_display_amt: c_display_amt,
      c_platform_charge: c_platform_charge,
      c_how_mouch_you_get: c_how_mouch_you_get,
      check: check,
      active: active

    }


    const query = knex(`${PAYMENTINFO.NAME}`).where(`${PAYMENTINFO.COLUMNS.DOCTOR_ID}`, doctor_id).update({
      [PAYMENTINFO.COLUMNS.DOCTOR_ID]: consultData.doctor_id,
      [PAYMENTINFO.COLUMNS.VIDEO_CONSULTING_FEE]: consultData.video_consulting_fee,
      [PAYMENTINFO.COLUMNS.V_DISPLAY_AMT]: consultData.v_display_amt,
      [PAYMENTINFO.COLUMNS.V_PLATFORM_CHARGE]: consultData.v_platform_charge,
      [PAYMENTINFO.COLUMNS.V_HOW_MOUCH_TOU_GET]: consultData.v_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.WALK_CONSULTING_FEE]: consultData.walk_consulting_fee,
      [PAYMENTINFO.COLUMNS.W_DISPLAY_AMT]: consultData.w_display_amt,
      [PAYMENTINFO.COLUMNS.W_PLATFORM_CHARGE]: consultData.w_platform_charge,
      [PAYMENTINFO.COLUMNS.W_HOW_MOUCH_TOU_GET]: consultData.w_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.INSTTANT_CONSULTING_FEE]: consultData.instant_consulting_fee,
      [PAYMENTINFO.COLUMNS.I_DISPLAY_AMT]: consultData.i_display_amt,
      [PAYMENTINFO.COLUMNS.I_PLATFORM_CHARGE]: consultData.i_platform_charge,
      [PAYMENTINFO.COLUMNS.I_HOW_MOUCH_TOU_GET]: consultData.i_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.SECOND_OPINION_FEE]: consultData.second_opinion_fee,
      [PAYMENTINFO.COLUMNS.S_DISPLAY_AMT]: consultData.s_display_amt,
      [PAYMENTINFO.COLUMNS.S_PLATFORM_CHARGE]: consultData.s_platform_charge,
      [PAYMENTINFO.COLUMNS.S_HOW_MOUCH_TOU_GET]: consultData.s_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.CHAT_CONSULTING_FEE]: consultData.chat_consulting_fee,
      [PAYMENTINFO.COLUMNS.C_DISPLAY_AMT]: consultData.c_display_amt,
      [PAYMENTINFO.COLUMNS.C_PLATFORM_CHARGE]: consultData.c_platform_charge,
      [PAYMENTINFO.COLUMNS.C_HOW_MOUCH_TOU_GET]: consultData.c_how_mouch_you_get,
      [PAYMENTINFO.COLUMNS.CHECK]: consultData.check,
      [PAYMENTINFO.COLUMNS.ACTIVE]: consultData.active,

    });
    const response = await query;


    return { success: true, message: "updated successfully" };

  }
  return {
    getConsultAdd
  };
}

function deleteConsultFeesRepositoryId(fastify) {
  async function ConsultFeesDelete({
    logTrace,
    params
  }) {
    const knex = this;

    id = params.doctor_id

    const query = await knex(`${PAYMENTINFO.NAME}`).where(`${PAYMENTINFO.COLUMNS.DOCTOR_ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    ConsultFeesDelete
  };
}








module.exports = {
  getConsultFeesReposCreate,
  getConsultFeesReposGet,
  getConsultFeesReposGetId,
  getConsultFeesReposPut,
  deleteConsultFeesRepositoryId
}