const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/consult-fees",
    schema: schemas.getConsultFeesSchema.createConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fees",
    schema: schemas.getConsultFeesSchema.getConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesHandlerGet(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/consult-fees/:doctor_id",
    schema: schemas.getConsultFeesSchema.getConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesByIdHandler(fastify)
  });


  fastify.route({
    method: "PUT",
    url: "/consult-fees/:doctor_id",
    schema: schemas.getConsultFeesSchema.updateConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesPutHandler(fastify)
  });



  fastify.route({
    method: "DELETE",
    url: "/consult-fees/:doctor_id",
   schema: schemas.getConsultFeesSchema.deleteConsultFeesSchema,
    handler: handlers.getConsultFeesInfo.getConsultFeesDeleteHandler(fastify)
  });

};
