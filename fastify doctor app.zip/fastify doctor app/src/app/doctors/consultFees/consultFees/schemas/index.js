const getConsultFeesSchema = require("./getConsultFeesSchema");

module.exports = {
    getConsultFeesSchema
};
