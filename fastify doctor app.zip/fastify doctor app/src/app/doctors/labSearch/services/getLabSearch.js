const labSearchInfoRepo = require("../repository/getLabSearch");
const { getTransformSearchInfo } = require("../transformers/getLabSearch");

function getDoctorBasicInfoService(fastify) {
    const {
        getLabSearch,
        getIllnessInfo,
        getIllnessSymptomsInfo,
        getSpecialityInfo
    } = labSearchInfoRepo(fastify);

    return async ({ body, params, logTrace }) => {
        const knex = fastify.knexMaster;
        const search_data = body.search_data;
        const promise1 = getLabSearch.call(knex, {
            search_data,
            logTrace
        });
        const promise2 = getIllnessInfo.call(knex, {
            search_data,
            logTrace
        });
        const promise3 = getIllnessSymptomsInfo.call(knex, {
            search_data,
            logTrace
        });
        const promise4 = getSpecialityInfo.call(knex, {
            search_data,
            logTrace
        });
        const [labInfo, illnessInfoList, illnessSymptomsList, specialityList] =
            await Promise.all([promise1, promise2, promise3, promise4]);
        // return [doctorInfo, illness, symptoms, speciality];

        return ({
            labInfo,
            illnessInfoList,
            illnessSymptomsList,
            specialityList
        });
    };
}
module.exports = getDoctorBasicInfoService;
