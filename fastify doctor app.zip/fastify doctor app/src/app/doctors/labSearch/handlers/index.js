const getLabSearchInfo = require('./getLabSearch');

module.exports = {
    getLabSearchInfo
}