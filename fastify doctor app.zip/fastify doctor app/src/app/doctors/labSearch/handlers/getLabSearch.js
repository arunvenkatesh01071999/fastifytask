const getLabSearchInfoService = require('../services/getLabSearch');

function getLabSearchInfoHandler(fastify) {
    const getLabSearch = getLabSearchInfoService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const response = await getLabSearch({
            body,
            params,
            logTrace
        });
        return reply.code(200).send(response)
    };
}

module.exports = getLabSearchInfoHandler;