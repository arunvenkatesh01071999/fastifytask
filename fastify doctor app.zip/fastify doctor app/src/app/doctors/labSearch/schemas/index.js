const getLabSearchInfoSchema = require('./getLabSearch');

module.exports = {
    getLabSearchInfoSchema
}