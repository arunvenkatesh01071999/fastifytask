const getSlotInfos = require("../services/getSlotInfoservices");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream");
const { log } = require("console");
// const pump = util.promisify(pipeline);


function getSlotInfoHandler(fastify) {
  const getSlotInfo =
  getSlotInfos.getallSlotService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getSlotInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



function getSlotInfoByIdHandler(fastify) {
  const getSlotInfo =
  getSlotInfos.getByIdSlotService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getSlotInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getslotInfoHandler(fastify) {
  const getSlotInfo =
  getSlotInfos.getSlotService(fastify);

    return async (request, reply) => {
    
  
      const { body, params, logTrace } = request;
      const { userDetails } = request;
      const response = await getSlotInfo({
        body,
        params,
        logTrace,
        userDetails
      });
      return reply.code(200).send(response);
    };
}


function getslotputInfoHandler(fastify) {
  const getSlotInfo =
  getSlotInfos.getPutRegService(fastify);

    return async (request, reply) => {
    
  
      const { body, params, logTrace } = request;
      const { userDetails } = request;
      const response = await getSlotInfo({
        body,
        params,
        logTrace,
        userDetails
      });
      return reply.code(200).send(response);
    };
}


function getslotGetReturnInfoHandler(fastify) {
  const getSlotInfo =
    getSlotInfos.getallSlotReturnService(fastify);

  return async (request, reply) => {

    const { body, logTrace } = request;

    const response = await getSlotInfo({
      body,
      logTrace
    });

    return reply.code(200).send(response);
  };

}



// function getRegisterputInfoHandler(fastify) {
//   const getRegisterInfo =
//     getRegInfos.getPutRegService(fastify);

//   return async (request, reply) => {
//     const partes=request.body.profile_image;
//     const originalObject=request.body;

//     const convertedData = {};

//     for (const key in originalObject) {
      
//       if (Object.hasOwnProperty.call(originalObject, key)) {
//         convertedData[key] = originalObject[key].value;
//       }
//     }

//     if(partes.filename==''){
//       convertedData[partes.fieldname] = 'null';
//     }
//     else{
//      await pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
//      convertedData[partes.fieldname] = partes.filename;

//     }

//     const { body, params, logTrace } = request;
//     const { userDetails } = request;
//     const response = await getRegisterInfo({
//       body,
//       params,
//       logTrace,
//       convertedData,
//       userDetails
//     });
//     return reply.code(200).send(response);
//   };
// }

// function getRegisterdeleteInfoHandler(fastify) {
//   const getRegisterInfo =
//     getRegInfos.getDeleteRegService(fastify);

//   return async (request, reply) => {
//     const { body, params, logTrace } = request;
//     const { userDetails } = request;
//     const response = await getRegisterInfo({
//       body,
//       params,
//       logTrace,
//       userDetails
//     });
//     return reply.code(200).send(response);
//   };
// }

// function getGenerateotp(fastify) {
//   const getRegisterInfo =
//     getRegInfos.getGenerateotpService(fastify);

//   return async (request, reply) => {
//     const { body, params, logTrace } = request;
//     const { userDetails } = request;
//     const response = await getRegisterInfo({
//       body,
//       params,
//       // logTrace,
//       userDetails
//     });
//     return reply.code(200).send(response);
//   };
// }

module.exports = {
  getSlotInfoHandler,
  getSlotInfoByIdHandler,
  getslotInfoHandler,
  getslotputInfoHandler,
  getslotGetReturnInfoHandler
  

};
