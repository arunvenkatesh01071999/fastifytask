const getSlotBasicInfo = require("./getSlotBasicInfo");

module.exports = {
  getSlotBasicInfo
};
