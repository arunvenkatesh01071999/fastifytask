const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { DOCTORAVILSLOTINFO } = require("../commons/constants");
const sms = require("../../../notification/repository/sms");
const nodemailer = require('nodemailer');
const previewEmail = require('preview-email');


const { CustomError } = require("../../../errorHandler");

function SlotAllRepo(fastify) {
  async function getslotall({ logTrace }) {
    const knex = this;
    const query = knex.select(`*`).from(`${DOCTORAVILSLOTINFO.NAME}`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Slot details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Slot info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getslotall
  };
}


function SlotGetByIdRepo(fastify) {
  async function getslotById({ logTrace, body, params }) {
    const knex = this;
    var doctor_name_id = params.doctor_name_id;
    const query =  knex.select(`*`).from(`${DOCTORAVILSLOTINFO.NAME}`)
      .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, doctor_name_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Slot details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Slot info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getslotById
  };
}




function SlotaddRepo(fastify) {
  async function getSlotadd({ logTrace, body, params, sl_data }) {
    const knex = this;

    const sl_data2 = {
      created_by: 2,
      updated_by: 2,
    }

    const query = knex(`${DOCTORAVILSLOTINFO.NAME}`).insert({
      [DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID]: sl_data.doctor_name_id,
      [DOCTORAVILSLOTINFO.COLUMNS.DAY]: sl_data.day,
      [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_1]: sl_data.slot_1,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_2]: sl_data.slot_2,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_3]: sl_data.slot_3,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_ACTIVE]: sl_data.slot_active,
      [DOCTORAVILSLOTINFO.COLUMNS.CHECK_WALKING]: sl_data.check_walking,
      [DOCTORAVILSLOTINFO.COLUMNS.DURATION]: sl_data.duration,
      [DOCTORAVILSLOTINFO.COLUMNS.INSTANT_CONSULATION]: sl_data.instant_consulation,
      [DOCTORAVILSLOTINFO.COLUMNS.VIDEO]: sl_data.video,
      [DOCTORAVILSLOTINFO.COLUMNS.WALKIN]: sl_data.walkin,
      [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
      [DOCTORAVILSLOTINFO.COLUMNS.IS_24HRS]: sl_data.is_24hrs,
      [DOCTORAVILSLOTINFO.COLUMNS.CREATED_BY]: sl_data2.created_by,
      [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_BY]: sl_data2.updated_by,
      [DOCTORAVILSLOTINFO.COLUMNS.CREATED_AT]: new Date(),
      [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_AT]: new Date()
    });

    const response = await query;
    return { success: true, message: "Insert successfully" };


  }

  return {
    getSlotadd
  };
}

function SlotputRepo(fastify) {
  async function getslotput({ logTrace, body, params, convertedData, userDetails, sl_data }) {
    const knex = this;
    

    const sl_data2 = {
      created_by: 2,
      updated_by: 2,
    }

    const query = knex(`${DOCTORAVILSLOTINFO.NAME}`).insert({
      [DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID]: sl_data.doctor_name_id,
      [DOCTORAVILSLOTINFO.COLUMNS.DAY]: sl_data.day,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_1]: sl_data.slot_1,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_2]: sl_data.slot_2,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_3]: sl_data.slot_3,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_ACTIVE]: sl_data.slot_active,
      [DOCTORAVILSLOTINFO.COLUMNS.CHECK_WALKING]: sl_data.check_walking,
      [DOCTORAVILSLOTINFO.COLUMNS.DURATION]: sl_data.duration,
      [DOCTORAVILSLOTINFO.COLUMNS.INSTANT_CONSULATION]: sl_data.instant_consulation,
      [DOCTORAVILSLOTINFO.COLUMNS.VIDEO]: sl_data.video,
      [DOCTORAVILSLOTINFO.COLUMNS.WALKIN]: sl_data.walkin,
      [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
      [DOCTORAVILSLOTINFO.COLUMNS.IS_24HRS]: sl_data.is_24hrs,
      [DOCTORAVILSLOTINFO.COLUMNS.CREATED_BY]: sl_data2.created_by,
      [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_BY]: sl_data2.updated_by,
      [DOCTORAVILSLOTINFO.COLUMNS.CREATED_AT]: new Date(),
      [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_AT]: new Date()
    });

    const response = await query;
    return { success: true, message: "Updated successfully" };


  }

  return {
    getslotput
  };
}

function SlotgetReturnRepo(fastify) {
  async function getslotReturn({ logTrace, body }) {
    const knex = this;
    var data = {};
    data = body;
    return data;
  }

  return {
    getslotReturn
  };
}

// function RegDeleteRepo(fastify) {
//   async function getregdelete({ logTrace, body, params, userDetails }) {
//     const knex = this;

//     const { id } = params;

//     const query = await knex(`${REGISTERINFO.NAME}`)
//       .where(`${REGISTERINFO.COLUMNS.ID}`, id)
//       .del();

//     const response = await query;

//     return { success: true, message: "Deleted successfully" };
//   }

//   return {
//     getregdelete
//   };
// }

// function generateotpRepo(fastify) {
//   const { sendSms } = sms(fastify);
//   async function getotp({  body, params, userDetails }) {
//     const knex = this;

//     const phone_number  = body.mobile;
//     const otp = Math.floor(1000 + Math.random() * 9000).toString();
// const  message=otp;

// const promise1 = sendSms.call(knex, {
//   phone_number, message
// });

// const transporter = nodemailer.createTransport({
//   service: 'Gmail',
//   auth: {
//     user: 'Pradhapbothan119@gmail.com',
//     pass: '9524203556'
//   }
// });
// const mailOptions = {
//   from:'Pradhapbothan119@gmail.com',
//   to: 'sivanandhini0307@gmail.com',
//   subject: 'Test Email',
//   text: 'This is a test email sent from Node.js using nodemailer!'
// };
// transporter.sendMail(mailOptions, (error, info) => {
//   if (error) {
//     console.error('Error occurred:', error);
//   } else {
//     console.log('Email sent:', info.response);
//   }
// });

// const transport = nodemailer.createTransport({
//   jsonTransport: true
// });

// // <https://nodemailer.com/message/>
// const message = {
//   from:'Pradhapbothan119@gmail.com',
//   to: 'sivanandhini0307@gmail.com',
//   subject: 'Hello world',
//   html: '<p>Hello world</p>',
//   text: 'Hello world',
//   // attachments: [{ filename: 'hello-world.txt', content: 'Hello world' }]
// };

// note that `attachments` will not be parsed unless you use
// `previewEmail` with the results of `transport.sendMail`
// e.g. `previewEmail(JSON.parse(res.message));` where `res`
// is `const res = await transport.sendMail(message);`
// previewEmail(message).then(console.log).catch(console.error);

// transport.sendMail(message).then(console.log).catch(console.error);



// D:\prathap\fastify\uno-api-serivces\src\app\notification\repository\sms.js
// console.log('mobile', mobile);
// const query = await knex(`${REGISTERINFO.NAME}`)
//   .where(`${REGISTERINFO.COLUMNS.ID}`, id)
//   .del();
// const response = await query;
// return promise1;
// }
// return {
//   getotp
// };
// }

module.exports = {
  SlotAllRepo,
  SlotGetByIdRepo,
  SlotaddRepo,
  SlotputRepo,
  SlotgetReturnRepo
  // RegDeleteRepo,
  // generateotpRepo
};
