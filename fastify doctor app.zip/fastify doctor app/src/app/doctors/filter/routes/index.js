const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/filter",
    // schema: schemas.getFilterSchema.createFilterSchema,
    handler: handlers.getFilterHandler.createFilterHandler(fastify)
  });



};
