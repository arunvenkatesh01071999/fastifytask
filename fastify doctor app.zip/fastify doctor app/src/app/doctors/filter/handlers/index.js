const getFilterHandler = require("./getFilterHandler.js");

module.exports = {
  getFilterHandler
};
