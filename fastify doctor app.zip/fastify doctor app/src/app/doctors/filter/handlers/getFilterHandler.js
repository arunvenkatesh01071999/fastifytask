const getFilterService = require("../services/getFilterService");



function createFilterHandler(fastify) {
  
  const createFilter =
  getFilterService.createFilterServiceBasic(fastify);

  return async (request, reply) => {
    const { body, logTrace } = request;
    
    const response = await createFilter({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
  
}





module.exports = {

  createFilterHandler

};
