// const OTHERTREATMENT = {
//   NAME: "e_other_treatment",
//   COLUMNS: {
//     ID: "id",
//     OTHER_TREATMENT: "other_treatment",
//     DOCTOR_ID: "doctor_id",
//     PATIENT_ID: "patient_id",
//     ACTIVE:"active",
//     CREATED_AT: "created_at",
//     UPDATED_AT: "updated_at",
//     CREATED_BY: "created_by",
//     UPDATED_BY: "updated_by"
//   }
// };
// module.exports = {
//   OTHERTREATMENT
// };
