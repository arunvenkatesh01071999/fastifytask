const getFilterRepository = require("../repository/getFilterRepository");

function createFilterServiceBasic(fastify) {
  const { FilterAdd } = getFilterRepository.postFilterRepositoryBasic(fastify);

  return async ({ body, logTrace}) => {
    const knex = fastify.knexMaster;
    const promise1 = FilterAdd.call(knex, {
      logTrace,
      body
    });

    const [FilterAddData] = await Promise.all([promise1]);

    return FilterAddData;
  };
}




module.exports = {

 createFilterServiceBasic

};
