const { StatusCodes } = require("http-status-codes");
// const { logQuery } = require("../../../../../../src/app/commons/helpers");
// const { Filter } = require("../commons/constants");
// const { CustomError } = require("../../../errorHandler");

function postFilterRepositoryBasic(fastify) {
  async function FilterAdd({ logTrace, body }) {
    const knex = this;


    const users = [
      { specialities: "arun" },
      { specialities: "arunkumar" },
      { specialities: "arunachalam" },
      { specialities: "ravi" }
    ];
    
    const filteredUsers = users.filter(user => user.specialities.startsWith("arun"));
    
    console.log(filteredUsers);


                                        //get all specialities.................................. 
    
    // const users = [
    //   { specialities: "arun" },
    //   { specialities: "arunkumar" },
    //   { specialities: "arunachalam" },
    //   { specialities: "ravi" }
    // ];
    
    // const specialitiesList = users.map(user => user.specialities);
    
    // console.log(specialitiesList);

    //                                                           get experience

//     const users = [
//       { experience: 5 },
//       { experience: 15 },
//       { experience:  25},
//       { experience: 45 }
//     ];


// const zeroToTen = users.filter(user => user.experience >= 0 && user.experience <= 10);
// console.log(zeroToTen); 

//                                                                get consultionFee

//         const users = [
//       { consultionFee: 50 },
//       { consultionFee: 100 },
//       { consultionFee:  200},
//       { consultionFee: 500 }
//     ];

    
// const zeroToTen = users.filter(user => user.consultionFee >= 0 && user.consultionFee <= 100);
// console.log(zeroToTen); 

//                                get distance

    //         const users = [
//       { distance: 50 },
//       { distance: 20 },
//       { distance:  10},
//       { distance: 30 }
//     ];

    
// const zeroToTen = users.filter(user => user.distance >= 0 && user.distance <= 20);
// console.log(zeroToTen); 
 

//                             get  gender


//     const users = [
//       { gender: "male" },
//       { gender: "female" },
//       { gender:  "male"},
//       { gender: "female" }
//     ];

// const zeroToTen = users.filter(user => user.gender.startsWith("m"));
// console.log(zeroToTen); 

//     return { success: true, message: "Insert successfully" };
//   }

// const users = [
//   { language: "tamil" },
//   { language: "english" },
//   { language: "telugu" },
//   { language: "malayalam" }
// ];

// const filterUsersByLanguages = (languages) => {
//   return users.filter(user => languages.includes(user.language));
// }

// const selectedUsers = filterUsersByLanguages(["tamil", "telugu"]);
// console.log(selectedUsers);



  // return { success: true, message: "Insert successfully" };
}

  return {
    FilterAdd

  };
}




module.exports = {
  postFilterRepositoryBasic
  

};
