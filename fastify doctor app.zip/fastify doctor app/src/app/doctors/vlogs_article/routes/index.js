const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/vlogs-article",
    preHandler: fastify.authenticate,
    schema: schemas.vlogArticleSchema.createVlogArticleSchema,
    handler:
      handlers.vlogArticleHandler.createVlogArticleHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/vlogs-article/:doctor_id",
    preHandler: fastify.authenticate,
    schema: schemas.vlogArticleSchema.updateVlogArticleSchema,
    handler: handlers.vlogArticleHandler.updateVlogArticleHandler(fastify)
  });

  fastify.route({
    method: "GET",
    preHandler: fastify.authenticate,
    url: "/vlogs-article",
    schema: schemas.vlogArticleSchema.getVlogArticleSchema,
    handler: handlers.vlogArticleHandler.getVlogArticleHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/vlogs-article/:doctor_id",
    preHandler: fastify.authenticate,
    schema: schemas.vlogArticleSchema.getVlogArticleSchema,
    handler: handlers.vlogArticleHandler.getVlogArticleHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/vlogs-article/:id",
    preHandler: fastify.authenticate,
    schema: schemas.vlogArticleSchema.deleteVlogArticleSchema,
    handler: handlers.vlogArticleHandler.deleteVlogArticleHandler(fastify)
  });

};
