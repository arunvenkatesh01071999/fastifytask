const vlogArticleRepository = require("../repository/vlogArticleRepository");


function createVlogArticleServiceBasic(fastify) {
  const { vlogArticleAdd } = vlogArticleRepository.postVlogArticleRepositoryBasic(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleAdd.call(knex, {
      logTrace,
      body
    });

    const [vlogArticleAddData] = await Promise.all([promise1]);

    return vlogArticleAddData;
  };
}

function updateVlogArticleServiceBasic(fastify) {
  const { vlogArticleUpdate } = vlogArticleRepository.updateVlogArticleRepository(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleUpdate.call(knex, {
      logTrace,
      body,
      params
    });

    const [updatedVlogArticleData] = await Promise.all([promise1]);

    return updatedVlogArticleData;
  };
}

function getVlogArticleInfoService(fastify) {

  const { vlogArticleGetAlls } = vlogArticleRepository.getVlogArticleRepository(fastify);

  return async ({ logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleGetAlls.call(knex, {
      logTrace
    });
    const [getVlogArticleAlldata] = await Promise.all([promise1]);
    return getVlogArticleAlldata;
  }
}

function getVlogArticleInfoServiceId(fastify) {

  const { vlogArticleGetOne } = vlogArticleRepository.getVlogArticleRepositoryId(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleGetOne.call(knex, {
      logTrace,
      params,
      body
    });
    const [getVlogArticleOnedata] = await Promise.all([promise1]);
    return getVlogArticleOnedata;
  }
}

function deleteVlogArticleServiceId(fastify) {

  const { vlogArticleDelete } = vlogArticleRepository.deleteVlogArticleRepositoryId(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = vlogArticleDelete.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });

    const [deleteVlogArticledata] = await Promise.all([promise1]);

    return deleteVlogArticledata;
  };
}


module.exports = {

  createVlogArticleServiceBasic,
  updateVlogArticleServiceBasic,
  getVlogArticleInfoService,
  getVlogArticleInfoServiceId,
  deleteVlogArticleServiceId
};
