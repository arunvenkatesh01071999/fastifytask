const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { VLOGS } = require("../commons/constants");

const { CustomError } = require("../../../errorHandler");

function postVlogArticleRepositoryBasic(fastify) {
  async function vlogArticleAdd({ logTrace, body }) {
    const knex = this;
    const query = await knex(`${VLOGS.NAME}`).insert({
      [VLOGS.COLUMNS.HEADING]: body.heading,
      [VLOGS.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [VLOGS.COLUMNS.LINK]: body.link,
      [VLOGS.COLUMNS.IS_VLOG]: body.is_vlog,
      [VLOGS.COLUMNS.IS_ARTICLE]: body.is_article,
      [VLOGS.COLUMNS.ACTIVE]: body.active,
      [VLOGS.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    vlogArticleAdd

  };
}

function updateVlogArticleRepository(fastify) {
  async function vlogArticleUpdate({ logTrace, body, params }) {
    const knex = this;
    const doctor_id = params.doctor_id;
    const query = await knex(`${VLOGS.NAME}`)
      .where(`${VLOGS.COLUMNS.DOCTOR_ID}`, doctor_id)
      .update({
        [VLOGS.COLUMNS.HEADING]: body.heading,
        [VLOGS.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [VLOGS.COLUMNS.LINK]: body.link,
        [VLOGS.COLUMNS.IS_VLOG]: body.is_vlog,
        [VLOGS.COLUMNS.IS_ARTICLE]: body.is_article,
        [VLOGS.COLUMNS.ACTIVE]: body.active,
        [VLOGS.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    vlogArticleUpdate,
  };
}

function getVlogArticleRepository(fastify) {

  async function vlogArticleGetAlls({ logTrace }) {

    const knex = this;
    const query = knex.select('*').from(`${VLOGS.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get vlogs_articles details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "vlogs_articles info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    vlogArticleGetAlls
  };

}


function getVlogArticleRepositoryId(fastify) {

  async function vlogArticleGetOne({ logTrace, params }) {

    const knex = this;
    const doctor_id = params.doctor_id;
    const query = knex.select('*').from(`${VLOGS.NAME}`)
    .where(`${VLOGS.COLUMNS.DOCTOR_ID}`, doctor_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get vlogs_articles details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Vlogs_Articles Info Not Found",
        property: "",
        code: "ID DOESN'T EXIST"
      });
    }
    return response;
  }

  return {
    vlogArticleGetOne
  };

}

function deleteVlogArticleRepositoryId(fastify) {
  async function vlogArticleDelete({
    logTrace,
    body,
    params,
    userDetails
  }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${VLOGS.NAME}`).where(`${VLOGS.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    vlogArticleDelete
  };
}


module.exports = {
  postVlogArticleRepositoryBasic,
  updateVlogArticleRepository,
  getVlogArticleRepository,
  getVlogArticleRepositoryId,
  deleteVlogArticleRepositoryId

};
