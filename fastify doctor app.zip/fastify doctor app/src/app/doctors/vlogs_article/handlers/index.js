const vlogArticleHandler = require("./vlogArticleHandler.js");

module.exports = {
  vlogArticleHandler
};
