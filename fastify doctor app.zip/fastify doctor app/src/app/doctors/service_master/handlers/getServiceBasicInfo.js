const getServiceBasicInfos = require("../services/getServiceBasicInfo");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream")
const pump = util.promisify(pipeline);

function getServiceBasicInfoHandler(fastify) {
  const getServiceBasicInfo =
    getServiceBasicInfos.getserviceBasicInfoService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getServiceBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}


function getServiceBasicInfoByIdHandler(fastify) {
  const getServiceBasicInfo =
    getServiceBasicInfos.getserviceBasicInfoByIdService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getServiceBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getServicBasicpostInfoHandler(fastify) {
  const getServiceBasicInfo =
    getServiceBasicInfos.getservicepostBasicInfoService(fastify);

  return async (request, reply) => {

    const partes = request.body.service_images;
    const originalObject = request.body;
    console.log('originalObject', originalObject);

    const convertedData = {};

    for (const key in originalObject) {

      if (Object.hasOwnProperty.call(originalObject, key)) {
        convertedData[key] = originalObject[key].value;
      }
    }
    if (partes.filename == '') {
      convertedData[partes.fieldname] = 'null';
    }
    else {
      await pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
      convertedData[partes.fieldname] = partes.filename;

    }

    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getServiceBasicInfo({
      body,
      params,
      logTrace,
      convertedData,
      userDetails

    });
    return reply.code(200).send(response);
  };
}

function getServicBasicputInfoHandler(fastify) {
  const getServiceBasicInfo =
    getServiceBasicInfos.getserviceputBasicInfoService(fastify);

  return async (request, reply) => {
    const partes = request.body.service_images;
    const originalObject = request.body;

    const convertedData = {};

    for (const key in originalObject) {

      if (Object.hasOwnProperty.call(originalObject, key)) {
        convertedData[key] = originalObject[key].value;
      }
    }

    if (partes.filename == '') {
      convertedData[partes.fieldname] = 'null';
    }
    else {
      await pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
      convertedData[partes.fieldname] = partes.filename;

    }

    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getServiceBasicInfo({
      body,
      params,
      logTrace,
      convertedData,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getServicBasicdeleteInfoHandler(fastify) {
  const getServiceBasicInfo =
    getServiceBasicInfos.getservicedeleteBasicInfoService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getServiceBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = {
  getServiceBasicInfoHandler,
  getServiceBasicInfoByIdHandler,
  getServicBasicpostInfoHandler,
  getServicBasicputInfoHandler,
  getServicBasicdeleteInfoHandler
};
