const getServiceBasicInfo = require("./getServiceBasicInfo");

module.exports = {
  getServiceBasicInfo
};
