const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { SERVICEINFO } = require("../commons/constants");

const { CustomError } = require("../../../errorHandler");

function serviceallBasicInfoRepo(fastify) {
  async function getserviceall({ logTrace }) {
    const knex = this;
    const query = knex.select(`*`).from(`${SERVICEINFO.NAME}`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Service details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Service info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getserviceall
  };
}


function serviceallBasicByIdInfoRepo(fastify) {
  async function getserviceById({ logTrace, body, params }) {
    const knex = this;
    const { id } = params;
    const query = knex.select(`*`).from(`${SERVICEINFO.NAME}`).where(`${SERVICEINFO.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Service details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Service info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getserviceById
  };
}




function serviceallBasicInfoRepos(fastify) {
  async function getserviceadd({ logTrace, body,params, convertedData }) {
    const knex = this;
    const query = await knex(`${SERVICEINFO.NAME}`).insert({
      [SERVICEINFO.COLUMNS.SERVICE_NAME]: convertedData.service_name,
      [SERVICEINFO.COLUMNS.SERVICE_DESCRIPTION]: convertedData.service_description,
      [SERVICEINFO.COLUMNS.SERVICE_TITLE]: convertedData.service_title,
      [SERVICEINFO.COLUMNS.SERVICE_IMAGES]: convertedData.service_images,
      [SERVICEINFO.COLUMNS.SERVICE_LINK]: convertedData.service_link,
      [SERVICEINFO.COLUMNS.CREATED_BY]: convertedData.created_by,
      [SERVICEINFO.COLUMNS.ACTIVE]: convertedData.active
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }

  return {
    getserviceadd
  };
}

function serviceputBasicInfoRepos(fastify) {
  async function getserviceput({ logTrace, body, params,convertedData, userDetails }) {
    const knex = this;
    const { id } = params;
    const query = await knex(`${SERVICEINFO.NAME}`)
      .where(`${SERVICEINFO.COLUMNS.ID}`, id)
      .update({
      [SERVICEINFO.COLUMNS.SERVICE_NAME]: convertedData.service_name,
      [SERVICEINFO.COLUMNS.SERVICE_DESCRIPTION]: convertedData.service_description,
      [SERVICEINFO.COLUMNS.SERVICE_TITLE]: convertedData.service_title,
      [SERVICEINFO.COLUMNS.SERVICE_IMAGES]: convertedData.service_images,
      [SERVICEINFO.COLUMNS.SERVICE_LINK]: convertedData.service_link,
      [SERVICEINFO.COLUMNS.UPDATED_BY]: convertedData.created_by,
      [SERVICEINFO.COLUMNS.ACTIVE]: convertedData.active
      });

    const response = await query;

    return { success: true, message: "Updated successfully" };
  }

  return {
    getserviceput
  };
}

function servicedeleteBasicInfoRepos(fastify) {
  async function getservicedelete({ logTrace, body, params, userDetails }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${SERVICEINFO.NAME}`)
      .where(`${SERVICEINFO.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    getservicedelete
  };
}

module.exports = {
  serviceallBasicInfoRepo,
  serviceallBasicByIdInfoRepo,
  serviceallBasicInfoRepos,
  serviceputBasicInfoRepos,
  servicedeleteBasicInfoRepos
};
