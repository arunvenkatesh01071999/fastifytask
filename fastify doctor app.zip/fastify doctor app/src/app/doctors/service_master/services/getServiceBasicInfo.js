const serviceBasicInfo = require("../repository/ServiceBasicInfo");
const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");

function getserviceBasicInfoService(fastify) {
  const { getserviceall } = serviceBasicInfo.serviceallBasicInfoRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getserviceall.call(knex, {
      logTrace
    });

    const [getservicealldata] = await Promise.all([promise1]);

    return getservicealldata;
  };
}

function getserviceBasicInfoByIdService(fastify) {
  const { getserviceById } = serviceBasicInfo.serviceallBasicByIdInfoRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getserviceById.call(knex, {
      logTrace, body, params
    });

    const [getserviceByIddata] = await Promise.all([promise1]);

    return getserviceByIddata;
  };
}

function getservicepostBasicInfoService(fastify) {
  const { getserviceadd } = serviceBasicInfo.serviceallBasicInfoRepos(fastify);

  return async ({ body, params, logTrace, userDetails, convertedData }) => {
    const knex = fastify.knexMaster;
    const promise1 = getserviceadd.call(knex, {
      logTrace,params,convertedData,
      body
    });

    const [getserviceadddata] = await Promise.all([promise1]);

    return getserviceadddata;
  };
}
function getserviceputBasicInfoService(fastify) {
  const { getserviceput } = serviceBasicInfo.serviceputBasicInfoRepos(fastify);

  return async ({ body, params, logTrace, userDetails, convertedData }) => {
    const knex = fastify.knexMaster;
    const promise1 = getserviceput.call(knex, {
      logTrace,
      body,
      params, convertedData,
      userDetails
    });

    const [getserviceputdata] = await Promise.all([promise1]);

    return getserviceputdata;
  };
}

function getservicedeleteBasicInfoService(fastify) {
  const { getservicedelete } =
    serviceBasicInfo.servicedeleteBasicInfoRepos(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getservicedelete.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });

    const [getservicedeletedata] = await Promise.all([promise1]);

    return getservicedeletedata;
  };
}

module.exports = {
  getserviceBasicInfoService,
  getserviceBasicInfoByIdService,
  getservicepostBasicInfoService,
  getserviceputBasicInfoService,
  getservicedeleteBasicInfoService
};
