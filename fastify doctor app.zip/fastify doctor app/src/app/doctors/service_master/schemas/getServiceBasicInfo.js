const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getserviceBasicInfoSchema = {
  tags: ["GET Service INFO"],
  summary: "This API is to get Service basic info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          service_name: { type: "string" },
          service_description: { type: "string" },
          service_title: { type: "string" },
          service_images: { type: "string" },
          service_link: { type: "string" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const getservicepostBasicInfoSchema = {

  tags: ["POST Service INFO"],
  summary: "This API is to Post Service basic info ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "service_name",
      "service_description",
      "service_title",
      "service_link",
      "service_images",
    ],
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getserviceputBasicInfoSchema = {
  tags: ["PUT Service INFO"],
  summary: "This API is to Put Service basic info ",
  headers: { $ref: "request-headers#" },
  params : {
    type: "object",
    properties: {
      id: { type: 'integer' },
    },
    required: ['id'],
  },
  body: {
    type: "object",
    required: [
      "service_name",
      "service_description",
      "service_title",
      "service_link",
      "service_images"
    ],
  },

  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getservicedeleteBasicInfoSchema = {
  tags: ["DELETE Service INFO"],
  summary: "This API is to delete Service basic info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {
  getserviceBasicInfoSchema,
  getservicepostBasicInfoSchema,
  getserviceputBasicInfoSchema,
  getservicedeleteBasicInfoSchema
};
