const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/service",
    schema: schemas.getServiceBasicInfo.getserviceBasicInfoSchema,
    handler: handlers.getServiceBasicInfo.getServiceBasicInfoHandler(fastify)
  });


  fastify.route({
    method: "GET",
    url: "/service/:id",
    schema: schemas.getServiceBasicInfo.getserviceBasicInfoSchema,
    handler: handlers.getServiceBasicInfo.getServiceBasicInfoByIdHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/service",
    schema: schemas.getServiceBasicInfo.getservicepostBasicInfoSchema,
    handler: handlers.getServiceBasicInfo.getServicBasicpostInfoHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/service/:id",
    schema: schemas.getServiceBasicInfo.getserviceputBasicInfoSchema,
    handler: handlers.getServiceBasicInfo.getServicBasicputInfoHandler(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/service/:id",
    schema: schemas.getServiceBasicInfo.getservicedeleteBasicInfoSchema,
    handler: handlers.getServiceBasicInfo.getServicBasicdeleteInfoHandler(fastify)
  });
};
