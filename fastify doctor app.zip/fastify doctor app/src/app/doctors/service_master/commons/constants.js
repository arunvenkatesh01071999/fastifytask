const SERVICEINFO = {
  NAME: "service_master",
  COLUMNS: {
    ID: "id",
    SERVICE_NAME: "service_name",
    SERVICE_DESCRIPTION: "service_description",
    SERVICE_IMAGES: "service_images",
    SERVICE_TITLE: "service_title",
    SERVICE_LINK: "service_link",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  SERVICEINFO
};
