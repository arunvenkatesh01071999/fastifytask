const getDoctorSignatureHandler = require("./getDoctorSignatureHandler.js");

module.exports = {
  getDoctorSignatureHandler
};
