const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
    // fastify.route({
    //     method: "GET",
    //     url: "/ehr-mapping",
    //     preHandler: fastify.authenticate,
    //     schema: schemas.getEhrMappingInfo.getEhrMappingInfoSchema,
    //     handler: handlers.getEhrMapping.getEhrMappingHandler(fastify)
    // });

    fastify.route({
        method: "GET",
        url: "/ehr-mapping/:id",
        preHandler: fastify.authenticate,
        schema: schemas.getEhrMappingInfo.getEhrMappingInfoSchema,
        handler: handlers.getEhrMapping.getEhrMappingHandler(fastify)
    });

    fastify.route({
        method: "POST",
        url: "/ehr-mapping",
        preHandler: fastify.authenticate,
        schema: schemas.getEhrMappingInfo.getEhrMappingPostInfoSchema,
        handler: handlers.getEhrMapping.getEhrMappingPostInfoHandler(fastify)
    });

    fastify.route({
        method: "PUT",
        url: "/ehr-mapping/:id",
        preHandler: fastify.authenticate,
        // schema: schemas.getEhrMappingInfo.getAccountPutInfoSchema,
        handler: handlers.getEhrMapping.getEhrMappingPutInfoHandler(fastify)
    });

    fastify.route({
        method: "DELETE",
        url: "/ehr-mapping/:id",
        preHandler: fastify.authenticate,
        // schema: schemas.getEhrMappingInfo.getEhrMappingDeleteInfoSchema,
        handler: handlers.getEhrMapping.getEhrMappingDeleteInfoHandler(fastify)
    });
};
