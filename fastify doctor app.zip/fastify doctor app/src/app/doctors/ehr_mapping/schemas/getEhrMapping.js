const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getEhrMappingPostInfoSchema = {
    tags: ["POST EhrMapping INFO"],
    summary: "This API is to Post EhrMapping basic info",
    headers: { $ref: "request-headers#" },
    body: {
        type: "object",
        required: ['doctor_id', 'ehr_type_id', 'active', 'created_by'],
        additionalProperties: false,
        properties: {
            doctor_id: { type: 'integer' },
            ehr_type_id: { type: 'integer' },
            ehr_list_id: { type: 'array' },
            active: { type: 'integer' },
            created_by: { type: 'integer' }
          },
    }
}

const getEhrMappingInfoSchema = {
    tags: ["GET EHR MAPPING DETAILS INFO"],
    summary: "This API is to get ehr info",
    header: { $ref: 'request-headers#' },
    response: {
        200: {
          type: 'object',
          properties: {
            allopathy_data_all: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  item: {
                    type: 'object',
                    properties: {
                      id: { type: 'integer' },
                      ehr_list_name: { type: 'string' },
                      active: { type: 'integer' },
                      created_at: { type: 'string'},
                      updated_at: { type: 'string'},
                      created_by: { type: 'integer' },
                      updated_by: { type: 'integer' },
                    },
                  },
                  choosen: { type: 'integer' },
                },
              },
            },
            ayurvedic_data_all: {
              type: 'array',
              items: {
                type: 'object',
                properties: {
                  item: {
                    type: 'object',
                    properties: {
                      id: { type: 'integer' },
                      ehr_list_name: { type: 'string' },
                      active: { type: 'integer' },
                      created_at: { type: 'string'},
                      updated_at: { type: 'string' },
                      created_by: { type: 'integer' },
                      updated_by: { type: 'integer' },
                    },
                  },
                  choosen: { type: 'integer' },
                },
              },
            },
          },
        },
      },
}

const getEhrMappingPutInfoSchema = {
    tags: ["PUT Service INFO"],
    summary: "This API is to Put EhrMapping Detail info ",
    headers: { $ref: "request-headers#" },
    body: {
        type: "object",
        required: [
            "doctor_id",
            "is_allo_ayur",
            "temp_id",
            "active"
        ],
        additionalProperties: false,

    }
}

const getEhrMappingDeleteInfoSchema = {
    tags: ["DELETE Service INFO"],
    summary: "This API is to delete Ehr Mapping info ",
    headers: { $ref: "request-headers#" },
    response: {
        200: {
            type: "object",
            properties: {
                success: { type: "boolean" },
                message: { type: "string" }
            }
        },
        ...errorSchemas
    }
}

module.exports = {
    getEhrMappingPostInfoSchema,
    getEhrMappingInfoSchema,
    getEhrMappingPutInfoSchema,
    getEhrMappingDeleteInfoSchema
}