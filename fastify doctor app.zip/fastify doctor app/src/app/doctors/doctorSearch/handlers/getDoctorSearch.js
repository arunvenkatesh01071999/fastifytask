const getDoctorSearchInfoService = require('../services/getDoctorSearch');

function getDoctorSearchInfoHandler(fastify) {
    const getDoctorSearch = getDoctorSearchInfoService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const response = await getDoctorSearch({
            body,
            params,
            logTrace
        });
        return reply.code(200).send(response)
    };
}

module.exports = getDoctorSearchInfoHandler;