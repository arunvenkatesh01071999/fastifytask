const getDoctorSearchInfo = require('./getDoctorSearch');

module.exports = {
    getDoctorSearchInfo
}