const getTransformSearchInfo = ({
    doctorInfo,
    illnessInfoList,
    illnessSymptomsList,
    specialityList
}) => {
    return {
        id: doctorInfo.id,
        doctor_name: doctorInfo.doctor_name,
        gender_id: doctorInfo.gender_id,
        gender_name: doctorInfo.gender_name,
        speciality_id: doctorInfo.speciality_id,
        speciality_name: doctorInfo.speciality_name,
        email: doctorInfo.email,
        phone_no: doctorInfo.phone_no,
        dob: doctorInfo.dob,
        age: doctorInfo.age,
        about: doctorInfo.about,
        image_path: doctorInfo.image_path,
        signature_path: doctorInfo.signature_path,
        active: doctorInfo.active,
        created_at: doctorInfo.created_at,
        updated_at: doctorInfo.updated_at,
        created_by: doctorInfo.created_by,
        updated_by: doctorInfo.updated_by,
        illness_type: illnessInfoList,
        illness_symptoms: illnessSymptomsList,
        speciality: specialityList
    }
};

module.exports = { getTransformSearchInfo };