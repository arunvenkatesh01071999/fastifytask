const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getDoctorSearchInfoSchema = {
    tags: ["DOCOTOR BASIC INFO"],
    summary: "This API is to get doctor search info ",
    headers: { $ref: "request-headers#" },
    response: {
        200: {
            type: "object",
            properties: {
                id: { type: "integer" },
                doctor_name: { type: "string" },
                gender_id: { type: "integer" },
                gender_name: { type: "string" },
                speciality_id: { type: "integer" },
                speciality_name: { type: "string" },
                email: { type: "string" },
                phone_no: { type: "string" },
                dob: { type: "string" },
                age: { type: "string" },
                about: { type: "string" },
                image_path: { type: "string" },
                signature_path: { type: "string" },
                active: { type: "integer" },
                created_at: { type: "string" },
                updated_at: { type: "string" },
                created_by: { type: "integer" },
                updated_by: { type: "integer" },

                illness_info: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            id: { type: "integer" },
                            illness_type_name: { type: "string" },
                            logo_image: { type: "string" },
                            active: { type: "boolean" },
                            created_at: { type: "string" },
                            updated_at: { type: "string" },
                            created_by: { type: "integer" },
                            updated_by: { type: "integer" }
                        }
                    }
                },
                symptoms_info: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            id: { type: "integer" },
                            illness_symptom_name: { type: "string" },
                            logo_image: { type: "string" },
                            active: { type: "boolean" },
                            created_at: { type: "string" },
                            updated_at: { type: "string" },
                            created_by: { type: "integer" },
                            updated_by: { type: "integer" }
                        }
                    }
                },
                speciality_info: {
                    type: "array",
                    items: {
                        type: "object",
                        properties: {
                            id: { type: "integer" },
                            speciality_name: { type: "string" },
                            logo_image: { type: "string" },
                            active: { type: "boolean" },
                            created_at: { type: "string" },
                            updated_at: { type: "string" },
                            created_by: { type: "integer" },
                            updated_by: { type: "integer" }
                        }
                    }
                },
            }
        },
        ...errorSchemas
    }
};

module.exports = getDoctorSearchInfoSchema;