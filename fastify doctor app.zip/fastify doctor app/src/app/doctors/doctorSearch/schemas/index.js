const getDoctorSearchInfoSchema = require('./getDoctorsearch');

module.exports = {
    getDoctorSearchInfoSchema
}