const schemas = require('../schemas');
const handlers = require('../handlers');

module.exports = async fastify => {
    fastify.route({
        method: "POST",
        preHandler: fastify.authenticate,
        url: "/doctorsearch",
        handler: handlers.getDoctorSearchInfo(fastify)
    });
};