const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { DOCTORBASICINFO } = require("../commons/constant");
const { ILLNESSINFO } = require("../commons/constant");
const { ILLNESSSYMPTOMSMASTER } = require("../commons/constant");
const { SPECIALITY } = require("../commons/constant");
const { CustomError } = require("../../../errorHandler");

function doctorSearchInfo(fastify) {

    async function getDoctorSearch({ logTrace, search_data }) {
        const knex = this;
        const query = knex(`${DOCTORBASICINFO.NAME}`)
            .select([`*`,
            ]).where(`${DOCTORBASICINFO.COLUMNS.DOCTOR_NAME}`, 'like', `%${search_data}%`);
        logQuery({
            logger: fastify.log,
            query,
            context: "Get doctor basic info details",
            logTrace
        });

        const response = await query;
        // if (!response.length) {
        //     throw CustomError.create({
        //         httpCode: StatusCodes.NOT_FOUND,
        //         message: "Doctor info not found",
        //         property: "",
        //         code: "NOT_FOUND"
        //     });
        // }
        return response;
    }

    async function getIllnessInfo({ logTrace, search_data }) {
        const knex = this;
        const query = knex(`${ILLNESSINFO.NAME}`)
            .select('*')
            .where(`${ILLNESSINFO.COLUMNS.ILLNESS_TYPE_NAME}`, 'like', `%${search_data}%`);
        logQuery({
            logger: fastify.log,
            query,
            context: "Get Illness type details",
            logTrace
        });

        const response = await query;
        // if (!response.length) {
        //     throw CustomError.create({
        //         httpCode: StatusCodes.NOT_FOUND,
        //         message: "Illness type info not found",
        //         property: "",
        //         code: "NOT_FOUND"
        //     });
        // }
        return response;
    }

    async function getIllnessSymptomsInfo({ logTrace, search_data }) {
        const knex = this;
        const query = knex(`${ILLNESSSYMPTOMSMASTER.NAME}`)
            .select('*')
            .where(`${ILLNESSSYMPTOMSMASTER.COLUMNS.ILLNESS_SYMPTOM_NAME}`, 'like', `%${search_data}%`);
        logQuery({
            logger: fastify.log,
            query,
            context: "Get Illness symptoms details",
            logTrace
        });

        const response = await query;
        // if (!response.length) {
        //     throw CustomError.create({
        //         httpCode: StatusCodes.NOT_FOUND,
        //         message: "Illness symptoms info not found",
        //         property: "",
        //         code: "NOT_FOUND"
        //     });
        // }
        return response;
    }

    async function getSpecialityInfo({ logTrace, search_data }) {
        const knex = this;
        const query = knex(`${SPECIALITY.NAME}`)
            .select('*')
            .where(`${SPECIALITY.COLUMNS.SPECIALITY_NAME}`, 'like', `%${search_data}%`);
        logQuery({
            logger: fastify.log,
            query,
            context: "Get Speciality type details",
            logTrace
        });

        const response = await query;
        // if (!response.length) {
        //     throw CustomError.create({
        //         httpCode: StatusCodes.NOT_FOUND,
        //         message: "Speciality info not found",
        //         property: "",
        //         code: "NOT_FOUND"
        //     });
        // }
        return response;
    }

    return {
        getDoctorSearch,
        getIllnessInfo,
        getIllnessSymptomsInfo,
        getSpecialityInfo
    };
}

module.exports = doctorSearchInfo;
