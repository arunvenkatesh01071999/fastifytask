const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getbannerBasicInfoSchema = {
  tags: ["GET Banner INFO"],
  summary: "This API is to get Banner basic info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          banner_name: { type: "string" },
          banner_description: { type: "string" },
          banner_title: { type: "string" },
          banner_images: { type: "string" },
          banner_type: { type: "integer" },
          banner_link: { type: "string" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const getBannerpostBasicInfoSchema = {

  tags: ["POST Banner INFO"],
  summary: "This API is to Post Banner INFO ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "banner_name",
      "banner_description",
      "banner_title",
      "banner_images",
      "banner_link"
    ],

  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getBannerputBasicInfoSchema = {
  tags: ["PUT Banner INFO"],
  summary: "This API is to put Banner basic info ",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      id: { type: 'integer' },
    },
    required: ['id'],
  },
  body: {
    type: "object",
    required: [
      "banner_name",
      "banner_description",
      "banner_title",
      "banner_images",
      "banner_link"
    ],

  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getBannerdeleteBasicInfoSchema = {
  tags: ["DELETE Banner INFO"],
  summary: "This API is to delete Banner basic info ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {
  getbannerBasicInfoSchema,
  getBannerpostBasicInfoSchema,
  getBannerputBasicInfoSchema,
  getBannerdeleteBasicInfoSchema
};
