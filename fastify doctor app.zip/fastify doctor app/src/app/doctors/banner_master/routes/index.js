const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/banner",
    preHandler: fastify.authenticate,
    schema: schemas.getBannerBasicInfo.getbannerBasicInfoSchema,
    handler: handlers.getBannerBasicInfo.getBannerBasicInfoHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/banner/:id",
    preHandler: fastify.authenticate,
    schema: schemas.getBannerBasicInfo.getbannerBasicInfoSchema,
    handler: handlers.getBannerBasicInfo.getBannerBasicInfoByIdHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/banner",
    preHandler: fastify.authenticate,
    schema: schemas.getBannerBasicInfo.getBannerpostBasicInfoSchema,
    handler: handlers.getBannerBasicInfo.getBannerBasicpostInfoHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/banner/:id",
    preHandler: fastify.authenticate,
    schema: schemas.getBannerBasicInfo.getBannerputBasicInfoSchema,
    handler: handlers.getBannerBasicInfo.getBannerBasicputInfoHandler(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/banner/:id",
    preHandler: fastify.authenticate,
    schema: schemas.getBannerBasicInfo.getBannerdeleteBasicInfoSchema,
    handler: handlers.getBannerBasicInfo.getBannerBasicdeleteInfoHandler(fastify)
  });
};
