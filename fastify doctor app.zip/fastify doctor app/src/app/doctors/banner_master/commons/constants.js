const BANNERINFO = {
  NAME: "banner_master",
  COLUMNS: {
    ID: "id",
    BANNER_NAME: "banner_name",
    BANNER_DESCRIPTION: "banner_description",
    BANNER_IMAGES: "banner_images",
    BANNER_TITLE: "banner_title",
    BANNER_LINK: "banner_link",
    BANNER_TYPE: "banner_type",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
module.exports = {
  BANNERINFO
};
