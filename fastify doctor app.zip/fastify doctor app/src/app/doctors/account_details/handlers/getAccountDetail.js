const getAccountDetailInfo = require("../services/getAccountDetails");

function getAccounDetailInfoHandler(fastify) {
    const getAccoutInfo =
        getAccountDetailInfo.getAccountInfoService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getAccoutInfo({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function getAccounDetailInfoByIdHandler(fastify) {
    const getAccoutInfo =
        getAccountDetailInfo.getAccountInfoByIdService(fastify);
    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getAccoutInfo({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function getAccounDetailPostInfoHandler(fastify) {
    const getAccounDetailInfo =
        getAccountDetailInfo.getAccountPostInfoService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getAccounDetailInfo({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function getAccounDetailPutInfoHandler(fastify) {
    const getAccoutInfo =
        getAccountDetailInfo.getAccountInfoPutService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getAccoutInfo({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

function getAccounDetailDeleteInfoHandler(fastify) {
    const getAccoutInfo =
        getAccountDetailInfo.getAccountDeleteService(fastify);

    return async (request, reply) => {
        const { body, params, logTrace } = request;
        const { userDetails } = request;
        const response = await getAccoutInfo({
            body,
            params,
            logTrace,
            userDetails
        });
        return reply.code(200).send(response);
    };
}

module.exports = {
    getAccounDetailInfoHandler,
    getAccounDetailPostInfoHandler,
    getAccounDetailPutInfoHandler,
    getAccounDetailDeleteInfoHandler,
    getAccounDetailInfoByIdHandler
};
