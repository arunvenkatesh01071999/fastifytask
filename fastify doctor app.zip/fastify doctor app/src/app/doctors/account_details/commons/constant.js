const ACCOUNTDETAILS = {
    NAME: "d_accounts_details",
    COLUMNS: {
        ID: "id",
        DOCTOR_ID: "doctor_id",
        HOLDER_NAME: "holder_name",
        BANK_ID: "bank_id",
        ACCOUNT_NO: "account_no",
        IFSC_CODE: "ifsc_code",
        UPI_IDS_GPAY: "upi_ids_gpay",
        UPI_IDS_PHONEPE: "upi_ids_phonepe",
        UPI_IDS_PAYTM: "upi_ids_paytm",
        NB_HOLDER_NAME: "nb_holder_name",
        NB_BANK_ID: "nb_bank_id",
        NB_ACCOUNT_NO:"nb_account_no",
        NB_IFSC_CODE: "nb_ifsc_code",
        CUSTOMER_NO: "customer_no",
        IS_SAVE_CURRENT:"is_save_current",
        IS_NBSAVE_CURRENT:" is_nbsave_current",
        ACTIVE: "active"

    }
};

module.exports = {
    ACCOUNTDETAILS
};