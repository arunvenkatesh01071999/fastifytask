const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getAccountPostInfoSchema = {
    tags: ["POST Service INFO"],
    summary: "This API is to Post Account basic info ",
    headers: { $ref: "request-headers#" },
    body: {
        type: "object",
        required: [
            'doctor_id',
            'holder_name',
            'bank_id',
            'account_no',
            'ifsc_code',
            'upi_ids_phonepe',
            'upi_ids_paytm',
            'nb_holder_name',
            'nb_bank_id',
            'nb_account_no',
            'nb_ifsc_code',
            'customer_no',
            'is_save_current',
            'is_nbsave_current',
            'active'
        ],
        additionalProperties: false,
        properties: {
            doctor_id: { type: "integer" },
            holder_name: { type: "string" },
            bank_id: { type: "integer" },
            account_no: { type: "string" },
            ifsc_code: { type: "string" },
            upi_ids_gpay: { type: "string" },
            upi_ids_phonepe: { type: "string" },
            upi_ids_paytm: { type: "string" },
            nb_holder_name: { type: "string" },
            nb_bank_id: { type: "integer" },
            nb_account_no: { type: "string" },
            nb_ifsc_code: { type: "string" },
            customer_no: { type: "string" },
            is_save_current: { type: "integer" },
            is_nbsave_current: { type: "integer" },
            active: { type: "integer" }
        }
    },
    response: {
        200: {
            type: "object",
            properties: {
                success: { type: "boolean" },
                message: { type: "string" }
            }
        },
        ...errorSchemas
    }
}

const getAccountGetInfoSchema = {
    tags: ["GET ACCOUNT DETAILS INFO"],
    summary: "This API is to get ACCOUNT DETAILS INFO",
    header: { $ref: "request-headers# " },
    response: {
        200: {
            type: "array",
            items: {
                type: "object",
                properties: {
                    id: { type: "integer" },
                    doctor_id: { type: "integer" },
                    holder_name: { type: "string" },
                    bank_id: { type: "integer" },
                    account_no: { type: "string" },
                    ifsc_code: { type: "string" },
                    upi_ids_gpay: { type: "string" },
                    upi_ids_phonepe: { type: "string" },
                    upi_ids_paytm: { type: "string" },
                    nb_holder_name: { type: "string" },
                    nb_bank_id: { type: "integer" },
                    nb_account_no: { type: "string" },
                    nb_ifsc_code: { type: "string" },
                    customer_no: { type: "string" },
                    is_save_current: { type: "integer" },
            is_nbsave_current: { type: "integer" },
                    active: { type: "integer" }
                }
            }
        },
        ...errorSchemas
    }
}

const getAccountPutInfoSchema = {
    tags: ["PUT Service INFO"],
    summary: "This API is to Put Account Detail info ",
    headers: { $ref: "request-headers#" },
    body: {
        type: "object",
        required: [
            'doctor_id',
            'holder_name',
            'bank_id',
            'account_no',
            'ifsc_code',
            'upi_ids_phonepe',
            'upi_ids_paytm',
            'nb_holder_name',
            'nb_bank_id',
            'nb_account_no',
            'nb_ifsc_code',
            'customer_no',
            'is_save_current',
            'is_nbsave_current',
            'active'
        ],
        additionalProperties: false,
        properties: {
            doctor_id: { type: "integer" },
            holder_name: { type: "string" },
            bank_id: { type: "integer" },
            account_no: { type: "string" },
            ifsc_code: { type: "string" },
            upi_ids_gpay: { type: "string" },
            upi_ids_phonepe: { type: "string" },
            upi_ids_paytm: { type: "string" },
            nb_holder_name: { type: "string" },
            nb_bank_id: { type: "integer" },
            nb_account_no: { type: "string" },
            nb_ifsc_code: { type: "string" },
            customer_no: { type: "string" },
            is_save_current: { type: "integer" },
            is_nbsave_current: { type: "integer" },
            active: { type: "integer" }
        }
    },
    response: {
        200: {
            type: "object",
            properties: {
                success: { type: "boolean" },
                message: { type: "string" }
            }
        },
        ...errorSchemas
    }
}

const getDeleteAccountInfoSchema = {
    tags: ["DELETE Service INFO"],
    summary: "This API is to delete Account info ",
    headers: { $ref: "request-headers#" },
    response: {
        200: {
            type: "object",
            properties: {
                success: { type: "boolean" },
                message: { type: "string" }
            }
        },
        ...errorSchemas
    }
}

module.exports = {
    getAccountPostInfoSchema,
    getAccountGetInfoSchema,
    getAccountPutInfoSchema,
    getDeleteAccountInfoSchema
}