const getAccounDetailInfo = require('./getAccountDetails');

module.exports = {
    getAccounDetailInfo
}