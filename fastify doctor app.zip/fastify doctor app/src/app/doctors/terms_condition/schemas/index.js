const getTermsAndConditionSchema = require("./getTermsAndCondition");

module.exports = {
  getTermsAndConditionSchema
};
