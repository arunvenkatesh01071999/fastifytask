const getTransformBasicInfo = ({
  doctorInfo,
  educationInfoList,
  addressInfoList,
  languageInfoList
}) => {
  return {
    id: doctorInfo.id,
    doctor_name: doctorInfo.doctor_name,
    gender_id: doctorInfo.gender_id,
    gender_name: doctorInfo.gender_name,
    speciality_id: doctorInfo.speciality_id,
    speciality_name: doctorInfo.speciality_name,
    email: doctorInfo.email,
    phone_no: doctorInfo.phone_no,
    dob: doctorInfo.dob,
    age: doctorInfo.age,
    about: doctorInfo.about,
    image_path: doctorInfo.image_path,
    signature_path: doctorInfo.signature_path,
    active: doctorInfo.active,
    created_at: doctorInfo.created_at,
    updated_at: doctorInfo.updated_at,
    created_by: doctorInfo.created_by,
    updated_by: doctorInfo.updated_by,
    education_info: educationInfoList,
    address_info: addressInfoList,
    languages_info: languageInfoList
  };
};

module.exports = { getTransformBasicInfo };

// education_info: educationInfoList.map(item => {
//     return {
//       id: doctorInfo["education_info.id"],
//       qualification_name_id:
//         doctorInfo["education_info.qualification_name_id"],
//       qualification_name: doctorInfo.qualification_name,
//       doctor_name_id: doctorInfo["education_info.doctor_name_id"],
//       certificate_path: doctorInfo["education_info.certificate_path"],
//       active: doctorInfo["education_info.active"],
//       created_at: doctorInfo["education_info.created_at"],
//       updated_at: doctorInfo["education_info.updated_at"],
//       created_by: doctorInfo["education_info.created_by"],
//       updated_by: doctorInfo["education_info.updated_by"]
//     };
//   })