const getDoctorBasicInfoSchema = require("./getDoctorBasicInfo");
const doctorLoginSchema = require("./doctorLoginSchema");
const uploadImagesSchema = require("./uploadImagesSchema");

module.exports = {
  getDoctorBasicInfoSchema,
  doctorLoginSchema,
  uploadImagesSchema
};