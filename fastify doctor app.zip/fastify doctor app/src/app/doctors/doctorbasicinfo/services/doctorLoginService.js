const doctorBasicInfoRepo = require("../repository/doctorBasicInfo");
function doctorLoginService(fastify) {
  const { doctorLogins } = doctorBasicInfoRepo(fastify);

  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await doctorLogins.call(knex, {
      mobile: body.mobile,
      logTrace
    });

    // Generate a JWT token
    const token = await fastify.jwt.sign({ response });

    return {
      token
    };
  };
}

module.exports = doctorLoginService;