const getDoctorBasicInfoService = require("../services/getDoctorBasicInfo");

function getDoctorBasicInfoHandler(fastify) {
  const getDoctorBasicInfo = getDoctorBasicInfoService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getDoctorBasicInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = getDoctorBasicInfoHandler;