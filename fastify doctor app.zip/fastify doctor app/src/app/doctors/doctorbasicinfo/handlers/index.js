const getDoctorBasicInfo = require("./getDoctorBasicInfo");
const doctorLoginHandler = require("./doctorLoginHandler");
const uploadImagesHandler = require("./uploadImagesHandler");


module.exports = {
  getDoctorBasicInfo,
  doctorLoginHandler,
  uploadImagesHandler
 
};