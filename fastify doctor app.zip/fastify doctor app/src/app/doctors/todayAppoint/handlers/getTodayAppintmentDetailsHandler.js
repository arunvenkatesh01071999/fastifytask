const getTodayAppintmentDetailsService = require("../services/getTodayAppintmentDetailsService");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream")
const pump = util.promisify(pipeline);








function getTodayAppintmentDetailsHandlerPost(fastify) {

  const getTodayAppintmentDetails = getTodayAppintmentDetailsService.getTodayAppintmentDetailsInfoServicePost(fastify);

  return async (request, reply) => {

    const { logTrace, params,body } = request;
    const response = await getTodayAppintmentDetails({
      logTrace,body,
      params

    });
    return reply.code(200).send(response);
  };

}



module.exports = {

 
  
  getTodayAppintmentDetailsHandlerPost

};
