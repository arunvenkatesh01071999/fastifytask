const getTodayAppintmentDetailsHandler = require("./getTodayAppintmentDetailsHandler.js");

module.exports = {
  getTodayAppintmentDetailsHandler
};
