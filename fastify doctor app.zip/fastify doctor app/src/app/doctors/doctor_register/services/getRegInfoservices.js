const RegBasicInfo = require("../repository/RegInfoRespo");
const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");

function getallRegService(fastify) {
  const { getregeall } = RegBasicInfo.RegAllRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getregeall.call(knex, {
      logTrace
    });
    const [getregealldata] = await Promise.all([promise1]);
    return getregealldata;
  };
}
function getByIdRegService(fastify) {
  const { getregById } = RegBasicInfo.RegGetByIdRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getregById.call(knex, {
      logTrace, body, params
    });
    const [getregByIddata] = await Promise.all([promise1]);
    return getregByIddata;
  };
}



function getPostRegService(fastify) {
  const { getregadd } = RegBasicInfo.RegPostRepo(fastify);
  return async ({ body, params, logTrace, userDetails, convertedData }) => {
    const knex = fastify.knexMaster;
    const promise1 = getregadd.call(knex, {
      logTrace, params, 
      // convertedData,
      body
    });
    const [getregadddata] = await Promise.all([promise1]);
    return getregadddata;
  };
}
function getPutRegService(fastify) {
  const { getregput } = RegBasicInfo.RegPutRepo(fastify);
  return async ({ body, params, logTrace, userDetails, convertedData }) => {
    const knex = fastify.knexMaster;
    const promise1 = getregput.call(knex, {
      logTrace,
      body,
      params, 
      // convertedData,
      userDetails
    });
    const [getregputdata] = await Promise.all([promise1]);
    return getregputdata;
  };
}



function getDeleteRegService(fastify) {
  const { getregdelete } =
    RegBasicInfo.RegDeleteRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getregdelete.call(knex, {
      logTrace,
      body,
      params,
      userDetails
    });
    const [getregdeletedata] = await Promise.all([promise1]);
    return getregdeletedata;
  };
}



function getcheckotpService(fastify) {
  const { getotpcheck } =
    RegBasicInfo.checkotpRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getotpcheck.call(knex, {
      // logTrace,
      body,
      params,
      userDetails
    });
    const phone = body.mobile;
    // if (!phone.match(phoneRegex)) {
    //   return "invalid phone number";
    // }
    try {
      const [getregdeletedata] = await Promise.all([promise1]);
      return getregdeletedata;
    } catch (error) {
      console.error(error);
      // res.status(500).json({ message: 'Failed to generate OTP.' });
    }
  };
}


function getresendotpService(fastify) {
  const { getresendotp } =
    RegBasicInfo.resendotpRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getresendotp.call(knex, {
      // logTrace,
      body,
      params,
      userDetails
    });
    const phone = body.mobile;

    try {
      const [getregdeletedata] = await Promise.all([promise1]);
      return getregdeletedata;
    } catch (error) {
      // console.error(error);
      // res.status(500).json({ message: 'Failed to generate OTP.' });
    }
  };
}
module.exports = {
  getallRegService,
  getByIdRegService,
  getPostRegService,
  getPutRegService,
  getDeleteRegService,
  getcheckotpService,
  getresendotpService
};