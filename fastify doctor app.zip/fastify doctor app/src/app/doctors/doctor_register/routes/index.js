const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/doc_register",
    // preHandler: fastify.authenticate,
    //  schema: schemas.getRegisterBasicInfo.getDoctorRegisterSchema,
    handler: handlers.getRegisterBasicInfo.getRegisterInfoHandler(fastify)
  });


  fastify.route({
    method: "GET",
    url: "/doc_register/:id",
    // preHandler: fastify.authenticate,
    //  schema: schemas.getRegisterBasicInfo.getDoctorRegisterSchema,
    handler: handlers.getRegisterBasicInfo.getRegisterInfoByIdHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/doc_register",
    // preHandler: fastify.authenticate,
    // schema: schemas.getRegisterBasicInfo.getDoctorRegisterPostSchema,
    handler: handlers.getRegisterBasicInfo.getRegisterpostInfoHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/doc_register/:id",
    // preHandler: fastify.authenticate,
    //  schema: schemas.getRegisterBasicInfo.getDoctorRegisterPutSchema,
    handler: handlers.getRegisterBasicInfo.getRegisterputInfoHandler(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/doc_register/:id",
    // preHandler: fastify.authenticate,
    schema: schemas.getRegisterBasicInfo.getDoctorRegisterDeleteSchema,
    handler: handlers.getRegisterBasicInfo.getRegisterdeleteInfoHandler(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/doc_register/checkotp",
    schema: schemas.getRegisterBasicInfo.getservicedeleteBasicInfoSchema,
    handler: handlers.getRegisterBasicInfo.checkotp(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/doc_register/resendotp",
    // schema: schemas.getRegisterBasicInfo.getservicedeleteBasicInfoSchema,
    handler: handlers.getRegisterBasicInfo.resendotp(fastify)
  });

};
