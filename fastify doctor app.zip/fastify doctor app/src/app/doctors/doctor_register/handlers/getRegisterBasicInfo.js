const getRegInfos = require("../services/getRegInfoservices");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream");
const { log } = require("console");
const pump = util.promisify(pipeline);


function getRegisterInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getallRegService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



function getRegisterInfoByIdHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getByIdRegService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getRegisterpostInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getPostRegService(fastify);

  return async (request, reply) => {
    // const partes = request.body.image_path;
    // const originalObject = request.body;

    // const convertedData = {};

    // for (const key in originalObject) {

    //   if (Object.hasOwnProperty.call(originalObject, key)) {
    //     convertedData[key] = originalObject[key].value;
    //   }

    // }

    // if (partes.filename == '') {
    //   convertedData[partes.fieldname] = 'null';
    // }
    // else {
    //   try {
    //     await pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
    //     convertedData[partes.fieldname] = partes.filename;
    //   } catch (error) {
    //     console.error('Error during file pump:', error);
    //   }

    // }
    // console.log(convertedData, "convertedData");
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      // convertedData,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



function getRegisterputInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getPutRegService(fastify);

  return async (request, reply) => {
    // const partes = request.body.image_path;
    // const originalObject = request.body;

    // const convertedData = {};

    // for (const key in originalObject) {

    //   if (Object.hasOwnProperty.call(originalObject, key)) {
    //     convertedData[key] = originalObject[key].value;
    //   }
    // }

    // if (partes.filename == '') {
    //   convertedData[partes.fieldname] = 'null';
    // }
    // else {
    //   pump(partes.file, fs.createWriteStream(`./uploads/${partes.filename}`));
    //   convertedData[partes.fieldname] = partes.filename;

    // }

    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      // convertedData,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getRegisterdeleteInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getDeleteRegService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}




function checkotp(fastify) {
  const getRegisterInfo =
    getRegInfos.getcheckotpService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      // logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}


function resendotp(fastify) {
  const getRegisterInfo =
    getRegInfos.getresendotpService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      // logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = {
  getRegisterInfoHandler,
  getRegisterInfoByIdHandler,
  getRegisterpostInfoHandler,
  getRegisterputInfoHandler,
  getRegisterdeleteInfoHandler,
  checkotp,
  resendotp

};
