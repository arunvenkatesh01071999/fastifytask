const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/patient-detail-dateFilter",
  //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler: handlers.getPatientDetailsHandler.getPatientDetailsDateFilterHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/patient-detail",
  //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler: handlers.getPatientDetailsHandler.getPatientDetailsHandlerPost(fastify)
  });

  
  fastify.route({
    method: "POST",
    url: "/patient-detail-img",
  //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler: handlers.getPatientDetailsHandler.getPatientDetailsHandlerPostImg(fastify)
  });
  

};
