const getPatientDetailsSchema = require("./getPatientDetails");

module.exports = {
  getPatientDetailsSchema
};
