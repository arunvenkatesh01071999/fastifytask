const getPatientDetailsHandler = require("./getPatientDetailsHandler.js");

module.exports = {
  getPatientDetailsHandler
};
