const getPatientDetailsRepository = require("../repository/getPatientDetailsRepository");


function getPatientDetailsInfoServicePost(fastify) {

  const { PatientDetailsGetOne } = getPatientDetailsRepository.getPatientDetailsRepositoryPost(fastify);

  return async ({ params, logTrace,body }) => {
    const knex = fastify.knexMaster;
    const promise1 = PatientDetailsGetOne.call(knex, {
      logTrace,body,
      params
    });
    const [getPatientDetailsOnedata] = await Promise.all([promise1]);
    return getPatientDetailsOnedata;
  }
}


function getPatientDetailsDateFilterInfoServicePost(fastify) {

  const { PatientDetailsGetOne } = getPatientDetailsRepository.getPatientDetailsDateFilterRepositoryPost(fastify);

  return async ({ params, logTrace,body }) => {
    const knex = fastify.knexMaster;
    const promise1 = PatientDetailsGetOne.call(knex, {
      logTrace,body,
      params
    });
    const [getPatientDetailsOnedata] = await Promise.all([promise1]);
    return getPatientDetailsOnedata;
  }
}

function getPatientDetailsInfoServicePostImg(fastify) {

  const { PatientDetailsGetOne } = getPatientDetailsRepository.getPatientDetailsRepositoryPostImg(fastify);

  return async ({ params, logTrace ,body}) => {
    const knex = fastify.knexMaster;
    const promise1 = PatientDetailsGetOne.call(knex, {
      logTrace,
      params,
      body
    });
    const [getPatientDetailsOnedata] = await Promise.all([promise1]);
    return getPatientDetailsOnedata;
  }
}


module.exports = {



  getPatientDetailsDateFilterInfoServicePost,
  getPatientDetailsInfoServicePostImg,
  getPatientDetailsInfoServicePost

};
