const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/bank",
    preHandler: fastify.authenticate, // Apply JWT authentication decorator
    schema: schemas.bankSchema,
    handler: handlers.getsbankInfoHandler(fastify)
  });
};
