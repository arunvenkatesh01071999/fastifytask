const getsbankInfoHandler = require("./getsbankInfoHandler");

module.exports = {
  getsbankInfoHandler
};
