const bankInfoService = require("../services/bankInfoService");

function getsbankInfoHandler(fastify) {
  const bankInfo = bankInfoService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await bankInfo({ logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getsbankInfoHandler;
