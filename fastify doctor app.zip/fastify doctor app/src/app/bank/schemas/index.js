const bankSchema = require("./bankSchema");

module.exports = {
  bankSchema
};
