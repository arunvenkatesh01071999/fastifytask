1. FAQ
Table: FAQ _doctors
    1. Q
    2. A

2. CONTACT US
   Table: company_info

   id
   address
   mobile
   email
   timestamps
   gst
   active
   


3. Rate us - to find plugin
4. Terms & Condtions
5. Abouts
6. LOgout
7. DeleteAccount 