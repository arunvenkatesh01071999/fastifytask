const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { MAIN_CATEGORY } = require("../commons/constants");

// Need Catalog DB Connection

function mainCategoryRepo(fastify) {
  async function getMainCategoryById({
    logTrace,
    input: { main_category_id }
  }) {
    const knex = this;
    const query = knex(MAIN_CATEGORY.NAME).where(
      MAIN_CATEGORY.COLUMNS.MCAT_ID,
      main_category_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get MainCategory By Id",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "main_category_id not found in MainCategory Table",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }

  async function updateMainCategoryImageById({
    logTrace,
    input: { main_category_id, image_url }
  }) {
    const knex = this;
    const query = knex(MAIN_CATEGORY.NAME)
      .update({
        [MAIN_CATEGORY.COLUMNS.IMG_PATH]: image_url,
        [MAIN_CATEGORY.COLUMNS.M_IM_GPATH]: image_url
      })
      .where(MAIN_CATEGORY.COLUMNS.MCAT_ID, main_category_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Update MainCategory Image By Id",
      logTrace
    });
    await query;
    return { success: true };
  }

  return {
    getMainCategoryById,
    updateMainCategoryImageById
  };
}

module.exports = mainCategoryRepo;
