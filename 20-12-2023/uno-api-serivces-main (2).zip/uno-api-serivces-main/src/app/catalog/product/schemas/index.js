const patchProductImageSchema = require("./patchProductImage");

module.exports = { patchProductImageSchema };
