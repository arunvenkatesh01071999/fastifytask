const bannerRepo = require("../repository/banner");

function getBannersService(fastify) {
  const { getBanners } = bannerRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexCatalog;
    const response = await getBanners.call(knex, {
      logTrace
    });
    return response;
  };
}
module.exports = getBannersService;
