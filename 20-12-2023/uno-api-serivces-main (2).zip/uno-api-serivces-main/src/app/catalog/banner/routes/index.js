const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/banners",
    schema: schemas.getBannersSchema,
    handler: handlers.getBanners(fastify)
  });
};
