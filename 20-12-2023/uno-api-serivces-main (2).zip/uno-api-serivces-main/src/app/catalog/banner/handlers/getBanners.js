const getBannersService = require("../services/getBanners");

function getBannersHandler(fastify) {
  const getBanners = getBannersService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await getBanners({ body, params, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getBannersHandler;
