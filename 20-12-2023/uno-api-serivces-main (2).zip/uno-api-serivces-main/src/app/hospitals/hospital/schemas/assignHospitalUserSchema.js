const { errorSchemas } = require("../../../commons/schemas/errorSchemas");
const assignHospitalUserSchema = {
  tags: ["HOSPITAL USER SETTINGS"],
  summary: "This API is to set lab slots",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["hospital_id", "user_id"],
    additionalProperties: false,
    properties: {
      hospital_id: { type: "integer" },
      user_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = assignHospitalUserSchema;
