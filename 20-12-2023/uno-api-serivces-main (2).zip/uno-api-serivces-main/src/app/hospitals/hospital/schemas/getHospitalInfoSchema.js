const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getHospitalInfoSchemas = {
  tags: ["HOSPITALS"],
  summary: "This API is to get hospitals information",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      hospital_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        hospital_name: { type: "string" },
        hospital_type_id: { type: "integer" },
        sector_id: { type: "integer" },
        hospital_sector_name: { type: "string" },
        accredation_id: { type: "integer" },
        accredation_name: { type: "string" },
        regNo: { type: "string" },
        about: { type: "string" },
        certicate_path: { type: "string" },
        addCheck: { type: "integer" },
        approved_by: { type: "integer" },
        approve_date: { type: "string", format: "date-time" },
        isApproved: { type: "integer" },
        hospital_image: { type: "string" },
        active: { type: "integer" },
        created_at: { type: "string", format: "date-time" },
        updated_at: { type: "string", format: "date-time" },
        created_by: { type: "integer" },
        updated_by: { type: "integer" },
        rating: { type: "number" },
        address_lines: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              address1: { type: "string" },
              address2: { type: "string" },
              city_id: { type: "integer" },
              state_id: { type: "integer" },
              country_id: { type: "integer" },
              pincode: { type: "string" },
              location: { type: "string" },
              longitude: { type: "string" },
              latitude: { type: "string" },
              distance: { type: "string" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              city_name: { type: "string" },
              states: { type: "string" },
              shortname: { type: "string" },
              phonecode: { type: "integer" },
              countries: { type: "string" }
            }
          }
        },
        contact_lines: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              mobile_no: { type: "string" },
              emergency_no: { type: "string" },
              toll_free_no: { type: "string" },
              helpline_no: { type: "string" },
              fax_no: { type: "string" },
              foreign_international_wing: { type: "string" },
              webiste_URL: { type: "string" },
              email_address_1: { type: "string" },
              email_address_2: { type: "string" },
              established_in: { type: "string" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              telephone_no: { type: "string" },
              ambulance_no: { type: "string" },
              blood_bank_no: { type: "string" }
            }
          }
        },
        infrastructure_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              no_of_doctor: { type: "integer" },
              no_of_ambulances: { type: "integer" },
              anesth_doctor: { type: "integer" },
              anotomy_doctor: { type: "integer" },
              cardio_doctor: { type: "integer" },
              operation_theatre: { type: "integer" },
              icu: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              hospital_name_id: { type: "integer" }
            }
          }
        },
        room_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              room_type_id: { type: "integer" },
              cost_id: { type: "integer" },
              no_of_days: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              room_type_name: { type: "string" }
            }
          }
        },
        departments_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              department_name_id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              department_name: { type: "string" }
            }
          }
        },
        speciality_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              speciality_name_id: { type: "integer" },
              speciality_id: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              speciality_name: { type: "string" },
              speciality_type: { type: "string" }
            }
          }
        },
        service_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              service_name_id: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              service_name: { type: "string" }
            }
          }
        },
        lab_services_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              lab_name_id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              service_name: { type: "string" }
            }
          }
        },
        scans_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              scan_name_id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              scan_test_name: { type: "string" }
            }
          }
        },
        insurance_lists: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              insurance_name_id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              insurance_name: { type: "string" }
            }
          }
        },
        official_information: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              person_name: { type: "string" },
              person_email_id: { type: "string" },
              designation: { type: "string" },
              mobile: { type: "string" },
              telephone: { type: "string" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              hospital_name_id: { type: "integer" }
            }
          }
        },
        terms_conditions: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              terms: { type: "string" },
              condition: { type: "string" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" }
            }
          }
        },
        hospital_payment_information: {
          type: "array",
          items: {
            type: "object",
            properties: {
              payment_name: { type: "string" },
              id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              fees_type_id: { type: "integer" },
              fees_amt: { type: "integer" },
              commision: { type: "integer" },
              check: { type: "integer" },
              N_display_amt: { type: "integer" },
              N_commision: { type: "integer" },
              N_payout: { type: "integer" },
              s_display_amt: { type: "integer" },
              s_commision: { type: "integer" },
              s_payout: { type: "integer" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              fees_type_name: { type: "string" }
            }
          }
        },
        hospital_doctors: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              doctor_name: { type: "string" },
              gender_id: { type: "integer" },
              speciality_id: { type: "integer" },
              email: { type: "string" },
              phone_no: { type: "string" },
              dob: { type: "string" },
              age: { type: "integer" },
              about: { type: "string" },
              image_path: { type: "string" },
              // signature_path: { type: "string" },
              active: { type: "integer" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" },
              created_by: { type: "integer" },
              updated_by: { type: "integer" },
              addCheck: { type: "integer" },
              reason: { type: "string" },
              isApproved: { type: "integer" },
              doctor_type_id: { type: "integer" },
              hospital_name_id: { type: "integer" },
              approved_by: { type: "integer" },
              approve_date: { type: "string" },
              last_otp: { type: "string" },
              workplacetype: { type: "integer" },
              update_on_whatsapp: { type: "integer" },
              gender_name: { type: "string" },
              speciality_name: { type: "string" },
              avail_chat: { type: "integer" },
              avail_consult: { type: "integer" },
              inst_time: { type: "integer" },
              inst_consult: { type: "string" },
              rating: { type: "number" },
              fees: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    doctor_id: { type: "integer" },
                    video_consulting_fee: { type: "number" },
                    v_display_amt: { type: "number" },
                    v_platform_charge: { type: "number" },
                    v_how_mouch_you_get: { type: "number" },
                    walk_consulting_fee: { type: "number" },
                    w_display_amt: { type: "number" },
                    w_platform_charge: { type: "number" },
                    w_how_mouch_you_get: { type: "number" },
                    instant_consulting_fee: { type: "number" },
                    i_display_amt: { type: "number" },
                    i_platform_charge: { type: "number" },
                    i_how_mouch_you_get: { type: "number" },
                    second_opinion_fee: { type: "number" },
                    s_display_amt: { type: "number" },
                    s_platform_charge: { type: "number" },
                    s_how_mouch_you_get: { type: "number" },
                    chat_consulting_fee: { type: "number" },
                    chat_display_amount: { type: "number" },
                    c_display_amt: { type: "number" },
                    c_platform_charge: { type: "number" },
                    c_how_mouch_you_get: { type: "number" },
                    check: { type: "integer" },
                    active: { type: "integer" }
                  }
                }
              },
              experiences: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    doctor_name_id: { type: "integer" },
                    department_id: { type: "integer" },
                    upload_certicate: { type: "string" },
                    experience: { type: "string" },
                    specialized_file: { type: "string" },
                    active: { type: "integer" }
                  }
                }
              },
              languages: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    id: { type: "integer" },
                    language_name: { type: "string" },
                    native_name: { type: "string" },
                    active: { type: "integer" }
                  }
                }
              }
            }
          }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = getHospitalInfoSchemas;
