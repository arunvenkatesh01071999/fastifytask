const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/hospitals/:page_size/:current_page/:search?",
    schema: schemas.getHospitalSchema,
    handler: handlers.getHospitalHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/hospitals/filter/:page_size/:current_page/:sortbyname/:sortbydistance/:sortbyreview/:search?",
    schema: schemas.getHospitalSchema,
    handler: handlers.getHospitalFilterHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/hospitals/info/:hospital_id",
    schema: schemas.getHospitalInfoSchema,
    handler: handlers.getHospitalInfoHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/hospital/assign/user",
    schema: schemas.assignHospitalUserSchema,
    handler: handlers.assignHospitalUserHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/hospital/info/user/:user_id",
    schema: schemas.getHospitalInfoByUserSchema,
    handler: handlers.getHospitalInfoByUserHandler(fastify)
  });
};
