const getHospitalReviewServices = require("../services/getHospitalReviewServices");

function getHospitalReviewHandler(fastify) {
  const getReview = getHospitalReviewServices(fastify);
  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await getReview({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getHospitalReviewHandler;
