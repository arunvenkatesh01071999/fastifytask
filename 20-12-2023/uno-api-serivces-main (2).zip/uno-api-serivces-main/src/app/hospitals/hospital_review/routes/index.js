const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "POST",
    url: "/hospital/review",
    schema: schemas.postHospitalReviewSchema,
    handler: handlers.postHospitalReviewHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/hospital/review/:hospital_id",
    schema: schemas.getHospitalReviewSchema,
    handler: handlers.getHospitalReviewHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/hospital/admin/review/:hospital_id",
    schema: schemas.getHospitalReviewSchema,
    handler: handlers.getHospitalAdminReviewHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/hospital/review/disable",
    schema: schemas.postDisableHospitalReviewSchema,
    handler: handlers.postDisableHospitalReviewHandler(fastify)
  });
};
