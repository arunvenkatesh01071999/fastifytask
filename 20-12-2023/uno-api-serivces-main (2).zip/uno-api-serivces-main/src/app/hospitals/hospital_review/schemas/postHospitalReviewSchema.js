const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postHospitalReviewSchema = {
  tags: ["HOSPITAL REVIEWS"],
  summary: "This API is used to post hospital reivews",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["hospital_id", "patient_id", "comments", "rating"],
    additionalProperties: false,
    properties: {
      hospital_id: { type: "integer" },
      patient_id: { type: "integer" },
      comments: { type: "string" },
      rating: { type: "number" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postHospitalReviewSchema;
