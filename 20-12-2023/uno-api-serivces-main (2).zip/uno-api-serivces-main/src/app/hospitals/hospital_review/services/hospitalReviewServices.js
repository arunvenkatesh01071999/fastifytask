const hospitalReviewRepo = require("../repository/hospitalReview");
const getHospitalReviewServices = require("./getHospitalReviewServices");
function hospitalReviewServices(fastify) {
  const { postReview } = hospitalReviewRepo(fastify);
  const calculateReview = getHospitalReviewServices(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const { hospital_id, patient_id, comments, rating } = body;

    const response = await postReview.call(knex, {
      logTrace,
      input: {
        hospital_id,
        patient_id,
        comments,
        rating
      }
    });

    calculateReview({
      logTrace,
      params: {
        hospital_id
      }
    });
    return response;
  };
}
module.exports = hospitalReviewServices;
