const hospitalReviewRepo = require("../repository/hospitalReview");

function calculateOverallRating(reviews) {
  let totalRating = 0;
  for (const review of reviews) {
    totalRating += review.rating;
  }
  const overallRating = totalRating / reviews.length;
  return overallRating.toFixed(1); // Round to one decimal place
}
function getHospitalAdminReviewServices(fastify) {
  const { getAdminReview, getPatientInfo, updateHospitalRate } =
    hospitalReviewRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;

    const response = await getAdminReview.call(knex, {
      logTrace,
      params
    });
    let overallRating = calculateOverallRating(response); // Assuming 'response' contains the reviews

    const updateLab = await updateHospitalRate.call(knex, {
      overallRating,
      params,
      logTrace
    });
    const reviewsWithPatientInfo = await Promise.all(
      response.map(async review => {
        let pid = review.patient_id;
        const patientInfo = await getPatientInfo({ pid, logTrace });
        return {
          ...review,
          patient_info: patientInfo
        };
      })
    );

    return {
      overall_rating: overallRating,
      out_of: response.length,
      reviews: reviewsWithPatientInfo
    };
  };
}
module.exports = getHospitalAdminReviewServices;
