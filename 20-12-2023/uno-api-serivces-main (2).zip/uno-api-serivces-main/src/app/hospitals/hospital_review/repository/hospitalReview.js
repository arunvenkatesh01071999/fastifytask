const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");

const { HOSPITAL_BASIC_INFO } = require("../commons/constants");
const { HOSPITAL_REVIEWS } = require("../commons/constants");
const { REGISTERINFO } = require("../commons/constants");
function hospitalReviewRepo(fastify) {
  async function postReview({
    logTrace,
    input: { hospital_id, patient_id, comments, rating }
  }) {
    const knex = this;
    const query = knex(HOSPITAL_REVIEWS.NAME)
      .where(HOSPITAL_REVIEWS.COLUMNS.HOSPITAL_ID, hospital_id)
      .where(HOSPITAL_REVIEWS.COLUMNS.PATIENT_ID, patient_id);

    const exists_response = await query;

    if (exists_response.length > 0) {
      // Review already exists, so update it
      const query_update = await knex(`${HOSPITAL_REVIEWS.NAME}`)
        .where(`${HOSPITAL_REVIEWS.COLUMNS.HOSPITAL_ID}`, hospital_id)
        .where(`${HOSPITAL_REVIEWS.COLUMNS.PATIENT_ID}`, patient_id)
        .update({
          [HOSPITAL_REVIEWS.COLUMNS.COMMENTS]: comments,
          [HOSPITAL_REVIEWS.COLUMNS.RATING]: rating
        });

      const response = await query_update;
      if (!response) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_IMPLEMENTED,
          message: "Error while updating patient review",
          property: "",
          code: "NOT_IMPLEMENTED"
        });
      }
    } else {
      // Review does not exist, so insert a new one
      const query_insert = knex(HOSPITAL_REVIEWS.NAME).insert({
        [HOSPITAL_REVIEWS.COLUMNS.PATIENT_ID]: patient_id,
        [HOSPITAL_REVIEWS.COLUMNS.HOSPITAL_ID]: hospital_id,
        [HOSPITAL_REVIEWS.COLUMNS.COMMENTS]: comments,
        [HOSPITAL_REVIEWS.COLUMNS.RATING]: rating
      });
      logQuery({
        logger: fastify.log,
        query,
        context: "Add patient review",
        logTrace
      });
      await query_insert;
    }

    return { success: true };
  }
  async function getReview({ params, logTrace }) {
    const knex = this;

    const query = knex(HOSPITAL_REVIEWS.NAME)
      .where(HOSPITAL_REVIEWS.COLUMNS.HOSPITAL_ID, params.hospital_id)
      .where(HOSPITAL_REVIEWS.COLUMNS.ACTIVE, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital reviews details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Reviews not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function getPatientInfo({ pid, logTrace }) {
    const knex = fastify.knexPatient;

    const query = knex(REGISTERINFO.NAME).where(REGISTERINFO.COLUMNS.ID, pid);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get patient details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "patient not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function updateHospitalRate({ overallRating, params, logTrace }) {
    const knex = this;

    const query_update = await knex(`${HOSPITAL_BASIC_INFO.NAME}`)
      .where(`${HOSPITAL_BASIC_INFO.COLUMNS.ID}`, params.hospital_id)
      .update({
        [HOSPITAL_BASIC_INFO.COLUMNS.RATING]: overallRating
      });

    await query_update;
  }
  async function getAdminReview({ params, logTrace }) {
    const knex = this;

    const query = knex(HOSPITAL_REVIEWS.NAME).where(
      HOSPITAL_REVIEWS.COLUMNS.HOSPITAL_ID,
      params.hospital_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get hospital reviews details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Reviews not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }
  async function postDisableReview({
    logTrace,
    input: { hospital_id, patient_id, active }
  }) {
    const knex = this;

    const query_update = await knex(`${HOSPITAL_REVIEWS.NAME}`)
      .where(`${HOSPITAL_REVIEWS.COLUMNS.PATIENT_ID}`, patient_id)
      .where(`${HOSPITAL_REVIEWS.COLUMNS.HOSPITAL_ID}`, hospital_id)
      .update({
        [HOSPITAL_REVIEWS.COLUMNS.ACTIVE]: active
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updating patient review",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  return {
    postReview,
    getReview,
    getPatientInfo,
    updateHospitalRate,
    getAdminReview,
    postDisableReview
  };
}

module.exports = hospitalReviewRepo;
