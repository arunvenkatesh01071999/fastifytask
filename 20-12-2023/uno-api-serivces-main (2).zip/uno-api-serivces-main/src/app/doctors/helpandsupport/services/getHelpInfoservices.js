const HelpBasicInfo = require("../repository/HelpInfoRespo");
const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");

function getallHelpService(fastify) {
  const { gethelpall } = HelpBasicInfo.HelpAllRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = gethelpall.call(knex, {
      logTrace
    });
    const [gethelpalldata] = await Promise.all([promise1]);
    return gethelpalldata;
  };
}


function getallCompanyService(fastify) {
  const { getcompanyall } = HelpBasicInfo.CompanyAllRepo(fastify);
  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const promise1 = getcompanyall.call(knex, {
      logTrace
    });
    const [getcompanyalldata] = await Promise.all([promise1]);
    return getcompanyalldata;
  };
}

function getpostHelpService(fastify) {
  const { gethelpall } = HelpBasicInfo.HelppostRepo(fastify);
  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = gethelpall.call(knex, {
      logTrace,
      body
    });
    const [gethelpalldata] = await Promise.all([promise1]);
    return gethelpalldata;
  };
}

function getallCompanypostService(fastify) {
  const { getcompanyall } = HelpBasicInfo.CompanyAllpostRepo(fastify);
  return async ({ body, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = getcompanyall.call(knex, {
      logTrace,
      body
    });
    const [getcompanyalldata] = await Promise.all([promise1]);
    return getcompanyalldata;
  };
}

function getputHelpService(fastify) {
  const { gethelpall } = HelpBasicInfo.HelpputRepo(fastify);
  return async ({ body,params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = gethelpall.call(knex, {
      logTrace,
      body,
      params
    });
    const [gethelpalldata] = await Promise.all([promise1]);
    return gethelpalldata;
  };
}
function getallCompanyputService(fastify) {
  const { getcompanyall } = HelpBasicInfo.CompanyAllputRepo(fastify);
  return async ({ body,params, logTrace }) => {
    const knex = fastify.knexMaster;
    const promise1 = getcompanyall.call(knex, {
      logTrace,
      body,
      params
    });
    const [getcompanyalldata] = await Promise.all([promise1]);
    return getcompanyalldata;
  };
}

module.exports = {
  getallHelpService,
  getallCompanyService,
  getpostHelpService,
  getallCompanypostService,
  getputHelpService,
  getallCompanyputService

};