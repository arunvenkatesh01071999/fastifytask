const getPdfInfoHandler = require("./getPdfInfo");

module.exports = {
  getPdfInfoHandler
};
