const getPdfInfoS = require('../services/getPdfInfo');
// const v = require('../views/template')
// console.log(v);
const fastify = require('fastify')({ logger: true });
// fastify.register(require('@fastify/view'), {
//   engine: {
//     ejs: require('ejs'),
//   },
//   templates: '../views/template',
//   // templates: path.join(__dirname, 'views'), // Replace 'views' with your template directory
//   // options: {
//   //   filename: path.join(__dirname, 'views'), // Replace 'views' with your template directory
//   // },
// });

// function getPdfInfoHandler(fastify) {
//     // const getPdfInfoServices = getPdfInfoS.getPDFInfoService(fastify);

//     return async (request, reply) => {
//       const knex = fastify.knexMaster;
//       const query = knex('e_cheif_complaints')
//   .select('*') // Replace with the actual column names you need
//   .where({
//     doctor_id: request.params.doctor_id,
//     patient_id: request.params.patient_id,
//   })
//   .orderBy('id', 'desc');
// const response = await query;
//       // const query = knex.raw(`select  * from e_cheif_complaints where doctor_id = ${request.params.doctor_id} 
//       // and patient_id = ${request.params.patient_id} order By id DESC`);
//       // const response = await query;
//       if (!response.length) {
//         throw CustomError.create({
//           httpCode: StatusCodes.NOT_FOUND,
//           message: "Cheif info not found",
//           property: "",
//           code: "NOT_FOUND"
//         });
//       }
      
//       // return response;

//       // const { params, logTrace,body } = request;
//       // const response = await getPdfInfoServices({
//       //   params,body, 
//       //   logTrace
//       // });
      
//       return reply.view('template.ejs', { response });
//       // return reply.code(200).send(response);
//     };
//   }


  function getPdfInfoHandler(fastify) {

    const getPatientDetails = getPdfInfoS.getPDFInfoService(fastify);
  
    return async (request, reply) => {
  
      const { logTrace, params, body } = request;
      const response = await getPatientDetails({
        logTrace, body,reply,
        params
  
      });
      return reply.code(200).send(response);
    };
  
  };

module.exports = {
    getPdfInfoHandler
}