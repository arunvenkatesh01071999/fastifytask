// const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
    fastify.route({
        method: "GET",
        url: "/pdf-generate/:patient_id/:doctor_id",
        handler: handlers.getPdfInfoHandler.getPdfInfoHandler(fastify)
    });

}