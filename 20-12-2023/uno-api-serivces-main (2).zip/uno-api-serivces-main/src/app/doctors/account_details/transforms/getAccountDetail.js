const getAccountInfo = ({ getAccountInfoData }) => {
    return {
        id: getAccountInfoData.id,
        doctor_id: getAccountInfoData.doctor_id,

        created_at: getAccountInfoData.created_at,
        updated_at: getAccountInfoData.updated_at,
        created_by: getAccountInfoData.created_by,
        updated_by: getAccountInfoData.updated_by
    }
};

module.exports = { getAccountInfo }