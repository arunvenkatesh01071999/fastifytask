const getAccounDetailInfo = require('./getAccountDetail')

module.exports = {
    getAccounDetailInfo
}