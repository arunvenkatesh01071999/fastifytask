const accoutDetailInfo = require("../repository/getAccountdetails");
// const getBannerBasicInfos = require("../transformers/getBannerBasicInfo");

function getAccountInfoService(fastify) {
    const { getAllAccount } = accoutDetailInfo.allAccountDetail(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAllAccount.call(knex, {
            logTrace
        });
        const [getAccountAllService] = await Promise.all([promise1]);

        return getAccountAllService;
    };
}

function getAccountInfoByIdService(fastify) {
    const { getAllIdAccount } = accoutDetailInfo.allAccountDetailById(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAllIdAccount.call(knex, {
            logTrace,body, params,
        });
        const [getAccountAllIdService] = await Promise.all([promise1]);

        return getAccountAllIdService;
    };
}

function getAccountPostInfoService(fastify) {
    const { getAddAccount } = accoutDetailInfo.accountPostRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAddAccount.call(knex, {
            logTrace,
            body
        });

        const [getAccountAddService] = await Promise.all([promise1]);

        return getAccountAddService;
    };
}
function getAccountInfoPutService(fastify) {
    const { getPutAccount } = accoutDetailInfo.accountPutRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getPutAccount.call(knex, {
            logTrace,
            body,
            params,
            userDetails
        });

        const [getAccountPutService] = await Promise.all([promise1]);

        return getAccountPutService;
    };
}

function getAccountDeleteService(fastify) {
    const { getAccountDelete } =
        accoutDetailInfo.accountDeleteRepo(fastify);

    return async ({ body, params, logTrace, userDetails }) => {
        const knex = fastify.knexMaster;
        const promise1 = getAccountDelete.call(knex, {
            logTrace,
            body,
            params,
            userDetails
        });

        const [getDeleteService] = await Promise.all([promise1]);

        return getDeleteService;
    };
}

module.exports = {
    getAccountInfoService,
    getAccountPostInfoService,
    getAccountInfoPutService,
    getAccountDeleteService,
    getAccountInfoByIdService
};
