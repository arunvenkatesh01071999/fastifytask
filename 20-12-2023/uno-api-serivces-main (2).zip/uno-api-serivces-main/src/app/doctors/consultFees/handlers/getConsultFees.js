const getConsultFeesInfo = require("../services/getConsultFeesService");

function getConsultFeesHandler(fastify) {
  const getConsultFeeInfo =
    getConsultFeesInfo.getConsultPostInfoService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getConsultFeeInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
};



function getConsultFeesHandlerGet(fastify) {
  const getConsultFees =
    getConsultFeesInfo.getallConsultFeesService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getConsultFees({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



function getConsultFeesByIdHandler(fastify) {
  const getConsultFees =
    getConsultFeesInfo.getByIdConsultFeesService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getConsultFees({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}


function getConsultFeesPutHandler(fastify) {
  const getConsultFeeInfo =
    getConsultFeesInfo.getConsultPutInfoService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getConsultFeeInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
};





module.exports = {
  getConsultFeesHandler,
  getConsultFeesHandlerGet,
  getConsultFeesByIdHandler,
  getConsultFeesPutHandler
}