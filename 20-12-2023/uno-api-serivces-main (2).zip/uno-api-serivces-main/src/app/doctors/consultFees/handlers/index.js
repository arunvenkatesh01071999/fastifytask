const getConsultFeesInfo = require('./getConsultFees')

module.exports = {
    getConsultFeesInfo
}