const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { LABINVESTIGATION } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");

function postLabInvestigationReportRepositoryBasic(fastify) {
  async function getLabInvestigationReportAdd({ logTrace, body }) {
    const knex = this;

    const investigation = body.lab_test_category_name;

    
    let investigationResult = investigation.join(",");

    const link = body.lab_link;
    
    let linkResult = link.join(",");

    const scan = body.scan_test_name;
    
    let scanResult = scan.join(",");

    const scanCenter = body.scan_center_link;
    
    let scanCenterResult = scanCenter.join(",");


    const query = await knex(`${LABINVESTIGATION.NAME}`).insert({

      [LABINVESTIGATION.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [LABINVESTIGATION.COLUMNS.PATIENT_ID]: body.patient_id,
      [LABINVESTIGATION.COLUMNS.ACTIVE]: body.active,

      [LABINVESTIGATION.COLUMNS.LAB_TEST_CATEGORY_NAME]: investigationResult,
      [LABINVESTIGATION.COLUMNS.LAB_LINK]: linkResult,
      [LABINVESTIGATION.COLUMNS.SCAN_TEST_NAME]: scanResult,
      [LABINVESTIGATION.COLUMNS.SCAN_CENTER_LINK]: scanCenterResult,
      [LABINVESTIGATION.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    getLabInvestigationReportAdd

  };
}

function updateLabInvestigationReportRepository(fastify) {
  async function getLabInvestigationReportUpdate({ logTrace, body, params }) {
    const knex = this;
    // const { patient_id } = params;
    const  patient_id = params.patient_id;
    const doctor_id = body.doctor_id

    const investigationReportGetID = await knex.raw(`select top 1 id from e_lab_investigation_report where patient_id = ${patient_id} and doctor_id = ${doctor_id} and end_consultation =0 order By id desc`)
    const id=investigationReportGetID[0].id

    const investigation = body.lab_test_category_name;
    
    let investigationResult = investigation.join(",");

    const link = body.lab_link;
    
    let linkResult = link.join(",");

    const scan = body.scan_test_name;
    
    let scanResult = scan.join(",");

    const scanCenter = body.scan_center_link;
    
    let scanCenterResult = scanCenter.join(",");


    const query = await knex(`${LABINVESTIGATION.NAME}`)
      .where(`${LABINVESTIGATION.COLUMNS.ID}`, id)
      .update({
        
      [LABINVESTIGATION.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [LABINVESTIGATION.COLUMNS.PATIENT_ID]: body.patient_id,
      [LABINVESTIGATION.COLUMNS.ACTIVE]: body.active,
        [LABINVESTIGATION.COLUMNS.LAB_TEST_CATEGORY_NAME]: investigationResult,
        [LABINVESTIGATION.COLUMNS.LAB_LINK]: linkResult,
        [LABINVESTIGATION.COLUMNS.SCAN_TEST_NAME]: scanResult,
        [LABINVESTIGATION.COLUMNS.SCAN_CENTER_LINK]: scanCenterResult,
        [LABINVESTIGATION.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    getLabInvestigationReportUpdate
  };
}

function getLabInvestigationReportRepository(fastify) {
  
  async function getLabInvestigationReportGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.select('*').from(`${LABINVESTIGATION.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get lab_investigation_report details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "lab_investigation_report info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getLabInvestigationReportGetAlls
  };

}


function getLabInvestigationReportRepositoryId(fastify) {
  
  async function getLabInvestigationReportGetOne({ logTrace, params }) {
    
    const knex = this;
    const patient_id = params.patient_id;
    const doctor_id = params.doctor_id;
     

    // const query = knex.select('*').from(`${LABINVESTIGATION.NAME}`).where(`${LABINVESTIGATION.COLUMNS.PATIENT_ID}`, patient_id);
    const query = knex.raw(`select top 1 * from e_lab_investigation_report  where patient_id =${patient_id} and doctor_id=${doctor_id} and end_consultation =0 order BY id desc`)

    logQuery({
      logger: fastify.log,
      query,
      context: "Get lab_investigation_report details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "lab_investigation_report info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getLabInvestigationReportGetOne
  };

}

function deleteLabInvestigationReportRepositoryId(fastify) {
  async function getLabInvestigationReportDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const  patient_id  = params.patient_id;
    const doctor_id  = params.doctor_id;

    const investigationReportGetID = await knex.raw(`select top 1 id from e_lab_investigation_report where patient_id = ${patient_id} and doctor_id = ${doctor_id}  and end_consultation =0 order By id desc`)
    const id=investigationReportGetID[0].id

    const query = await knex(`${LABINVESTIGATION.NAME}`).where(`${LABINVESTIGATION.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    getLabInvestigationReportDelete
  };
}


module.exports = {
  postLabInvestigationReportRepositoryBasic,
  updateLabInvestigationReportRepository,
  getLabInvestigationReportRepository,
  getLabInvestigationReportRepositoryId,
  deleteLabInvestigationReportRepositoryId

};
