const getCheifComplaintsSchema = require("./getCheifComplaints");

module.exports = {
  getCheifComplaintsSchema
};
