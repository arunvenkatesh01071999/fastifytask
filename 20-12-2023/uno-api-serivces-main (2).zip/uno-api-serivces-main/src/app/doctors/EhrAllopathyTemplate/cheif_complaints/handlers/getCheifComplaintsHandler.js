const getCheifComplaintsService = require("../services/getCheifComplaintsService");



function createCheifComplaintsHandler(fastify) {

  const createCheifComplaints =
    getCheifComplaintsService.createCheifComplaintsServiceBasic(fastify);

  return async (request, reply) => {
    const { body, logTrace } = request;

    const response = await createCheifComplaints({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };

}

function updateCheifComplaintsHandler(fastify) {
  const updateCheifComplaints = getCheifComplaintsService.updateCheifComplaintsServiceBasic(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await updateCheifComplaints({
      body,
      params,
      logTrace

    });
    return reply.code(200).send(response);
  };
}

function getCheifComplaintsHandler(fastify) {

  const getCheifComplaints = getCheifComplaintsService.getCheifComplaintsInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getCheifComplaints({
      logTrace
    });
    return reply.code(200).send(response);
  };

}



function getCheifComplaintsHandlerId(fastify) {

  const getCheifComplaints = getCheifComplaintsService.getCheifComplaintsInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getCheifComplaints({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}



function deleteCheifComplaintsHandler(fastify) {
  const deleteCheifComplaints = getCheifComplaintsService.deleteCheifComplaintsServiceId(fastify);
  return async (request, reply) => {
    const { params, logTrace } = request;
    const response = await deleteCheifComplaints({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}


function getCheifComplaintsIllnessTypesHandler(fastify) {

  const getCheifComplaints = getCheifComplaintsService.getCheifComplaintsIllnessTypesInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getCheifComplaints({
      logTrace
    });
    return reply.code(200).send(response);
  };

}

function getPatientEhrSearchHandler(fastify) {

  const getCheifComplaints = getCheifComplaintsService.getPatientEhrSearchService(fastify);

  return async (request, reply) => {

    const { logTrace , body } = request;
    const response = await getCheifComplaints({
      logTrace,
      body
    });
    return reply.code(200).send(response);
  };

}

function getPatientEhrSearchGetAllHandler(fastify) {
  const getCheifComplaints = getCheifComplaintsService.getPatientEhrSearchGetAllService(fastify);
  return async (request, reply) => {
    const { logTrace , body } = request;
    const response = await getCheifComplaints({
      logTrace,
      body
    });
    return reply.code(200).send(response);
  };
}



module.exports = {

  createCheifComplaintsHandler,
  updateCheifComplaintsHandler,
  getCheifComplaintsHandler,
  getCheifComplaintsHandlerId,
  deleteCheifComplaintsHandler,
  getCheifComplaintsIllnessTypesHandler,
  getPatientEhrSearchHandler,
  getPatientEhrSearchGetAllHandler

};
