const { errorSchemas } = require("../../../../../app/commons/schemas/errorSchemas");

const createCheifComplaintsSchema = {
  tags: ["POST CheifComplaints"],
  summary: "This API is to Post CheifComplaints ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ['doctor_id', 'patient_id','appoint_id', 'isallo_or_auyr', 'cheif_complients', 'active', 'created_by'],
    additionalProperties: false,
    properties: {
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      isallo_or_auyr: { type: "integer" },
      appoint_id: { type: "integer" },
      cheif_complients: {
        type: "array",
        items: {
          type: "string"
        }
      },
      active: { type: "integer" },
      created_by: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};
const updateCheifComplaintsSchema = {
  tags: ["PUT CheifComplaints"],
  summary: "This API is to Update CheifComplaints ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ['doctor_id', 'patient_id','appoint_id', 'isallo_or_auyr', 'cheif_complients', 'active', 'created_by'],
    additionalProperties: false,
    properties: {
      doctor_id: { type: "integer" },
      patient_id: { type: "integer" },
      isallo_or_auyr: { type: "integer" },
      appoint_id: { type: "integer" },
      cheif_complients: {
        type: "array",
        items: {
          type: "string"
        }
      },
      active: { type: "integer" },
      created_by: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};
const getCheifComplaintsSchema = {
  tags: ["GET  ALL CheifComplaints"],
  summary: "This API is to get CheifComplaints ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          doctor_id: { type: "integer" },
          patient_id: { type: "integer" },
          isallo_or_auyr: { type: "integer" },
          appoint_id: { type: "integer" },
          end_consultation:{ type: "integer" },
          cheif_complients: {
            type: "string",
          },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};
const deleteCheifComplaintsSchema = {
  tags: ["DELETE CheifComplaints"],
  summary: "This API is to delete CheifComplaints ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};
module.exports = {
  createCheifComplaintsSchema,
  updateCheifComplaintsSchema,
  getCheifComplaintsSchema,
  deleteCheifComplaintsSchema
};