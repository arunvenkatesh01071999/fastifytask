const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "GET",
    url: "/other-treatment-suggestion",
    preHandler: fastify.authenticate,
    // schema: schemas.getOtherTreatmentSchema.getOtherTreatmentSchema,
    handler: handlers.getOtherTreatmentHandler.getOtherTreatmentHandler(fastify)
  });


};
