const getOtherTreatmentService = require("../services/getOtherTreatmentService");





function getOtherTreatmentHandler(fastify) {

  const getOtherTreatment = getOtherTreatmentService.getOtherTreatmentInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getOtherTreatment({
      logTrace
    });
    return reply.code(200).send(response);
  };

}



module.exports = {


  getOtherTreatmentHandler,

};
