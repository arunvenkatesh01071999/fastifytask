const getPrescriptionMedicineService = require("../services/getPrescriptionMedicineService");

function ehruniquegetHandler(fastify) {
  
  const createehruniqueget =
  getPrescriptionMedicineService.ehruniquegetServiceBasic(fastify);

  return async (request, reply) => {

    const { body, logTrace } = request;
    
    const response = await createehruniqueget({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
  
}

function createPrescriptionMedicineHandler(fastify) {
  
  const createPrescriptionMedicine =
  getPrescriptionMedicineService.createPrescriptionMedicineServiceBasic(fastify);

  return async (request, reply) => {

    const { body, logTrace } = request;
    
    const response = await createPrescriptionMedicine({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
  
}

function updatePrescriptionMedicineHandler(fastify) {
  const updatePrescriptionMedicine = getPrescriptionMedicineService.updatePrescriptionMedicineServiceBasic(fastify);

  return async (request, reply) => {
    
    const { body, params, logTrace } = request;
    const response = await updatePrescriptionMedicine({
      body,
      params,
      logTrace
      
    });
    return reply.code(200).send(response);
  };
}

function getPrescriptionMedicineHandler(fastify) {

  const getPrescriptionMedicine = getPrescriptionMedicineService.getPrescriptionMedicineInfoService(fastify);

  return async (request, reply) => {

    const { logTrace ,params } = request;
    const response = await getPrescriptionMedicine({
      logTrace,
      params
    });
    return reply.code(200).send(response);
  };

}

function getPrescriptionMedicineHandlerId(fastify) {

  const getPrescriptionMedicine = getPrescriptionMedicineService.getPrescriptionMedicineInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getPrescriptionMedicine({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}

function deletePrescriptionMedicineHandler(fastify) {

  const deletePrescriptionMedicine = getPrescriptionMedicineService.deletePrescriptionMedicineServiceId(fastify);
  return async (request, reply) => {
    const {  params, logTrace } = request;
  
    const response = await deletePrescriptionMedicine({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}

function deleteAllPrescriptionMedicineHandler(fastify) {

  const deletePrescriptionMedicine = getPrescriptionMedicineService.deleteAllPrescriptionMedicineServiceId(fastify);
  return async (request, reply) => {
    const {  params, logTrace } = request;
  
    const response = await deletePrescriptionMedicine({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}
module.exports = {

  createPrescriptionMedicineHandler,
  updatePrescriptionMedicineHandler,
  getPrescriptionMedicineHandler,
  getPrescriptionMedicineHandlerId,
  deletePrescriptionMedicineHandler,
  deleteAllPrescriptionMedicineHandler,
  ehruniquegetHandler
};
