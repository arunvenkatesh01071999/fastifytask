const getPrescriptionMedicineSchema = require("./getPrescriptionMedicine");

module.exports = {
  getPrescriptionMedicineSchema
};
