
const { errorSchemas } = require("../../../../commons/schemas/errorSchemas");

const createPastMedicalHistorySchema = {
  tags: ["POST PastMedicalHistory"],
  summary: "This API is to Post PastMedicalHistory ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "doctor_id",
      "patient_id",
      "health_record_details",
      "past_illness",
      "past_medicine",
      "past_surgeries",
      "history_of_allergy",
      "previous_vacination",
      "pregnancy",
      "is_trimester",
      "is_lactation",
      "active",
      'created_by'

    ],
    // additionalProperties: false,
    // properties: {
      
    //   doctor_id: { type: 'integer' },
    //   patient_id: { type: 'integer' },
    //   health_record_details: { type: 'string' },
    //   past_illness: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   past_medicine: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   past_surgeries: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   history_of_allergy: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   previous_vacination: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   pregnancy: { type: 'integer' },
    //   is_trimester: { type: 'integer' },
    //   is_lactation: { type: 'integer' },
 
    //   active: { type: 'integer' },
    //   created_by: { type: "integer" }
    // }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const updatePastMedicalHistorySchema = {
  tags: ["PUT PastMedicalHistory"],
  summary: "This API is to Update PastMedicalHistory ",
  headers: { $ref: "request-headers#" },
 
  body: {
    type: "object",
    required: [
      "doctor_id",
      "patient_id",
      "health_record_details",
      "past_illness",
      "past_medicine",
      "past_surgeries",
      "history_of_allergy",
      "previous_vacination",
      "pregnancy",
      "is_trimester",
      "is_lactation",
      "active",
      'created_by'
    ],
    // additionalProperties: false,
    // properties: {
      
    //   doctor_id: { type: 'integer' },
    //   patient_id: { type: 'integer' },
    //   health_record_details: { type: 'string' },
    //   past_illness: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   past_medicine: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   past_surgeries: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   history_of_allergy: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   previous_vacination: {
    //     type: "array",
    //     items: {
    //       type: "string"
    //     }
    //   },
    //   pregnancy: { type: 'integer' },
    //   is_trimester: { type: 'integer' },
    //   is_lactation: { type: 'integer' },
 
    //   active: { type: 'integer' },
    //   created_by: { type: "integer" }
    // }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getPastMedicalHistorySchema = {

  tags: ["GET PastMedicalHistory"],
  summary: "This API is to get PastMedicalHistory ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          doctor_id: { type: 'integer' },
          patient_id: { type: 'integer' },
          health_record_details: { type: 'string' },
          past_illness: {
            type: "array",
            items: {
              type: "string"
            }
          },
          past_medicine: {
            type: "array",
            items: {
              type: "string"
            }
          },
          past_surgeries: {
            type: "array",
            items: {
              type: "string"
            }
          },
          history_of_allergy: {
            type: "array",
            items: {
              type: "string"
            }
          },
          previous_vacination: {
            type: "array",
            items: {
              type: "string"
            }
          },
          pregnancy: { type: 'integer' },
          is_trimester: { type: 'integer' },
          is_lactation: { type: 'integer' },
     
          active: { type: 'integer' }
        }
      }
    },
    ...errorSchemas
  }
};

const deletePastMedicalHistorySchema = {
  tags: ["DELETE PastMedicalHistory"],
  summary: "This API is to delete PastMedicalHistory ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createPastMedicalHistorySchema,
  updatePastMedicalHistorySchema,
  getPastMedicalHistorySchema,
  deletePastMedicalHistorySchema
};
