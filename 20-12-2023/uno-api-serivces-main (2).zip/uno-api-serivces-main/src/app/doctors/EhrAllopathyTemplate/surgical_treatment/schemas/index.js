const getSurgicalTreatmentSchema = require("./getSurgicalTreatment");

module.exports = {
  getSurgicalTreatmentSchema
};
