const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { CustomError } = require("../../../../errorHandler");

const { CHEIFCOMPLAINTS } = require('../commons/constant');
const { PASTMEDICALHISTORY } = require('../commons/constant');
const { CLINICALEXAM } = require('../commons/constant');
const { PRESCRIPTION } = require('../commons/constant');
const { EXAMINATORY } = require('../commons/constant');
const { LABINVESTIGATION } = require('../commons/constant');
const { OTHERTREATMENT } = require('../commons/constant');
const { PROVISIONAL } = require('../commons/constant');
const { SURGICAL } = require('../commons/constant');
const { FINALDIAGNOSIS } = require('../commons/constant');


function getEhrPdfInfo(fastify) {

  async function cheifComplaint({ logTrace, params }) {
    const knex = this;

    const { patient_id, doctor_id } = params;

    const query = knex.select('*').from(CHEIFCOMPLAINTS.NAME)
      .where(CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(CHEIFCOMPLAINTS.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1)

    logQuery({
      logger: fastify.log,
      query,
      context: "Get cheifComplaints details",
      logTrace
    });
    const response = await query;

    return response;
  }

  async function pastMedicalhistory({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    const query = await knex
      .select('*')
      .from(PASTMEDICALHISTORY.NAME)
      .where(PASTMEDICALHISTORY.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get pastMedicalhistory details",
    //   logTrace
    // });
    const response = await query;

    return response;
  }

  async function clinicalexamination({ logTrace, params }) {
    const knex = this;

    const { patient_id, doctor_id } = params;
    const query = await knex
      .select('*').from(CLINICALEXAM.NAME)
      .where(CLINICALEXAM.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(CLINICALEXAM.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get clinicalexamination details",
    //   logTrace
    // });
    const response = await query;

    return response;
  }

  async function prescription({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    // const query = await knex
    // .select('*').from(CLINICALEXAM.NAME)
    // .where(CLINICALEXAM.COLUMNS.PATIENT_ID, patient_id)
    // .andWhere(CLINICALEXAM.COLUMNS.DOCTOR_ID, doctor_id)
    // .limit(1);

    const query = await knex.select('*').from(PRESCRIPTION.NAME)
      .where(PRESCRIPTION.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(PRESCRIPTION.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    //   logQuery({
    //     logger: fastify.log,
    //     query,
    //     context: "Get prescription details",
    //     logTrace
    //   });
    const response = await query;

    return response;
  }

  async function examinatory({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    const query = knex.select('*').from(EXAMINATORY.NAME)
      .where(EXAMINATORY.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(EXAMINATORY.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    //   logQuery({
    //     logger: fastify.log,
    //     query,
    //     context: "Get examinatory details",
    //     logTrace
    //   });
    const response = await query;

    return response;
  }

  async function finalDiagnosis({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    const query = knex.select('*').from(FINALDIAGNOSIS.NAME)
      .where(FINALDIAGNOSIS.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(FINALDIAGNOSIS.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get finalDiagnosis details",
    //   logTrace
    // });

    const response = await query;

    return response;
  }

  async function labInvestigation({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    const query = knex.select('*').from(LABINVESTIGATION.NAME)
      .where(LABINVESTIGATION.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(LABINVESTIGATION.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get labInvestigation details",
    //   logTrace
    // });
    const response = await query;

    return response;
  }

  async function otherTreatment({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    const query = knex.select('*').from(OTHERTREATMENT.NAME)
      .where(OTHERTREATMENT.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(OTHERTREATMENT.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get otherTreatment details",
    //   logTrace
    // });
    const response = await query;

    return response;
  }

  async function provisionalDiagnosis({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    const query = knex.select('*').from(PROVISIONAL.NAME)
      .where(PROVISIONAL.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(PROVISIONAL.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    // logQuery({
    //   logger: fastify.log,
    //   query,
    //   context: "Get provisionalDiagnosis details",
    //   logTrace
    // });
    const response = await query;

    return response;
  }

  async function surgicalTreatment({ logTrace, params }) {
    const knex = this;
    const { patient_id, doctor_id } = params;
    const query = knex.select('*').from(SURGICAL.NAME)
      .where(SURGICAL.COLUMNS.PATIENT_ID, patient_id)
      .andWhere(SURGICAL.COLUMNS.DOCTOR_ID, doctor_id)
      .limit(1);

    logQuery({
      logger: fastify.log,
      query,
      context: "Get surgicalTreatment details",
      logTrace
    });
    const response = await query;

    return response;
  }

  return {
    cheifComplaint,
    pastMedicalhistory,
    clinicalexamination,
    prescription,
    examinatory,
    finalDiagnosis,
    labInvestigation,
    otherTreatment,
    provisionalDiagnosis,
    surgicalTreatment

  }

}

module.exports = {
  getEhrPdfInfo
}