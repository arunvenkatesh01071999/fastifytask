const CHEIFCOMPLAINTS = {
    NAME: "e_cheif_complaints",
    COLUMNS: {
        ID: "id",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ISALLO_OR_AUYR: "isallo_or_auyr",
        APPOINT_ID: "appoint_id",
        CHEIF_COMPLIENTS: "cheif_complients",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const PASTMEDICALHISTORY = {
    NAME: "e_past_medical_history",
    COLUMNS: {
        ID: "id",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        HEALTH_RECORD_DETAILS: "health_record_details",
        PAST_ILLNESS: "past_illness",
        PAST_MEDICINE: "past_medicine",
        PAST_SURGERIES: "past_surgeries",
        HISTORY_OF_ALLERGY: "history_of_allergy",
        PREVIOUS_VACINATION: "previous_vacination",
        PREGNANCY: "pregnancy",
        IS_TRIMESTER: "is_trimester",
        IS_LACTATION: "is_lactation",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by",
        ACTIVE: "active"
    }
};

const CLINICALEXAM = {
    NAME: "e_clinical_examination",
    COLUMNS: {
        ID: "id",
        TEMPERATURE: "temperature",
        PULSE: "pulse",
        RESPIRATORY_RATE: "respiratory_rate",
        SP: "sp",
        HEART_RATE: "heart_rate",
        BLOOD_SYSTOLIC: "blood_systolic",
        BLOOD_DIASTOLIC: "blood_diastolic",
        HEIGHT: "height",
        WEIGHT: "weight",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        CLINICAL_EXAMINATION: "clinical_examination",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const PRESCRIPTION = {
    NAME: "e_e_prescription",
    COLUMNS: {
        ID: "id",
        MEDICINE_NAME: "medicine_name",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const EXAMINATORY = {
    NAME: "e_examinatory_notes",
    COLUMNS: {
        ID: "id",
        EXAMINATORY_NOTES: "examinatory_notes",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const FINALDIAGNOSIS = {
    NAME: "e_final_diagnosis",
    COLUMNS: {
        ID: "id",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        LIST_NAME: "list_name",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const LABINVESTIGATION = {
    NAME: "e_lab_investigation_report",
    COLUMNS: {
        ID: "id",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        LAB_TEST_CATEGORY_NAME: "lab_test_category_name",
        LAB_LINK: "lab_link",
        SCAN_TEST_NAME: "scan_test_name",
        SCAN_CENTER_LINK: "scan_center_link",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const OTHERTREATMENT = {
    NAME: "e_other_treatment",
    COLUMNS: {
        ID: "id",
        OTHER_TREATMENT: "other_treatment",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const PROVISIONAL = {
    NAME: "e_provisional_diagnosis",
    COLUMNS: {
        ID: "id",
        LIST_NAME: "list_name",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

const SURGICAL = {
    NAME: "e_surgical_treatment",
    COLUMNS: {
        ID: "id",
        LIST_NAME: "list_name",
        SURGICAL_HOSPITAL_LINK: "surgical_hospital_link",
        DOCTOR_ID: "doctor_id",
        PATIENT_ID: "patient_id",
        ACTIVE: "active",
        CREATED_AT: "created_at",
        UPDATED_AT: "updated_at",
        CREATED_BY: "created_by",
        UPDATED_BY: "updated_by"
    }
};

module.exports = {
    CHEIFCOMPLAINTS,
    PASTMEDICALHISTORY,
    CLINICALEXAM,
    PRESCRIPTION,
    EXAMINATORY,
    FINALDIAGNOSIS,
    LABINVESTIGATION,
    OTHERTREATMENT,
    PROVISIONAL,
    SURGICAL
};  