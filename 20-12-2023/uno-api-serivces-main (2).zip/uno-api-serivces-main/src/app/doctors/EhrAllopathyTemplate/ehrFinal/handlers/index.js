const getEhrPdfHandler = require("./getEhrPdfInfo");

module.exports = {
  getEhrPdfHandler
};
