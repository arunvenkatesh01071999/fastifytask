const getProvisionalDiagnosisHandler = require("./getProvisionalDiagnosisHandler.js");

module.exports = {
  getProvisionalDiagnosisHandler
};
