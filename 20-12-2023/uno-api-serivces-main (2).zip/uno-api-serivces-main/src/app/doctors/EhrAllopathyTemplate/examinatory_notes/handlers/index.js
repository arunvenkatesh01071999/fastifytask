const getExaminatoryNotesHandler = require("./getExaminatoryNotesHandler.js");

module.exports = {
  getExaminatoryNotesHandler
};
