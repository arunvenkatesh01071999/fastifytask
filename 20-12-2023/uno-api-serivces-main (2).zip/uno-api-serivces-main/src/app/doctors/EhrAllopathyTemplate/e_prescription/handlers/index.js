const getPrescriptionHandler = require("./getPrescriptionHandler.js");

module.exports = {
  getPrescriptionHandler
};
