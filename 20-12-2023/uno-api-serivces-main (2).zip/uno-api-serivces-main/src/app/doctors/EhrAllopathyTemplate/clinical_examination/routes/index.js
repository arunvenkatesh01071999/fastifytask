const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/clinical-exam",
    preHandler: fastify.authenticate,
    schema: schemas.getClinicalExamSchema.createClinicalExamSchema,
    handler: handlers.getClinicalExamHandler.createClinicalExamHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/clinical-exam/:patient_id",
    preHandler: fastify.authenticate,
    schema: schemas.getClinicalExamSchema.updateClinicalExamSchema,
    handler: handlers.getClinicalExamHandler.updateClinicalExamHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/clinical-exam",
    preHandler: fastify.authenticate,
    schema: schemas.getClinicalExamSchema.getClinicalExamSchema,
    handler: handlers.getClinicalExamHandler.getClinicalExamHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/clinical-exam/:patient_id/:doctor_id",
    preHandler: fastify.authenticate,
    schema: schemas.getClinicalExamSchema.getClinicalExamSchema,
    handler: handlers.getClinicalExamHandler.getClinicalExamHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/clinical-exam/:patient_id/:doctor_id",
    preHandler: fastify.authenticate,
    schema: schemas.getClinicalExamSchema.deleteClinicalExamSchema,
    handler: handlers.getClinicalExamHandler.deleteClinicalExamHandler(fastify)
  });

};
