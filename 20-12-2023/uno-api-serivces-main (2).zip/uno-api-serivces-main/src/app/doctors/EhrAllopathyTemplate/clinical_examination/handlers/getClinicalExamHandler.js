const getClinicalExamService = require("../services/getClinicalExamService");



function createClinicalExamHandler(fastify) {
  
  const createClinicalExam =
  getClinicalExamService.createClinicalExamServiceBasic(fastify);

  return async (request, reply) => {
    const { body, logTrace } = request;
    
    const response = await createClinicalExam({
      body,
      logTrace
    });
    return reply.code(200).send(response);
  };
  
}

function updateClinicalExamHandler(fastify) {
  const updateClinicalExam = getClinicalExamService.updateClinicalExamServiceBasic(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const response = await updateClinicalExam({
      body,
      params,
      logTrace
      
    });
    return reply.code(200).send(response);
  };
}

function getClinicalExamHandler(fastify) {

  const getClinicalExam = getClinicalExamService.getClinicalExamInfoService(fastify);

  return async (request, reply) => {

    const { logTrace } = request;
    const response = await getClinicalExam({
      logTrace
    });
    return reply.code(200).send(response);
  };

}

function getClinicalExamHandlerId(fastify) {

  const getClinicalExam = getClinicalExamService.getClinicalExamInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, params } = request;
    const response = await getClinicalExam({
      logTrace,
      params

    });
    return reply.code(200).send(response);
  };

}

function deleteClinicalExamHandler(fastify) {

  const deleteClinicalExam = getClinicalExamService.deleteClinicalExamServiceId(fastify);
  return async (request, reply) => {
    const {  params, logTrace } = request;
  
    const response = await deleteClinicalExam({
      params,
      logTrace
    });
    return reply.code(200).send(response);
  };
}

module.exports = {

  createClinicalExamHandler,
  updateClinicalExamHandler,
  getClinicalExamHandler,
  getClinicalExamHandlerId,
  deleteClinicalExamHandler
};
