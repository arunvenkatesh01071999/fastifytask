const doctorBasicInfoRepo = require("../repository/doctorBasicInfo");
const { getTransformBasicInfo } = require("../transformers/getDoctorBasicInfo");

function getDoctorBasicInfoService(fastify) {
  const {
    getDoctorBasicInfo,
    getDoctorEducationInfo,
    getDoctorAddressInfo,
    getDoctorLanguageInfo
  } = doctorBasicInfoRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const doctor_id = userDetails.response.id;
    const promise1 = getDoctorBasicInfo.call(knex, {
      doctor_id,
      logTrace
    });
    const promise2 = getDoctorEducationInfo.call(knex, {
      doctor_id,
      logTrace
    });
    const promise3 = getDoctorAddressInfo.call(knex, {
      doctor_id,
      logTrace
    });
    const promise4 = getDoctorLanguageInfo.call(knex, {
      doctor_id,
      logTrace
    });
    const [doctorInfo, educationInfoList, addressInfoList, languageInfoList] =
      await Promise.all([promise1, promise2, promise3, promise4]);

    return getTransformBasicInfo({
      doctorInfo,
      educationInfoList,
      addressInfoList,
      languageInfoList
    });
  };
}
module.exports = getDoctorBasicInfoService;