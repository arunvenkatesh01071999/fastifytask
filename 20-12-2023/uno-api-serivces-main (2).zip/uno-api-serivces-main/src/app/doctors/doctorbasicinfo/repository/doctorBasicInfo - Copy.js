const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { DOCTORBASICINFO } = require("../commons/constants");
const { DOCTOREDUCATIONINFO } = require("../commons/constants");
const { GENDER } = require("../../../masterData/commons/constants");
const { SPECIALITIES } = require("../../../masterData/commons/constants");
const { CustomError } = require("../../../errorHandler");
const {
  QUALIFICATIONMASTER
} = require("../../../masterData/commons/constants");

function doctorBasicInfoRepo(fastify) {
  async function getDoctorBasicInfo({ doctor_id, logTrace }) {
    const knex = this;
    const { ID, QUALIFICATION_NAME_ID, DOCTOR_NAME_ID } =
      DOCTOREDUCATIONINFO.COLUMNS;
    const query = knex
      .select([
        `BS.*`,
        `GENDER.${GENDER.COLUMNS.GENDER_NAME} as gender_name`,
        `SPECIALITIES.${SPECIALITIES.COLUMNS.SPECIALITIY_NAME} as speciality_name`,
        `EDUCATION.${ID} as education_info.${ID}`,
        `EDUCATION.qualification_name_id as education_info.qualification_name_id`,
        `QUALIFICATION.qualification as qualification_name`,
        `EDUCATION.doctor_name_id as education_info.doctor_name_id`,
        `EDUCATION.certificate_path as education_info.certificate_path`,
        `EDUCATION.active as education_info.active`,
        `EDUCATION.created_at as education_info.created_at`,
        `EDUCATION.updated_at as education_info.updated_at`,
        `EDUCATION.created_by as education_info.created_by`,
        `EDUCATION.updated_by as education_info.updated_by`
      ])
      .from(`${DOCTORBASICINFO.NAME} as BS`)
      .leftJoin(`${GENDER.NAME} as GENDER`, "BS.gender_id", "GENDER.id")
      .leftJoin(
        `${SPECIALITIES.NAME} as SPECIALITIES`,
        "BS.speciality_id",
        "SPECIALITIES.id"
      )
      .leftJoin(
        `${DOCTOREDUCATIONINFO.NAME} as EDUCATION`,
        "BS.id",
        "EDUCATION.doctor_name_id"
      )
      .leftJoin(
        `${QUALIFICATIONMASTER.NAME} as QUALIFICATION`,
        "EDUCATION.qualification_name_id",
        "QUALIFICATION.id"
      )
      .where("BS.active", "1")
      .where("BS.id", doctor_id);

    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Doctor info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }
  async function getDoctorEducationInfo({ doctor_id, logTrace }) {
    const knex = this;

    const query = knex(DOCTOREDUCATIONINFO.NAME).where(
      DOCTOREDUCATIONINFO.COLUMNS.DOCTOR_NAME_ID,
      doctor_id
    );

    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor education info details",
      logTrace
    });

    const response = await query;

    return response;
  }

  async function doctorLogins({ mobile, logTrace }) {
    const knex = this;
    const query = knex(DOCTORBASICINFO.NAME)
      .select(
        DOCTORBASICINFO.COLUMNS.ID,
        DOCTORBASICINFO.COLUMNS.EMAIL,
        DOCTORBASICINFO.COLUMNS.PHONE_NO,
        DOCTORBASICINFO.COLUMNS.DOB
      )
      .where(DOCTORBASICINFO.COLUMNS.PHONE_NO, mobile)
      .where(DOCTORBASICINFO.COLUMNS.ACTIVE, "1");

    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor login info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Customer not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response[0];
  }

  return {
    getDoctorBasicInfo,
    doctorLogins,
    getDoctorEducationInfo
  };
}

module.exports = doctorBasicInfoRepo;