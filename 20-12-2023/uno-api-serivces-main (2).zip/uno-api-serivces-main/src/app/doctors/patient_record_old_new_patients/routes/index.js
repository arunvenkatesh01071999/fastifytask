const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/patient-records-old-and-new-front",
  //  schema: schemas.getPatientRecordsSchema.getPatientRecordsSchema,
    handler: handlers.getPatientRecordsHandler.getPatientRecordsFrontHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/patient-records-old-and-new",
  //  schema: schemas.getPatientRecordsSchema.getPatientRecordsSchema,
    handler: handlers.getPatientRecordsHandler.getPatientRecordsDateFilterHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/patient-records-old-and-new-fullDetail",
  //  schema: schemas.getPatientRecordsSchema.getPatientRecordsSchema,
    handler: handlers.getPatientRecordsHandler.getPatientRecordsOldHandlerPost(fastify)
  });

};
