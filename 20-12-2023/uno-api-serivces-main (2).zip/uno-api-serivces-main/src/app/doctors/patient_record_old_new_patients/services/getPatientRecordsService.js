const getPatientRecordsRepository = require("../repository/getPatientRecordsRepository");


function getPatientRecordsFrontInfoServicePost(fastify) {

  const { PatientRecordsGetOne } = getPatientRecordsRepository.getPatientRecordsFrontRepositoryPost(fastify);

  return async ({ params, logTrace,body }) => {
    const knex = fastify.knexPatient;
    const promise1 = PatientRecordsGetOne.call(knex, {
      logTrace,
      body,
      params
    });
    const [getPatientRecordsOnedata] = await Promise.all([promise1]);
    return getPatientRecordsOnedata;
  }
}

function getPatientRecordsDateFilterInfoServicePost(fastify) {

  const { PatientRecordsGetOne } = getPatientRecordsRepository.getPatientRecordsDateFilterRepositoryPost(fastify);

  return async ({ params, logTrace,body }) => {
    const knex = fastify.knexPatient;
    const promise1 = PatientRecordsGetOne.call(knex, {
      logTrace,
      body,
      params
    });
    const [getPatientRecordsOnedata] = await Promise.all([promise1]);
    return getPatientRecordsOnedata;
  }
}

// function getPatientRecordsOldInfoServicePost(fastify) {

//   const { PatientRecordsGetOne } = getPatientRecordsRepository.getPatientRecordsOldRepositoryPost(fastify);

//   return async ({ params, logTrace,body }) => {
//     const knex = fastify.knexPatient;
//     const promise1 = PatientRecordsGetOne.call(knex, {
//       logTrace,
//       body,
//       params
//     });
//     const [getPatientRecordsOnedata] = await Promise.all([promise1]);
    
//     return getPatientRecordsOnedata;

//     // const groupedAndFiltered = groupByFileFlagAndTransform(response);
//     // return groupedAndFiltered;
//   }
// }

// const fileFlagMapping = {
//   1: "EHRS",
//   2: "PRESCRPTION",
//   3: "INVESTIGATION",
//   4: "DIAGNOSIS",
//   5: "LABREPORTS",
//   6: "SCANREPORTS"
// };
// // ...
// function groupByFileFlagAndTransform(records) {
//   const groupedRecords = {};
//   records.forEach(record => {
//     const { active, created_at, updated_at, created_by, updated_by, ...filteredRecord } = record;
//     const { file_flag } = filteredRecord;
//     const key = fileFlagMapping[file_flag];
//     if (!groupedRecords[key]) {
//       groupedRecords[key] = [];
//     }
//     groupedRecords[key].push(filteredRecord);
//   });
//   return groupedRecords;
// }
// ...




function getPatientRecordsOldInfoServicePost(fastify) {
  const { getPatientRocords, getDoctorInfo ,getDoctorInfoFull} = getPatientRecordsRepository.getPatientRecordsOldRepositoryPost(fastify);

  return async ({ body, params, logTrace }) => {
    const knex = fastify.knexPatient;
    const patient_id=body.patient_id;
    const response = await getPatientRocords.call(knex, {
      params,
      logTrace,
      body,
      patient_id
    })


    const doctorInfo = await Promise.all(
      response.map(async doctor => {
        let doctor_id = doctor.doctor_id;

        if (doctor_id > 0) {
          const docInfo = await getDoctorInfo({ doctor_id, logTrace });
          return {
            ...doctor,
            doctor_name: docInfo.doctor_name 
          };
        } else {
          return {
            ...doctor,
            doctor_name: "" 
          };
        }
      })
    )

    var groupedAndFiltered =  groupByFileFlagAndTransform(doctorInfo)
    
    var response2 = await getDoctorInfoFull.call(knex, {
      params,
      logTrace,
      body,
      patient_id
    })

    return {
      ...groupedAndFiltered,
      patientDetails: response2
    }

  };
}

function groupByFileFlagAndTransform(records) {
  const fileFlagMapping = {
    0: "PASTMEDICALS",
    1: "EHRS",
    2: "PRESCRPTION",
    3: "INVESTIGATION",
    4: "DIAGNOSIS",
    5: "LABREPORTS",
    6: "SCANREPORTS"
  };

  const groupedRecords = {
    PASTMEDICALS: [],
    EHRS: [],
    PRESCRPTION: [],
    INVESTIGATION: [],
    DIAGNOSIS: [],
    LABREPORTS: [],
    SCANREPORTS: []
  };

  records.forEach(record => {
    const { file_flag } = record;
    const fileFlagKey = fileFlagMapping[file_flag];
    if (fileFlagKey && groupedRecords[fileFlagKey]) {
      const {
        active,
        // created_at,
        updated_at,
        created_by,
        updated_by,
        ...filteredRecord
      } = record;
      groupedRecords[fileFlagKey].push(filteredRecord);
    }
  });

  return groupedRecords;
}

module.exports = {
  getPatientRecordsFrontInfoServicePost,
  getPatientRecordsDateFilterInfoServicePost,
  getPatientRecordsOldInfoServicePost

};
