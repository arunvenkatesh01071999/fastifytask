const PATIENTDETAILS = {
  NAME: "patient_details_img",
  COLUMNS: {
    ID: "id",
    PATIENT_UPLOAD: "patient_upload",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ACTIVE:"active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const PATIENT_RECORD = {
  NAME: "patient_record_details",
  COLUMNS: {
    ID: "id",
    PATIENT_ID: "patient_id",
    DOCTOR_ID: "doctor_id",
    FILE_PATH: "patient_file_path",
    FILE_FLAG: "file_flag",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const DOCTORBASICINFO = {
  NAME: "d_doctor_basic_info",
  COLUMNS: {
    ID: "id",
    HOSPITAL_ID: "hospital_name_id",
    DOCTOR_NAME: "doctor_name",
    GENDER_ID: "gender_id",
    SPECIALITY_ID: "speciality_id",
    EMAIL: "email",
    PHONE_NO: "phone_no",
    DOB: "dob",
    AGE: "age",
    ABOUT: "about",
    IMAGE_PATH: "image_path",
    SIGNATURE_PATH: "signature_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    DEVICETOKEN: "deviceToken"
  }
};
module.exports = {
    PATIENTDETAILS,
    PATIENT_RECORD,
    DOCTORBASICINFO
};
