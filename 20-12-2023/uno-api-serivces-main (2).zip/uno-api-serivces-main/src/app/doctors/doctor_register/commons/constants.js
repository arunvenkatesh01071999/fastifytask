const REGISTERINFO = {
  NAME: "d_doctor_basic_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME: "doctor_name",
    EMAIL: "email",
    GENDER_ID: "gender_id",
    SPECIALITY_ID: "speciality_id",
    DOB: "dob",
    AGE: "age",
    PHONE_NO: "phone_no",
    ABOUT: "about",
    IMAGE_PATH: "image_path",
    SIGNATURE_PATH: "signature_path",
    LAST_OTP: "last_otp",
    ADDCHECK: "addCheck",
    REASON: "reason",
    ISAPPROVED: "isApproved",
    DOCTOR_TYPE_ID: "doctor_type_id",
    // PROFILE_COMPLETION_PERCENTAGE: "profile_completion_percentage",
    HOSPITAL_NAME_ID: "hospital_name_id",
    APPROVED_BY: "approved_by",
    APPROVE_DATE: "approve_date",
    ACTIVE: "active",
    WORKPLACETYPE: "workplacetype",
    UPDATE_ON_WHATSAPP: "update_on_whatsapp",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    UPDATED_BY: "updated_by",
    DEVICETOKEN:"deviceToken"

  }

};

const ADDRESSINFO = {
  NAME: "d_address_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME_ID: "doctor_name_id",
    ADDRESS1: "address1",
    ADDRESS2: "address2",
    CITY_ID: "city_id",
    STATE_ID: "state_id",
    COUNTRY_ID: "country_id",
    PINCODE: "pincode",
    LOCATION: "location",
    LONGITUDE: "longitude",
    LATITUDE: "latitude",
    LONGITUDE1: "longitude1",
    LATITUDE1: "latitude1",
    PINCODE1: "pincode1",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }

};

const LANGUAGEINFO = {
  NAME: "d_language_info",
  COLUMNS: {
    ID: "id",
    LANGUAGE_NAME_id: "language_name_id",
    DOCTOR_NAME_ID: "doctor_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"

  }

};

module.exports = {
  REGISTERINFO,
  ADDRESSINFO,
  LANGUAGEINFO
};

