const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getDoctorRegisterSchema = {
  tags: ["GET DOCTOR REGISTER"],
  summary: "This API is to get DOCTOR REGISTER ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        // properties: {
        //   id: { type: "integer" },
        //   doctor_name: { type: "string" },
        //   gender_id: { type: "integer" },
        //   speciality_id: { type: "integer" },
        //   email: { type: "string" },
        //   phone_no: { type: "string" },
        //   dob: { type: "string" },
        //   age: { type: "integer" },
        //   about: { type: "string" },
        //   image_path: { type: "string" },
        //   signature_path: { type: "string" },
        //   active: { type: "integer" },

        //   created_at: { type: "string" },
        //   updated_at: { type: "string" },
        //   created_by: { type: "integer" },
        //   updated_by: { type: "integer" },

        //   addCheck: { type: "integer" },
        //   reason: { type: "string" },
        //   isApproved: { type: "integer" },
        //   doctor_type_id: { type: "integer" },
        //   hospital_name_id: { type: "integer" },
        //   approved_by: { type: "integer" },
        //   approve_date: { type: "string" },
        //   last_otp: { type: "string" },
        //   workplacetype: { type: "integer" },
        //   update_on_whatsapp: { type: "integer" }

          
        // }

        required: [
          'id', 'doctor_name', 'gender_id', 'speciality_id', 'email', 'phone_no', 'dob', 
          'update_on_whatsapp', 'address1', 'address2', 'city_id', 'country_id', 
          'latitude', 'latitude1', 'longitude', 'longitude1', 'pincode', 'pincode1', 
          'state_id', 'language_name_id'
        ]
      }
    },
    ...errorSchemas
  }
};

const getDoctorRegisterPostSchema = {
  tags: ["POST DOCTOR REGISTER"],
  summary: "This API is to Post DOCTOR REGISTER ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "doctor_name",
      "active"
    ]

  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getDoctorRegisterPutSchema = {
  tags: ["PUT DOCTOR REGISTER"],
  summary: "This API is to Put DOCTOR REGISTER ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "doctor_name",
      "active",

    ]
   
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

const getDoctorRegisterDeleteSchema = {
  tags: ["DELETE DOCTOR REGISTER"],
  summary: "This API is to delete Doctor Register ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {
  getDoctorRegisterSchema,
  getDoctorRegisterPostSchema,
  getDoctorRegisterPutSchema,
  getDoctorRegisterDeleteSchema
};
