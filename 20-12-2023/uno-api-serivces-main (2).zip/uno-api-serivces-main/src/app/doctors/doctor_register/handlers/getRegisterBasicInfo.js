const getRegInfos = require("../services/getRegInfoservices");
const fs = require("fs");
const util = require("util");
const { pipeline } = require("stream");
const { log } = require("console");
const pump = util.promisify(pipeline);


function getRegisterInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getallRegService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



function getRegisterInfoByIdHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getByIdRegService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getRegisterpostInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getPostRegService(fastify);

  return async (request, reply) => {
    
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}



function getRegisterputInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getPutRegService(fastify);

  return async (request, reply) => {

    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getRegisterdeleteInfoHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getDeleteRegService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}




function checkotp(fastify) {
  const getRegisterInfo =
    getRegInfos.getcheckotpService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      // logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}


function resendotp(fastify) {
  const getRegisterInfo =
    getRegInfos.getresendotpService(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      // logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}


function getdocInfoByIdHandler(fastify) {
  const getRegisterInfo =
    getRegInfos.getdocByIdRegService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getRegisterInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = {
  getRegisterInfoHandler,
  getRegisterInfoByIdHandler,
  getRegisterpostInfoHandler,
  getRegisterputInfoHandler,
  getRegisterdeleteInfoHandler,
  checkotp,
  resendotp,
  getdocInfoByIdHandler

};
