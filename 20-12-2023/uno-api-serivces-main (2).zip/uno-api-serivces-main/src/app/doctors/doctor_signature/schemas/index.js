const getDoctorSignatureSchema = require("./getDoctorSignature");

module.exports = {
  getDoctorSignatureSchema
};
