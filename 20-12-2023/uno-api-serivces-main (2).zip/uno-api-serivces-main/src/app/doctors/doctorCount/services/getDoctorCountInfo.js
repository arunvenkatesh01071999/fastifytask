const doccountBasicInfo = require("../repository/AvilDoctorCount");

function getAvilDocInfoService(fastify) {
  const { getalldocInfo } = doccountBasicInfo.getallBasicInfoRepo(fastify);

  return async ({ body, params, logTrace, userDetails }) => {
    const knex = fastify.knexMaster;
    const userlong = body.userlong;
    const userlat = body.userlat;
    const promise1 = getalldocInfo.call(knex, {
      logTrace,
      body,
      userlong,
      userlat
    });

    const [getalldocInfodata] = await Promise.all([promise1]);

    return getalldocInfodata;
  };
}

module.exports = {
  getAvilDocInfoService
};
