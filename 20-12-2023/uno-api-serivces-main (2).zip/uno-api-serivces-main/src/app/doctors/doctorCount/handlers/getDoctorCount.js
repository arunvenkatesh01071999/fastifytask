const getDoctorCountInfo = require("../services/getDoctorCountInfo");

function getavilDoctCountInfoHandler(fastify) {
  const getavilDoctorCountInfo =
    getDoctorCountInfo.getAvilDocInfoService(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await getavilDoctorCountInfo({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = getavilDoctCountInfoHandler;
