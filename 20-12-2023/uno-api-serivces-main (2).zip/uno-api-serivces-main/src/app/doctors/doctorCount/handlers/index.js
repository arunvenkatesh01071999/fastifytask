const getDoctorCountInfo = require("./getDoctorCount");

module.exports = {
  getDoctorCountInfo
};
