const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { HANDWRITTEN } = require("../commons/constants");
const { CustomError } = require("../../../errorHandler");

// function postHandWrittenRepositoryBasic(fastify) {
//   async function HandWrittenAdd({ logTrace, body,body ,userDetails }) {
    
//     const knex = this;

//     const query = await knex(`${HANDWRITTEN.NAME}`).insert({
//       [HANDWRITTEN.COLUMNS.HAND_WRITTEN_UPLOAD]: body.hand_written_upload,
//       [HANDWRITTEN.COLUMNS.ADD_FOLLOW_UP]: body.add_follow_up,
//       [HANDWRITTEN.COLUMNS.DOCTOR_ID]: body.doctor_id,
//       [HANDWRITTEN.COLUMNS.PATIENT_ID]: body.patient_id,
//       [HANDWRITTEN.COLUMNS.ACTIVE]: body.active,
//       [HANDWRITTEN.COLUMNS.CREATED_BY]: body.created_by
//     });

//     const response = await query;

//     return { success: true, message: "Insert successfully" };
//   }


//   return {
//     HandWrittenAdd

//   };
// }


function postHandWrittenRepositoryBasic(fastify) {
  async function HandWrittenAdd({ logTrace,body ,userDetails }) {
    
    const knex = this;

    const hand_written_upload = body.hand_written_upload;

    if (hand_written_upload !== '' && hand_written_upload !== undefined) {
      if (hand_written_upload.filename !== undefined && hand_written_upload.filename !== '') {
        const img = await UploadImageService(hand_written_upload, fastify);
        var imgurl = img.image_url;
      }
      else {
        var imgurl = null;
      }
    }
    else {
      var imgurl = null;
    }

    const query = await knex(`${HANDWRITTEN.NAME}`).insert({
      [HANDWRITTEN.COLUMNS.HAND_WRITTEN_UPLOAD]: imgurl,
      [HANDWRITTEN.COLUMNS.ADD_FOLLOW_UP]: body.add_follow_up.value,
      [HANDWRITTEN.COLUMNS.DOCTOR_ID]: body.doctor_id.value,
      [HANDWRITTEN.COLUMNS.PATIENT_ID]: body.patient_id.value,
      [HANDWRITTEN.COLUMNS.ACTIVE]: body.active.value,
      [HANDWRITTEN.COLUMNS.CREATED_BY]: body.created_by.value
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    HandWrittenAdd

  };
}

function updateHandWrittenRepository(fastify) {
  async function HandWrittenUpdate({
    logTrace,body,
    params,
    userDetails
     }) {
    const knex = this;
    const { patient_id } = params;

    // const hand_written_upload = body.hand_written_upload;
    // if (hand_written_upload.filename != '') {
    //   const img = await UploadImageService(hand_written_upload, fastify);
    //   var imgurl = img.image_url;
    // } else {
    //   var imgurl = null;
    // }

    const hand_written_upload = body.hand_written_upload;

    if (hand_written_upload !== '' && hand_written_upload !== undefined) {
      if (hand_written_upload.filename !== undefined && hand_written_upload.filename !== '') {
        const img = await UploadImageService(hand_written_upload, fastify);
        var imgurl = img.image_url;
      }
      else {
        var imgurl = null;
      }
    }
    else {
      var imgurl = null;
    }


    const query = await knex(`${HANDWRITTEN.NAME}`)
      .where(`${HANDWRITTEN.COLUMNS.PATIENT_ID}`, patient_id)
      .update({
        [HANDWRITTEN.COLUMNS.HAND_WRITTEN_UPLOAD]: imgurl,
        [HANDWRITTEN.COLUMNS.ADD_FOLLOW_UP]: body.add_follow_up.value,
        [HANDWRITTEN.COLUMNS.DOCTOR_ID]: body.doctor_id.value,
        [HANDWRITTEN.COLUMNS.PATIENT_ID]: body.patient_id.value,
        [HANDWRITTEN.COLUMNS.ACTIVE]: body.active.value,
        [HANDWRITTEN.COLUMNS.CREATED_BY]: body.created_by.value
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    HandWrittenUpdate,
  };
}

function getHandWrittenRepository(fastify) {
  
  async function HandWrittenGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.select('*').from(`${HANDWRITTEN.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Hand_Written details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hand_Written info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    HandWrittenGetAlls
  };

}


function getHandWrittenRepositoryId(fastify) {
  
  async function HandWrittenGetOne({ logTrace, params }) {
    
    const knex = this;
    const { patient_id } = params;
    const query = knex.select('*').from(`${HANDWRITTEN.NAME}`).where(`${HANDWRITTEN.COLUMNS.PATIENT_ID}`, patient_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Hand_Written details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Hand_Written info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    HandWrittenGetOne
  };

}

function deleteHandWrittenRepositoryId(fastify) {
  async function HandWrittenDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const { patient_id } = params;

    const query = await knex(`${HANDWRITTEN.NAME}`).where(`${HANDWRITTEN.COLUMNS.PATIENT_ID}`, patient_id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    HandWrittenDelete
  };
}


module.exports = {
  postHandWrittenRepositoryBasic,
  updateHandWrittenRepository,
  getHandWrittenRepository,
  getHandWrittenRepositoryId,
  deleteHandWrittenRepositoryId

};
