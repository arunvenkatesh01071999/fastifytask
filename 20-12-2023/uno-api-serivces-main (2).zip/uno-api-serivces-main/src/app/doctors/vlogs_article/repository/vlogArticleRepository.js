const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { VLOGS } = require("../commons/constants");

const { CustomError } = require("../../../errorHandler");

function postVlogArticleRepositoryBasic(fastify) {
  async function vlogArticleAdd({ logTrace, body }) {
    const knex = this;
    const query = await knex(`${VLOGS.NAME}`).insert({
      [VLOGS.COLUMNS.HEADING]: body.heading,
      [VLOGS.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [VLOGS.COLUMNS.LINK]: body.link,
      [VLOGS.COLUMNS.IS_VLOG]: body.is_vlog,
      [VLOGS.COLUMNS.IS_ARTICLE]: body.is_article,
      [VLOGS.COLUMNS.ACTIVE]: body.active,
      [VLOGS.COLUMNS.CREATED_BY]: body.created_by
    }).returning(VLOGS.COLUMNS.ID);

    const response = await query[0].id;
    return { success: true, message: "Insert successfully",id:response };
  }


  return {
    vlogArticleAdd

  };
}

function updateVlogArticleRepository(fastify) {
  async function vlogArticleUpdate({ logTrace, body, params }) {
    const knex = this;
    const id = params.id;
    const query = await knex(`${VLOGS.NAME}`)
      .where(`${VLOGS.COLUMNS.ID}`, id)
      .update({
        [VLOGS.COLUMNS.HEADING]: body.heading,
        [VLOGS.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [VLOGS.COLUMNS.LINK]: body.link,
        [VLOGS.COLUMNS.IS_VLOG]: body.is_vlog,
        [VLOGS.COLUMNS.IS_ARTICLE]: body.is_article,
        [VLOGS.COLUMNS.ACTIVE]: body.active,
        [VLOGS.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    vlogArticleUpdate,
  };
}

function getVlogArticleRepository(fastify) {

  async function vlogArticleGetAlls({ logTrace,params }) {

    const knex = this;
    const query = knex.select('*').from(`${VLOGS.NAME}`).where(`${VLOGS.COLUMNS.ACTIVE}`, 1)
    .where(`${VLOGS.COLUMNS.IS_VLOG}`, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get vlogs_articles details",
      logTrace
    });
   
    const response = await query
      .orderBy(VLOGS.COLUMNS.ID, "DESC")
      .paginate({
        pageSize: params.page_size,
        currentPage: params.current_page
      });
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "vlogs_articles info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    return response;
  }

  return {
    vlogArticleGetAlls
  };

}


function getVlogArticleRepositoryId(fastify) {

  async function vlogArticleGetOne({ logTrace, params }) {

    const knex = this;
    const doctor_id = params.doctor_id;
    const query = knex.select('*').from(`${VLOGS.NAME}`)
    .where(`${VLOGS.COLUMNS.DOCTOR_ID}`, doctor_id) 
    .where(`${VLOGS.COLUMNS.ACTIVE}`, 1)
    .where(`${VLOGS.COLUMNS.IS_VLOG}`, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get vlogs_articles details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Vlogs_Articles Info Not Found",
        property: "",
        code: "ID DOESN'T EXIST"
      });
    }
    return response;
  }

  return {
    vlogArticleGetOne
  };

}

function deleteVlogArticleRepositoryId(fastify) {
  async function vlogArticleDelete({
    logTrace,
    body,
    params,
    userDetails
  }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${VLOGS.NAME}`).where(`${VLOGS.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    vlogArticleDelete
  };
}
function getVlogArticleRepositorybyId(fastify) {

  async function vlogbyid({ logTrace, params }) {

    const knex = this;
    const id= params.id;
    const query = knex.select('*').from(`${VLOGS.NAME}`)
    .where(`${VLOGS.COLUMNS.ID}`, id) 
    .where(`${VLOGS.COLUMNS.ACTIVE}`, 1)
    .where(`${VLOGS.COLUMNS.IS_VLOG}`, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get vlogs_articles details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Vlogs_Articles Info Not Found",
        property: "",
        code: "ID DOESN'T EXIST"
      });
    }
    return response;
  }

  return {
    vlogbyid
  };

}

module.exports = {
  postVlogArticleRepositoryBasic,
  updateVlogArticleRepository,
  getVlogArticleRepository,
  getVlogArticleRepositoryId,
  deleteVlogArticleRepositoryId,
  getVlogArticleRepositorybyId

};
