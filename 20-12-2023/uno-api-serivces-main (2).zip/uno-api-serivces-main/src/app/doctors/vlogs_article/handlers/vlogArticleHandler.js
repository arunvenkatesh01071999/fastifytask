const vlogArticleService = require("../services/vlogArticleService");



function createVlogArticleHandler(fastify) {
  const createVlogArticle =
    vlogArticleService.createVlogArticleServiceBasic(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await createVlogArticle({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function updateVlogArticleHandler(fastify) {
  const updateVlogArticle = vlogArticleService.updateVlogArticleServiceBasic(fastify);

  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await updateVlogArticle({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

function getVlogArticleHandler(fastify) {

  const getVlogArticle = vlogArticleService.getVlogArticleInfoService(fastify);

  return async (request, reply) => {

    const { logTrace,params } = request;

    const response = await getVlogArticle({

      logTrace,params

    });
    return reply.code(200).send(response);
  };

}

function getVlogArticleHandlerId(fastify) {

  const getVlogArticle = vlogArticleService.getVlogArticleInfoServiceId(fastify);

  return async (request, reply) => {

    const { logTrace, body, params } = request;

    const response = await getVlogArticle({

      logTrace,
      body,
      params

    });
    return reply.code(200).send(response);
  };

}

function getVlogArticleHandlerbyid(fastify) {

  const getVlogArticle = vlogArticleService.getVlogArticleInfoServicebyId(fastify);

  return async (request, reply) => {

    const { logTrace, body, params } = request;

    const response = await getVlogArticle({

      logTrace,
      body,
      params

    });
    return reply.code(200).send(response);
  };

}

function deleteVlogArticleHandler(fastify) {

  const deleteVlogArticle = vlogArticleService.deleteVlogArticleServiceId(fastify);
  return async (request, reply) => {
    const { body, params, logTrace } = request;
    const { userDetails } = request;
    const response = await deleteVlogArticle({
      body,
      params,
      logTrace,
      userDetails
    });
    return reply.code(200).send(response);
  };
}

module.exports = {

  createVlogArticleHandler,
  updateVlogArticleHandler,
  getVlogArticleHandler,
  getVlogArticleHandlerId,
  deleteVlogArticleHandler,
  getVlogArticleHandlerbyid
};
