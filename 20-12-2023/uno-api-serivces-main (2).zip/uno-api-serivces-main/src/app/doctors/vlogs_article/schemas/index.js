const vlogArticleSchema = require("./vlogArticleSchema");

module.exports = {
  vlogArticleSchema
};
