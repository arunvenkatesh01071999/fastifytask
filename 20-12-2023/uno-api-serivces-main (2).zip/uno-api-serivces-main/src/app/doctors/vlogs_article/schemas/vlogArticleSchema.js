const { errorSchemas } = require("../../../commons/schemas/errorSchemas");


const createVlogArticleSchema = {
  tags: ["POST Vlogs_Articles"],
  summary: "This API is to Post Vlogs_Articles ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: [
      "heading",
      "doctor_id",
      "link",
      "is_vlog",
      "is_article",
      "active"
    ],
    additionalProperties: false,
    properties: {
      heading: { type: "string" },
      doctor_id: { type: "integer" },
      link: { type: "string" },
      is_vlog: { type: "integer" },
      is_article: { type: "integer" },
      active: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" },
        id: { type: "integer" }
      }
    },
    ...errorSchemas
  }
};

const updateVlogArticleSchema = {
  tags: ["PUT Vlogs_Articles"],
  summary: "This API is to Update Vlogs_Articles ",
  headers: { $ref: "request-headers#" },
  params: {
    type: 'object',
    properties: {
      id: { type: 'integer' },
    },
    required: ['id'],
  },
  body: {
    type: "object",
    required: [
      "doctor_id",
      "heading",
      "link",
      "is_vlog",
      "is_article",
      "active"
    ],
    additionalProperties: false,
    properties: {
      doctor_id: { type: 'integer' },
      heading: { type: 'string' },
      link: { type: 'string' }, // Assuming it's a valid URL
      is_vlog: { type: 'integer', enum: [0, 1] }, // Assuming it's 0 or 1
      is_article: { type: 'integer', enum: [0, 1] }, // Assuming it's 0 or 1
      active: { type: 'integer', enum: [0, 1] },
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};


const getVlogArticleSchema = {

  tags: ["GET Vlogs_Articles"],
  summary: "This API is to get Vlogs_Articles ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          id: { type: "integer" },
          doctor_id: { type: 'integer' },
          heading: { type: "string" },
          link: { type: "string" },
          is_vlog: { type: "integer" },
          is_article: { type: "integer" },
          active: { type: "integer" }
        }
      }
    },
    ...errorSchemas
  }
};

const deleteVlogArticleSchema = {
  tags: ["DELETE Vlogs_Articles"],
  summary: "This API is to delete Vlogs_Articles ",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" },
        message: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = {

  createVlogArticleSchema,
  updateVlogArticleSchema,
  getVlogArticleSchema,
  deleteVlogArticleSchema
};
