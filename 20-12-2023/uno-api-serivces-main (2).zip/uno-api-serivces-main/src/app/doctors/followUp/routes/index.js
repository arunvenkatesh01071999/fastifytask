const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
    fastify.route({
        method: "POST",
        url: "/d_follow_up",
        // preHandler: fastify.authenticate,
        // schema: schemas.getFollowUpDetailInfo.getFollowUpSchema,
        handler: handlers.getFollowUpDetailInfo.getFollowUpInfoHandler(fastify)
    });

    fastify.route({
        method: "POST",
        url: "/d_ehr_submit",
        // preHandler: fastify.authenticate,
        // schema: schemas.getFollowUpDetailInfo.getFollowUpSchema,
        handler: handlers.getFollowUpDetailInfo.getehrsubmitInfoHandler(fastify)
    });

//-----------------------------ADMIN PANEL -----------------

    fastify.route({
        method: "POST",
        url: "/d_admin_follow_up",
        // preHandler: fastify.authenticate,
        // schema: schemas.getFollowUpDetailInfo.getFollowUpSchema,
        handler: handlers.getFollowUpDetailInfo.adminFollowUpInfoHandler(fastify)
    });

}