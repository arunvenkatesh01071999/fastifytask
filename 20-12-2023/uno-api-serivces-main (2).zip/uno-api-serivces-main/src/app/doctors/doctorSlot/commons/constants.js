const DOCTORAVILSLOTINFO = {
  NAME: "doct_avil_slot",
  COLUMNS: {
    ID: "id",
    CHECK_WALKING: "check_walking",
    DOCTOR_NAME_ID: "doctor_name_id",
    DURATION: "duration",
    INSTANT_CONSULATION: "instant_consulation",
    VIDEO: "video",
    WALKIN: "walkin",
    DAY: "day",
    SLOT_ACTIVE: "slot_active",
    SLOT_1: "slot_1",
    SLOT_2: "slot_2",
    SLOT_3: "slot_3",
    ACTIVE: "active",
    IS_24HRS:"is_24hrs",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }


};
module.exports = {
  DOCTORAVILSLOTINFO
};

