// const { StatusCodes } = require("http-status-codes");
// const { logQuery } = require("../../../commons/helpers");
// const { DOCTORAVILSLOTINFO } = require("../commons/constants");
// const sms = require("../../../notification/repository/sms");
// const nodemailer = require('nodemailer');
// const previewEmail = require('preview-email');


// const { CustomError } = require("../../../errorHandler");

// function SlotAllRepo(fastify) {
//   async function getslotall({ logTrace }) {
//     const knex = this;
//     const query = knex.select(`*`).from(`${DOCTORAVILSLOTINFO.NAME}`);
//     logQuery({
//       logger: fastify.log,
//       query,
//       context: "Get Slot details",
//       logTrace
//     });

//     const response = await query;
//     if (!response.length) {
//       throw CustomError.create({
//         httpCode: StatusCodes.NOT_FOUND,
//         message: "Slot info not found",
//         property: "",
//         code: "NOT_FOUND"
//       });
//     }
//     return response;
//   }

//   return {
//     getslotall
//   };
// }


// function SlotGetByIdRepo(fastify) {
//   async function getslotById({ logTrace, body, params }) {
//     const knex = this;
//     var doctor_name_id = params.doctor_name_id;
//     const query =  knex.select(`*`).from(`${DOCTORAVILSLOTINFO.NAME}`)
//       .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, doctor_name_id);
//     logQuery({
//       logger: fastify.log,
//       query,
//       context: "Get Slot details",
//       logTrace
//     });

//     const response = await query;
//     if (!response.length) {
//       throw CustomError.create({
//         httpCode: StatusCodes.NOT_FOUND,
//         message: "Slot info not found",
//         property: "",
//         code: "NOT_FOUND"
//       });
//     }
//     return response;
//   }

//   return {
//     getslotById
//   };
// }




// function SlotaddRepo(fastify) {
//   async function getSlotadd({ logTrace, body, params, sl_data }) {
//     const knex = this;

//     const sl_data2 = {
//       created_by: 2,
//       updated_by: 2,
//     }

//     const query = knex(`${DOCTORAVILSLOTINFO.NAME}`).insert({
//       [DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID]: sl_data.doctor_name_id,
//       [DOCTORAVILSLOTINFO.COLUMNS.DAY]: sl_data.day,
//       [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_1]: sl_data.slot_1,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_2]: sl_data.slot_2,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_3]: sl_data.slot_3,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_ACTIVE]: sl_data.slot_active,
//       [DOCTORAVILSLOTINFO.COLUMNS.CHECK_WALKING]: sl_data.check_walking,
//       [DOCTORAVILSLOTINFO.COLUMNS.DURATION]: sl_data.duration,
//       [DOCTORAVILSLOTINFO.COLUMNS.INSTANT_CONSULATION]: sl_data.instant_consulation,
//       [DOCTORAVILSLOTINFO.COLUMNS.VIDEO]: sl_data.video,
//       [DOCTORAVILSLOTINFO.COLUMNS.WALKIN]: sl_data.walkin,
//       [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
//       [DOCTORAVILSLOTINFO.COLUMNS.IS_24HRS]: sl_data.is_24hrs,
//       [DOCTORAVILSLOTINFO.COLUMNS.CREATED_BY]: sl_data2.created_by,
//       [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_BY]: sl_data2.updated_by,
//       [DOCTORAVILSLOTINFO.COLUMNS.CREATED_AT]: new Date(),
//       [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_AT]: new Date()
//     });

//     const response = await query;
//     return { success: true, message: "Insert successfully" };


//   }

//   return {
//     getSlotadd
//   };
// }

// function SlotputRepo(fastify) {
//   async function getslotput({ logTrace, body, params, convertedData, userDetails, sl_data }) {
//     const knex = this;
    

//     const sl_data2 = {
//       created_by: 2,
//       updated_by: 2,
//     }

//     const query = knex(`${DOCTORAVILSLOTINFO.NAME}`).insert({
//       [DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID]: sl_data.doctor_name_id,
//       [DOCTORAVILSLOTINFO.COLUMNS.DAY]: sl_data.day,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_1]: sl_data.slot_1,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_2]: sl_data.slot_2,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_3]: sl_data.slot_3,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_ACTIVE]: sl_data.slot_active,
//       [DOCTORAVILSLOTINFO.COLUMNS.CHECK_WALKING]: sl_data.check_walking,
//       [DOCTORAVILSLOTINFO.COLUMNS.DURATION]: sl_data.duration,
//       [DOCTORAVILSLOTINFO.COLUMNS.INSTANT_CONSULATION]: sl_data.instant_consulation,
//       [DOCTORAVILSLOTINFO.COLUMNS.VIDEO]: sl_data.video,
//       [DOCTORAVILSLOTINFO.COLUMNS.WALKIN]: sl_data.walkin,
//       [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
//       [DOCTORAVILSLOTINFO.COLUMNS.IS_24HRS]: sl_data.is_24hrs,
//       [DOCTORAVILSLOTINFO.COLUMNS.CREATED_BY]: sl_data2.created_by,
//       [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_BY]: sl_data2.updated_by,
//       [DOCTORAVILSLOTINFO.COLUMNS.CREATED_AT]: new Date(),
//       [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_AT]: new Date()
//     });

//     const response = await query;
//     return { success: true, message: "Updated successfully" };


//   }

//   return {
//     getslotput
//   };
// }

// function SlotgetReturnRepo(fastify) {
//   async function getslotReturn({ logTrace, body }) {
//     const knex = this;
//     var data = {};
//     data = body;
//     return data;
//   }

//   return {
//     getslotReturn
//   };
// }

// // function RegDeleteRepo(fastify) {
// //   async function getregdelete({ logTrace, body, params, userDetails }) {
// //     const knex = this;

// //     const { id } = params;

// //     const query = await knex(`${REGISTERINFO.NAME}`)
// //       .where(`${REGISTERINFO.COLUMNS.ID}`, id)
// //       .del();

// //     const response = await query;

// //     return { success: true, message: "Deleted successfully" };
// //   }

// //   return {
// //     getregdelete
// //   };
// // }

// // function generateotpRepo(fastify) {
// //   const { sendSms } = sms(fastify);
// //   async function getotp({  body, params, userDetails }) {
// //     const knex = this;

// //     const phone_number  = body.mobile;
// //     const otp = Math.floor(1000 + Math.random() * 9000).toString();
// // const  message=otp;

// // const promise1 = sendSms.call(knex, {
// //   phone_number, message
// // });

// // const transporter = nodemailer.createTransport({
// //   service: 'Gmail',
// //   auth: {
// //     user: 'Pradhapbothan119@gmail.com',
// //     pass: '9524203556'
// //   }
// // });
// // const mailOptions = {
// //   from:'Pradhapbothan119@gmail.com',
// //   to: 'sivanandhini0307@gmail.com',
// //   subject: 'Test Email',
// //   text: 'This is a test email sent from Node.js using nodemailer!'
// // };
// // transporter.sendMail(mailOptions, (error, info) => {
// //   if (error) {
// //     console.error('Error occurred:', error);
// //   } else {
// //     console.log('Email sent:', info.response);
// //   }
// // });

// // const transport = nodemailer.createTransport({
// //   jsonTransport: true
// // });

// // // <https://nodemailer.com/message/>
// // const message = {
// //   from:'Pradhapbothan119@gmail.com',
// //   to: 'sivanandhini0307@gmail.com',
// //   subject: 'Hello world',
// //   html: '<p>Hello world</p>',
// //   text: 'Hello world',
// //   // attachments: [{ filename: 'hello-world.txt', content: 'Hello world' }]
// // };

// // note that `attachments` will not be parsed unless you use
// // `previewEmail` with the results of `transport.sendMail`
// // e.g. `previewEmail(JSON.parse(res.message));` where `res`
// // is `const res = await transport.sendMail(message);`
// // previewEmail(message).then(console.log).catch(console.error);

// // transport.sendMail(message).then(console.log).catch(console.error);



// // D:\prathap\fastify\uno-api-serivces\src\app\notification\repository\sms.js
// // console.log('mobile', mobile);
// // const query = await knex(`${REGISTERINFO.NAME}`)
// //   .where(`${REGISTERINFO.COLUMNS.ID}`, id)
// //   .del();
// // const response = await query;
// // return promise1;
// // }
// // return {
// //   getotp
// // };
// // }

// module.exports = {
//   SlotAllRepo,
//   SlotGetByIdRepo,
//   SlotaddRepo,
//   SlotputRepo,
//   SlotgetReturnRepo
//   // RegDeleteRepo,
//   // generateotpRepo
// };



const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { DOCTORAVILSLOTINFO } = require("../commons/constants");
const sms = require("../../../notification/repository/sms");
const nodemailer = require('nodemailer');
const previewEmail = require('preview-email');
const addCheck = require("../../../commons/addcheck");
const { CustomError } = require("../../../errorHandler");

function SlotAllRepo(fastify) {
  async function getslotall({ logTrace }) {
    const knex = this;
    const query = knex.select(`*`).from(`${DOCTORAVILSLOTINFO.NAME}`);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Slot details",
      logTrace
    });

    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Slot info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    getslotall
  };
}


// function SlotGetByIdRepo(fastify) {
//   async function getslotById({ logTrace, body, params }) {
//     const knex = this;
//     var doctor_name_id = params.doctor_name_id;
//     const query =  knex.select(`*`).from(`${DOCTORAVILSLOTINFO.NAME}`)
//       .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, doctor_name_id);
//     logQuery({
//       logger: fastify.log,
//       query,
//       context: "Get Slot details",
//       logTrace
//     });

//     const response = await query;
//     if (!response.length) {
//       throw CustomError.create({
//         httpCode: StatusCodes.NOT_FOUND,
//         message: "Slot info not found",
//         property: "",
//         code: "NOT_FOUND"
//       });
//     }
//     return response;
//   }

//   return {
//     getslotById
//   };
// }
function SlotGetByIdRepo(fastify) {
  async function getslotById({ logTrace, body, params }) {
    const knex = this;
    var doctor_name_id = params.doctor_name_id;
    const query =  knex.select(`*`).from(`${DOCTORAVILSLOTINFO.NAME}`)
      .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, doctor_name_id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Slot details",
      logTrace
    });
    const responseData = await query;
    console.log('responseData',responseData);
    if (responseData.length==0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Not Exist This Patient-ID",
        property: "",
        code: "NOT_FOUND"
      });
    }
    const transformedData = {
      "check_walking": responseData[0].check_walking,
      "duration": responseData[0].duration,
      "doctor_name_id": responseData[0].doctor_name_id,
      "instant_consulation": responseData[0].instant_consulation,
      "video": responseData[0].video,
      "walkin": responseData[0].walkin,
      "created_by": responseData[0].created_by,
      "updated_by": responseData[0].updated_by,
      "active": responseData[0].active,
      "day": {}
  };
  // Iterate through the original data to structure it by days
  responseData.forEach(dayData => {
      transformedData.day[dayData.day] = {
          "slot_active": dayData.slot_active,
          "is_24hrs": dayData.is_24hrs,
          "slot_1": dayData.slot_1.split(',').filter(Boolean), // Split and remove empty elements
          "slot_2": dayData.slot_2.split(',').filter(Boolean),
          "slot_3": dayData.slot_3.split(',').filter(Boolean),
      };
  });
  const final=JSON.stringify(transformedData, null, 2);
    if (final.length==0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Slot info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return final;
  }
  return {
    getslotById
  };
}




// function SlotaddRepo(fastify) {
//   async function getSlotadd({ logTrace, body, params, sl_data }) {
//     const knex = this;

    
//     const sl_data2 = {
//       created_by: 2,
//       updated_by: 2,
//     }

//     const query = knex(`${DOCTORAVILSLOTINFO.NAME}`).insert({
//       [DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID]: sl_data.doctor_name_id,
//       [DOCTORAVILSLOTINFO.COLUMNS.DAY]: sl_data.day,
//       [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_1]: sl_data.slot_1,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_2]: sl_data.slot_2,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_3]: sl_data.slot_3,
//       [DOCTORAVILSLOTINFO.COLUMNS.SLOT_ACTIVE]: sl_data.slot_active,
//       [DOCTORAVILSLOTINFO.COLUMNS.CHECK_WALKING]: sl_data.check_walking,
//       [DOCTORAVILSLOTINFO.COLUMNS.DURATION]: sl_data.duration,
//       [DOCTORAVILSLOTINFO.COLUMNS.INSTANT_CONSULATION]: sl_data.instant_consulation,
//       [DOCTORAVILSLOTINFO.COLUMNS.VIDEO]: sl_data.video,
//       [DOCTORAVILSLOTINFO.COLUMNS.WALKIN]: sl_data.walkin,
//       [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
//       [DOCTORAVILSLOTINFO.COLUMNS.IS_24HRS]: sl_data.is_24hrs,
//       [DOCTORAVILSLOTINFO.COLUMNS.CREATED_BY]: sl_data2.created_by,
//       [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_BY]: sl_data2.updated_by,
//       [DOCTORAVILSLOTINFO.COLUMNS.CREATED_AT]: new Date(),
//       [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_AT]: new Date()
//     });

//     const response = await query;
//     return { success: true, message: "Insert successfully" };


//   }

//   return {
//     getSlotadd
//   };
// }


function SlotaddRepo(fastify) {
  async function getSlotadd({ logTrace, body, params }) {
    const knex = this;
    const uniqueDoctorNameId = body.doctor_name_id;
    const sl_data2 = {
      created_by: 2,
      updated_by: 2,
    }
    const query2 = knex.raw(`select * from doct_avil_slot where doctor_name_id =${uniqueDoctorNameId}`);
    const response1 = await query2;
    const responseLength = response1.length;
    var data = body.day;
    if (responseLength === 0) {
      const keys = Object.keys(data);
      for (let i = 0; i < keys.length; i++) {
        const day = keys[i];
        const timings = data[day];
        const slot_active = timings.slot_active;
        const slot_1 = timings.slot_1;
        const slot_2 = timings.slot_2;
        const slot_3 = timings.slot_3;
        const is_24hrs = timings.is_24hrs;
        const sl_data = {
          doctor_name_id: parseInt(body.doctor_name_id),
          day: `${day}`,
          slot_1: `${slot_1.join(',')}`,
          slot_2: `${slot_2.join(',')}`,
          slot_3: `${slot_3.join(',')}`,
          slot_active: slot_active,
          is_24hrs: is_24hrs,
          check_walking: body.check_walking,
          duration: body.duration,
          instant_consulation: body.instant_consulation,
          video: body.video,
          walkin: body.walkin,
          active: body.active,
          created_by: body.created_by
        };
        const query = await knex(`${DOCTORAVILSLOTINFO.NAME}`).insert({
          [DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID]: sl_data.doctor_name_id,
          [DOCTORAVILSLOTINFO.COLUMNS.DAY]: sl_data.day,
          [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
          [DOCTORAVILSLOTINFO.COLUMNS.SLOT_1]: sl_data.slot_1,
          [DOCTORAVILSLOTINFO.COLUMNS.SLOT_2]: sl_data.slot_2,
          [DOCTORAVILSLOTINFO.COLUMNS.SLOT_3]: sl_data.slot_3,
          [DOCTORAVILSLOTINFO.COLUMNS.SLOT_ACTIVE]: sl_data.slot_active,
          [DOCTORAVILSLOTINFO.COLUMNS.CHECK_WALKING]: sl_data.check_walking,
          [DOCTORAVILSLOTINFO.COLUMNS.DURATION]: sl_data.duration,
          [DOCTORAVILSLOTINFO.COLUMNS.INSTANT_CONSULATION]: sl_data.instant_consulation,
          [DOCTORAVILSLOTINFO.COLUMNS.VIDEO]: sl_data.video,
          [DOCTORAVILSLOTINFO.COLUMNS.WALKIN]: sl_data.walkin,
          [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
          [DOCTORAVILSLOTINFO.COLUMNS.IS_24HRS]: sl_data.is_24hrs,
          [DOCTORAVILSLOTINFO.COLUMNS.CREATED_BY]: sl_data2.created_by,
          [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_BY]: sl_data2.updated_by,
          [DOCTORAVILSLOTINFO.COLUMNS.CREATED_AT]: new Date(),
          [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_AT]: new Date()
        });
      }
      // const response = await query;
      const setvalue=25;
      const doctor_name_id=uniqueDoctorNameId;
      const addcheck = await addCheck(setvalue,doctor_name_id,fastify);
      return { success: true, message: "Insert successfully" };
    }
    else {
      const dr_id_num = knex
        .select(`*`)
        .from(`${DOCTORAVILSLOTINFO.NAME}`)
        .where(`${DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID}`, body.doctor_name_id);
      const dr_id_num_response = await dr_id_num;
      if (dr_id_num_response.length > 0) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Doctor Id Already Exists",
          property: "",
          code: "NOT_FOUND"
        });
      }
    }
  }
  return {
    getSlotadd
  };
}

function SlotputRepo(fastify) {
  async function getslotput({ logTrace, body, params, convertedData, userDetails, sl_data }) {
    const knex = this;
    

    const sl_data2 = {
      created_by: 2,
      updated_by: 2,
    }

    const query = knex(`${DOCTORAVILSLOTINFO.NAME}`).insert({
      [DOCTORAVILSLOTINFO.COLUMNS.DOCTOR_NAME_ID]: sl_data.doctor_name_id,
      [DOCTORAVILSLOTINFO.COLUMNS.DAY]: sl_data.day,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_1]: sl_data.slot_1,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_2]: sl_data.slot_2,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_3]: sl_data.slot_3,
      [DOCTORAVILSLOTINFO.COLUMNS.SLOT_ACTIVE]: sl_data.slot_active,
      [DOCTORAVILSLOTINFO.COLUMNS.CHECK_WALKING]: sl_data.check_walking,
      [DOCTORAVILSLOTINFO.COLUMNS.DURATION]: sl_data.duration,
      [DOCTORAVILSLOTINFO.COLUMNS.INSTANT_CONSULATION]: sl_data.instant_consulation,
      [DOCTORAVILSLOTINFO.COLUMNS.VIDEO]: sl_data.video,
      [DOCTORAVILSLOTINFO.COLUMNS.WALKIN]: sl_data.walkin,
      [DOCTORAVILSLOTINFO.COLUMNS.ACTIVE]: sl_data.active,
      [DOCTORAVILSLOTINFO.COLUMNS.IS_24HRS]: sl_data.is_24hrs,
      [DOCTORAVILSLOTINFO.COLUMNS.CREATED_BY]: sl_data2.created_by,
      [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_BY]: sl_data2.updated_by,
      [DOCTORAVILSLOTINFO.COLUMNS.CREATED_AT]: new Date(),
      [DOCTORAVILSLOTINFO.COLUMNS.UPDATED_AT]: new Date()
    });

    const response = await query;
    return { success: true, message: "Updated successfully" };


  }

  return {
    getslotput
  };
}

function SlotgetReturnRepo(fastify) {
  async function getslotReturn({ logTrace, body }) {
    const knex = this;
    var data = {};
    data = body;
    return data;
  }

  return {
    getslotReturn
  };
}

// function RegDeleteRepo(fastify) {
//   async function getregdelete({ logTrace, body, params, userDetails }) {
//     const knex = this;

//     const { id } = params;

//     const query = await knex(`${REGISTERINFO.NAME}`)
//       .where(`${REGISTERINFO.COLUMNS.ID}`, id)
//       .del();

//     const response = await query;

//     return { success: true, message: "Deleted successfully" };
//   }

//   return {
//     getregdelete
//   };
// }

// function generateotpRepo(fastify) {
//   const { sendSms } = sms(fastify);
//   async function getotp({  body, params, userDetails }) {
//     const knex = this;

//     const phone_number  = body.mobile;
//     const otp = Math.floor(1000 + Math.random() * 9000).toString();
// const  message=otp;

// const promise1 = sendSms.call(knex, {
//   phone_number, message
// });

// const transporter = nodemailer.createTransport({
//   service: 'Gmail',
//   auth: {
//     user: 'Pradhapbothan119@gmail.com',
//     pass: '9524203556'
//   }
// });
// const mailOptions = {
//   from:'Pradhapbothan119@gmail.com',
//   to: 'sivanandhini0307@gmail.com',
//   subject: 'Test Email',
//   text: 'This is a test email sent from Node.js using nodemailer!'
// };
// transporter.sendMail(mailOptions, (error, info) => {
//   if (error) {
//     console.error('Error occurred:', error);
//   } else {
//     console.log('Email sent:', info.response);
//   }
// });

// const transport = nodemailer.createTransport({
//   jsonTransport: true
// });

// // <https://nodemailer.com/message/>
// const message = {
//   from:'Pradhapbothan119@gmail.com',
//   to: 'sivanandhini0307@gmail.com',
//   subject: 'Hello world',
//   html: '<p>Hello world</p>',
//   text: 'Hello world',
//   // attachments: [{ filename: 'hello-world.txt', content: 'Hello world' }]
// };

// note that `attachments` will not be parsed unless you use
// `previewEmail` with the results of `transport.sendMail`
// e.g. `previewEmail(JSON.parse(res.message));` where `res`
// is `const res = await transport.sendMail(message);`
// previewEmail(message).then(console.log).catch(console.error);

// transport.sendMail(message).then(console.log).catch(console.error);



// D:\prathap\fastify\uno-api-serivces\src\app\notification\repository\sms.js
// console.log('mobile', mobile);
// const query = await knex(`${REGISTERINFO.NAME}`)
//   .where(`${REGISTERINFO.COLUMNS.ID}`, id)
//   .del();
// const response = await query;
// return promise1;
// }
// return {
//   getotp
// };
// }

module.exports = {
  SlotAllRepo,
  SlotGetByIdRepo,
  SlotaddRepo,
  SlotputRepo,
  SlotgetReturnRepo
  // RegDeleteRepo,
  // generateotpRepo
};

