const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const doctorLoginSchema = {
  tags: ["LOGIN DOCTORS"],
  summary: "This API is used to login ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["phone_no"],
    additionalProperties: false,
    properties: {
      phone_no: { type: "string" },
      hash: { type: "string" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        doctor_id: { type: "integer" }
      }
    },
    ...errorSchemas
  }
};

const doctorVerifySchemas = {
  tags: ["LOGIN DOCTORS"],
  summary: "This API is used to login ",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["otp", "doctor_name_id"],
    additionalProperties: false,
    properties: {
      otp: { type: "string" },
      doctor_name_id: { type: "string" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        token: { type: "string" }
      }
    },
    ...errorSchemas
  }
};

module.exports = { doctorLoginSchema, doctorVerifySchemas };
