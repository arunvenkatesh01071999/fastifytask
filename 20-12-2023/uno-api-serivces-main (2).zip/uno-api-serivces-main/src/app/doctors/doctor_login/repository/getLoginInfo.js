const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers");
const { DOCTORBASICINFO } = require("../commons/constant");
const { CustomError } = require("../../../errorHandler");
const sms = require("../../../notification/repository/sms");

function doctorLogin(fastify) {
  async function getdoctorLogin({ phone_no, logTrace, body }) {
    const knex = this;
    const { sendSms } = sms(fastify);
    const query = knex(DOCTORBASICINFO.NAME)
      .select(
        DOCTORBASICINFO.COLUMNS.ID,
        DOCTORBASICINFO.COLUMNS.EMAIL,
        DOCTORBASICINFO.COLUMNS.PHONE_NO
      )
      .where(DOCTORBASICINFO.COLUMNS.PHONE_NO, phone_no);

    logQuery({
      logger: fastify.log,
      query,
      context: "Get doctor login info",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Doctor not found",
        property: "",
        code: "NOT_FOUND"
      });
    } else {
      const flattenedArray = response.flat();
      const id = flattenedArray[0].id;
      const phone_number = phone_no;
      const otp = Math.floor(1000 + Math.random() * 9000).toString();
      let hash = body.hash;
      if (!body.hash || body.hash == "" || body.hash == undefined) {
        hash = otp;
      }
      const promise1 = sendSms(phone_no, otp, hash);

      const query2 = knex(`${DOCTORBASICINFO.NAME}`)
        .where(`${DOCTORBASICINFO.COLUMNS.ID}`, id)
        .update({
          [DOCTORBASICINFO.COLUMNS.LAST_OTP]: otp,
          [DOCTORBASICINFO.COLUMNS.CREATED_AT]: new Date()
        });
      const response_data = await query2;
      // const token = await fastify.jwt.sign({ response });

      return { doctor_id: id, otp: otp };
    }
  }

  return {
    getdoctorLogin
  };
}

function doctorLogincheck(fastify) {
  async function getdoctorLoginCheck({ body, logTrace }) {
    const knex = this;

    const doctor_name_id = body.doctor_name_id;
    const otp = body.otp;

    const query = await knex(`${DOCTORBASICINFO.NAME}`).where(
      `${DOCTORBASICINFO.COLUMNS.ID}`,
      doctor_name_id
    );

    const otp_check = query[0].last_otp;
    if (otp_check == otp) {
      const token = await fastify.jwt.sign({ query });

      return {
        token: token,
        doctor_id: doctor_name_id,
        message: "OTP Verified successfully"
      };
      // return { success: true, message: "OTP Verified successfully" };
    } else {
      return { success: false, message: "Please Check OTP" };
    }
  }

  return {
    getdoctorLoginCheck
  };
}

module.exports = { doctorLogin, doctorLogincheck };
