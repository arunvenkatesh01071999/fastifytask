const DOCTORBASICINFO = {
  NAME: "d_doctor_basic_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME: "doctor_name",
    GENDER_ID: "gender_id",
    SPECIALITY_ID: "speciality_id",
    EMAIL: "email",
    PHONE_NO: "phone_no",
    DOB: "dob",
    AGE: "age",
    ABOUT: "about",
    IMAGE_PATH: "image_path",
    SIGNATURE_PATH: "signature_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    RATING: "rating"
  }
};
const DOCTOREDUCATIONINFO = {
  NAME: "d_education_info",
  COLUMNS: {
    ID: "id",
    QUALIFICATION_NAME_ID: "qualification_name_id",
    DOCTOR_NAME_ID: "doctor_name_id",
    CERTIFICATE_PATH: "certificate_path",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    YOP: "yop"
  }
};
const DOCTORADDRESSINFO = {
  NAME: "d_address_info",
  COLUMNS: {
    ID: "id",
    DOCTOR_NAME_ID: "doctor_name_id",
    ADDRESS1: "address1",
    ADDRESS2: "address2",
    CITYID: "city_id",
    STATEID: "state_id",
    COUNTRYID: "country_id",
    PINCODE: "pincode",
    LOCATION: "location",
    LOGITUDE: "longitude",
    LATITUDE: "latitude",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DOCTORLANGUAGEINFO = {
  NAME: "d_language_info",
  COLUMNS: {
    ID: "id",
    LANGUAGE_NAME_ID: "language_name_id",
    DOCTOR_NAME_ID: "doctor_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const DOCTOR_REVIEWS = {
  NAME: "d_doctor_reviews",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    COMMENTS: "comments",
    RATING: "rating",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const REGISTERINFO = {
  NAME: "patient_registration",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    EMAIL: "email",
    GENDER_ID: "gender_id",
    DOB: "dob",
    MOBILE: "mobile",
    BLOOD_GROUP_ID: "blood_group_id",
    PROFILE_IMAGE: "profile_image",
    IS_VERIFIED: "is_verified",
    LAST_OTP: "last_otp",
    PROFILE_COMPLETION_PERCENTAGE: "profile_completion_percentage",
    MARTIAL_STATUS_ID: "martial_status_id",
    LOGITUTE: "logitute",
    LATITUDE: "latitude",
    ACTIVE: "active",
    AGE: "age",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    ADDRESS: "address",
    FULLADDRESS: "fulladdress"
  }
};

module.exports = {
  DOCTORBASICINFO,
  DOCTOREDUCATIONINFO,
  DOCTORADDRESSINFO,
  DOCTORLANGUAGEINFO,
  DOCTOR_REVIEWS,
  REGISTERINFO
};
