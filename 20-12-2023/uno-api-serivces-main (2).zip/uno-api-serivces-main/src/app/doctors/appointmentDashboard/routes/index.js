const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/patient-detail-dateFilter",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler: handlers.getPatientDetailsHandler.getPatientDetailsDateFilterHandlerPost(fastify)
  });

  fastify.route({
    method: "POST",
    url: "/patient-detail",
    // preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler: handlers.getPatientDetailsHandler.getPatientDetailsHandlerPost(fastify)
  });


  fastify.route({
    method: "POST",
    url: "/patient-detail-img",
    preHandler: fastify.authenticate,
    //  schema: schemas.getPatientDetailsSchema.getPatientDetailsSchema,
    handler: handlers.getPatientDetailsHandler.getPatientDetailsHandlerPostImg(fastify)
  });

};
