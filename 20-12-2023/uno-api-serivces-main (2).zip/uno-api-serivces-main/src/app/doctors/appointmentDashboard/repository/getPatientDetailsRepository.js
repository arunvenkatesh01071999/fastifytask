const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../commons/helpers")

const { PATIENTDETAILS } = require("../commons/constants");
const { CustomError } = require("../../../errorHandler");
const UploadImageService = require("../../../commons/imageupload");


function getPatientDetailsDateFilterRepositoryPost(fastify) {
  async function PatientDetailsGetOne({ logTrace, body }) {


    const knex = this;
    const doctor_id = body.doctor_id;
    const check_video_walking = body.check_video_walking;

    const appintmentDate = body.appintmentDate;

    if (check_video_walking == 0) {
      const query = knex.raw(`select b.name,b.dob,c.gender_name,a.patient_id,b.mobile,b.logitute,
      b.latitude,a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul, 
      d.patient_upload from HealthUno_Patient.dbo.patient_booking as a
      left join HealthUno_Patient.dbo.patient_registration as b on b.id=a.patient_id
      left join HealthunoMst_dev.dbo.gender as c ON c.id = b.gender_id
      left join HealthunoMst_dev.dbo.patient_details_img as d on d.doctor_id=a.doctor_id
      where a.doctor_id=${doctor_id} and a.appointment_status !=3 and 
      a.hospitalcounsul_or_videoconsul=0 and a.appointment_date = '${appintmentDate}'`);
      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patient details",
        logTrace
      });

      const response = await query;
      if (!response.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patient info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }
      return response;

    }
    else {

      const query = knex.raw(`select b.name,b.dob,c.gender_name,a.patient_id,a.appointment_date,
      a.appointment_day,b.mobile,b.logitute,b.latitude,
      a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul, d.patient_upload
      from HealthUno_Patient.dbo.patient_booking as a
      left join HealthUno_Patient.dbo.patient_registration as b on b.id=a.patient_id
      left join HealthunoMst_dev.dbo.gender as c ON c.id = b.gender_id
      left join HealthunoMst_dev.dbo.patient_details_img as d on d.doctor_id=a.doctor_id
      where a.doctor_id=${doctor_id} and a.appointment_status !=3 and  
      a.hospitalcounsul_or_videoconsul=1 and
      a.appointment_date = '${appintmentDate}'`);




      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patient details",
        logTrace
      });

      const response = await query;
      if (!response.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patient info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }
      return response;

    }


  }

  return {
    PatientDetailsGetOne
  };
}



function getPatientDetailsRepositoryPostImg(fastify) {

  async function PatientDetailsGetOne({ logTrace, params, body }) {

    const knex = this;

    // const patient_upload = body.patient_upload;
    // if (patient_upload.filename != '') {
    //   const img = await UploadImageService(patient_upload, fastify);
    //   var imgurl = img.image_url;
    // } else {
    //   var imgurl = null;
    // }

    const patient_upload = body.patient_upload;

    if (patient_upload !== '' && patient_upload !== undefined) {

      if (patient_upload.filename !== undefined && patient_upload.filename !== '') {

        const img = await UploadImageService(patient_upload, fastify);
        var imgurl = img.image_url;
      }
      else {
        var imgurl = null;

      }
    }
    else {
      var imgurl = null;
    }


    const query = await knex(`${PATIENTDETAILS.NAME}`).insert({

      [PATIENTDETAILS.COLUMNS.DOCTOR_ID]: body.doctor_id.value,
      [PATIENTDETAILS.COLUMNS.PATIENT_ID]: body.patient_id.value,
      [PATIENTDETAILS.COLUMNS.PATIENT_UPLOAD]: imgurl,
      [PATIENTDETAILS.COLUMNS.ACTIVE]: body.active.value,
      [PATIENTDETAILS.COLUMNS.CREATED_BY]: body.created_by.value,

    });


    const response = await query;

    return { success: true, message: "Insert successfully" };
  }

  return {
    PatientDetailsGetOne
  };

}

function getPatientDetailsRepositoryPost(fastify) {
  async function PatientDetailsGetOne({ logTrace, body }) {
    const knex = this;

    const doctor_id = body.doctor_id;
    const check_video_walking = body.check_video_walking;
const db1 = process.env.PATIENT_DB_NAME;
const db2 = process.env.MASTER_DB_NAME;
    // if (check_video_walking == 0) {
      const query = knex
      .select(
        'b.name',
        'b.dob',
        'a.patient_id',
        // 'c.gender_name',
        'a.appointment_date',
        'a.appointment_day',
        'b.mobile',
        'b.logitute',
        'b.latitude',
        'a.appointment_from_time',
        'a.appointment_to_time',
        'a.hospitalcounsul_or_videoconsul',
        'd.patient_upload'
      )
      .from('patient_booking as a')
      .leftJoin('patient_registration as b', 'b.id', 'a.patient_id')
      // .leftJoin('db2.gender as c', 'c.id', 'b.gender_id')
      .leftJoin('patient_details_img as d', 'd.doctor_id', 'a.doctor_id')
      // .where('a.doctor_id', doctor_id)
      // .whereNot('a.appointment_status', 3)
      // .where('a.hospitalcounsul_or_videoconsul', 0)

      console.log(query,"querywsdfghjkl;");
      // return query;
      // .whereNot('a.appointment_status', 3)
      // .where('a.hospitalcounsul_or_videoconsul', 1);
      // const query = knex.raw(`select b.name,b.dob,a.patient_id,a.appointment_date,a.appointment_day,b.mobile,b.logitute,b.latitude,
      // a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul, d.patient_upload
      // from HealthUno_Patient.dbo.patient_booking as a
      // left join HealthUno_Patient.dbo.patient_registration as b on b.id=a.patient_id
      // left join HealthunoMst_dev.dbo.patient_details_img as d on d.doctor_id=a.doctor_id
      // where a.doctor_id=${doctor_id} and a.appointment_status !=3 and  a.hospitalcounsul_or_videoconsul=0`);

      logQuery({
        logger: fastify.log,
        query,
        context: "Get Patient details",
        logTrace
      });

      const response = await query;
      if (!response.length) {
        throw CustomError.create({
          httpCode: StatusCodes.NOT_FOUND,
          message: "Patient info not found",
          property: "",
          code: "NOT_FOUND"
        });
      }
      return response;

    // }
    // else {

    //   const query = knex.raw(`select b.name,b.dob,c.gender_name,a.patient_id,a.appointment_date,a.appointment_day,b.mobile,b.logitute,b.latitude,
    // a.appointment_from_time,a.appointment_to_time,a.hospitalcounsul_or_videoconsul, d.patient_upload
    // from HealthUno_Patient.dbo.patient_booking as a
    // left join HealthUno_Patient.dbo.patient_registration as b on b.id=a.patient_id
    // left join HealthunoMst_dev.dbo.gender as c ON c.id = b.gender_id
    // left join HealthunoMst_dev.dbo.patient_details_img as d on d.doctor_id=a.doctor_id
    // where a.doctor_id=${doctor_id} and a.appointment_status !=3 and  a.hospitalcounsul_or_videoconsul=1`);

    //   logQuery({
    //     logger: fastify.log,
    //     query,
    //     context: "Get Patient details",
    //     logTrace
    //   });

    //   const response = await query;
    //   if (!response.length) {
    //     throw CustomError.create({
    //       httpCode: StatusCodes.NOT_FOUND,
    //       message: "Patient info not found",
    //       property: "",
    //       code: "NOT_FOUND"
    //     });
    //   }
    //   return response;
    // }
  }

  return {
    PatientDetailsGetOne
  };
}


module.exports = {

  getPatientDetailsDateFilterRepositoryPost,
  getPatientDetailsRepositoryPostImg,
  getPatientDetailsRepositoryPost

};
