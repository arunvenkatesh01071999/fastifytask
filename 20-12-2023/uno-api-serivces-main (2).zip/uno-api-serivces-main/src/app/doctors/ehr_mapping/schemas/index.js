const getEhrMappingInfo = require('./getEhrMapping')

module.exports = {
    getEhrMappingInfo
}