const healthCardServices = require("../services/healthCardServices");

function getHealthCardHandler(fastify) {
  const getHealthCard = healthCardServices.getHealthCardService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await getHealthCard({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = getHealthCardHandler;
