const healthCardServices = require("../services/healthCardServices");

function renewelHealthCardHandler(fastify) {
  const renewelHealthCard =
    healthCardServices.renewelHealthCardService(fastify);

  return async (request, reply) => {
    const { params, body, logTrace } = request;
    const response = await renewelHealthCard({ params, body, logTrace });
    return reply.code(200).send(response);
  };
}

module.exports = renewelHealthCardHandler;
