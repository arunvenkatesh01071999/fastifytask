const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getHealthCardSchema = {
  tags: ["CARD MASTERS"],
  summary: "This API is to get Card information ",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      patient_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        id: { type: "integer" },
        patient_id: { type: "integer" },
        valid_from: { type: "string", format: "date-time" },
        valid_to: { type: "string", format: "date-time" },
        is_valid: { type: "integer" },
        is_valid_message: { type: "string" },
        card_type: { type: "integer" },
        card_type_name: { type: "string" },
        card_number: { type: "string" },
        card_pin: { type: "integer" },
        card_value: { type: "number" },
        validity_months: { type: "integer" },
        razor_payment_id: { type: "string" },
        consult_offer: { type: "number" },
        lab_offer: { type: "number" },
        scan_offer: { type: "number" },
        active: { type: "boolean" },
        created_at: { type: "string", format: "date-time" },
        updated_at: { type: "string", format: "date-time" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getHealthCardSchema;
