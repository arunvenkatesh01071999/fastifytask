const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "POST",
    url: "/card/purchase",
    schema: schemas.purchaseHealthCardSchema,
    handler: handlers.purchaseHealthCardHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/card/upgrade",
    schema: schemas.purchaseHealthCardSchema,
    handler: handlers.upgradeHealthCardHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/card/active/:patient_id",
    schema: schemas.getHealthCardSchema,
    handler: handlers.getHealthCardHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/card/renewel",
    schema: schemas.renewelHealthCardSchema,
    handler: handlers.renewelHealthCardHandler(fastify)
  });
};
