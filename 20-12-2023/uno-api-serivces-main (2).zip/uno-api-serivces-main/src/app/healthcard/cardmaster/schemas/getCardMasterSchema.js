const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getCardMasterSchema = {
  tags: ["CARD MASTERS"],
  summary: "This API is to get Card Masters",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      page_size: { type: "integer" },
      current_page: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        data: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              card_type: { type: "string" },
              card_value: { type: "number" },
              validity_months: { type: "number" },
              consult_offer: { type: "number" },
              lab_offer: { type: "number" },
              scan_offer: { type: "number" },
              active: { type: "boolean" },
              created_at: { type: "string", format: "date-time" },
              updated_at: { type: "string", format: "date-time" }
            }
          }
        },
        meta: { $ref: "response-meta#" }
      }
    },
    ...errorSchemas
  }
};

module.exports = getCardMasterSchema;
