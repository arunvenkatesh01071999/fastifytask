const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const putCardMasterSchema = {
  tags: ["CARDS"],
  summary: "This API is to update cards",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      card_type_id: { type: "integer" }
    }
  },
  body: {
    type: "object",
    required: [
      "card_type",
      "card_value",
      "validity_months",
      "consult_offer",
      "lab_offer",
      "scan_offer",
      "active"
    ],
    properties: {
      card_type: { type: "string" },
      card_value: { type: "number" },
      validity_months: { type: "integer" },
      consult_offer: { type: "number" },
      lab_offer: { type: "number" },
      scan_offer: { type: "number" },
      active: { type: "boolean" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = putCardMasterSchema;
