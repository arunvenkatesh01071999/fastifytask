const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { CARD_MASTERS } = require("../commons/constants");
const { PATIENT_INFO } = require("../commons/constants");
const { PATIENT_RECORD } = require("../commons/constants");
function cardMasterRepo(fastify) {
  async function getCardMaster({ body, params, logTrace }) {
    const knex = this;
    const query = knex(CARD_MASTERS.NAME);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters",
      logTrace
    });
    const response = await query
      .orderBy(CARD_MASTERS.COLUMNS.ID, "DESC")
      .paginate({
        pageSize: params.page_size, // Customize as needed
        currentPage: params.current_page // Customize as needed
      });
    if (response.meta.pagination.total_pages < params.current_page) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Requested page is beyond the available data",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    if (!response.data.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Card Masters not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response;
  }
  async function postCardMaster({ params, body, logTrace }) {
    const knex = this;
    const query = knex(CARD_MASTERS.NAME).where(
      CARD_MASTERS.COLUMNS.CARD_TYPE,
      body.card_type
    );

    const exists_response = await query;

    if (exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Card Type Name Already Exists",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }
    const query_insert = await knex(`${CARD_MASTERS.NAME}`).insert({
      [CARD_MASTERS.COLUMNS.CARD_TYPE]: body.card_type,
      [CARD_MASTERS.COLUMNS.CARD_VALUE]: body.card_value,
      [CARD_MASTERS.COLUMNS.VALIDITY_MONTHS]: body.validity_months,
      [CARD_MASTERS.COLUMNS.CONSULT_OFFER]: body.consult_offer,
      [CARD_MASTERS.COLUMNS.LAB_OFFER]: body.lab_offer,
      [CARD_MASTERS.COLUMNS.SCAN_OFFER]: body.scan_offer,
      [CARD_MASTERS.COLUMNS.ACTIVE]: body.active
    });

    const response = await query_insert;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while creating Card type",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function putCardMaster({ card_type_id, body, logTrace }) {
    const knex = this;
    const query = knex(CARD_MASTERS.NAME).where(
      CARD_MASTERS.COLUMNS.ID,
      card_type_id
    );

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Card type not found to update",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_update = await knex(`${CARD_MASTERS.NAME}`)
      .where(`${CARD_MASTERS.COLUMNS.ID}`, card_type_id)
      .update({
        [CARD_MASTERS.COLUMNS.CARD_TYPE]: body.card_type,
        [CARD_MASTERS.COLUMNS.CARD_VALUE]: body.card_value,
        [CARD_MASTERS.COLUMNS.VALIDITY_MONTHS]: body.validity_months,
        [CARD_MASTERS.COLUMNS.CONSULT_OFFER]: body.consult_offer,
        [CARD_MASTERS.COLUMNS.LAB_OFFER]: body.lab_offer,
        [CARD_MASTERS.COLUMNS.SCAN_OFFER]: body.scan_offer,
        [CARD_MASTERS.COLUMNS.ACTIVE]: body.active,
        [CARD_MASTERS.COLUMNS.UPDATED_AT]: new Date()
      });

    const response = await query_update;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_IMPLEMENTED,
        message: "Error while updatind Card Type",
        property: "",
        code: "NOT_IMPLEMENTED"
      });
    }

    return { success: true };
  }
  async function deleteCardMaster({ card_type_id, body, logTrace }) {
    const knex = this;
    const query = knex(CARD_MASTERS.NAME).where(
      CARD_MASTERS.COLUMNS.ID,
      card_type_id
    );

    const exists_response = await query;

    if (!exists_response.length > 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_ACCEPTABLE,
        message: "Card type not found to delete",
        property: "",
        code: "NOT_ACCEPTABLE"
      });
    }

    const query_delete = knex(CARD_MASTERS.NAME)
      .where(CARD_MASTERS.COLUMNS.ID, card_type_id)
      .del();
    logQuery({
      logger: fastify.log,
      query,
      context: "delete Card type",
      logTrace
    });
    const response = await query_delete;
    if (!response) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Card type not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }
  async function getCardMasterInfo({ body, params, logTrace }) {
    const knex = this;
    const query = knex(CARD_MASTERS.NAME).where(
      CARD_MASTERS.COLUMNS.ID,
      params.card_type_id
    );
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Card Masters Info",
      logTrace
    });
    const response = await query;

    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Card Masters info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }

    return response[0];
  }

  return {
    getCardMaster,
    postCardMaster,
    putCardMaster,
    deleteCardMaster,
    getCardMasterInfo
  };
}

module.exports = cardMasterRepo;
