const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {
  fastify.route({
    method: "GET",
    url: "/card/master/:page_size/:current_page",
    schema: schemas.getCardMasterSchema,
    handler: handlers.getCardMasterHandler(fastify)
  });
  fastify.route({
    method: "GET",
    url: "/card/master/info/:card_type_id",
    schema: schemas.getCardMasterInfoSchema,
    handler: handlers.getCardMasterInfoHandler(fastify)
  });
  fastify.route({
    method: "POST",
    url: "/card/master",
    schema: schemas.postCardMasterSchema,
    handler: handlers.postCardMasterHandler(fastify)
  });
  fastify.route({
    method: "PUT",
    url: "/card/master/:card_type_id",
    schema: schemas.putCardMasterSchema,
    handler: handlers.putCardMasterHandler(fastify)
  });
  fastify.route({
    method: "DELETE",
    url: "/card/master/:card_type_id",
    schema: schemas.deleteCardMasterSchema,
    handler: handlers.deleteCardMasterHandler(fastify)
  });
};
