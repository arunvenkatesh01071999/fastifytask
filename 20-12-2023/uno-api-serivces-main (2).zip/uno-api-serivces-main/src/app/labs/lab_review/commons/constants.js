const LAB_BASIC_INFO = {
  NAME: "l_lab_basic_infos",
  COLUMNS: {
    ID: "id",
    LAB_NAME: "lab_name",
    LAB_TYPE_ID: "lab_type_id",
    SECTOR_ID: "sector_id",
    ACCREDATION_ID: "accredation_id",
    LAB_REGNO: "lab_regNo",
    ABOUT: "about",
    CERTIFICATE_PATH: "certicate_path",
    ADDCHECK: "addCheck",
    APPROVEDATE: "approve_date",
    ISAPPROVED: "isApproved",
    LAB_OR_SCAN: "lab_or_scan",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    LAB_USER: "lab_user",
    RATING: "rating"
  }
};
const LAB_REVIEWS = {
  NAME: "l_lab_reviews",
  COLUMNS: {
    ID: "id",
    LAB_ID: "lab_id",
    PATIENT_ID: "patient_id",
    COMMENTS: "comments",
    RATING: "rating",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const REGISTERINFO = {
  NAME: "patient_registration",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    EMAIL: "email",
    GENDER_ID: "gender_id",
    DOB: "dob",
    MOBILE: "mobile",
    BLOOD_GROUP_ID: "blood_group_id",
    PROFILE_IMAGE: "profile_image",
    IS_VERIFIED: "is_verified",
    LAST_OTP: "last_otp",
    PROFILE_COMPLETION_PERCENTAGE: "profile_completion_percentage",
    MARTIAL_STATUS_ID: "martial_status_id",
    LOGITUTE: "logitute",
    LATITUDE: "latitude",
    ACTIVE: "active",
    AGE: "age",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    ADDRESS: "address",
    FULLADDRESS: "fulladdress"
  }
};

module.exports = {
  LAB_BASIC_INFO,
  LAB_REVIEWS,
  REGISTERINFO
};
