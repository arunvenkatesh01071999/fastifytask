const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const postDisableLabReviewSchema = {
  tags: ["LAB REVIEWS"],
  summary: "This API is used to dia reivews",
  headers: { $ref: "request-headers#" },
  body: {
    type: "object",
    required: ["lab_id", "patient_id", "active"],
    additionalProperties: false,
    properties: {
      lab_id: { type: "integer" },
      patient_id: { type: "integer" },
      active: { type: "boolean" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        success: { type: "boolean" }
      }
    },
    ...errorSchemas
  }
};

module.exports = postDisableLabReviewSchema;
