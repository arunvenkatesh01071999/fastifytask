const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const getLabReviewSchema = {
  tags: ["DOCTOR REVIEWS"],
  summary: "This API is used to get lab reivews",
  headers: { $ref: "request-headers#" },
  params: {
    type: "object",
    properties: {
      lab_id: { type: "integer" }
    }
  },
  response: {
    200: {
      type: "object",
      properties: {
        overall_rating: { type: "string" },
        out_of: { type: "integer" },
        reviews: {
          type: "array",
          items: {
            type: "object",
            properties: {
              id: { type: "integer" },
              lab_id: { type: "integer" },
              patient_id: { type: "integer" },
              comments: { type: "string" },
              rating: { type: "number" },
              active: { type: "integer" },
              created_at: { type: "string" },
              updated_at: { type: "string" },
              patient_info: {
                type: "object", // Assuming patient info is an object
                properties: {
                  id: { type: "integer" },
                  name: { type: "string" },
                  email: { type: "string" },
                  gender_id: { type: "integer" },
                  dob: { type: "string" },
                  mobile: { type: "string" },
                  profile_image: { type: "string" },
                  martial_status_id: { type: "integer" },
                  address: { type: "string" },
                  fulladdress: { type: "string" }
                }
              }
            }
          }
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = getLabReviewSchema;
