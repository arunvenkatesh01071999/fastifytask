const postLabReviewHandler = require("./postLabReviewHandler");
const getLabReviewHandler = require("./getLabReviewHandler");
const getLabAdminReviewHandler = require("./getLabAdminReviewHandler");
const postDisableLabReviewHandler = require("./postDisableLabReviewHandler");

module.exports = {
  postLabReviewHandler,
  getLabReviewHandler,
  getLabAdminReviewHandler,
  postDisableLabReviewHandler
};
