const LAB_TEST = {
  NAME: "lab_test",
  COLUMNS: {
    ID: "id",
    TEST_NAME: "test_name",
    ALTER_NAME: "alter_name",
    LONG_DESCRIPTION: "long_descrip",
    SHORT_DESCRIPTION: "short_descrip",
    RECOMMEND: "recommend",
    SAMPLE_COLLECTED: "sample_collected",
    PRETEST_PREPARE: "pretest_prepare",
    CATEGORY_ID: "category_id",
    IACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_BASIC_INFO = {
  NAME: "l_lab_basic_infos",
  COLUMNS: {
    ID: "id",
    LAB_NAME: "lab_name",
    LAB_TYPE_ID: "lab_type_id",
    SECTOR_ID: "sector_id",
    ACCREDATION_ID: "accredation_id",
    LAB_REGNO: "lab_regNo",
    ABOUT: "about",
    CERTIFICATE_PATH: "certicate_path",
    ADDCHECK: "addCheck",
    APPROVEDATE: "approve_date",
    ISAPPROVED: "isApproved",
    LAB_OR_SCAN: "lab_or_scan",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    LAB_IMAGE: "lab_image",
    LAB_USER: "lab_user"
  }
};
const ACCREDATION = {
  NAME: "accredation",
  COLUMNS: {
    ID: "id",
    ACCREDATION_NAME: "accredation_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SECTOR = {
  NAME: "lab_sector",
  COLUMNS: {
    ID: "id",
    LAB_SECTOR_NAME: "lab_sector_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_TYPE_MASTER = {
  NAME: "lab_type_master",
  COLUMNS: {
    ID: "id",
    LAB_TYPE_NAME: "lab_type_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_TEST_PACK = {
  NAME: "l_lab_test_pack",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    LAB_PACK_NAME: "lab_pack_name",
    COST: "cost",
    OFFER_PERCENT: "offer_percent",
    VALID_FROM: "vaild_from",
    VALID_TO: "vaild_to",
    APPLY_PROMO: "apply_promo",
    LAB_TEST_ID: "lab_test_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const L_LAB_INFO = {
  NAME: "l_lab_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    COST: "cost",
    DISCOUNT: "discount",
    PACK_NAME: "pack_name",
    LAB_TEST_ID: "lab_test_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const CITIES = {
  NAME: "cities",
  COLUMNS: {
    ID: "id",
    CITYNAME: "city_name",
    STATEID: "state_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const STATES = {
  NAME: "states",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    COUNTRYID: "country_id"
  }
};
const COUNTRIES = {
  NAME: "countries",
  COLUMNS: {
    ID: "id",
    SHORTNAME: "shortname",
    NAME: "name",
    PHONECODE: "phonecode",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

const LAB_ADDRESS_INFO = {
  NAME: "l_address_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    ADDRESS1: "address1",
    ADDRESS2: "address2",
    CITY_ID: "city_id",
    STATE_ID: "state_id",
    COUNTRY_ID: "country_id",
    PINCODE: "pincode",
    LOCATION: "location",
    LONGITUDE: "longitude",
    LATITUDE: "latitude",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_CONTACT_INFO = {
  NAME: "l_contact_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    TELEPHONE: "telephone",
    MOBILE_NO: "mobile_no",
    EMERGENY_NO: "emergency_no",
    TOLL_FREE_NO: "toll_free_no",
    HELPLINE_NO: "helpline_no",
    FAX_NO: "fax_no",
    WEBSITE_URL: "webiste_URL",
    EMAIL_ADDRESS_1: "email_address_1",
    EMAIL_ADDRESS_2: "email_address_2",
    ESTABLISHED_IN: "established_in",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SERVICE = {
  NAME: "lab_service",
  COLUMNS: {
    ID: "id",
    SERVICE_NAME: "service_name",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SERVICE_INFO = {
  NAME: "l_lab_service_info",
  COLUMNS: {
    ID: "id",
    LAB_NAME_ID: "lab_name_id",
    SERVICE_NAME_ID: "service_name_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const LAB_SLOT = {
  NAME: "l_lab_slot ",
  COLUMNS: {
    ID: "id",
    LAB_ID: "lab_id",
    DAYS: "days",
    OPENS_FROM: "opens_from",
    CLOSED_AT: "closed_at",
    INTERVAL: "interval",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const LAB_CART = {
  NAME: "l_lab_cart ",
  COLUMNS: {
    ID: "id",
    PATIENT_ID: "patient_id",
    LAB_ID: "lab_id",
    LAB_TEST_ID: "lab_test_id",
    LAB_PACKAGE_ID: "lab_package_id",
    IS_TEST_OR_PACKAGE: "is_test_or_package",
    CREATED_AT: "created_at"
  }
};
const LAB_ORDER_MASTER = {
  NAME: "l_lab_orders_master ",
  COLUMNS: {
    ID: "id",
    PATIENT_ID: "patient_id",
    LAB_ID: "lab_id",
    LAB_ORDER_TOTAL: "lab_order_total",
    LAB_ORDER_TOTAL_SAVINGS: "lab_order_total_savings",
    NO_OF_TESTS: "no_of_tests",
    NO_OF_PACKAGES: "no_of_packages",
    TESTS_CART_ITEMS_TOTAL: "tests_cart_items_total",
    TESTS_CART_TOTAL_SAVINGS: "tests_cart_total_savings",
    PACK_CART_ITEMS_TOTAL: "pack_cart_items_total",
    PACKAGES_CART_TOTAL_SAVINGS: "packages_cart_total_savings",
    PAYMENT_REFNO: "payment_refno",
    APPOINTMENT_TIME: "appointment_time",
    APPOINTMENT_DATE: "appointment_date",
    ORDER_MODE: "order_mode",
    ORDER_TYPE: "order_type",
    REPORT_STATUS: "report_status",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    IS_LAB_OR_HOME: "is_lab_or_home",
    HOME_ADDRESS: "home_address"
  }
};
const LAB_ORDER_DETAILS = {
  NAME: "l_lab_orders_detaiils ",
  COLUMNS: {
    ID: "id",
    LAB_ORDER_ID: "lab_order_id",
    PATIENT_ID: "patient_id",
    LAB_ID: "lab_id",
    LAB_TEST_ID: "lab_test_id",
    LAB_PACKAGE_ID: "lab_package_id",
    IS_TEST_OR_PACKAGE: "is_test_or_package",
    TESTS_COST: "tests_cost",
    TESTS_DISCOUNT: "tests_discount",
    TESTS_CART_ITEMS_TOTAL: "tests_cart_items_total",
    TESTS_CART_TOTAL_SAVINGS: "test_cart_items_total_savings",
    PACK_COST: "pack_cost",
    PACK_OFFER_PERCENT: "pack_offer_percent",
    PACK_CART_ITEMS_TOTAL: "pack_cart_items_total",
    PACKAGES_CART_TOTAL_SAVINGS: "pack_cart_items_total_savings",
    LAB_REPORT_STATUS: "lab_report_status",
    LAB_REPORT_STATUS_LINK: "lab_report_status_link",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};
const PATIENT_INFO = {
  NAME: "patient_registration",
  COLUMNS: {
    ID: "id",
    NAME: "name",
    EMAIL: "email",
    GENDER_ID: "gender_id",
    DOB: "dob",
    MOBILE: "mobile",
    BLOOD_GROUP_ID: "blood_group_id",
    PROFILE_IMAGE: "profile_image",
    IS_VERIFIED: "is_verified",
    LAST_OTP: "last_otp",
    PROFILE_COMPLETION_PERCENTAGE: "profile_completion_percentage",
    MARTIAL_STATUS_ID: "martial_status_id",
    LOGITUTE: "logitute",
    LATITUDE: "latitude",
    ACTIVE: "active",
    AGE: "age",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by",
    WALLET_AMT: "wallet_amt",
    CARD_BALANCE: "card_balance"
  }
};
const PATIENT_RECORD = {
  NAME: "patient_record_details",
  COLUMNS: {
    ID: "id",
    PATIENT_ID: "patient_id",
    DOCTOR_ID: "doctor_id",
    FILE_PATH: "patient_file_path",
    FILE_FLAG: "file_flag",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};
const HEALTH_CARDS = {
  NAME: "health_cards",
  COLUMNS: {
    ID: "id",
    PATIENT_ID: "patient_id",
    VALID_FROM: "valid_from",
    VALID_TO: "valid_to",
    CARD_TYPE: "card_type",
    CARD_NUMBER: "card_number",
    CARD_PIN: "card_pin",
    CARD_VALUE: "card_value",
    VALIDITY_MONTHS: "validity_months",
    CONSULT_OFFER: "consult_offer",
    LAB_OFFER: "lab_offer",
    SCAN_OFFER: "scan_offer",
    RAZOR_PAYMENT_ID: "razor_payment_id",
    ACTIVE: "active",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at"
  }
};

module.exports = {
  LAB_TEST,
  LAB_BASIC_INFO,
  ACCREDATION,
  LAB_SECTOR,
  LAB_TYPE_MASTER,
  LAB_TEST_PACK,
  L_LAB_INFO,
  CITIES,
  STATES,
  COUNTRIES,
  LAB_ADDRESS_INFO,
  LAB_CONTACT_INFO,
  LAB_SERVICE,
  LAB_SERVICE_INFO,
  LAB_SLOT,
  LAB_CART,
  LAB_ORDER_MASTER,
  LAB_ORDER_DETAILS,
  PATIENT_INFO,
  PATIENT_RECORD,
  HEALTH_CARDS
};
