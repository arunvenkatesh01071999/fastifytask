const getOrderService = require("../services/getOrderServices");

function uploadPastMedicalHandler(fastify) {
  const uploadPastReport = getOrderService.uploadPastReportService(fastify);
  return async (request, reply) => {
    const { body, logTrace } = request;
    const response = await uploadPastReport({ body, logTrace, request, reply });
    return reply.code(200).send(response);
  };
}

module.exports = uploadPastMedicalHandler;
