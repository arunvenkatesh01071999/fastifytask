const { StatusCodes } = require("http-status-codes");
const { CustomError } = require("../../../errorHandler");
const { logQuery } = require("../../../commons/helpers");
const { LAB_TEST } = require("../commons/constants");
const { LAB_BASIC_INFO } = require("../commons/constants");
const { ACCREDATION } = require("../commons/constants");
const { LAB_SECTOR } = require("../commons/constants");
const { LAB_TYPE_MASTER } = require("../commons/constants");
const { LAB_TEST_PACK } = require("../commons/constants");
const { L_LAB_INFO } = require("../commons/constants");
const { CITIES } = require("../commons/constants");
const { STATES } = require("../commons/constants");
const { COUNTRIES } = require("../commons/constants");
const { LAB_ADDRESS_INFO } = require("../commons/constants");
const { LAB_CONTACT_INFO } = require("../commons/constants");
const { LAB_SERVICE } = require("../commons/constants");
const { LAB_SERVICE_INFO } = require("../commons/constants");
const { LAB_CART } = require("../commons/constants");

function cartRepo(fastify) {
  async function getTestQuantityOfItemInCart({
    logTrace,
    input: {
      patient_id,
      lab_id,
      lab_test_id,
      lab_package_id,
      is_test_or_package
    }
  }) {
    const knex = this;
    const query = knex(LAB_CART.NAME)
      .select(LAB_CART.COLUMNS.LAB_TEST_ID)
      .where(LAB_CART.COLUMNS.PATIENT_ID, patient_id)
      .where(LAB_CART.COLUMNS.LAB_ID, lab_id)
      .where(LAB_CART.COLUMNS.LAB_TEST_ID, lab_test_id)
      .where(LAB_CART.COLUMNS.IS_TEST_OR_PACKAGE, 0);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Tests Quantity of Item In Cart",
      logTrace
    });
    const response = await query;
    return response[0];
  }
  async function getPackageQuantityOfItemInCart({
    logTrace,
    input: {
      patient_id,
      lab_id,
      lab_test_id,
      lab_package_id,
      is_test_or_package
    }
  }) {
    const knex = this;
    const query = knex(LAB_CART.NAME)
      .select(LAB_CART.COLUMNS.LAB_TEST_ID)
      .where(LAB_CART.COLUMNS.PATIENT_ID, patient_id)
      .where(LAB_CART.COLUMNS.LAB_ID, lab_id)
      .where(LAB_CART.COLUMNS.LAB_PACKAGE_ID, lab_package_id)
      .where(LAB_CART.COLUMNS.IS_TEST_OR_PACKAGE, 1);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Package Quantity of Item In Cart",
      logTrace
    });
    const response = await query;
    return response[0];
  }
  async function addItemToCart({
    logTrace,
    input: {
      patient_id,
      lab_id,
      lab_test_id,
      lab_package_id,
      is_test_or_package
    }
  }) {
    const knex = this;
    const query = knex(LAB_CART.NAME).insert({
      [LAB_CART.COLUMNS.PATIENT_ID]: patient_id,
      [LAB_CART.COLUMNS.LAB_ID]: lab_id,
      [LAB_CART.COLUMNS.LAB_TEST_ID]: lab_test_id,
      [LAB_CART.COLUMNS.LAB_PACKAGE_ID]: lab_package_id,
      [LAB_CART.COLUMNS.IS_TEST_OR_PACKAGE]: is_test_or_package
    });
    logQuery({
      logger: fastify.log,
      query,
      context: "Add Item To Cart",
      logTrace
    });
    await query;
    return { success: true };
  }
  async function getTestsItemsInCart({
    logTrace,
    input: { patient_id, lab_id }
  }) {
    const knex = this;
    const response = await knex.transaction(async trx => {
      // Fetch Carts
      const query = knex
        .select([
          `${LAB_CART.NAME}.*`,
          knex.raw(
            `  ${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.COST} as tests_cart_items_total`
          ),
          knex.raw(
            `ROUND((${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.COST} *  ${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.DISCOUNT} / 100 ),2) as test_cart_items_total_savings`
          ),

          `${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.COST}`,
          `${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.DISCOUNT}`,
          `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.TEST_NAME}`,
          `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.ALTER_NAME}`,
          `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.PRETEST_PREPARE}`,
          `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.SAMPLE_COLLECTED}`,
          `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.LONG_DESCRIPTION}`
        ])
        .from(`${LAB_CART.NAME} as ${LAB_CART.NAME}`)
        .leftJoin(
          `${L_LAB_INFO.NAME} as ${L_LAB_INFO.NAME}`,
          `${LAB_CART.NAME}.${LAB_CART.COLUMNS.LAB_TEST_ID}`,
          `${L_LAB_INFO.NAME}.${L_LAB_INFO.COLUMNS.LAB_TEST_ID}`
        )
        .leftJoin(
          `${LAB_TEST.NAME} as ${LAB_TEST.NAME}`,
          `${LAB_CART.NAME}.${LAB_CART.COLUMNS.LAB_TEST_ID}`,
          `${LAB_TEST.NAME}.${LAB_TEST.COLUMNS.ID}`
        )

        .where(LAB_CART.COLUMNS.PATIENT_ID, patient_id)
        .where(LAB_CART.COLUMNS.IS_TEST_OR_PACKAGE, 0)
        .where(LAB_CART.COLUMNS.LAB_ID, lab_id)
        .where(L_LAB_INFO.COLUMNS.LAB_NAME_ID, lab_id);

      logQuery({
        logger: fastify.log,
        query,
        context: "Get tests Cart details",
        logTrace
      });

      const tests_cart_lines = await query;

      return {
        tests_cart_lines
      };
    });

    return response;
  }
  async function getPackagesItemsInCart({
    logTrace,
    input: { patient_id, lab_id }
  }) {
    const knex = this;
    const response = await knex.transaction(async trx => {
      // Fetch Carts
      const query = knex
        .select([
          `${LAB_CART.NAME}.*`,
          knex.raw(
            `  ${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.COST} as pack_cart_items_total`
          ),
          knex.raw(
            `ROUND((${LAB_TEST_PACK.NAME}.${L_LAB_INFO.COLUMNS.COST} *  ${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.OFFER_PERCENT} / 100 ),2) as pack_cart_items_total_savings`
          ),

          `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.COST}`,
          `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.OFFER_PERCENT}`,
          `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.LAB_PACK_NAME}`,
          `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.LAB_TEST_ID}`
        ])
        .from(`${LAB_CART.NAME} as ${LAB_CART.NAME}`)
        .leftJoin(
          `${LAB_TEST_PACK.NAME} as ${LAB_TEST_PACK.NAME}`,
          `${LAB_CART.NAME}.${LAB_CART.COLUMNS.LAB_PACKAGE_ID}`,
          `${LAB_TEST_PACK.NAME}.${LAB_TEST_PACK.COLUMNS.ID}`
        )

        .where(LAB_CART.COLUMNS.PATIENT_ID, patient_id)
        .where(LAB_CART.COLUMNS.IS_TEST_OR_PACKAGE, 1)
        .where(LAB_CART.COLUMNS.LAB_ID, lab_id)
        .where(LAB_TEST_PACK.COLUMNS.LAB_NAME_ID, lab_id);

      logQuery({
        logger: fastify.log,
        query,
        context: "Get package Cart details",
        logTrace
      });

      const tests_packages_cart_lines = await query;

      return {
        tests_packages_cart_lines
      };
    });

    return response;
  }
  async function deleteItemFromCart({
    logTrace,
    input: {
      patient_id,
      lab_id,
      lab_test_id,
      lab_package_id,
      is_test_or_package
    }
  }) {
    const knex = this;
    let query;
    if (is_test_or_package == 0) {
      query = knex(LAB_CART.NAME)
        .delete()
        .where(LAB_CART.COLUMNS.PATIENT_ID, patient_id)
        .where(LAB_CART.COLUMNS.LAB_ID, lab_id)
        .where(LAB_CART.COLUMNS.LAB_TEST_ID, lab_test_id)
        .where(LAB_CART.COLUMNS.IS_TEST_OR_PACKAGE, 0);
    }
    if (is_test_or_package == 1) {
      query = knex(LAB_CART.NAME)
        .delete()
        .where(LAB_CART.COLUMNS.PATIENT_ID, patient_id)
        .where(LAB_CART.COLUMNS.LAB_ID, lab_id)
        .where(LAB_CART.COLUMNS.LAB_PACKAGE_ID, lab_package_id)
        .where(LAB_CART.COLUMNS.IS_TEST_OR_PACKAGE, 1);
    }

    logQuery({
      logger: fastify.log,
      query,
      context: "Delete Item From Cart",
      logTrace
    });
    const response = await query;

    if (response === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "tests/packages not found in Cart",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }
  async function clearCartItems({ logTrace, params }) {
    const knex = this;
    let query;

    query = knex(LAB_CART.NAME)
      .delete()
      .where(LAB_CART.COLUMNS.PATIENT_ID, params.patient_id)
      .where(LAB_CART.COLUMNS.LAB_ID, params.lab_id);

    logQuery({
      logger: fastify.log,
      query,
      context: "Clear Items From Cart",
      logTrace
    });
    const response = await query;

    if (response === 0) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "tests/packages not found in Cart",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return { success: true };
  }

  return {
    getTestQuantityOfItemInCart,
    getPackageQuantityOfItemInCart,
    deleteItemFromCart,
    addItemToCart,
    getTestsItemsInCart,
    getPackagesItemsInCart,
    clearCartItems
  };
}

module.exports = cartRepo;
