const { CustomError } = require("../../app/errorHandler");
const { StatusCodes } = require("http-status-codes");
async function UploadImageService(singleimg, fastify) {
    // return  ({ body, logTrace, request, reply }) => {
    const file = singleimg;
    if (!file) {
        throw CustomError.create({
            httpCode: StatusCodes.NOT_FOUND,
            message: "No file uploaded",
            property: "",
            code: "NOT_FOUND"
        });
    }
    console.log('Received file:', file.filename);
    const inputBuffer = await file.toBuffer();
    // console.log('File converted to buffer:', inputBuffer.length, 'bytes');
    const media_path = 'patient_mobile_app/' + file.filename;
    const result = await fastify.bucketOperations.saveFileBuffer({
        file_path: media_path,
        buffer: inputBuffer
    });
    if (!result) {
        throw CustomError.create({
            httpCode: StatusCodes.NOT_FOUND,
            message: console.log(result),
            property: "",
            code: "NOT_FOUND"
        });
    }
    const cloudStorageBaseUrl = process.env.GCS_URL + '/' + process.env.GCP_BUCKET_NAME;
    const fullUrl = `${cloudStorageBaseUrl}/${media_path}`;
    return {
        'message': 'File uploaded successfully',
        'image_url': fullUrl
    };
};
// }
module.exports = UploadImageService;