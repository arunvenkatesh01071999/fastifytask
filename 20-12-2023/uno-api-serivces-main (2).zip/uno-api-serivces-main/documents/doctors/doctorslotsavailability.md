## SLOT AVAILABILITY

1. slots settings api - crud

## Payment Settings.

1. payment setting for normal (General)
2. payment setting for Smartcard 

## Account Deatils.

Table : doctor_accounts_details

## Feilds
 1. doctor_id
 2. holder_name
 3. bank
 4. account_no
 5. ifsc_code
 6. account_type
 7. Upi_Ids -google
 8. Upi_Ids -phonepay
 9. Upi_Ids -paytm
 10. Net banking
 