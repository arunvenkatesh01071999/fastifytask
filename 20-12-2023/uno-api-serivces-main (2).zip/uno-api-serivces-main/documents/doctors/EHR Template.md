## EHR Template

## EHR Types

1.  Allopathy
2.  Auyrvedic

## Table : EHR_Types

## Fields

1. id -primary key
2. Ehr_type
3. created_at
4. updated_at
5. created_by
6. updated_by
7. active

EHR Type masters to be created in back end (Basic CRUD Operations)

## EHR Headers Masters List

1. Cheif Complaint
2. Past Medical History
3. Clinical Eaxmination
4. Examinatory Notes
5. Provisional Diagnosis
6. Investigation
7. Final Diagnosis
8. E-Prescription
9. Surgical Treatment
10. Other Treatment Plan

EHR Masters to be created in back end (Basic CRUD Operations)

## Table : EHR_Masters

## Fields

1. id -primary key
2. Ehr_Name
3. created_at
4. updated_at
5. created_by
6. updated_by
7. active

## EHR Masters and EHR Types with Doctors

## Table : EHR Mapping With Doctors

## Fields

1. id
2. EHR_id
3. EHR_type_id
4. doctor_id
5. is_allopathy
6. is_ayurvedic
7. created_at
8. updated_at
9. created_by
10. updated_by

## APIs

1. EHR Types
2. EHR Masters
3. EHR Customization APIs by Doctors - POST APIs
4. EHR Template Fetch by doctor_id
