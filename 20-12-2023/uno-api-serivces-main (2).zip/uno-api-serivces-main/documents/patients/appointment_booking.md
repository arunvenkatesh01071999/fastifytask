## Appointment booking

## Booking Types - Client Requirements

User can able to book a doctor by following ways.

1. can able to book a individual doctors
   - This case can do online consultation
2. can able to book a clinic doctors
   - patient can go directly to clinic
   - or they can do online consultation
3. can able to book a hospital doctors
   - Here booking notification send to health uno team and hosiptal co-ordinators
   - Based on doctor availably , they can arrange doctor consultation
   - Or user can able to visit hospital - based on slot availabilty that is confirmed by co-ordinators or UNO

## Logic:

## step 1

## Patients can able to search a doctors by following ways

- By symptoms Ex. chest pain, head ache
- By Illness (Disease) Ex. Dengu , Malria
- By Specality
- By Doctor Name

## step 2

- after serach done, it results doctors lists . It contains individual, hospital, clinic, doctors
- it shows doctors consulation fees also

## step 3

- in doctor lists , user can able to filter following scenario
- language
- fees
- instant consult
- experience
- distance
- location
- walk in - doctors
- video consults

## step 4

- then user can select anyone of the doctors from the list

## step 5

- after selecting doctors, next page will shows the doctors details list to know about the doctors
- also shows availabilty timings for booking
- use can able to select today,tommorrow and future dates.
- also can able to view entire slots availability

## step 6

- after selecting book appointment, it shows the booking details and payment details
- user can pay by using payment options

## step 7

- booking confirmation notifactions will send to patients, doctors, health uno team

## Tables Used

- doctors tables - all the tables with prefix d\_ are using to save doctors details
- from above table we list doctors list.

## Appointment booking Table

## Fields

- id - primary key
- doctor_id
- patient_id
- appointment_date
- appointment_from_time
- appointment_to_time
- appointment_status - "booked," "available," "cancelled," or "attended."
- reason - if cancelled reason to be captured
- appointment_duartion
- clinical_id - if clinical doctor booking
- hospital_id - if hospital doctor booking
- confirmation_status - 1 for confirmed ,0-booked ,2-rescheduled
- is_followup
- created_at
- updated_at
- created_by
- updated_by

## Reschedule History

To manage rescheduled appointments in a doctor-patient application, you can consider the following approaches:

Update Existing Appointment: When a patient requests to reschedule an appointment, you can update the existing appointment record in the database with the new date and time requested by the patient. This way, you can maintain a history of changes and have a record of the original appointment as well.

Availability Check: Before confirming the rescheduled appointment, check the availability of the doctor for the requested date and time. Ensure that the new slot does not conflict with any other appointments or schedule constraints.

Notification: Notify both the doctor and the patient about the rescheduled appointment. Send automated emails, SMS, or push notifications to inform them about the change in the appointment details.

Cancellation and Creation: If the rescheduling involves canceling the existing appointment and creating a new one, you can follow these steps:

a. Cancel the existing appointment: Update the status of the original appointment as "cancelled" and free up the slot in the doctor's schedule.

b. Create a new appointment: Create a new appointment record with the rescheduled date and time, and assign it to the respective doctor and patient. Ensure that the new slot is available and not conflicting with any other appointments.

History and Audit Trail: Maintain a history or audit trail of appointment changes, including the original and rescheduled dates and times. This can help in tracking the appointment history and identifying any patterns or issues.

By implementing these steps, you can effectively manage rescheduled appointments in your doctor-patient application and ensure smooth communication and coordination between doctors and patients.

## Fields

- id
- old_appointment_id
- new_appointment_id
- patient_id
- doctor_id
- created_at
- updated_at
- created_by
- updated_by

## APIs Needed.

1. Slot booking APIs by patient - POST API
2. Get all booking by passing patient id
3. rescheduled history also needed.
