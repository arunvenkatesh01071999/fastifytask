const { masterDbConfig, patientDbConfig } = require("./knexConfig");

module.exports = {
  masterDbConfig,
  patientDbConfig
};
