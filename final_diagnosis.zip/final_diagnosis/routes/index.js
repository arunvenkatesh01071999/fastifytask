const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  fastify.route({
    method: "POST",
    url: "/final-diagnosis",
     schema: schemas.getFinalDiagnosisSchema.createFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.createFinalDiagnosisHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/final-diagnosis/:id",
    schema: schemas.getFinalDiagnosisSchema.updateFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.updateFinalDiagnosisHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/final-diagnosis",
    schema: schemas.getFinalDiagnosisSchema.getFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.getFinalDiagnosisHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/final-diagnosis/:id",
   schema: schemas.getFinalDiagnosisSchema.getFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.getFinalDiagnosisHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/final-diagnosis/:id",
   schema: schemas.getFinalDiagnosisSchema.deleteFinalDiagnosisSchema,
    handler: handlers.getFinalDiagnosisHandler.deleteFinalDiagnosisHandler(fastify)
  });

};
