const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../../../src/app/commons/helpers");
const { FINALDIAGNOSIS } = require("../commons/constants");
// const { CustomError } = require("../../../errorHandler");

function postFinalDiagnosisRepositoryBasic(fastify) {
  async function FinalDiagnosisAdd({ logTrace, body }) {
    const knex = this;
    const query = await knex(`${FINALDIAGNOSIS.NAME}`).insert({
      [FINALDIAGNOSIS.COLUMNS.FINAL_DIAGNOSIS]: body.final_diagnosis,
      [FINALDIAGNOSIS.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    FinalDiagnosisAdd

  };
}

function updateFinalDiagnosisRepository(fastify) {
  async function FinalDiagnosisUpdate({ logTrace, body, params }) {
    const knex = this;
    const { id } = params;
    const query = await knex(`${FINALDIAGNOSIS.NAME}`)
      .where(`${FINALDIAGNOSIS.COLUMNS.ID}`, id)
      .update({
        [FINALDIAGNOSIS.COLUMNS.FINAL_DIAGNOSIS]: body.final_diagnosis,
      [FINALDIAGNOSIS.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    FinalDiagnosisUpdate,
  };
}

function getFinalDiagnosisRepository(fastify) {
  
  async function FinalDiagnosisGetAlls({ logTrace }) {
  
    const knex = this;
    const query = knex.select('*').from(`${FINALDIAGNOSIS.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get FINAL_DIAGNOSIS details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "FINAL_DIAGNOSIS info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    FinalDiagnosisGetAlls
  };

}


function getFinalDiagnosisRepositoryId(fastify) {
  
  async function FinalDiagnosisGetOne({ logTrace, params }) {
    
    const knex = this;
    const { id } = params;
    const query = knex.select('*').from(`${FINALDIAGNOSIS.NAME}`).where(`${FINALDIAGNOSIS.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get FINAL_DIAGNOSIS details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "FINAL_DIAGNOSIS info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    FinalDiagnosisGetOne
  };

}

function deleteFinalDiagnosisRepositoryId(fastify) {
  async function FinalDiagnosisDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${FINALDIAGNOSIS.NAME}`).where(`${FINALDIAGNOSIS.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    FinalDiagnosisDelete
  };
}


module.exports = {
  postFinalDiagnosisRepositoryBasic,
  updateFinalDiagnosisRepository,
  getFinalDiagnosisRepository,
  getFinalDiagnosisRepositoryId,
  deleteFinalDiagnosisRepositoryId

};
