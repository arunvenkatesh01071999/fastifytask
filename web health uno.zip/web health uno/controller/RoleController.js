const success_func = require('../api_responser').success_func;
const failure_func = require('../api_responser').failure_func;
const date = require('../services/datetime_service');
const role_services = require('../services/role_service');
const service_services = require('../services/service_service');
const cache = require('../services/redis_cache_service');
// const logger = require('../config/logger');


const FetchRoles = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await role_services.GetbyId(id)
            .then(role => {
                res.status(200).json(success_func(role))
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_roles');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await role_services.Get()
                .then(role => {
                    cache.SET(req.user.id + '_roles', role)
                    res.status(200).json(success_func(role))
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
        }
    }
}
const FetchRolesByModule = async (req, res, next) => {
    service_id = req.params.service_id;
    if (service_id) {
        await role_services.GetbyModuleId(service_id)
            .then(role => {
                res.status(200).json(success_func(role))
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {

        msg = "Module ID Not found";
        res.status(401).json(failure_func(msg))

    }
}

const NewRole = async (req, res, next) => {
    role_name = req.body.role_name;
    active = req.body.active;
    service_id = req.body.service_id;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (service_id) {
        await service_services.GetbyId(service_id)
            .then(service => {
                if (service.length == 0) {
                    msg = "Invalid service_id";
                    res.status(500).json(failure_func(msg))
                }
            })
    }
    if (role_name && service_id) {
        await role_services.GetbyName(role_name)
            .then(role_data => {
                if (role_data.length > 0) {
                    msg = "Role Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    role_services.CreateRole(role_name, active, service_id, created_by, updated_by)
                        .then(role => {
                            if (role.errors) {
                                msg = role.errors[0].message;
                                res.status(500).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_roles');
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(500).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "role_name, active and service_id is required";
        res.status(500).json(failure_func(msg))
    }
}

const UpdateRole = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        role_name = req.body.role_name;
        active = req.body.active;
        service_id = req.body.service_id;
        updated_by = req.user.id;
        updated_at = date();
        if (service_id) {
            await service_services.GetbyId(service_id)
                .then(service => {
                    if (service.length == 0) {
                        msg = "Invalid service_id";
                        res.status(500).json(failure_func(msg))
                    }
                })
        }
        if (role_name && service_id) {
            data = {
                role_name: role_name,
                active: active,
                service_id: service_id,
                updated_by: updated_by,
                updated_at: updated_at
            }
            // await role_services.GetbyName(role_name)
            //     .then(role_data => {
            //         if (role_data.length > 0) {
            //             msg = "Role Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
                        role_services.UpdateRole(id, data)
                            .then(role => {
                                if (role == 1) {
                                    msg = "Updated successfully"
                                    cache.DEL(req.user.id + '_roles');
                                    res.status(200).json(success_func(msg))
                                } else {
                                    msg = "ID doesn't exist"
                                    res.status(500).json(failure_func(msg))
                                }
                            })
                            .catch(err => {
                                res.status(500).json(failure_func(err))
                            })
                //     }
                // })
        } else {
            msg = "role_name, active and service_id is required";
            res.status(500).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

const DeleteRole = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await role_services.DestroyRole(id)
            .then(role => {
                if (role == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_roles');
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exists"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}


module.exports = {
    NewRole,
    FetchRoles,
    UpdateRole,
    DeleteRole,
    FetchRolesByModule
}