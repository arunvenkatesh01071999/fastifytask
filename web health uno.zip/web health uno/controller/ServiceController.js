const service_services = require('../services/service_service');
const date = require('../services/datetime_service');
const success_func = require('../api_responser').success_func;
const failure_func = require('../api_responser').failure_func;
const cache = require('../services/redis_cache_service');


const FetchServices = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await service_services.GetbyId(id)
            .then(service => {
                res.status(200).json(success_func(service))
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
            await service_services.Get()
                .then(service => {
                    cache.SET(req.user.id + '_services', service)
                    res.status(200).json(success_func(service))
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
        }
    }
// }

const NewService = async (req, res, next) => {

    const service_name = req.body.service_name;
    const active = req.body.active;

    if (service_name) {
        s_data = {
            service_name: service_name,
            active: active
        }
        await service_services.GetbyName(service_name)
            .then(services_data => {
                if (services_data.length > 0) {
                    msg = "Service Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    service_services.CreateService(s_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_services');
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
        //   try {
        //     const service = await service_services.CreateService(service_name, active);
        //     if (service.errors) {
        //       const msg = service.errors[0].message;
        //       res.send(success_func(msg));
        //     } else {
        //       const msg = "Created Successfully";
        //       cache.DEL(req.user.id + '_services');
        //       res.send(success_func(msg));
        //     }
        //   } catch (err) {
        //     res.status(401).send(failure_func(err));
        //   }
    } else {
        const msg = "service_name and active required";
        res.status(401).send(failure_func(msg));
    }
};

const UpdateService = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        service_name = req.body.service_name;
        active = req.body.active;
        updated_at = date();
        if (service_name) {
            data = { service_name: service_name, active: active, updated_at: updated_at }
            await service_services.UpdateService(id, data)
                .then(service => {
                    if (service == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_services');
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exists"
                        res.status(200).json(success_func(msg))
                    }
                })
                .catch(err => {
                    res.status(500).json(failure_func(err))
                })
        } else {
            msg = "service_name and active required";
            res.status(500).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}

const DeleteService = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await service_services.DestroyService(id)
            .then(service => {
                if (service == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_services');
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exists"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(500).json(failure_func(msg))
    }
}


module.exports = {
    NewService,
    FetchServices,
    UpdateService,
    DeleteService
}