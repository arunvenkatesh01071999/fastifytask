// const { success_func, failure_func } = require('../api_responser');
// const login_services = require('../services/login_service');
// const crypto = require('crypto');
// const generate_token = require('../services/generate_token');
// const logger = require('../config/logger');
// const { log } = require('winston');

// const UserLogin = async (req, res) => {
//     email = req.body.email;
//     password = req.body.password;
//     if (email && password) {
//         const hashed_password = crypto.pbkdf2Sync(password, 'salt', 2000, 40, 'sha256').toString('hex');
//         await login_services.GetUser(email, hashed_password)
//             .then(user => {
//                 if (user.length != 0) {
//                     data = user[0];
//                     const id = data.id
//                     const roles_id = data.roles_id
//                     // console.log(data.roles_id);
//                     const token = generate_token(data);
//                     msg = "Login Successful";
//                     logger.info(msg);
//                     resp2 = {id : id}
//                     resp3 = {roles_id : roles_id}
//                     resp = success_func(msg);
//                     resp.token = token;
//                     res.status(200).json([resp,resp2,resp3]);

//                 } else {
//                     msg = "Invalid credentials";
//                     logger.error(msg);
//                     res.status(401).json(failure_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.send(err)
//             })
//     } else {
//         msg = "email and password is required"
//         res.status(401).json(failure_func(msg))
//     }
// }

// module.exports = { UserLogin };

const { success_func, failure_func } = require('../api_responser');
const login_services = require('../services/login_service');
const crypto = require('crypto');
const generate_token = require('../services/generate_token');
const rolename = require('../services/role_name_service');
const logger = require('../config/logger');
const { log } = require('winston');

const UserLogin = async (req, res) => {
    email = req.body.email;
    password = req.body.password;
    if (email && password) {
        const hashed_password = crypto.pbkdf2Sync(password, 'salt', 2000, 40, 'sha256').toString('hex');
        await login_services.GetUser(email, hashed_password)
            .then(async user => {
                if (user.length != 0) {
                    data = user[0];
                    
                    const id = data.id;
                    const roles_id = data.roles_id;
                    const service_id = data.roles_id;
                    const rolenames = await rolename(roles_id);
                    const service_names = await rolename(service_id);
                    const token = await generate_token.generateToken(data);
                    // console.log('token', token);
                    msg = "Login Successful";
                    logger.info(msg);
                    const resp2 = { id: id }
                    const resp3 = { roles_id: roles_id }
                    const resp4 = { roles_name: rolenames }
                    const resp5 = { service_name: service_names }

                    resp = success_func(msg);
                    // console.log('d', resp);
                    resp.token = token;
                    res.status(200).json([resp, resp2, resp3, resp4, resp5]);


                } else {
                    msg = "Invalid credentials";
                    logger.error(msg);
                    res.status(401).json(failure_func(msg))
                }
            })
            .catch(err => {
                res.send(err)
            })
    } else {
        msg = "email and password is required"
        res.status(401).json(failure_func(msg))
    }
}

module.exports = { UserLogin };