const Infrastructure = require('../models/InfrastructureModel');
// const RoomTypeMaster = require('../../MastersApp/models/RoomTypeMasterModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');

const Get = async () => {
    await Infrastructure.findAll({ include: [HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (hospital_name_id) => {
    await Infrastructure.findAll({ where: { hospital_name_id: hospital_name_id }, include: [HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetId = async (id) => {
    await Infrastructure.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateInfra = async (in_data) => {
    await Infrastructure.create(in_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateInfra = async (id, in_data) => {
    await Infrastructure.update(in_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyInfra = async (id) => {
    await Infrastructure.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetId,
    GetbyId,
    CreateInfra,
    UpdateInfra,
    DestroyInfra,
};