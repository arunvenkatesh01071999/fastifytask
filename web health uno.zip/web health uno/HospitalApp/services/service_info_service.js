const ServiceInfo = require('../models/ServiceModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');

const Get = async () => {
    await ServiceInfo.findAll({ include: [HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (hospital_name_id) => {
    await ServiceInfo.findAll({ where: { hospital_name_id: hospital_name_id }, include: [HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetId = async (id) => {
    await ServiceInfo.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateService = async (l_data) => {
    await ServiceInfo.create(l_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

// const UpdateService = async (id, l_data) => {
//     await ServiceInfo.update(l_data, { where: { id: id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// };

const DestroyService = async (hospital_name_id) => {
    await ServiceInfo.destroy({ where: { hospital_name_id: hospital_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetId,
    GetbyId,
    CreateService,
    // UpdateService,
    DestroyService
};