const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const HospitalInfo = require('../models/HospitalBasicInfoModel');

const Contactinfo = sequelize.define("h_contact_info", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    mobile_no: {
        type: DataTypes.NUMBER,
        allowNull: false,
        // validate: {
        //     notEmpty: {
        //         msg: "Mobile Nummber is required"
        //     },
        //     len: {
        //         args: [10, 15],
        //         msg: "Please enter 10 digit Mobile Number"
        //     }
        // }
    },
    telephone_no: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    emergency_no: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    toll_free_no: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    helpline_no: {
        type: DataTypes.NUMBER,
        allowNull: false,
    },
    fax_no: {
        type: DataTypes.NUMBER,
        allowNull: false
    },
    ambulance_no: {
        type: DataTypes.NUMBER,
        allowNull: false
    },
    blood_bank_no: {
        type: DataTypes.NUMBER,
        allowNull: false
    },
    foreign_international_wing: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    webiste_URL: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    email_address_1: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    email_address_2: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    established_in: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
}, { freezeTableName: true });

Contactinfo.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' });

Contactinfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_contact_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

Contactinfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_contact_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = Contactinfo;