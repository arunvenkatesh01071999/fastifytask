const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const RoomType = require('../../MastersApp/models/RoomTypeMasterModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');
const logger = require('../../config/activity_logger');


const RoomInfo = sequelize.define("h_room_info", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    room_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    cost_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    no_of_days: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

RoomInfo.belongsTo(RoomType, { foreignKey: 'room_type_id' });
// RoomInfo.belongsTo(RoomType, { foreignKey: 'cost_id' });
RoomInfo.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' });

RoomInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_room_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

RoomInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_room_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = RoomInfo;