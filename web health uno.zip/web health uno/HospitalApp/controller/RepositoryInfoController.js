const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const repository_basic_info_services = require('../services/repository_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');

const FetchrepositoryBasicInfo = async (req, res, next) => {

    id = req.params.hospital_name_id;
    if (id) {
        await repository_basic_info_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_repository_basic_info_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await repository_basic_info_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_repository_basic_info_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        // }
    }
};



module.exports = {
    FetchrepositoryBasicInfo
}