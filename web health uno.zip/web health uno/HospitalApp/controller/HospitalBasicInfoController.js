// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const hospitalBasicInfo_services = require('../services/hospital_basic_info_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');
// const fs = require('fs');
// const hospital_img_services = require('../services/hospital_basic_img_service');
// const db1 = require('../../config/db1');
// const { log, count } = require('console');
// const HospitalImgInfo = require('../models/HospitalImgModel');

// const FetchHospitalBasicInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await hospitalBasicInfo_services.GetbyId(id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         // data = await cache.GET(req.user.id + '_hospitalBasicInfo_services');
//         // if (data) {
//         //     res.status(200).json(success_func(JSON.parse(data)))
//         // } else {
//         await hospitalBasicInfo_services.Get()
//             .then(data => {
//                 // console.log('data',data);
//                 cache.SET(req.user.id + '_hospitalBasicInfo_services', data)
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     }
// }
// // };

// const NewHospitalBasicInfo = async (req, res, next) => {
//     hospital_name = req.body.hospital_name;
//     hospital_type_id = req.body.hospital_type_id;
//     sector_id = req.body.sector_id;
//     accredation_id = req.body.accredation_id;
//     regNo = req.body.regNo;
//     about = req.body.about;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     const addCheck = 8;
//     try {
//         hospital_image = req.files.hospital_image;
//     } catch {
//         hospital_image = null
//     }
//     try {
//         certicate_path = req.files.certicate_path
//     } catch {
//         certicate_path = null
//     }
//     if (hospital_name) {
//         i_data = {
//             hospital_name: hospital_name,
//             hospital_type_id: parseInt(hospital_type_id),
//             sector_id: parseInt(sector_id),
//             accredation_id: parseInt(accredation_id),
//             certicate_path: certicate_path,
//             regNo: regNo,
//             about: about,
//             active: parseInt(active),
//             addCheck: addCheck,
//             created_by: created_by,
//             updated_by: updated_by
//         }

//         if (certicate_path) {
//             i_data.certicate_path = certicate_path.name;
//             buffer = certicate_path.data
//             path = './media/' + certicate_path.name;
//             fs.writeFile(path.toString(), buffer, function (err) {
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         console.log(i_data);

//         await hospitalBasicInfo_services.GetbyName(hospital_name)
//             .then(basic_data => {
//                 if (basic_data.length > 0) {
//                     msg = "Hospital Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     // console.log('else');
//                     hospitalBasicInfo_services.CreateHospitalBasicInfo(i_data)
//                         .then(data => {
//                             // if (data.errors) {
//                             //     msg = data.errors[0].message;
//                             //     res.status(400).json(failure_func(msg))
//                             // } else {
//                             // console.log(data.dataValues.id);
//                             var as = [];
//                             as.push(hospital_image)
//                             if (data.dataValues.id) {
//                                 if (hospital_image.length) {
//                                     hospital_image.forEach((element) => {
//                                         hospital_image = element.name;
//                                         record = element.name;
//                                         buffer = element.data
//                                         path = './media/' + element.name;
//                                         fs.writeFile(path.toString(), buffer, function (err) {
//                                             if (err) {
//                                                 return console.log(err);
//                                             }
//                                         });
//                                         i_data_img = {
//                                             hospital_name_id: data.dataValues.id,
//                                             hospital_image: record,
//                                             active: active,
//                                             created_by: created_by,
//                                             updated_by: updated_by
//                                         }
//                                         // console.log('l_data_img', l_data_img);
//                                         hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                     });
//                                 }
//                                 else {
//                                     as.forEach((element) => {
//                                         hospital_image = element.name;
//                                         record = element.name;
//                                         buffer = element.data
//                                         path = './media/' + element.name;
//                                         fs.writeFile(path.toString(), buffer, function (err) {
//                                             if (err) {
//                                                 return console.log(err);
//                                             }
//                                         });
//                                         i_data_img = {
//                                             hospital_name_id: data.dataValues.id,
//                                             hospital_image: record,
//                                             active: active,
//                                             created_by: created_by,
//                                             updated_by: updated_by
//                                         }
//                                         // console.log('l_data_img', l_data_img);
//                                         hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                     });
//                                 }


//                             }

//                             hospitalBasicInfo_services.GetbyName(hospital_name)
//                                 .then(datas => {
//                                     datas.msg = "Created Successfully";
//                                     //cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                                     res.status(200).json(success_func(datas))
//                                 })
//                                 .catch(err => {
//                                     res.status(400).json(failure_func(err))
//                                 })
//                             // }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     }
//     else {
//         msg = "hospital_name is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateHospitalBasicInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         // hospitalBasicInfo_services.DestroyHospitalBasicInfo(id);
//         hospital_name = req.body.hospital_name;
//         hospital_type_id = req.body.hospital_type_id;
//         sector_id = req.body.sector_id;
//         accredation_id = req.body.accredation_id;
//         regNo = req.body.regNo;
//         about = req.body.about;


//         if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//             // File is uploaded
//             certicate_path = req.files.certicate_path;
//             // Process the uploaded file
//         } else {
//             // Text input
//             certicate_path = req.body.certicate_path; // Assuming the input field name is 'hospital_image'
//             // Process the text input
//         }
//         try {
//             hospital_image = req.files.hospital_image;
//         } catch {
//             hospital_image_body = req.body.hospital_image;
//         }
//         isApproved = req.body.isApproved;
//         approve_date = req.body.approve_date;
//         approved_by = req.body.approved_by;
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (hospital_name) {
//             const i_data = {
//                 hospital_name: hospital_name,
//                 hospital_type_id: parseInt(hospital_type_id),
//                 sector_id: parseInt(sector_id),
//                 accredation_id: parseInt(accredation_id),
//                 regNo: regNo,
//                 about: about,
//                 certicate_path: certicate_path,
//                 // hospital_image: hospital_image,
//                 isApproved: isApproved,
//                 approved_by: approved_by,
//                 approve_date: approve_date,
//                 active: parseInt(active),
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }

//             if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//                 // File is uploaded
//                 i_data.certicate_path = certicate_path.name;
//                 buffer = certicate_path.data
//                 path = './media/' + certicate_path.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//                 // Process the uploaded file
//             }
//             else {
//                 // Text input
//                 certicate_path = req.body.certicate_path; // Assuming the input field name is 'hospital_image'
//                 i_data.certicate_path = certicate_path;
//                 // Process the text input
//             }
//             console.log(i_data)
//             await hospitalBasicInfo_services.UpdateHospitalBasicInfo(id, i_data)
//                 .then(data => {
//                     if (data == 1) {
//                         const hosp_id = req.params.id;
//                         hospital_img_services.CheckHospitalmgBasicInfo(hosp_id)
//                             .then(result => {
//                                 if (req.files == null) {
//                                     const hospital_image_body_data = req.body.hospital_image.toString();
//                                     var req_array = hospital_image_body_data.split(',');
//                                     var exist_array = [];

//                                     result.forEach((element) => {
//                                         exist_array.push(element.hospital_image)
//                                     });
//                                     var uncommonElements = [];

//                                     // Create sets for faster lookup
//                                     const set1 = new Set(req_array);
//                                     const set2 = new Set(exist_array);
//                                     for (const item of set1) {
//                                         if (!set2.has(item)) {
//                                             uncommonElements.push(item);
//                                         }
//                                     }
//                                     // Check for uncommon elements in arr2
//                                     for (const item of set2) {
//                                         if (!set1.has(item)) {
//                                             uncommonElements.push(item);
//                                         }
//                                     }
//                                     if (uncommonElements.length > 0) {
//                                         const filteredData = result.filter((item) => uncommonElements.includes(item.hospital_image));
//                                         filteredData.forEach((element) => {
//                                             HospitalImgInfo.destroy({ where: { hospital_image: element.hospital_image } })
//                                                 .then(data => {
//                                                     res = data
//                                                 }).catch(err => {
//                                                     res = err
//                                                 })
//                                         });
//                                     }
//                                 }
//                                 else {
//                                     console.log('else');
//                                     const hospital_image = req.files.hospital_image;
//                                     const check_file = hospital_image.length;
//                                     if (check_file == undefined) {
//                                         const dummy = [];
//                                         dummy.push(hospital_image);
//                                         dummy.forEach((element) => {
//                                             const hospital_image = element.name;
//                                             const record = element.name;
//                                             buffer = element.data
//                                             path = './media/' + element.name;
//                                             fs.writeFile(path.toString(), buffer, function (err) {
//                                                 if (err) {
//                                                     return console.log(err);
//                                                 }
//                                             });
//                                             i_data_img = {
//                                                 hospital_name_id: req.params.id,
//                                                 hospital_image: record,
//                                                 active: active,
//                                                 created_by: updated_by,
//                                                 updated_by: updated_by
//                                             }
//                                             console.log('l_data_img', i_data_img);
//                                             hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                         });

//                                     }
//                                     else {
//                                         hospital_image.forEach((element) => {
//                                             const hospital_image = element.name;
//                                             const record = element.name;
//                                             buffer = element.data
//                                             path = './media/' + element.name;
//                                             fs.writeFile(path.toString(), buffer, function (err) {
//                                                 if (err) {
//                                                     return console.log(err);
//                                                 }
//                                             });
//                                             i_data_img = {
//                                                 hospital_name_id: req.params.id,
//                                                 hospital_image: record,
//                                                 active: active,
//                                                 created_by: updated_by,
//                                                 updated_by: updated_by
//                                             }
//                                             console.log('l_data_img', i_data_img);
//                                             hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

//                                         });
//                                     }


//                                 }
//                             })
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         } else {
//             msg = "hospital_name is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const DeleteHospitalBasicInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await hospitalBasicInfo_services.DestroyHospitalBasicInfo(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const HospitalApprove = async (req, res, next) => {
//     const id = req.params.id
//     // console.log(req.body, "idhhjhjk");
//     if (id) {
//         const { isApproved, approve_date, approved_by, reason, id } = req.body;
//         // if (isApproved) {
//         if (isApproved === 1) {
//             const a_data = {
//                 id: parseInt(id),
//                 isApproved: isApproved,
//                 approve_date: approve_date,
//                 approved_by: approved_by,
//                 reason: reason
//             }
//             // console.log(a_data, "a_datajwueqje");
//             hospitalBasicInfo_services.CreateApprove(id, a_data)
//                 .then(data => {
//                     if (data.errors) {
//                         msg = data.errors[0].message;
//                         res.status(400).json(failure_func(msg))
//                     } else {
//                         msg = "Approved Successfully"
//                         cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                         res.status(200).json(success_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         }
//         else {
//             const a_data = {
//                 id: parseInt(id),
//                 isApproved: isApproved,
//                 approve_date: approve_date,
//                 approved_by: approved_by,
//                 reason: reason
//             }
//             // console.log(a_data, "12223");
//             hospitalBasicInfo_services.CreateApprove(id, a_data)
//                 .then(data => {
//                     if (data.errors) {
//                         msg = data.errors[0].message;
//                         res.status(400).json(failure_func(msg))
//                     } else {
//                         msg = "Rejected Successfully"
//                         cache.DEL(req.user.id + '_hospitalBasicInfo_services')
//                         res.status(200).json(success_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })

//         }
//         // }
//     }
// }

// const UpdateforApprove = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await hospitalBasicInfo_services.UpdateIsApprove(id)
//             .then(data => {
//                 res.json("created success")
//             }).catch(err => {
//                 res.json("not created")
//             })
//     }
// }

// module.exports = {
//     FetchHospitalBasicInfo,
//     NewHospitalBasicInfo,
//     UpdateHospitalBasicInfo,
//     DeleteHospitalBasicInfo,
//     HospitalApprove,
//     UpdateforApprove
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const hospitalBasicInfo_services = require('../services/hospital_basic_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const hospital_img_services = require('../services/hospital_basic_img_service');
const db1 = require('../../config/db1');
const { log, count } = require('console');
const HospitalImgInfo = require('../models/HospitalImgModel');

const FetchHospitalBasicInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospitalBasicInfo_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_hospitalBasicInfo_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await hospitalBasicInfo_services.Get()
            .then(data => {
                // console.log('data',data);
                cache.SET(req.user.id + '_hospitalBasicInfo_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// };



const fetchhosnameid = async (req, res, next) => {
    user_id = req.params.user_id;
   
      await hospitalBasicInfo_services.GetuserId(user_id)
        .then(data => {
          res.status(200).json(success_func(data))
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })};
  

const NewHospitalBasicInfo = async (req, res, next) => {
    hospital_name = req.body.hospital_name;
    hospital_type_id = req.body.hospital_type_id;
    sector_id = req.body.sector_id;
    accredation_id = req.body.accredation_id;
    regNo = req.body.regNo;
    about = req.body.about;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    const addCheck = 8;
    try {
        hospital_image = req.files.hospital_image;
    } catch {
        hospital_image = null
    }
    try {
        certicate_path = req.files.certicate_path
    } catch {
        certicate_path = null
    }
    if (hospital_name) {
        i_data = {
            hospital_name: hospital_name,
            hospital_type_id: parseInt(hospital_type_id),
            sector_id: parseInt(sector_id),
            accredation_id: parseInt(accredation_id),
            certicate_path: certicate_path,
            regNo: regNo,
            about: about,
            active: parseInt(active),
            addCheck: addCheck,
            created_by: created_by,
            updated_by: updated_by
        }

        if (certicate_path) {
            i_data.certicate_path = certicate_path.name;
            buffer = certicate_path.data
            path = './media/' + certicate_path.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });
        }
        console.log(i_data);

        await hospitalBasicInfo_services.GetbyName(hospital_name)
            .then(basic_data => {
                if (basic_data.length > 0) {
                    msg = "Hospital Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                  
                    // console.log('else');
                    hospitalBasicInfo_services.CreateHospitalBasicInfo(i_data)
                        .then(data => {   
                            // console.log("asdaf");
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                            console.log('kkkkkk',data);
                            var as = [];
                          
                            as.push(hospital_image)
                            console.log('hhhh',data.dataValues.id);
                            if (data.dataValues.id) {     
                                
                                if (hospital_image.length) {
                               
                                    hospital_image.forEach((element) => {
                                        hospital_image = element.name;
                                        record = element.name;
                                        buffer = element.data
                                        path = './media/' + element.name;
                                        fs.writeFile(path.toString(), buffer, function (err) {
                                            if (err) {
                                                return console.log(err);
                                            }
                                        });
                                        i_data_img = {
                                            hospital_name_id: data.dataValues.id,
                                            hospital_image: record,
                                            active: active,
                                            created_by: created_by,
                                            updated_by: updated_by
                                        }
                                        // console.log('l_data_img', l_data_img);
                                        hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

                                    });
                                }
                                else {
                                    as.forEach((element) => {
                                        hospital_image = element.name;
                                        record = element.name;
                                        buffer = element.data
                                        path = './media/' + element.name;
                                        fs.writeFile(path.toString(), buffer, function (err) {
                                            if (err) {
                                                return console.log(err);
                                            }
                                        });
                                        i_data_img = {
                                            hospital_name_id: data.dataValues.id,
                                            hospital_image: record,
                                            active: active,
                                            created_by: created_by,
                                            updated_by: updated_by
                                        }
                                        // console.log('l_data_img', l_data_img);
                                        hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

                                    });
                                }


                            }

                            hospitalBasicInfo_services.GetbyName(hospital_name)
                                .then(datas => {
                                    datas.msg = "Created Successfully";
                                    //cache.DEL(req.user.id + '_hospitalBasicInfo_services')
                                    res.status(200).json(success_func(datas))
                                })
                                .catch(err => {
                                    res.status(400).json(failure_func(err))
                                })
                            }
                        })
                        .catch(err => {
                            msg = "failed"
                            res.status(400).json(failure_func(msg))
                        })
                }
            })
    }
    else {
        msg = "hospital_name is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateHospitalBasicInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        // hospitalBasicInfo_services.DestroyHospitalBasicInfo(id);
        hospital_name = req.body.hospital_name;
        hospital_type_id = req.body.hospital_type_id;
        sector_id = req.body.sector_id;
        // user_id = req.body.user_id;
        accredation_id = req.body.accredation_id;
        regNo = req.body.regNo;
        about = req.body.about;


        if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
            // File is uploaded
            certicate_path = req.files.certicate_path;
            // Process the uploaded file
        } else {
            // Text input
            certicate_path = req.body.certicate_path; // Assuming the input field name is 'hospital_image'
            // Process the text input
        }
        try {
            hospital_image = req.files.hospital_image;
        } catch {
            hospital_image_body = req.body.hospital_image;
        }
        isApproved = req.body.isApproved;
        approve_date = req.body.approve_date;
        approved_by = req.body.approved_by;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (hospital_name) {
            const i_data = {
                hospital_name: hospital_name,
                hospital_type_id: parseInt(hospital_type_id),
                sector_id: parseInt(sector_id),
                accredation_id: parseInt(accredation_id),
                regNo: regNo,
                // user_id : user_id,
                about: about,
                certicate_path: certicate_path,
                // hospital_image: hospital_image,
                isApproved: isApproved,
                approved_by: approved_by,
                approve_date: approve_date,
                active: parseInt(active),
                updated_by: updated_by,
                updated_at: updated_at
            }

            if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
                // File is uploaded
                i_data.certicate_path = certicate_path.name;
                buffer = certicate_path.data
                path = './media/' + certicate_path.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });
                // Process the uploaded file
            }
            else {
                // Text input
                certicate_path = req.body.certicate_path; // Assuming the input field name is 'hospital_image'
                i_data.certicate_path = certicate_path;
                // Process the text input
            }
            console.log(i_data)
            await hospitalBasicInfo_services.UpdateHospitalBasicInfo(id, i_data)
                .then(data => {
                    if (data == 1) {
                        const hosp_id = req.params.id;
                        hospital_img_services.CheckHospitalmgBasicInfo(hosp_id)
                            .then(result => {
                                if (req.files == null) {
                                    const hospital_image_body_data = req.body.hospital_image.toString();
                                    var req_array = hospital_image_body_data.split(',');
                                    var exist_array = [];

                                    result.forEach((element) => {
                                        exist_array.push(element.hospital_image)
                                    });
                                    var uncommonElements = [];

                                    // Create sets for faster lookup
                                    const set1 = new Set(req_array);
                                    const set2 = new Set(exist_array);
                                    for (const item of set1) {
                                        if (!set2.has(item)) {
                                            uncommonElements.push(item);
                                        }
                                    }
                                    // Check for uncommon elements in arr2
                                    for (const item of set2) {
                                        if (!set1.has(item)) {
                                            uncommonElements.push(item);
                                        }
                                    }
                                    if (uncommonElements.length > 0) {
                                        const filteredData = result.filter((item) => uncommonElements.includes(item.hospital_image));
                                        filteredData.forEach((element) => {
                                            HospitalImgInfo.destroy({ where: { hospital_image: element.hospital_image } })
                                                .then(data => {
                                                    res = data
                                                }).catch(err => {
                                                    res = err
                                                })
                                        });
                                    }
                                }
                                else {
                                    console.log('else');
                                    const hospital_image = req.files.hospital_image;
                                    const check_file = hospital_image.length;
                                    if (check_file == undefined) {
                                        const dummy = [];
                                        dummy.push(hospital_image);
                                        dummy.forEach((element) => {
                                            const hospital_image = element.name;
                                            const record = element.name;
                                            buffer = element.data
                                            path = './media/' + element.name;
                                            fs.writeFile(path.toString(), buffer, function (err) {
                                                if (err) {
                                                    return console.log(err);
                                                }
                                            });
                                            i_data_img = {
                                                hospital_name_id: req.params.id,
                                                hospital_image: record,
                                                active: active,
                                                created_by: updated_by,
                                                updated_by: updated_by
                                            }
                                            console.log('l_data_img', i_data_img);
                                            hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

                                        });

                                    }
                                    else {
                                        hospital_image.forEach((element) => {
                                            const hospital_image = element.name;
                                            const record = element.name;
                                            buffer = element.data
                                            path = './media/' + element.name;
                                            fs.writeFile(path.toString(), buffer, function (err) {
                                                if (err) {
                                                    return console.log(err);
                                                }
                                            });
                                            i_data_img = {
                                                hospital_name_id: req.params.id,
                                                hospital_image: record,
                                                active: active,
                                                created_by: updated_by,
                                                updated_by: updated_by
                                            }
                                            console.log('l_data_img', i_data_img);
                                            hospital_img_services.CreateHospitalmgBasicInfo(i_data_img)

                                        });
                                    }


                                }
                            })
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_hospitalBasicInfo_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "hospital_name is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteHospitalBasicInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospitalBasicInfo_services.DestroyHospitalBasicInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_hospitalBasicInfo_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const HospitalApprove = async (req, res, next) => {
    const id = req.params.id
    // console.log(req.body, "idhhjhjk");
    if (id) {
        const { isApproved, approve_date, approved_by, reason, id } = req.body;
        // if (isApproved) {
        if (isApproved === 1) {
            const a_data = {
                id: parseInt(id),
                isApproved: isApproved,
                approve_date: approve_date,
                approved_by: approved_by,
                reason: reason
            }
            // console.log(a_data, "a_datajwueqje");
            hospitalBasicInfo_services.CreateApprove(id, a_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                        res.status(400).json(failure_func(msg))
                    } else {
                        msg = "Approved Successfully"
                        cache.DEL(req.user.id + '_hospitalBasicInfo_services')
                        res.status(200).json(success_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        else {
            const a_data = {
                id: parseInt(id),
                isApproved: isApproved,
                approve_date: approve_date,
                approved_by: approved_by,
                reason: reason
            }
            console.log(a_data, "12223");
            hospitalBasicInfo_services.CreateApprove(id, a_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                        res.status(400).json(failure_func(msg))
                    } else {
                        msg = "Rejected Successfully"
                        cache.DEL(req.user.id + '_hospitalBasicInfo_services')
                        res.status(200).json(success_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        }
        // }
    }
}

const UpdateforApprove = async (req, res, next) => {
    id = req.params.id;
    if (id) {
      await hospitalBasicInfo_services.UpdateIsApprove(id)
      .then(data=>{
        res.json('created success')
    }).catch(err=>{
        res.json('not created')
    })
    }
  }

module.exports = {
    FetchHospitalBasicInfo,
    NewHospitalBasicInfo,
    UpdateHospitalBasicInfo,
    DeleteHospitalBasicInfo,
    HospitalApprove,
    UpdateforApprove,
    fetchhosnameid
}