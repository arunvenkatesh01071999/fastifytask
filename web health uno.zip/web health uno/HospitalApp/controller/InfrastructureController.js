const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const infrastructure_services = require('../services/infrastructure_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');

const FetchInfraStructure = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await infrastructure_services.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_infrastructure_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await infrastructure_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_infrastructure_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// };

const NewInfraStructure = async (req, res, next) => {
    hospital_name_id = req.body.hospital_name_id;
    no_of_doctor = req.body.no_of_doctor;
    no_of_ambulances = req.body.no_of_ambulances;
    anesth_doctor = req.body.anesth_doctor;
    anotomy_doctor = req.body.anotomy_doctor;
    cardio_doctor = req.body.cardio_doctor;
    operation_theatre = req.body.operation_theatre;
    icu = req.body.icu;
    // room_type_id = req.body.room_type_id;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.hospital_name_id);

    if (no_of_doctor) {
        in_data = {
            hospital_name_id: hospital_name_id,
            no_of_doctor: no_of_doctor,
            no_of_ambulances: no_of_ambulances,
            anesth_doctor: anesth_doctor,
            anotomy_doctor: anotomy_doctor,
            cardio_doctor: cardio_doctor,
            operation_theatre: operation_theatre,
            icu: icu,
            addCheck: addCheck,
            // room_type_id: parseInt(room_type_id),
            active: active,
            created_by: created_by,
            updated_by: updated_by
        };
        // console.log(in_data);
        await infrastructure_services.GetId(hospital_name_id)
            .then(data => {
                if (data.length > 0) {
                    msg = "Hospital Address Already Exist";
                    return res.status(200).json(failure_func(msg))
                } else {
                    infrastructure_services.CreateInfra(in_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                infrastructure_services.GetId(hospital_name_id)
                                    .then(datas => {
                                        datas.msg = "Created Successfully"
                                        cache.DEL(req.user.id + '_infrastructure_services')
                                        res.status(200).json(success_func(datas))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "No Of Doctor is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateInfraStructure = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        hospital_name_id = req.body.hospital_name_id;
        no_of_doctor = req.body.no_of_doctor;
        no_of_ambulances = req.body.no_of_ambulances;
        anesth_doctor = req.body.anesth_doctor;
        anotomy_doctor = req.body.anotomy_doctor;
        cardio_doctor = req.body.cardio_doctor;
        operation_theatre = req.body.operation_theatre;
        icu = req.body.icu;
        // room_type_id = req.body.room_type_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (no_of_doctor) {
            in_data = {
                hospital_name_id: hospital_name_id,
                no_of_doctor: no_of_doctor,
                no_of_ambulances: no_of_ambulances,
                anesth_doctor: anesth_doctor,
                anotomy_doctor: anotomy_doctor,
                cardio_doctor: cardio_doctor,
                operation_theatre: operation_theatre,
                icu: icu,
                // room_type_id: room_type_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            console.log(in_data)
            await infrastructure_services.UpdateInfra(id, in_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_infrastructure_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "No Of Doctor is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteInfraStructure = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await infrastructure_services.DestroyInfra(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_infrastructure_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    FetchInfraStructure,
    NewInfraStructure,
    UpdateInfraStructure,
    DeleteInfraStructure
}