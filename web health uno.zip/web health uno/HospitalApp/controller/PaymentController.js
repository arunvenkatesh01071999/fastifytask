// // const success_func = require('../../api_responser').success_func;
// // const failure_func = require('../../api_responser').failure_func;
// // const date = require('../../services/datetime_service');
// // const payment_service = require('../../services/payment_info_service');
// // const logger = require('../../config/logger');
// // const cache = require('../../services/redis_cache_service');
// // const HospitalPaymentInfoModel = require('../models/HospitalPaymentinfoModel');
// // const db1 = require('../../config/db1')

// // const FetchPayment = async (req, res, next) => {
// //     hospital_name_id = req.params.hospital_name_id;
// //     if (hospital_name_id) {
// //         await HospitalPaymentInfoModel.findAll({
// //             where: { hospital_name_id: hospital_name_id }
// //         })
// //             .then(data => {
// //                 ress = data
// //             })
// //             .catch(err => {
// //                 ress = err
// //             })
// //         res.status(200).json(success_func(ress))
// //     }
// //     else {

// //         await HospitalPaymentInfoModel.findAll({})
// //             .then(data => {
// //                 ress = data
// //             })
// //             .catch(err => {
// //                 ress = err
// //             })
// //         res.status(200).json(success_func(ress))
// //     }
// // }


// // const NewPayment = async (req, res, next) => {
// //     fees_type_id = req.body.fees_type_id;
// //     fees_amt = req.body.fees_amt;
// //     commision = req.body.commision;
// //     check = req.body.check;
// //     active = req.body.active;
// //     hospital_name_id = req.body.hospital_name_id;
// //     created_by = req.user.id;
// //     updated_by = req.user.id;
// //     check_name = req.body.name;
// //     const addCheck = 4;
// //     const query = `select addCheck from h_hospital_basic_info where id =${req.body.hospital_name_id}`;
// //     var customerFeedback = await db1.query(query);
// //     var menu_data = customerFeedback.flat();
// //     var total_add=0;
// //     total_add = addCheck + menu_data[0].addCheck;
// //     const query1 = `UPDATE h_hospital_basic_info SET addCheck = ${total_add} where id =${hospital_name_id}`
// //     var customerFeedback1 = await db1.query(query1);
// //     updated_at = date();
// //     created_at = date();

// //     if (fees_amt) {
// //         if (check == 0) {
// //             N_display_amt = fees_amt;
// //             N_commision = fees_amt * (commision / 100);
// //             N_payout = fees_amt - N_commision;
// //             s_display_amt = 0;
// //             s_commision = 0;
// //             s_payout = 0;


// //         }
// //         else {
// //             N_display_amt = 0;
// //             N_commision = 0;
// //             N_payout = 0;
// //             cal = fees_amt * (commision / 100);
// //             final_amt = fees_amt - cal;
// //             s_display_amt = 0;
// //             s_commision = 0;
// //             s_payout = final_amt;
// //         }

// //         sl_data = {
// //             fees_type_id: fees_type_id,
// //             fees_amt: fees_amt,
// //             commision: commision,
// //             check: check,
// //             N_display_amt: N_display_amt,
// //             N_commision: N_commision,
// //             N_payout: N_payout,
// //             s_display_amt: s_display_amt,
// //             s_commision: s_commision,
// //             s_payout: s_payout,
// //             name: check_name,
// //             addCheck:addCheck,
// //             active: active,
// //             hospital_name_id: hospital_name_id,
// //             created_by: created_by,
// //             created_at: created_at,
// //             updated_at: updated_at,
// //             updated_by: updated_by
// //         }
// //         await payment_service.CreatePaymentInfo(sl_data)
// //             .then(data => {
// //                 if (data.errors) {
// //                     msg = data.errors[0].message;
// //                     res.status(400).json(failure_func(msg))
// //                 } else {
// //                     msg = "Created Successfully"
// //                     cache.DEL(req.user.id + '_payment_service')
// //                     res.status(200).json(success_func(data))
// //                 }
// //             })
// //             .catch(err => {
// //                 res.status(400).json(failure_func(err))
// //             })
// //     } else {
// //         msg = "Fees Amt is required";
// //         res.status(400).json(failure_func(msg))
// //     }
// // }


// // module.exports = {
// //     NewPayment,
// //     FetchPayment
// // }

// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const payment_service = require('../../services/payment_info_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');
// const HospitalPaymentInfoModel = require('../models/HospitalPaymentinfoModel');
// const db1 = require('../../config/db1');
// const consultFeeType = require('../../MastersApp/models/FeesTypeMasterModel');
// // const hospitalBasic = require('../models/HospitalBasicInfoModel')

// const FetchPayment = async (req, res, next) => {
//     hospital_name_id = req.params.hospital_name_id;
//     if (hospital_name_id) {
//         await HospitalPaymentInfoModel.findAll({
//             where: { hospital_name_id: hospital_name_id },
//             include : [consultFeeType]
//         })
//             .then(data => {
//                 ress = data
//             })
//             .catch(err => {
//                 ress = err
//             })
//         res.status(200).json(success_func(ress))
//     }
//     else {

//         await HospitalPaymentInfoModel.findAll({
//             include : [consultFeeType]
//         })
//             .then(data => {
//                 ress = data
//             })
//             .catch(err => {
//                 ress = err
//             })
//         res.status(200).json(success_func(ress))
//     }
// }


// const NewPayment = async (req, res, next) => {
//     fees_type_id = req.body.fees_type_id;
//     fees_amt = req.body.fees_amt;
//     commision = req.body.commision;
//     check = req.body.check;
//     active = req.body.active;
//     hospital_name_id = req.body.hospital_name_id;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     check_name = req.body.name;
//     const addCheck = 4;
//     const query = `select addCheck from h_hospital_basic_info where id =${req.body.hospital_name_id}`;
//     var customerFeedback = await db1.query(query);
//     var menu_data = customerFeedback.flat();
//     var total_add=0;
//     total_add = addCheck + menu_data[0].addCheck;
//     const query1 = `UPDATE h_hospital_basic_info SET addCheck = ${total_add} where id =${hospital_name_id}`
//     var customerFeedback1 = await db1.query(query1);
//     updated_at = date();
//     created_at = date();

//     if (fees_amt) {
//         if (check == 0) {
//             N_display_amt = fees_amt;
//             N_commision = fees_amt * (commision / 100);
//             N_payout = fees_amt - N_commision;
//             s_display_amt = 0;
//             s_commision = 0;
//             s_payout = 0;


//         }
//         else {
//             N_display_amt = 0;
//             N_commision = 0;
//             N_payout = 0;
//             cal = fees_amt * (commision / 100);
//             final_amt = fees_amt - cal;
//             s_display_amt = 0;
//             s_commision = 0;
//             s_payout = final_amt;
//         }

//         sl_data = {
//             fees_type_id: fees_type_id,
//             fees_amt: fees_amt,
//             commision: commision,
//             check: check,
//             N_display_amt: N_display_amt,
//             N_commision: N_commision,
//             N_payout: N_payout,
//             s_display_amt: s_display_amt,
//             s_commision: s_commision,
//             s_payout: s_payout,
//             name: check_name,
//             addCheck:addCheck,
//             active: active,
//             hospital_name_id: hospital_name_id,
//             created_by: created_by,
//             created_at: created_at,
//             updated_at: updated_at,
//             updated_by: updated_by
//         }
        
//         await payment_service.CreatePaymentInfo(sl_data)
//             .then(data => {
//                 if (data.errors) {
//                     msg = data.errors[0].message;
//                     res.status(400).json(failure_func(msg))
//                 } else {
//                     msg = "Created Successfully"
//                     cache.DEL(req.user.id + '_payment_service')
//                     res.status(200).json(success_func(data))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "Fees Amt is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


// module.exports = {
//     NewPayment,
//     FetchPayment
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const payment_service = require('../../services/payment_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const HospitalPaymentInfoModel = require('../models/HospitalPaymentinfoModel');
const db1 = require('../../config/db1')

const consultFeeType = require('../../MastersApp/models/FeesTypeMasterModel')

const FetchPayment = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await HospitalPaymentInfoModel.findAll({
            where: { hospital_name_id: hospital_name_id },
            include : [consultFeeType]
        })
            .then(data => {
                ress = data
            })
            .catch(err => {
                ress = err
            })
        res.status(200).json(success_func(ress))
    }
    else {

        await HospitalPaymentInfoModel.findAll({
            include : [consultFeeType]
        })
            .then(data => {
                ress = data
            })
            .catch(err => {
                ress = err
            })
        res.status(200).json(success_func(ress))
    }
}


const NewPayment = async (req, res, next) => {
    fees_type_id = req.body.fees_type_id;
    fees_amt = req.body.fees_amt;
    commision = req.body.commision;
    check = req.body.check;
    active = req.body.active;
    hospital_name_id = req.body.hospital_name_id;
    created_by = req.user.id;
    updated_by = req.user.id;
    check_name = req.body.name;
    const addCheck = 4;
    const query = `select addCheck from h_hospital_basic_info where id =${req.body.hospital_name_id}`;
    var customerFeedback = await db1.query(query);
    var menu_data = customerFeedback.flat();
    var total_add=0;
    total_add = addCheck + menu_data[0].addCheck;
    const query1 = `UPDATE h_hospital_basic_info SET addCheck = ${total_add} where id =${hospital_name_id}`
    var customerFeedback1 = await db1.query(query1);
    updated_at = date();
    created_at = date();

    if (fees_amt) {
        if (check == 0) {
            N_display_amt = fees_amt;
            N_commision = fees_amt * (commision / 100);
            N_payout = fees_amt - N_commision;
            s_display_amt = 0;
            s_commision = 0;
            s_payout = 0;


        }
        else {
            N_display_amt = 0;
            N_commision = 0;
            N_payout = 0;
            cal = fees_amt * (commision / 100);
            final_amt = fees_amt - cal;
            s_display_amt = 0;
            s_commision = 0;
            s_payout = final_amt;
        }

        sl_data = {
            fees_type_id: fees_type_id,
            fees_amt: fees_amt,
            commision: commision,
            check: check,
            N_display_amt: N_display_amt,
            N_commision: N_commision,
            N_payout: N_payout,
            s_display_amt: s_display_amt,
            s_commision: s_commision,
            s_payout: s_payout,
            name: check_name,
            addCheck:addCheck,
            active: active,
            hospital_name_id: hospital_name_id,
            created_by: created_by,
            created_at: created_at,
            updated_at: updated_at,
            updated_by: updated_by
        }
        
        await payment_service.CreatePaymentInfo(sl_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_payment_service')
                    res.status(200).json(success_func(data))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "Fees Amt is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewPayment,
    FetchPayment
}