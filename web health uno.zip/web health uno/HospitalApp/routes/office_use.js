const express = require('express');
const router = express();
const OfficeUseController = require('../controller/OfficeUseController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, OfficeUseController.FetchOfficeUse);
router.get('/:hospital_name_id', verify_token, OfficeUseController.FetchOfficeUse);
router.post('/', verify_token, OfficeUseController.NewOfficeUse);
router.put('/:id', verify_token, OfficeUseController.UpdateOfficeUse);
// router.delete('/:id', verify_token, OfficeUseController.DeleteOfficeUse);

module.exports = router;