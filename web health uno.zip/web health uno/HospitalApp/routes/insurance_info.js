const express = require('express');
const router = express();
const InsuranceInfoController = require('../controller/InsuranceController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, InsuranceInfoController.FetchInsuranceInfo);
router.get('/:hospital_name_id', verify_token, InsuranceInfoController.FetchInsuranceInfo);
router.post('/', verify_token, InsuranceInfoController.NewInsuranceInfo);
router.put('/:hospital_name_id', verify_token, InsuranceInfoController.UpdateInsuranceInfo);
// router.delete('/:id', verify_token, InsuranceInfoController.DeleteInsuranceInfo);

module.exports = router;