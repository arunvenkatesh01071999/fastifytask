const express = require('express');
const router = express();
const UserController = require('../controller/UserController');
const verify_token = require('../services/verify_token');

router.get('/user', verify_token, UserController.FetchUsers);
router.get('/user/:id', verify_token, UserController.FetchUsers);
router.post('/user', verify_token, UserController.NewUser);
router.put('/user/:id', verify_token, UserController.UpdateUser);
router.delete('/user/:id', verify_token, UserController.DeleteUser);
router.post('/user/verify-otp', verify_token, UserController.otp_verification);


module.exports = router; 