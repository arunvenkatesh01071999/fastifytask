const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const LabInfo = require('../models/LabBasicInfoModel');


const OfficeInfo = sequelize.define("l_office_use", {
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Address is required"
            }
        }
    },
    person_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "person_name is required"
            }
        }
    },
    person_email_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    designation : {
        type: DataTypes.STRING,
        allowNull: false,
    },
    mobile: {
        type: DataTypes.NUMBER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Mobile Number is required"
            },
            len: {
                args: [10, 15],
                msg: "Please enter 10 digit Mobile Number"
            }
        }
    },
    telephone: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Telephone is required"
            },
            len: {
                args: [10, 15],
                msg: "Please enter 10 digit Mobile Number"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

OfficeInfo.belongsTo(LabInfo, { foreignKey: 'lab_name_id' })

OfficeInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'l_office_use',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

OfficeInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'l_office_use',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = OfficeInfo;