const LabImgInfo = require('../models/LabImageInfoModel');

const CreateLablmgBasicInfo = async (i_data) => {
    await LabImgInfo.create(i_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestoryLablmgBasicInfo = async (lab_id) => {
    await LabImgInfo.destroy({ where: { lab_name_id: lab_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const CheckLabImgmgBasicInfo = async (lab_id) => {
    await LabImgInfo.findAll({ where: { lab_name_id: lab_id } ,raw: true })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    CreateLablmgBasicInfo,
    DestoryLablmgBasicInfo,
    CheckLabImgmgBasicInfo
};