const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const Get = async () => {

    const query = `	select a.id,a.addCheck,a.lab_name,g.lab_image,a.certicate_path,a.lab_regNo,a.created_at
    ,a.isApproved,a.approve_date,a.approved_by,b.lab_type_name,c.accredation_name,d.hospital_sector_name,e.lab_name_id,e.address1,
    e.address2,e.pincode,e.location,f.mobile_no,f.telephone,f.email_address_1,
    f.email_address_2 from l_lab_basic_info as a
    left join lab_type_master as b on a.lab_type_id = b.id
    left join accredation as c on a.accredation_id = c.id
    left join hospital_sector as d on a.sector_id = d.id
    left join l_address_info as e on e.lab_name_id = a.id
    left join l_contact_info as f on f.lab_name_id = a.id
	left join l_lab_image as g on g.lab_name_id = a.id`;

    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((error) => {
            res = err
        });

    return res
}

const GetbyId = async (lab_name_id) => {

    const query = `	select a.id,a.addCheck,a.lab_name,g.lab_image,a.certicate_path,a.lab_regNo,a.created_at
    ,a.isApproved,a.approve_date,a.approved_by,b.lab_type_name,c.accredation_name,d.hospital_sector_name,e.lab_name_id,e.address1,
    e.address2,e.pincode,e.location,f.mobile_no,f.telephone,f.email_address_1,
    f.email_address_2 from l_lab_basic_info as a
    left join lab_type_master as b on a.lab_type_id = b.id
    left join accredation as c on a.accredation_id = c.id
    left join hospital_sector as d on a.sector_id = d.id
    left join l_address_info as e on e.lab_name_id = a.id
    left join l_contact_info as f on f.lab_name_id = a.id
	left join l_lab_image as g on g.lab_name_id = a.id where a.id=${lab_name_id}`;

    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((error) => {
            res = err
        });

    return res
}

module.exports = {
    Get,
    GetbyId
};