const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const labRepositoryInfo_service = require('../services/lab_repository_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');

const FetchLabRepositoryInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        await labRepositoryInfo_service.GetbyId(lab_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_labRepositoryInfo_service');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await labRepositoryInfo_service.Get()
            .then(data => {
                cache.SET(req.user.id + '_labRepositoryInfo_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        // }
    }
};



module.exports = {
    FetchLabRepositoryInfo
}