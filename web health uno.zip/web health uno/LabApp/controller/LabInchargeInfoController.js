const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const labInchargeInfo_services = require('../services/lab_incharge_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const AddCheck = require('../../services/lab_addCheck_service');

const FetchLabInchargeInfo = async (req, res, next) => {
    id = req.params.lab_name_id;
    if (id) {
        await labInchargeInfo_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_labInchargeInfo_services');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await labInchargeInfo_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_labInchargeInfo_services', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
};

const NewLabInchargeInfo = async (req, res, next) => {
    lab_name_id = req.body.lab_name_id;
    doctor_name = req.body.doctor_name;
    gender_id = req.body.gender_id;
    email = req.body.email;
    phone_no = req.body.phone_no;
    about = req.body.about;
    if (req.files && req.files.image_path && req.files.image_path.name) {

        image_path = req.files.image_path;

    } else {
        image_path = req.body.image_path;
    }
    if (req.files && req.files.signature_path && req.files.signature_path.name) {

        signature_path = req.files.signature_path;
    } else {
        signature_path = req.body.signature_path;
    }
    dob = req.body.dob;
    age = req.body.age;
    speciality_id = req.body.speciality_id;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    addCheck = 8;
    const query = AddCheck(req.body.lab_name_id);

    if (doctor_name) {
        d_data = {
            doctor_name: doctor_name,
            gender_id: parseInt(gender_id),
            lab_name_id: parseInt(lab_name_id),
            email: email,
            phone_no: phone_no,
            about: about,
            dob: dob,
            about: about,
            age: age,
            speciality_id: parseInt(speciality_id),
            active: active,
            addCheck: addCheck,
            created_by: created_by,
            updated_by: updated_by
        }

        if (req.files && req.files.image_path && req.files.image_path.name) {
            d_data.image_path = image_path.name;
            buffer = image_path.data
            path = './media/' + image_path.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });
        } else {

            image_path = req.body.image_path;
            d_data.image_path = image_path;
        }

        if (req.files && req.files.signature_path && req.files.signature_path.name) {

            d_data.signature_path = signature_path.name;
            buffer = signature_path.data
            path = './media/' + signature_path.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });

        } else {

            signature_path = req.body.signature_path;
            d_data.signature_path = signature_path;

        }
        console.log(d_data);

        // await labInchargeInfo_services.GetbyName(doctor_name)
        //     .then(basic_data => {
        //         if (basic_data.length > 0) {
        //             msg = "Doctor Name already exists";
        //             return res.status(200).json(failure_func(msg))
        //         } else {
        labInchargeInfo_services.CreateLabInChargeInfo(d_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    labInchargeInfo_services.GetbyName(doctor_name)
                        .then(datas => {
                            datas.msg = "Created Successfully";
                            cache.DEL(req.user.id + '_labInchargeInfo_services')
                            res.status(200).json(success_func(datas))
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        //     }
        // })
    }
    else {
        msg = "doctor_name is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateLabinChargeInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        doctor_name = req.body.doctor_name;
        gender_id = req.body.gender_id;
        lab_name_id = req.body.lab_name_id;
        email = req.body.email;
        phone_no = req.body.phone_no;
        about = req.body.about;
        if (req.files && req.files.image_path && req.files.image_path.name) {

            image_path = req.files.image_path;

        } else {
            image_path = req.body.image_path;
        }
        if (req.files && req.files.signature_path && req.files.signature_path.name) {

            signature_path = req.files.signature_path;
        } else {
            signature_path = req.body.signature_path;
        }
        dob = req.body.dob;
        age = req.body.age;
        about = req.body.about;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (doctor_name) {
            d_data = {
                doctor_name: doctor_name,
                gender_id: gender_id,
                email: email,
                lab_name_id: lab_name_id,
                phone_no: phone_no,
                about: about,
                dob: dob,
                about: about,
                age: age,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }

            if (req.files && req.files.image_path && req.files.image_path.name) {
                d_data.image_path = image_path.name;
                buffer = image_path.data
                path = './media/' + image_path.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });
            } else {

                image_path = req.body.image_path;
                d_data.image_path = image_path;
            }

            if (req.files && req.files.signature_path && req.files.signature_path.name) {

                d_data.signature_path = signature_path.name;
                buffer = signature_path.data
                path = './media/' + signature_path.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });

            } else {

                signature_path = req.body.signature_path;
                d_data.signature_path = signature_path;

            }
            labInchargeInfo_services.UpdateLabInchargeInfo(id, d_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_labInchargeInfo_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        } else {
            msg = "doctor_name is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteLabInChargeInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await labInchargeInfo_services.DestroyLanInChargeInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_labInchargeInfo_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    FetchLabInchargeInfo,
    NewLabInchargeInfo,
    UpdateLabinChargeInfo,
    DeleteLabInChargeInfo
}