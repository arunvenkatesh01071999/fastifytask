const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const lab_basic_service = require('../services/lab_basic_info_service');
const lab_img_service = require('../services/lab_image_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const labimginfomodel = require('../models/LabImageInfoModel');

const FetchLabBasicInfo = async (req, res, next) => {
  lab_name_id = req.params.lab_name_id;
  if (lab_name_id) {
    await lab_basic_service.GetbyId(lab_name_id)
      .then(data => {
        res.status(200).json(success_func(data))
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    // data = await cache.GET(req.user.id + '_lab_basic_service');
    // if (data) {
    //   res.status(200).json(success_func(JSON.parse(data)))
    // } else {
      await lab_basic_service.Get()
        .then(data => {
          cache.SET(req.user.id + '_lab_basic_service', data)
          res.status(200).json(success_func(data))
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })
    }
  }
// };

const NewLabBasicInfo = async (req, res, next) => {
  lab_name = req.body.lab_name;
  lab_type_id = req.body.lab_type_id;
  sector_id = req.body.sector_id;
  accredation_id = req.body.accredation_id;
  lab_regNo = req.body.lab_regNo;
  about = req.body.about;
  active = req.body.active;
  created_by = req.user.id;
  updated_by = req.user.id;
  const addCheck = 8;
  try {
    lab_image = req.files.lab_image;
  } catch {
    lab_image = null
  }
  // console.log(lab_image.length, "lab_image");
  try {
    certicate_path = req.files.certicate_path
  } catch {
    certicate_path = null
  }
  if (lab_name) {
    l_data = {
      lab_name: lab_name,
      lab_type_id: parseInt(lab_type_id),
      sector_id: parseInt(sector_id),
      accredation_id: parseInt(accredation_id),
      certicate_path: certicate_path,
      lab_image:lab_image,
      lab_regNo: lab_regNo,
      about: about,
      addCheck: addCheck,
      active: parseInt(active),
      created_by: created_by,
      updated_by: updated_by
    }


    if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
      l_data.certicate_path = certicate_path.name;
      buffer = certicate_path.data;
      path = './media/' + certicate_path.name;
      fs.writeFile(path.toString(), buffer, function (err) {
        if (err) {
          return console.log(err);
        }
      });
    } else {

      certicate_path = req.body.certicate_path;
      l_data.certicate_path = certicate_path;
    }
    // console.log(l_data);
    // console.log(lab_image.length, lab_image, "testing1");
    await lab_basic_service.GetbyName(lab_name)
      .then(basic_data => {
        if (basic_data.length > 0) {
          msg = "Name already exists";
          return res.status(200).json(failure_func(msg))
        } else {
          console.log(lab_image.length, lab_image, "testing2");
          lab_basic_service.CreateLabBasicInfo(l_data)
            .then(data => {
              //   if (data.errors) {
              //     msg = data.errors[0].message;
              //     res.status(400).json(failure_func(msg))
              //   } else {
              // console.log(lab_image.length, lab_image, "testing3");
              var as = [];
              as.push(lab_image)
              if (data.dataValues.id) {
                if (lab_image.length) {
                  lab_image.forEach((element) => {
                    lab_image = element.name;
                    record = element.name;
                    buffer = element.data
                    path = './media/' + element.name;
                    fs.writeFile(path.toString(), buffer, function (err) {
                      if (err) {
                        return console.log(err);
                      }
                    });
                    l_data_img = {
                      lab_name_id: data.dataValues.id,
                      lab_image: record,
                      active: active,
                      created_by: created_by,
                      updated_by: updated_by
                    }
                    // console.log('l_data_img', l_data_img);
                    lab_img_service.CreateLablmgBasicInfo(l_data_img)

                  });
                }
                else {
                  as.forEach((element) => {
                    lab_image = element.name;
                    record = element.name;
                    buffer = element.data
                    path = './media/' + element.name;
                    fs.writeFile(path.toString(), buffer, function (err) {
                      if (err) {
                        return console.log(err);
                      }
                    });
                    l_data_img = {
                      lab_name_id: data.dataValues.id,
                      lab_image: record,
                      active: active,
                      created_by: created_by,
                      updated_by: updated_by
                    }
                    // console.log('l_data_img', l_data_img);
                    lab_img_service.CreateLablmgBasicInfo(l_data_img)

                  });
                }

              }
              // console.log(data.dataValues.id);
              lab_basic_service.GetbyName(lab_name)
                .then(datas => {
                  datas.msg = "Created Successfully";
                  cache.DEL(req.user.id + '_lab_basic_service')
                  res.status(200).json(success_func(datas))
                })
                .catch(err => {
                  res.status(400).json(failure_func(err))
                })
              // }
            })
            .catch(err => {
              res.status(400).json(failure_func(err))
            })
        }
      })
  }
  else {
    msg = "lab_name is required";
    res.status(400).json(failure_func(msg))
  }
}

const UpdateLabBasicInfo = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    lab_name = req.body.lab_name;
    lab_type_id = req.body.lab_type_id;
    sector_id = req.body.sector_id;
    accredation_id = req.body.accredation_id;
    lab_regNo = req.body.lab_regNo;
    about = req.body.about;
    if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
      certicate_path = req.files.certicate_path;
    } else {
      certicate_path = req.body.certicate_path;
    }
    try {
      lab_image = req.files.lab_image;
    } catch {
      lab_image_body = req.body.lab_image;
    }
    isApproved = req.body.isApproved;
    approve_date = req.body.approve_date;
    approved_by = req.body.approved_by;
    active = req.body.active;
    updated_by = req.user.id;
    updated_at = date();
    if (lab_name) {
      const l_data = {
        lab_name: lab_name,
        lab_type_id: parseInt(lab_type_id),
        sector_id: parseInt(sector_id),
        accredation_id: parseInt(accredation_id),
        lab_regNo: lab_regNo,
        certicate_path: certicate_path,
        about: about,
        active: parseInt(active),
        updated_by: updated_by,
        updated_at: updated_at
      }
      if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
        l_data.certicate_path = certicate_path.name;
        buffer = certicate_path.data;
        path = './media/' + certicate_path.name;
        fs.writeFile(path.toString(), buffer, function (err) {
          if (err) {
            return console.log(err);
          }
        });
      } else {
        certicate_path = req.body.certicate_path;
        l_data.certicate_path = certicate_path;
      }
      await lab_basic_service.UpdateLabBasicInfo(id, l_data)
        .then(data => {
          if (data == 1) {
            const lab_id = req.params.id;
            lab_img_service.CheckLabImgmgBasicInfo(lab_id)
              .then(result => {
                if (req.files == null) {
                  const lab_image_body_data = req.body.lab_image.toString();
                  var req_array = lab_image_body_data.split(',');


                  var exist_array = [];
                  result.forEach((element) => {
                    exist_array.push(element.lab_image)
                  });
                  var uncommonElements = [];


                  const set1 = new Set(req_array);
                  const set2 = new Set(exist_array);
                  for (const item of set1) {
                    if (!set2.has(item)) {
                      uncommonElements.push(item);
                    }
                  }

                  // Check for uncommon elements in arr2
                  for (const item of set2) {
                    if (!set1.has(item)) {
                      uncommonElements.push(item);
                    }
                  }

                  if (uncommonElements.length > 0) {
                    const filteredData = result.filter((item) => uncommonElements.includes(item.lab_image));
                    filteredData.forEach((element) => {
                      labimginfomodel.destroy({ where: { lab_image: element.lab_image } })
                        .then(data => {
                          res = data
                        }).catch(err => {
                          res = err
                        })
                    });
                  }
                }

                // if (lab_id) {
                //   if (req.body.lab_image == undefined) {
                //     if (lab_image.length) {
                //       lab_image.forEach((element) => {
                //         lab_image = element.name;
                //         record = element.name;
                //         buffer = element.data
                //         path = './media/' + element.name;
                //         fs.writeFile(path.toString(), buffer, function (err) {
                //           if (err) {
                //             return console.log(err);
                //           }
                //         });
                //         l_data_img = {
                //           lab_name_id: lab_id,
                //           lab_image: record,
                //           active: active,
                //           created_by: req.user.id,
                //           updated_by: req.user.id
                //         }
                //         // console.log('l_data_img', l_data_img);
                //         lab_img_service.CreateLablmgBasicInfo(l_data_img)

                //       });
                //     }
                //     else {
                //       as.forEach((element) => {
                //         lab_image = element.name;
                //         record = element.name;
                //         buffer = element.data
                //         path = './media/' + element.name;
                //         fs.writeFile(path.toString(), buffer, function (err) {
                //           if (err) {
                //             return console.log(err);
                //           }
                //         });
                //         l_data_img = {
                //           lab_name_id: lab_id,
                //           lab_image: record,
                //           active: active,
                //           created_by: req.user.id,
                //           updated_by: req.user.id
                //         }
                //         // console.log('l_data_img', l_data_img);
                //         lab_img_service.CreateLablmgBasicInfo(l_data_img)

                //       });
                //     }
                //   }
                else {
                  console.log('else');
                  const lab_image = req.files.lab_image;
                  const check_file = lab_image.length;
                  if (check_file == undefined) {
                    const dummy = [];
                    dummy.push(lab_image);
                    dummy.forEach((element) => {
                      const lab_image = element.name;
                      const record = element.data
                      path = './media/' + element.name;
                      fs.writeFile(path.toString(), buffer, function (err) {
                        if (err) {
                          return console.log(err);
                        }
                      });
                      l_data_img = {
                        lab_name_id: req.params.id,
                        lab_image: record,
                        active: active,
                        created_by: updated_by,
                        updated_by: updated_by
                      }
                      console.log('i_data_img', l_data_img);
                      lab_img_service.CreateLablmgBasicInfo(l_data_img)
                    });
                  } else {
                    lab_image.forEach((element) => {
                      const lab_image = element.name;
                      const record = element.data;
                      buffer = element.data
                      path = './media/' + element.name;
                      fs.writeFile(path.toString(), buffer, function (err) {
                        if (err) {
                          return console.log(err);
                        }
                      });
                      l_data_img = {
                        lab_name_id: req.params.id,
                        lab_image: record,
                        active: active,
                        created_by: updated_by,
                        updated_by: updated_by
                      }
                      // console.log('i_data_img', l_data_img);
                      lab_img_service.CreateLablmgBasicInfo(l_data_img)

                    });
                  }
                }
              })
            msg = "Updated successfully"
            cache.DEL(req.user.id + '_lab_basic_service')
            res.status(200).json(success_func(msg))
          } else {
            msg = "ID doesn't exist"
            res.status(400).json(failure_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })
    }
    else {
      msg = "lab_name is required";
      res.status(400).json(failure_func(msg))
    }
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg))
  }
};

const LabApprove = async (req, res, next) => {
  const id = req.params.id;
  if (id) {
    const { isApproved, approve_date, approved_by, reason, id } = req.body;
    // if (isApproved) {
    if (isApproved === 1) {
      const a_data = {
        id: parseInt(id),
        isApproved: isApproved,
        approve_date: approve_date,
        approved_by: approved_by,
        reason: reason
      }
      lab_basic_service.CreateApprove(id, a_data)
        .then(data => {
          if (data.errors) {
            msg = data.errors[0].message;
            res.status(400).json(failure_func(msg))
          } else {
            msg = "Approved Successfully"
            // cache.DEL(req.user.id + '_lab_basic_service')
            res.status(200).json(success_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })
    }
    else {
      const a_data = {
        id: parseInt(id),
        isApproved: isApproved,
        approve_date: approve_date,
        approved_by: approved_by,
        reason: reason
      }
      lab_basic_service.CreateApprove(id, a_data)
        .then(data => {
          if (data.errors) {
            msg = data.errors[0].message;
            res.status(400).json(failure_func(msg))
          } else {
            msg = "Rejected Successfully"
            // cache.DEL(req.user.id + '_lab_basic_service')
            res.status(200).json(success_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })

    }
    // }
  }
}

const DeleteLabBasicInfo = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await lab_basic_service.DestroyLabBasicInfo(id)
      .then(data => {
        if (data == 1) {
          msg = "Deleted successfully"
          cache.DEL(req.user.id + '_lab_basic_service')
          res.status(200).json(success_func(msg))
        } else {
          msg = "ID doesn't exist"
          res.status(200).json(success_func(msg))
        }
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg))
  }
}

const updateIsapprove = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await lab_basic_service.UpdateIsapprove(id)
      .then(data => {
        if (data == 1) {
          msg = "Updated successfully"
          res.status(200).json(success_func(msg))
        }
        else {
          msg = "ID doesn't exist"
          res.status(200).json(success_func(msg))
        }
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg))
  }
}

module.exports = {
  FetchLabBasicInfo,
  NewLabBasicInfo,
  UpdateLabBasicInfo,
  DeleteLabBasicInfo,
  LabApprove,
  updateIsapprove
}