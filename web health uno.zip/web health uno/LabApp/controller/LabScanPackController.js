// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const scan_test_pack_service = require('../services/lab_scan_pack_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');
// // const AddCheck = require('../../services/lab_addCheck_service');

// const FetchScanTestInfo = async (req, res, next) => {
//     lab_name_id = req.params.lab_name_id;
//     if (lab_name_id) {
//         await scan_test_pack_service.GetbyId(lab_name_id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         // data = await cache.GET(req.user.id + '_scan_test_pack_service');
//         // if (data) {
//         //     res.status(200).json(success_func(JSON.parse(data)))
//         // } else {
//         await scan_test_pack_service.Get()
//             .then(data => {
//                 // cache.SET(req.user.id + '_scan_test_pack_service', data)
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     }
// }
// // }

// const NewScanTestInfo = async (req, res, next) => {
//     const { lab_name_id, scan_pack_name, scan_name_id, cost,
//         offer_percent, vaild_from, vaild_to, apply_promo, active } = req.body;
//     // const addCheck = 8;
//     // const query = AddCheck(req.body.lab_name_id)
//     created_by = req.user.id;
//     updated_by = req.user.id;

//     const stringScanNameId = scan_name_id.join(',');

//     const lt_data = {
//         lab_name_id: lab_name_id,
//         scan_pack_name: scan_pack_name,
//         cost: cost,
//         offer_percent: offer_percent,
//         vaild_from: vaild_from,
//         vaild_to: vaild_to,
//         apply_promo: apply_promo,
//         scan_name_id: stringScanNameId,
//         active: active,
//         // addCheck: addCheck,
//         created_by: created_by,
//         updated_by: updated_by
//     }
//     console.log(lt_data)
//     await scan_test_pack_service.CreatTestPack(lt_data)
//         .then(data => {
//             if (data.errors) {
//                 msg = data.errors[0].message;
//                 res.status(400).json(failure_func(msg))
//             } else {
//                 msg = "Created Successfully"
//                 cache.DEL(req.user.id + '_scan_test_pack_service')
//                 res.status(200).json(success_func(msg))
//             }
//         })
//         .catch(err => {
//             res.status(400).json(failure_func(err))
//         })
// }


// const UpdateScanTestInfo = async (req, res, next) => {
//     lab_name_id = req.params.lab_name_id;

//     if (lab_name_id) {
//         const { scan_pack_name, scan_name_id, cost,
//             offer_percent, vaild_from, vaild_to, apply_promo, active } = req.body;

//         updated_by = req.user.id;
//         updated_at = date();

//         const stringScanNameId = scan_name_id.join(',');

//         lt_data = {
//             lab_name_id: lab_name_id,
//             scan_pack_name: scan_pack_name,
//             cost: cost,
//             offer_percent: offer_percent,
//             vaild_from: vaild_from,
//             vaild_to: vaild_to,
//             apply_promo: apply_promo,
//             scan_name_id: stringScanNameId,
//             active: active,
//             updated_by: updated_by,
//             updated_at: updated_at

//         }
//         await scan_test_pack_service.UpdateTestInfo(lab_name_id, lt_data)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Updated successfully"
//                     //cache.DEL(req.user.id + '_scan_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(400).json(failure_func(msg));
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })

//     }
// }

// const DeleteScanTestInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await scan_test_pack_service.DestroyTestInfo(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_scan_test_pack_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     }
//     //  else {
//     //     msg = "ID is required";
//     //     res.status(400).json(failure_func(msg))
//     // }
// }


// module.exports = {
//     NewScanTestInfo,
//     FetchScanTestInfo,
//     UpdateScanTestInfo,
//     DeleteScanTestInfo
// }


const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const scan_test_pack_service = require('../services/lab_scan_pack_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/lab_addCheck_service');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const FetchScanTestInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        await scan_test_pack_service.GetbyId(lab_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_scan_test_pack_service');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await scan_test_pack_service.Get()
            .then(data => {
                // cache.SET(req.user.id + '_scan_test_pack_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewScanTestInfo = async (req, res, next) => {
    const { lab_name_id, scan_pack_name, scan_name_id, cost,
        offer_percent, vaild_from, vaild_to, apply_promo, active } = req.body;
    // const addCheck = 8;
    // const query = AddCheck(req.body.lab_name_id)
   const created_by = req.user.id;
  const  updated_by = req.user.id;

    query = `SELECT COUNT(*) AS count FROM l_scan_test_pack WHERE lab_name_id = ${lab_name_id}`;
    const result_data = await db1.query(query);
    const t = result_data.flat();
    const check = t[0].count;
    if (check === 0) {
        const query = AddCheck(req.body.lab_name_id)
    }

    const stringScanNameId = scan_name_id.join(',');

    const lt_data = {
        lab_name_id:parseInt (lab_name_id),
        scan_pack_name: scan_pack_name,
        cost: cost,
        offer_percent: offer_percent,
        vaild_from: vaild_from,
        vaild_to: vaild_to,
        apply_promo: apply_promo,
        scan_name_id: stringScanNameId,
        active:parseInt (active),
        // addCheck: addCheck,
        created_by: created_by,
        updated_by: updated_by
    }
    console.log(lt_data)
    await scan_test_pack_service.CreatTestPack(lt_data)
        .then(data => {
            if (data.errors) {
                msg = data.errors[0].message;
                res.status(400).json(failure_func(msg))
            } else {
                msg = "Created Successfully"
                cache.DEL(req.user.id + '_scan_test_pack_service')
                res.status(200).json(success_func(msg))
            }
        })
        .catch(err => {
            res.status(400).json(failure_func(err))
        })
}


const UpdateScanTestInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;

    if (lab_name_id) {
        const { scan_pack_name, scan_name_id, cost,
            offer_percent, vaild_from, vaild_to, apply_promo, active } = req.body;

        updated_by = req.user.id;
        updated_at = date();

        const stringScanNameId = scan_name_id.join(',');

        lt_data = {
            lab_name_id: lab_name_id,
            scan_pack_name: scan_pack_name,
            cost: cost,
            offer_percent: offer_percent,
            vaild_from: vaild_from,
            vaild_to: vaild_to,
            apply_promo: apply_promo,
            scan_name_id: stringScanNameId,
            active: active,
            updated_by: updated_by,
            updated_at: updated_at

        }
        await scan_test_pack_service.UpdateTestInfo(lab_name_id, lt_data)
            .then(data => {
                if (data == 1) {
                    msg = "Updated successfully"
                    //cache.DEL(req.user.id + '_scan_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(400).json(failure_func(msg));
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })

    }
}

const DeleteScanTestInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
      const d1 =   await scan_test_pack_service.DestroyTestInfo(id)
            // .then(data => {
                if (d1 == 1) {
                    query = `SELECT COUNT(*) AS count FROM l_scan_test_pack WHERE lab_name_id = ${lab_name_id}`;
                    const result_data =  await db1.query(query);
                    const t = result_data.flat();
                    const check = t[0].count;
                    if (check === 0) {
                        const addCheck = 8;
                        const query2 = `select addCheck from l_lab_basic_info where id =${lab_name_id}`;
                        var customerFeedback = await db1.query(query2);
                        var menu_data = customerFeedback.flat();
                        total_add = menu_data[0].addCheck - addCheck;    
                        const query1 = `UPDATE l_lab_basic_info SET addCheck = ${total_add} where id =${lab_name_id}`
                        var customerFeedback1 = db1.query(query1);
                    }
                    msg = "Deleted successfully"
                    // cache.DEL(req.user.id + '_scan_test_pack_service')
                    res.status(200).json(success_func(msg))
            //     } else {
            //         msg = "ID doesn't exist"
            //         res.status(200).json(success_func(msg))
                }
            // })
            // .catch(err => {
            //     res.status(400).json(failure_func(err))
            // })
    }
    //  else {
    //     msg = "ID is required";
    //     res.status(400).json(failure_func(msg))
    // }
}


module.exports = {
    NewScanTestInfo,
    FetchScanTestInfo,
    UpdateScanTestInfo,
    DeleteScanTestInfo
}