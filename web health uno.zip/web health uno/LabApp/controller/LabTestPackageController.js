// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const lab_test_pack_service = require('../services/lab_test_pack_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');
// // const AddCheck = require('../../services/lab_addCheck_service');

// const FetchLabTestInfo = async (req, res, next) => {
//     lab_name_id = req.params.lab_name_id;
//     if (lab_name_id) {
//         await lab_test_pack_service.GetbyId(lab_name_id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         // data = await cache.GET(req.user.id + '_lab_test_pack_service');
//         // if (data) {
//         //     res.status(200).json(success_func(JSON.parse(data)))
//         // } else {
//         await lab_test_pack_service.Get()
//             .then(data => {
//                 //cache.SET(req.user.id + '_lab_test_pack_service', data)
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     }
// }
// // }

// const NewLabTestInfo = async (req, res, next) => {
//     const { lab_name_id, lab_pack_name, cost, offer_percent,
//         vaild_from, vaild_to, apply_promo, lab_category_id, active } = req.body;
//     // const addCheck = 8;
//     // const query = AddCheck(req.body.lab_name_id)
//     const created_by = req.user.id;
//     const updated_by = req.user.id;

//     const stringlabCatId = lab_category_id.join(',');

//     const l_data = {
//         lab_name_id: lab_name_id,
//         lab_pack_name: lab_pack_name,
//         cost: cost,
//         offer_percent: offer_percent,
//         vaild_from: vaild_from,
//         vaild_to: vaild_to,
//         apply_promo: apply_promo,
//         lab_category_id: stringlabCatId,
//         active: active,
//         // addCheck: addCheck,
//         created_by: created_by,
//         updated_by: updated_by
//     }
//     console.log(l_data);
//     await lab_test_pack_service.CreatTestPack(l_data)
//         .then(data => {
//             if (data.errors) {
//                 msg = data.errors[0].message;
//                 res.status(400).json(failure_func(msg))
//             } else {
//                 msg = "Created Successfully"
//                 cache.DEL(req.user.id + '_lab_test_pack_service')
//                 res.status(200).json(success_func(msg))
//             }
//         })
//         .catch(err => {
//             res.status(400).json(failure_func(err))
//         })
// }



// const UpdateLabTestInfo = async (req, res, next) => {
//     lab_name_id = req.params.lab_name_id;
//     if (lab_name_id) {
//         //lab_test_pack_service.DestroyTestInfo(lab_name_id);


//         const { lab_pack_name, cost, offer_percent,
//             vaild_from, vaild_to, apply_promo, lab_category_id, active } = req.body;

//         updated_by = req.user.id;
//         updated_at = date();

//         const stringLabCategoryId = lab_category_id.join(',');
//         // lab_name_id = req.body.lab_name_id;
//         // lab_pack_name = req.body.lab_pack_name;
//         // cost = req.body.cost;
//         // offer_percent = req.body.offer_percent;
//         // vaild_to = req.body.vaild_to;
//         // vaild_from = req.body.vaild_from;
//         // apply_promo = req.body.apply_promo;
//         // lab_category_id = req.body.lab_category_id;
//         // active = req.body.active;
//         // updated_by = req.user.id;
//         // updated_at = date();

//         tc_data = {
//             lab_name_id: lab_name_id,
//             lab_pack_name: lab_pack_name,
//             cost: cost,
//             offer_percent: offer_percent,
//             vaild_from: vaild_from,
//             vaild_to: vaild_to,
//             apply_promo: apply_promo,
//             lab_category_id: stringLabCategoryId,
//             active: active,
//             updated_by: updated_by,
//             updated_at: updated_at
//         }
//         await lab_test_pack_service.UpdateLabTestPackService(lab_name_id, tc_data)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Updated successfully"
//                     //cache.DEL(req.user.id + '_scan_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(400).json(failure_func(msg));
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     }
// }
// const DeleteLabTestInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await lab_test_pack_service.DestroyTestPack(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_scan_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(400).json(failure_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     }
//     // else {
//     //     msg = "ID is required";
//     //     res.status(400).json(failure_func(msg))
//     // }
// }


// module.exports = {
//     NewLabTestInfo,
//     FetchLabTestInfo,
//     UpdateLabTestInfo,
//     DeleteLabTestInfo
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const lab_test_pack_service = require('../services/lab_test_pack_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/lab_addCheck_service');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');


const FetchLabTestInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        await lab_test_pack_service.GetbyId(lab_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_lab_test_pack_service');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await lab_test_pack_service.Get()
            .then(data => {
                //cache.SET(req.user.id + '_lab_test_pack_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewLabTestInfo = async (req, res, next) => {
    const { lab_name_id, lab_pack_name, cost, offer_percent,
        vaild_from, vaild_to, apply_promo, lab_category_id, active } = req.body;
    // const addCheck = 8;
    // const query = AddCheck(req.body.lab_name_id)
    const created_by = req.user.id;
    const updated_by = req.user.id;

    query = `SELECT COUNT(*) AS count FROM l_lab_test_pack WHERE lab_name_id = ${lab_name_id}`;
    const result_data = await db1.query(query);
    const t = result_data.flat();
    const check = t[0].count;
    if (check === 0) {
        const query = AddCheck(req.body.lab_name_id)
    }


    const stringlabCatId = lab_category_id.join(',');

    const l_data = {
        lab_name_id:parseInt (lab_name_id),
        lab_pack_name: lab_pack_name,
        cost: cost,
        offer_percent: offer_percent,
        vaild_from: vaild_from,
        vaild_to: vaild_to,
        apply_promo: apply_promo,
        lab_category_id: stringlabCatId,
        active:parseInt (active),
        // addCheck: addCheck,
        created_by: created_by,
        updated_by: updated_by
    }
    console.log(l_data);
    await lab_test_pack_service.CreatTestPack(l_data)
        .then(data => {
            if (data.errors) {
                msg = data.errors[0].message;
                res.status(400).json(failure_func(msg))
            } else {
                msg = "Created Successfully"
                cache.DEL(req.user.id + '_lab_test_pack_service')
                res.status(200).json(success_func(msg))
            }
        })
        .catch(err => {
            res.status(400).json(failure_func(err))
        })
}



const UpdateLabTestInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        //lab_test_pack_service.DestroyTestInfo(lab_name_id);


        const { lab_pack_name, cost, offer_percent,
            vaild_from, vaild_to, apply_promo, lab_category_id, active } = req.body;

        updated_by = req.user.id;
        updated_at = date();

        const stringLabCategoryId = lab_category_id.join(',');
        // lab_name_id = req.body.lab_name_id;
        // lab_pack_name = req.body.lab_pack_name;
        // cost = req.body.cost;
        // offer_percent = req.body.offer_percent;
        // vaild_to = req.body.vaild_to;
        // vaild_from = req.body.vaild_from;
        // apply_promo = req.body.apply_promo;
        // lab_category_id = req.body.lab_category_id;
        // active = req.body.active;
        // updated_by = req.user.id;
        // updated_at = date();

        tc_data = {
            lab_name_id: lab_name_id,
            lab_pack_name: lab_pack_name,
            cost: cost,
            offer_percent: offer_percent,
            vaild_from: vaild_from,
            vaild_to: vaild_to,
            apply_promo: apply_promo,
            lab_category_id: stringLabCategoryId,
            active: active,
            updated_by: updated_by,
            updated_at: updated_at
        }
        await lab_test_pack_service.UpdateLabTestPackService(lab_name_id, tc_data)
            .then(data => {
                if (data == 1) {
                    msg = "Updated successfully"
                    //cache.DEL(req.user.id + '_scan_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(400).json(failure_func(msg));
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
const DeleteLabTestInfo = async (req, res, next) => {
    id = req.params.id;
    lab_name_id = req.params.lab_name_id;
    if (id) {
      const d1 =  await lab_test_pack_service.DestroyTestPack(id)
            // .then(data => {
                if (d1 == 1) {
                    query = `SELECT COUNT(*) AS count FROM l_lab_test_pack WHERE lab_name_id = ${lab_name_id}`;
                    const result_data =  await db1.query(query);
                    const t = result_data.flat();
                    const check = t[0].count;
                    if (check === 0) {
                        const addCheck = 8;
                        const query2 = `select addCheck from l_lab_basic_info where id =${lab_name_id}`;
                        var customerFeedback = await db1.query(query2);
                        var menu_data = customerFeedback.flat();
                        total_add = menu_data[0].addCheck - addCheck;    
                        const query1 = `UPDATE l_lab_basic_info SET addCheck = ${total_add} where id =${lab_name_id}`
                        var customerFeedback1 = db1.query(query1);
                    }
                    msg = "Deleted successfully"
                    // cache.DEL(req.user.id + '_scan_service')
                    res.status(200).json(success_func(msg))
                // } else {
                //     msg = "ID doesn't exist"
                //     res.status(400).json(failure_func(msg))
                }
            // })
            // .catch(err => {
            //     res.status(400).json(failure_func(err))
            // })
    }
    // else {
    //     msg = "ID is required";
    //     res.status(400).json(failure_func(msg))
    // }
}


module.exports = {
    NewLabTestInfo,
    FetchLabTestInfo,
    UpdateLabTestInfo,
    DeleteLabTestInfo
}