const express = require('express');
const router = express();
const TermConditionController = require('../controller/LabTermsController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, TermConditionController.FetchTermCondition);
router.get('/:lab_name_id', verify_token, TermConditionController.FetchTermCondition);
router.post('/', verify_token, TermConditionController.NewTermCondition);
router.put('/:id', verify_token, TermConditionController.UpdateTermCondition);

module.exports = router;