// const express = require('express');
// const router = express();
// const LabInfoController = require('../controller/LabInfoController');
// const verify_token = require('../../services/verify_token');

// router.get('/', verify_token, LabInfoController.FetchLabInfo);
// router.get('/:lab_name_id', verify_token, LabInfoController.FetchLabInfo);
// router.post('/', verify_token, LabInfoController.NewLabInfo);
// router.put('/:lab_name_id', verify_token, LabInfoController.UpdateLabInfo);
// router.delete('/:id', verify_token, LabInfoController.DeleteLabInfo);

// module.exports = router;

const express = require('express');
const router = express();
const LabInfoController = require('../controller/LabInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabInfoController.FetchLabInfo);
router.get('/:lab_name_id', verify_token, LabInfoController.FetchLabInfo);
router.post('/', verify_token, LabInfoController.NewLabInfo);
router.put('/:lab_name_id', verify_token, LabInfoController.UpdateLabInfo);
router.delete('/:id/:lab_name_id', verify_token, LabInfoController.DeleteLabInfo);

module.exports = router;