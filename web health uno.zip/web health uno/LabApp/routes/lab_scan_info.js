const express = require('express');
const router = express();
const LabScanInfoController = require('../controller/LabScanInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabScanInfoController.FetchScanInfo);
router.get('/:lab_name_id', verify_token, LabScanInfoController.FetchScanInfo);
router.post('/', verify_token, LabScanInfoController.NewScanInfo);
router.put('/:lab_name_id', verify_token, LabScanInfoController.UpdateScanInfo);
router.delete('/:id/:lab_name_id', verify_token, LabScanInfoController.DeleteScanInfo);

module.exports = router;