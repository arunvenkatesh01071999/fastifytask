const express = require('express');
const app = express();
const morgan = require('morgan');
const cors = require('cors');
const fileupload = require("express-fileupload");
const LoginRouter = require('./routes/login');
const RolesRouter = require('./routes/role');
const UsersRouter = require('./routes/user');
const ServiceRouter = require('./routes/service');
const MastersRouter = require('./MastersApp/app');
const HospitalRouter = require('./HospitalApp/app');
const DoctorRouter = require('./DoctorApp/app');
const LabRouter = require('./LabApp/app');
const writer = require("./config/api_logger");
morgan.token('body', function (req, res) { return JSON.stringify(req.body) })
app.use(morgan('"date":":date[clf]", "client":":remote-addr", "method":":method", "url":":url HTTP/:http-version", "status":":status", "res_length":":res[content-length]", "body"::body, "agent":":user-agent"', { "stream": writer }));

app.use(morgan('dev'));
app.use(express.json());
app.use(express.urlencoded({ extended: false }));
app.use(cors());
app.use(fileupload());
app.use(express.static('media')); // serve static files from the media directory

app.use('/api', LoginRouter);
app.use('/api', RolesRouter);
app.use('/api', UsersRouter);
app.use('/api', ServiceRouter);
app.use('/api', MastersRouter);
app.use('/api', HospitalRouter);
app.use('/api', DoctorRouter);
app.use('/api', LabRouter);

module.exports = app;