const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const address_info_services = require('../services/address_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/doctor_addCheck_service');


const FetchDoctorAddressInfo = async (req, res, next) => {
    doctor_name_id = req.params.doctor_name_id;
    if (doctor_name_id) {
        await address_info_services.GetbyId(doctor_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_address_info_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await address_info_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_address_info_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// };

const NewDoctorAddressInfo = async (req, res, next) => {
    doctor_name_id = req.body.doctor_name_id;
    address1 = req.body.address1;
    address2 = req.body.address2;
    city_id = req.body.city_id;
    state_id = req.body.state_id;
    country_id = req.body.country_id;
    pincode = req.body.pincode;
    location = req.body.location;
    longitude = req.body.longitude;
    latitude = req.body.latitude;
    active = req.body.active;
    created_at = date();
    updated_at = date();
    created_by = req.user.id;
    updated_by = req.user.id;
    const addCheck = 11;
    const query = AddCheck(req.body.doctor_name_id)

    if (address1) {
        a_data = {
            doctor_name_id: doctor_name_id,
            address1: address1,
            address2: address2,
            city_id: city_id,
            state_id: state_id,
            country_id: country_id,
            pincode: pincode,
            location: location,
            longitude: longitude,
            latitude: latitude,
            active: active,
            created_at:created_at,
            updated_at:updated_at,
            created_by: created_by,
            updated_by: updated_by
        };
        console.log(a_data);
        await address_info_services.GetId(doctor_name_id)
            .then(info => {
                if (info.length > 0) {
                    msg = " Already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    address_info_services.CreateDoctorAddress(a_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                address_info_services.GetId(doctor_name_id)
                                    .then(datas => {
                                        datas.msg = "Created Successfully";
                                        cache.DEL(req.user.id + '_address_info_services')
                                        res.status(200).json(success_func(datas))
                                    })
                                    .catch(err => {
                                        res.status(400).json(failure_func(err))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "No Of Doctor is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateDoctorAddressInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        doctor_name_id = req.body.doctor_name_id;
        address1 = req.body.address1;
        address2 = req.body.address2;
        city_id = req.body.city_id;
        state_id = req.body.state_id;
        country_id = req.body.country_id;
        pincode = req.body.pincode;
        location = req.body.location;
        longitude = req.body.longitude;
        latitude = req.body.latitude
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (address1) {
            a_data = {
                doctor_name_id: doctor_name_id,
                address1: address1,
                address2: address2,
                city_id: city_id,
                state_id: state_id,
                country_id: country_id,
                pincode: pincode,
                location: location,
                longitude: longitude,
                latitude: latitude,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await address_info_services.UpdateDoctorAddress(id, a_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_address_info_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "No Of Doctor is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteDoctorAddressInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await address_info_services.DestroyDoctorAddress(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_address_info_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    FetchDoctorAddressInfo,
    NewDoctorAddressInfo,
    UpdateDoctorAddressInfo,
    DeleteDoctorAddressInfo
}