const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const experience_info_service = require('../services/experience_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const AddCheck = require('../../services/doctor_addCheck_service');


const FetchExperienceInfo = async (req, res, next) => {
    doctor_name_id = req.params.doctor_name_id;
    if (doctor_name_id) {
        await experience_info_service.GetbyId(doctor_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_experience_info_service');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await experience_info_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_experience_info_service', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewExperienceInfo = async (req, res, next) => {
    const experience = req.body.experience;
    const department_id = req.body.department_id;
    const specialization_id = req.body.specialization_id;
    const doctor_name_id = req.body.doctor_name_id;
    if (req.files && req.files.upload_certicate && req.files.upload_certicate.name) {

        upload_certicate = req.files.upload_certicate;
    } else {
        upload_certicate = req.body.upload_certicate;
    }
    const active = req.body.active;
    const created_at = date();
    const updated_at = date();
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const addCheck = 11;
    const query = AddCheck(req.body.doctor_name_id);

    if (experience) {
        e_data = {
            experience: experience,
            specialization_id: specialization_id,
            department_id: department_id,
            doctor_name_id: doctor_name_id,
            active: active,
            created_at: created_at,
            updated_at: updated_at,
            created_by: created_by,
            updated_by: updated_by
        }
        if (req.files && req.files.upload_certicate && req.files.upload_certicate.name) {
            e_data.upload_certicate = upload_certicate.name;
            buffer = upload_certicate.data
            path = './media/' + upload_certicate.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });

        } else {
            upload_certicate = req.body.upload_certicate;
            e_data.upload_certicate = upload_certicate;
        }
        console.log(e_data)
        await experience_info_service.CreateExperienceInfo(e_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_experience_info_service')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "experience and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateExperienceInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        const experience = req.body.experience;
        const department_id = req.body.department_id;
        const specialization_id = req.body.specialization_id;
        const doctor_name_id = req.body.doctor_name_id;
        if (req.files && req.files.upload_certicate && req.files.upload_certicate.name) {

            upload_certicate = req.files.upload_certicate;
        } else {
            upload_certicate = req.body.upload_certicate;
        }
        const active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (experience) {
            e_data = {
                experience: experience,
                department_id: department_id,
                specialization_id: specialization_id,
                doctor_name_id: doctor_name_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            if (req.files && req.files.upload_certicate && req.files.upload_certicate.name) {
                e_data.upload_certicate = upload_certicate.name;
                buffer = upload_certicate.data
                path = './media/' + upload_certicate.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });

            } else {
                upload_certicate = req.body.upload_certicate;
                e_data.upload_certicate = upload_certicate;
            }
            // console.log(e_data)
            await experience_info_service.UpdateExperienceInfo(id, e_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_experience_info_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "experience and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteExperienceInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await experience_info_service.DestroyExperienceInfo(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_experience_info_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewExperienceInfo,
    FetchExperienceInfo,
    UpdateExperienceInfo,
    DeleteExperienceInfo
}