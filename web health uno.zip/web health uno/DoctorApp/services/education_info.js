const EducationInfo = require('../models/EducationInfoModel');
const EducationMasterModel = require('../../MastersApp/models/QualificationMasterModel');
const DoctorInfo = require('../models/DoctorBasicInfoModel');


const Get = async () => {
    await EducationInfo.findAll({ include: [EducationMasterModel, DoctorInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (doctor_name_id) => {
    await EducationInfo.findAll({
        where: { doctor_name_id: doctor_name_id },
        include: [EducationMasterModel, DoctorInfo]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await EducationInfo.findAll({ where: { doctor_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateEducationInfo = async (s_data) => {
    await EducationInfo.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateEducationInfo = async (id, s_data) => {
    await EducationInfo.update(s_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyEducationInfo = async (id) => {
    await EducationInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateEducationInfo,
    UpdateEducationInfo,
    DestroyEducationInfo
};
