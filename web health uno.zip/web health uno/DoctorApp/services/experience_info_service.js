const ExperienceInfo = require('../models/ExperienceModel');
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const DepartmentModel = require('../../MastersApp/models/DepartmentMasterModel');
const SpecialitiesModel = require('../../MastersApp/models/SpecialitiesModel');

const Get = async () => {
    await ExperienceInfo.findAll({ include: [DepartmentModel, DoctorInfo, SpecialitiesModel] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (doctor_name_id) => {
    await ExperienceInfo.findAll({
        where: { doctor_name_id: doctor_name_id },
        include: [DepartmentModel, DoctorInfo, SpecialitiesModel]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await ExperienceInfo.findAll({ where: { doctor_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateExperienceInfo = async (e_data) => {
    await ExperienceInfo.create(e_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateExperienceInfo = async (id, e_data) => {
    await ExperienceInfo.update(e_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyExperienceInfo = async (id) => {
    await ExperienceInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateExperienceInfo,
    UpdateExperienceInfo,
    DestroyExperienceInfo
};
