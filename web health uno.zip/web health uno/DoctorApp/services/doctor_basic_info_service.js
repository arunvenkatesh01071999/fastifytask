// const DoctorBasicInfo = require('../models/DoctorBasicInfoModel');
// const SpecialityInfo = require('../../MastersApp/models/SpecialitiesModel');
// const GenderMaster = require('../../MastersApp/models/GenderModel');
// const db1 = require('../../config/db1');
// const { Sequelize } = require('sequelize');
// const DoctorType = require('../../MastersApp/models/DoctorTypeMasterModel');
// const HospitalBasic = require('../../HospitalApp/models/HospitalBasicInfoModel');
// const moment = require('moment/moment');

// const Get = async () => {
//     await DoctorBasicInfo.findAll({
//         include:
//             [SpecialityInfo, GenderMaster, DoctorType,
//                 {
//                     model: HospitalBasic,
//                     as: 'HospitalBasic',
//                     attributes: ['id', 'hospital_name']
//                 }
//             ]
//     })
//         .then(data => {
//             res = data
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

// const GetbyId = async (id) => {
//     await DoctorBasicInfo.findAll({
//         where: { id: id },
//         include: [SpecialityInfo, GenderMaster, DoctorType,
//             {
//                 model: HospitalBasic,
//                 as: 'HospitalBasic',
//                 attributes: ['id', 'hospital_name']
//             }
//         ]
//     })
//         .then(data => {
//             res = data
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

// const GetbyName = async (name) => {
//     await DoctorBasicInfo.findAll({ where: { doctor_name: name }, raw: true })
//         .then(data => {
//             res = data
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

// const CreateDoctorBasicInfo = async (d_data) => {
//     console.log('d_data', d_data);
//     const query = `INSERT INTO d_doctor_basic_info(doctor_name,active,addCheck,created_at,updated_at,created_by,updated_by) 
//     values('ioisssooi',1,11,'2023-12-12','2023-12-12',2,2)`
//     await db1.query(query, { type: Sequelize.QueryTypes })
//     .then((result) => {
//         console.log('result',result);
//         // res = result;
//         return res
//     })
//     .catch((err) => {
//         console.log('err',err);
//         res = err
//     });
//     res = result;
//     // await DoctorBasicInfo.create(d_data)
//     //     .then(data => {
//     //         res = data
//     //         // console.log('res',res);
//     //     }).catch(err => {
//     //         res = err
//     //     })
//     // return res
// }

// const UpdateDoctorBasicInfo = async (id, d_data) => {
//     await DoctorBasicInfo.update(d_data, { where: { id: id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

// const DestroyDoctorBasicInfo = async (id) => {
//     await DoctorBasicInfo.destroy({ where: { id: id } })
//         .then(data => {
//             res = data
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

// const CreateApprove = async (id, a_data) => {

//     const approve = moment(a_data.approve_date).format('L');
//     const query = `UPDATE d_doctor_basic_info
//     SET isApproved = ${a_data.isApproved}, approve_date = '${approve}', 
//     approved_by = ${a_data.approved_by} , reason = '${a_data.reason}'
//     WHERE id = ${id}`;

//     await db1.query(query, { type: Sequelize.QueryTypes })
//         .then((result) => {
//             res = result
//         })
//         .catch((err) => {
//             res = err
//         });

//     return res
// }

// const UpdateIsApprove = async (id) => {
//     var query = `UPDATE [dbo].[d_doctor_basic_info] SET isApproved = 0
//     where isApproved = 1 and isApproved = 2 and id = ${id} `
//     await db1.query(query, { type: Sequelize.QueryTypes })
//         .then((result) => {
//             res = result
//         })
//         .catch((err) => {
//             res = err
//         });
//     return res
// }

// module.exports = {
//     Get,
//     GetbyId,
//     CreateDoctorBasicInfo,
//     UpdateDoctorBasicInfo,
//     DestroyDoctorBasicInfo,
//     GetbyName,
//     CreateApprove,
//     UpdateIsApprove
// };

const DoctorBasicInfo = require('../models/DoctorBasicInfoModel');
const SpecialityInfo = require('../../MastersApp/models/SpecialitiesModel');
const GenderMaster = require('../../MastersApp/models/GenderModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');
const DoctorType = require('../../MastersApp/models/DoctorTypeMasterModel');
const HospitalBasic = require('../../HospitalApp/models/HospitalBasicInfoModel');
const moment = require('moment/moment');
const Get = async () => {
    await DoctorBasicInfo.findAll({
        include:
            [SpecialityInfo, GenderMaster, DoctorType,
                {
                    model: HospitalBasic,
                    as: 'HospitalBasic',
                    attributes: ['id', 'hospital_name']
                }
            ]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyId = async (id) => {
    await DoctorBasicInfo.findAll({
        where: { id: id },
        include: [SpecialityInfo, GenderMaster, DoctorType,
            {
                model: HospitalBasic,
                as: 'HospitalBasic',
                attributes: ['id', 'hospital_name']
            }
        ]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyName = async (name) => {
    await DoctorBasicInfo.findAll({ where: { doctor_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const CreateDoctorBasicInfo = async (d_data) => {
    await DoctorBasicInfo.create(d_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const UpdateDoctorBasicInfo = async (id, d_data) => {
    await DoctorBasicInfo.update(d_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}
const DestroyDoctorBasicInfo = async (id) => {
    await DoctorBasicInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const CreateApprove = async (id, a_data) => {
    
    const approve = moment(a_data.approve_date).format('L');
    const query = `UPDATE d_doctor_basic_info
    SET isApproved = ${a_data.isApproved}, approve_date = '${approve}', 
    approved_by = ${a_data.approved_by} , reason = '${a_data.reason}'
    WHERE id = ${id}`;
    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((err) => {
            res = err
        });
    return res
}
module.exports = {
    Get,
    GetbyId,
    CreateDoctorBasicInfo,
    UpdateDoctorBasicInfo,
    DestroyDoctorBasicInfo,
    GetbyName,
    CreateApprove
};