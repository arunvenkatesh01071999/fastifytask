const AddressInfo = require('../models/DoctorAddressInfoModel');
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const CityMaster = require('../../MastersApp/models/CityModel');
const StateMaster = require('../../MastersApp/models/StateModel');
const CountryMaster = require('../../MastersApp/models/CountryModel');


const Get = async () => {
    await AddressInfo.findAll({
        include: [DoctorInfo, CityMaster, StateMaster, CountryMaster]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (doctor_name_id) => {
    await AddressInfo.findAll({
        where: { doctor_name_id: doctor_name_id },
        include: [DoctorInfo, CityMaster, StateMaster, CountryMaster]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetId = async (doctor_name_id) => {
    await AddressInfo.findAll({ where: { doctor_name_id: doctor_name_id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateDoctorAddress = async (a_data) => {
    await AddressInfo.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateDoctorAddress = async (id, a_data) => {
    await AddressInfo.update(a_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyDoctorAddress = async (id) => {
    await AddressInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateDoctorAddress,
    UpdateDoctorAddress,
    DestroyDoctorAddress
};
