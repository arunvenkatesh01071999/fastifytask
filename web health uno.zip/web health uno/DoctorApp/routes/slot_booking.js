const express = require('express');
const router = express();
const SlotBookingController = require('../../DoctorApp/controller/SlotBookingController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, SlotBookingController.FetchSlotBooking);
router.get('/:doctor_name_id', verify_token, SlotBookingController.FetchSlotBooking);
router.post('/', verify_token, SlotBookingController.NewSlotBooking);
router.put('/:doctor_name_id', verify_token, SlotBookingController.UpdateSlotBooking);
router.delete('/:id', verify_token, SlotBookingController.DeleteSlotBooking);

module.exports = router;