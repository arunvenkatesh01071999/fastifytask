const express = require('express');
const router = express();
const Doc_repositoryBasicInfoController = require('../../DoctorApp/controller/RepositoryController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, Doc_repositoryBasicInfoController.FetchDoctorBasicInfoRepository);
router.get('/:doctor_name_id', verify_token, Doc_repositoryBasicInfoController.FetchDoctorBasicInfoRepository);




module.exports = router; 