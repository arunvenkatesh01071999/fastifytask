const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const DepartmentModel = require('../../MastersApp/models/DepartmentMasterModel');
const SpecialitiesModel = require('../../MastersApp/models/SpecialitiesModel');
const logger = require('../../config/activity_logger');


const ExperienceInfo = sequelize.define("d_experience_info", {
    doctor_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    experience: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    specialization_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    department_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    upload_certicate: {
        type: DataTypes.STRING,
        allowNull: false
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

ExperienceInfo.belongsTo(DepartmentModel, { foreignKey: 'department_id' });
ExperienceInfo.belongsTo(DoctorInfo, { foreignKey: 'doctor_name_id' });
ExperienceInfo.belongsTo(SpecialitiesModel, { foreignKey: 'specialization_id' });


ExperienceInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'd_experience_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

ExperienceInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'd_experience_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = ExperienceInfo;