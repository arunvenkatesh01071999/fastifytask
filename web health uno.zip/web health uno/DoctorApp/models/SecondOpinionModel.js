const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const DoctorInfo = require('../models/DoctorBasicInfoModel');
const AvailabilityModel = require('../models/AvailabilityModel');
const PeriodModel = require('../../MastersApp/models/PeriodMasterModel');

const SecondOpinionInfo = sequelize.define("d_second_opinion_info", {
    doctor_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "doctor_name_id is required"
            }
        }
    },
    period_id: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    fees: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

SecondOpinionInfo.belongsTo(DoctorInfo, { foreignKey: 'doctor_name_id' });
SecondOpinionInfo.belongsTo(PeriodModel, { foreignKey: 'period_id' });

SecondOpinionInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'd_second_opinion_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

SecondOpinionInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'd_second_opinion_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = SecondOpinionInfo;