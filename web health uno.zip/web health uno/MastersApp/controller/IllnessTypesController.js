// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const illness_types_services = require('../services/illness_types_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');


// const FetchIllnessTypes = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await illness_types_services.GetbyId(id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         data = await cache.GET(req.user.id + '_illness_types');
//         if (data) {
//             res.status(200).json(success_func(JSON.parse(data)))
//         } else {
//             await illness_types_services.Get()
//                 .then(data => {
//                     cache.SET(req.user.id + '_illness_types', data)
//                     res.status(200).json(success_func(data))
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         }
//     }
// }

// const NewIllnessType = async (req, res, next) => {
//     illness_type_name = req.body.illness_type_name;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     if (illness_type_name) {
//         it_data = {
//             illness_type_name: illness_type_name,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         await illness_types_services.GetbyName(illness_type_name)
//             .then(illness_data => {
//                 if (illness_data.length > 0) {
//                     msg = "Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     illness_types_services.CreateIllnessType(it_data)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_illness_types')
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     } else {
//         msg = "illness_type_name and active is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateIllnessType = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         illness_type_name = req.body.illness_type_name;
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (illness_type_name) {
//             it_data = {
//                 illness_type_name: illness_type_name,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }

//             illness_types_services.UpdateIllnessType(id, it_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_illness_types')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })

//         } else {
//             msg = "illness_type_name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const DeleteIllnessType = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await illness_types_services.DestroyIllnessType(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_illness_types')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


// module.exports = {
//     NewIllnessType,
//     FetchIllnessTypes,
//     UpdateIllnessType,
//     DeleteIllnessType
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const illness_types_services = require('../services/illness_types_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs')


const FetchIllnessTypes = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await illness_types_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_illness_types');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await illness_types_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_illness_types', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewIllnessType = async (req, res, next) => {
    illness_type_name = req.body.illness_type_name;
    // console.log("First",req.files)
    try {
        logo_image = req.files.logo_image;
    } catch {
        logo_image = null
    }
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (illness_type_name) {
        it_data = {
            illness_type_name: illness_type_name,
            active: active,
            logo_image: logo_image,
            created_by: created_by,
            updated_by: updated_by
        }
        if (logo_image) {

            it_data.logo_image = logo_image.name;
            buffer = logo_image.data
            path = './media/' + logo_image.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });
        }
        await illness_types_services.GetbyName(illness_type_name)
            .then(illness_data => {
                if (illness_data.length > 0) {
                    msg = "Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    illness_types_services.CreateIllnessType(it_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_illness_types')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "illness_type_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

// const UpdateIllnessType = async (req, res, next) => {

//     img_data = req.body.logo_image
//     id = req.params.id;
//     if (id) {
//         illness_type_name = req.body.illness_type_name;
//         if (img_data && img_data != 'undefined') {
//             logo_image_data = img_data
//         }
//         else {
//             logo_image = req.files.logo_image;
//             if (logo_image) {
//                 logo_image_data = logo_image.name;
//                 buffer = logo_image.data
//                 path = './media/' + logo_image.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//             }
//         }
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (illness_type_name) {
//             it_data = {
//                 illness_type_name: illness_type_name,
//                 logo_image: logo_image_data,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             //console.log(it_data,"it_data");
//             illness_types_services.UpdateIllnessType(id, it_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_illness_types_services')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })

//         } else {
//             msg = "illness_type_name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const UpdateIllnessType = async (req, res, next) => {
    console.log("update");
    img_data = req.body.logo_image
    id = req.params.id;
    if (id) {
        illness_type_name = req.body.illness_type_name;
        if (img_data && img_data != 'undefined') {
            logo_image_data = img_data
        }
        else {
            logo_image = req.files.logo_image;
            if (logo_image) {
                logo_image_data = logo_image.name;
                buffer = logo_image.data
                path = './media/' + logo_image.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });
            }
        }
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (illness_type_name) {
            it_data = {
                illness_type_name: illness_type_name,
                logo_image: logo_image_data,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            console.log(it_data, "it_data");
            illness_types_services.UpdateIllnessType(id, it_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_illness_types')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "illness_type_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteIllnessType = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await illness_types_services.DestroyIllnessType(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_illness_types')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewIllnessType,
    FetchIllnessTypes,
    UpdateIllnessType,
    DeleteIllnessType
}