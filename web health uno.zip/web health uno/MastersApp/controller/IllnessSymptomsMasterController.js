// // const success_func = require('../../api_responser').success_func;
// // const failure_func = require('../../api_responser').failure_func;
// // const date = require('../../services/datetime_service');
// // const illness_symptom_master_services = require('../services/illness_symptom_master_service');
// // const illness_symptoms_services = require('../services/illness_symptoms_service');
// // const logger = require('../../config/logger');
// // const cache = require('../../services/redis_cache_service');


// // const FetchIllnessSymptomsMasters = async (req, res, next) => {
// //     id = req.params.id;
// //     if (id) {
// //         await illness_symptom_master_services.GetbyRelationsId(id)
// //             .then(data => {
// //                 res.status(200).json(success_func(data))
// //             })
// //             .catch(err => {
// //                 res.status(400).json(failure_func(err))
// //             })
// //     } else {
// //         data = await cache.GET(req.user.id + '_illness_symptom_master');
// //         if (data) {
// //             res.status(200).json(success_func(JSON.parse(data)))
// //         } else {
// //             await illness_symptom_master_services.GetbyRelations()
// //                 .then(data => {
// //                     cache.SET(req.user.id + '_illness_symptom_master', data)
// //                     res.status(200).json(success_func(data))
// //                 })
// //                 .catch(err => {
// //                     res.status(400).json(failure_func(err))
// //                 })
// //         }
// //     }
// // }

// // const NewIllnessSymptomsMaster = async (req, res, next) => {
// //     illness_symptom_name = req.body.illness_symptom_name;
// //     illness_type_ids = req.body.illness_type_ids;
// //     active = req.body.active;
// //     created_by = req.user.id;
// //     updated_by = req.user.id;
// //     if (illness_symptom_name && illness_type_ids && Array.isArray(illness_type_ids)) {

// //         sm_data = {
// //             illness_symptom_name: illness_symptom_name,
// //             active: active,
// //             created_by: created_by,
// //             updated_by: updated_by
// //         }
// //         //Check Duplicate values

// //         await illness_symptom_master_services.GetbyName(illness_symptom_name)
// //             .then(symptom_data => {
// //                 if (symptom_data.length > 0) {
// //                     msg = "Symptom Name already exists";
// //                     return res.status(200).json(failure_func(msg))
// //                 } else {
// //                     //insert portion
// //                     illness_symptom_master_services.CreateIllnessSymptomsMaster(sm_data)
// //                         .then(data => {
// //                             if (data.errors) {
// //                                 msg = data.errors[0].message;
// //                                 res.status(400).json(failure_func(msg))
// //                             } else {
// //                                 symptompsdata = data.dataValues;
// //                                 sysmid = symptompsdata.id;

// //                                 if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
// //                                     for (const i of illness_type_ids) { // Use for...of loop
// //                                         const nt_data = {
// //                                             illness_symptom_id: sysmid,
// //                                             illness_type_id: i,
// //                                             active: true,
// //                                             created_by: created_by,
// //                                             updated_by: updated_by
// //                                         }
// //                                         // console.log(nt_data);
// //                                         illness_symptoms_services.CreateIllnessSymptom(nt_data);
// //                                     }
// //                                 }

// //                                 msg = "Created Successfully"
// //                                 cache.DEL(req.user.id + '_illness_symptom_master') // Check cache implementation
// //                                 res.status(200).json(success_func(msg))
// //                             }
// //                         })
// //                         .catch(err => {
// //                             res.status(400).json(failure_func(err))
// //                         })
// //                     //END insert portion
// //                 }
// //             })
// //     } else {
// //         // msg = "illness_symptom_name and active is required";
// //         msg = "illness_symptom_name, illness_type_ids and active is required and illness_type_ids should be an array";
// //         res.status(400).json(failure_func(msg))
// //     }
// // }


// // const UpdateIllnessSymptomsMaster = async (req, res, next) => {
// //     const id = req.params.id;
// //     if (id) {

// //         illness_symptom_name = req.body.illness_symptom_name;
// //         illness_type_ids = req.body.illness_type_ids;
// //         active = req.body.active;
// //         const created_by = req.user.id;
// //         const updated_by = req.user.id;
// //         const updated_at = date();
// //         if (illness_symptom_name) {
// //             sm_data = {
// //                 illness_symptom_name: illness_symptom_name, active: active,
// //                 updated_by: updated_by, updated_at: updated_at
// //             }

// //             // await illness_symptom_master_services.GetbyName(illness_symptom_name)
// //             //     .then(symptom_data => {
// //             //         if (symptom_data.length > 0) {
// //             //             msg = "Symptom Name already exists";
// //             //             return res.status(200).json(failure_func(msg))
// //             //         } else {
// //             illness_symptom_master_services.UpdateIllnessSymptomsMaster(id, sm_data)
// //                 .then(data => {
// //                     if (data == 1) {

// //                         if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
// //                             illness_symptoms_services.DestroyIllnessSymptombymap(id);
// //                             console.log(illness_type_ids);
// //                             for (const i of illness_type_ids) { // Use for...of loop
// //                                 const nt_data = {
// //                                     illness_symptom_id: id,
// //                                     illness_type_id: i,
// //                                     active: true,
// //                                     created_by: created_by,
// //                                     updated_by: updated_by
// //                                 }
// //                                 console.log(nt_data);
// //                                 illness_symptoms_services.CreateIllnessSymptom(nt_data);

// //                             }
// //                         }

// //                         msg = "Updated successfully"
// //                         cache.DEL(req.user.id + '_illness_symptom_master')
// //                         res.status(200).json(success_func(msg))
// //                     } else {
// //                         msg = "ID doesn't exist"
// //                         res.status(400).json(failure_func(msg))
// //                     }
// //                 })
// //                 .catch(err => {
// //                     res.status(400).json(failure_func(err))
// //                 })
// //             //     }
// //             // })

// //         } else {
// //             msg = "illness_symptom_name and active is required";
// //             res.status(400).json(failure_func(msg))
// //         }
// //     } else {
// //         msg = "ID is required";
// //         res.status(400).json(failure_func(msg))
// //     }
// // }

// // const DeleteIllnessSymptomsMaster = async (req, res, next) => {
// //     id = req.params.id;
// //     if (id) {
// //         await illness_symptom_master_services.DestroyIllnessSymptomsMaster(id)
// //             .then(data => {
// //                 if (data == 1) {
// //                     msg = "Deleted successfully"
// //                     cache.DEL(req.user.id + '_illness_symptom_master')
// //                     res.status(200).json(success_func(msg))
// //                 } else {
// //                     msg = "ID doesn't exist"
// //                     res.status(200).json(success_func(msg))
// //                 }
// //             })
// //             .catch(err => {
// //                 res.status(400).json(failure_func(err))
// //             })
// //     } else {
// //         msg = "ID is required";
// //         res.status(400).json(failure_func(msg))
// //     }
// // }


// // module.exports = {
// //     NewIllnessSymptomsMaster,
// //     FetchIllnessSymptomsMasters,
// //     UpdateIllnessSymptomsMaster,
// //     DeleteIllnessSymptomsMaster
// // }

// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const illness_symptom_master_services = require('../services/illness_symptom_master_service');
// const illness_symptoms_services = require('../services/illness_symptoms_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');
// const fs = require('fs');
// const { log } = require('winston');

// const FetchIllnessSymptomsMasters = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await illness_symptom_master_services.GetbyRelationsId(id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         data = await cache.GET(req.user.id + '_illness_symptom_master');
//         if (data) {
//             res.status(200).json(success_func(JSON.parse(data)))
//         } else {
//             await illness_symptom_master_services.GetbyRelations()
//                 .then(data => {
//                     cache.SET(req.user.id + '_illness_symptom_master', data)
//                     res.status(200).json(success_func(data))
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         }
//     }
// }


// const NewIllnessSymptomsMaster = async (req, res, next) => {
//     illness_symptom_name = req.body.illness_symptom_name;
//     // illness_type_ids = req.body.illness_type_ids;
//     logo_image = req.body.logo_image;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     if (illness_symptom_name) {
//         sm_data = {
//             illness_symptom_name: illness_symptom_name,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         if (logo_image) {
//             sm_data.logo_image = logo_image.name;
//             buffer = logo_image.data
//             path = './media/' + logo_image.name;
//             fs.writeFile(path.toString(), buffer, function (err) {
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         await illness_symptom_master_services.GetbyName(illness_symptom_name)
//             .then(data => {
//                 if (data.length > 0) {
//                     msg = "Illness Symptom Name already exists"
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     illness_symptom_master_services.CreateIllnessSymptomsMaster(sm_data)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_illness_symptom_master')
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     }
// }

// // const UpdateIllnessSymptomsMaster = async (req, res, next) => {
// //     const id = req.params.id;
// //     img_data = req.body.logo_image
// //     if (id) {

// //         illness_symptom_name = req.body.illness_symptom_name;
// //         illness_type_id = JSON.parse(req.body.illness_type_id);

// //         if (img_data && img_data != 'undefined') {
// //             logo_image_data = img_data
// //         }
// //         else {
// //             logo_image = req.files.logo_image;
// //             if (logo_image) {
// //                 logo_image_data = logo_image.name;
// //                 buffer = logo_image.data
// //                 path = './media/' + logo_image.name;
// //                 fs.writeFile(path.toString(), buffer, function (err) {
// //                     if (err) {
// //                         return console.log(err);
// //                     }
// //                 });
// //             }
// //         }

// //         active = req.body.active;
// //         const created_by = req.user.id;
// //         const updated_by = req.user.id;
// //         const updated_at = date();
// //         if (illness_symptom_name) {
// //             sm_data = {
// //                 illness_symptom_name: illness_symptom_name,
// //                 active: active,
// //                 logo_image: logo_image_data,
// //                 updated_by: updated_by,
// //                 updated_at: updated_at
// //             }

// //             // await illness_symptom_master_services.GetbyName(illness_symptom_name)
// //             //     .then(symptom_data => {
// //             //         if (symptom_data.length > 0) {
// //             //             msg = "Symptom Name already exists";
// //             //             return res.status(200).json(failure_func(msg))
// //             //         } else {
// //             illness_symptom_master_services.UpdateIllnessSymptomsMaster(id, sm_data)
// //                 .then(data => {
// //                     if (data == 1) {

// //                         if (illness_type_id && Array.isArray(illness_type_id) && illness_type_id.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
// //                             illness_symptoms_services.DestroyIllnessSymptombymap(id);
// //                             console.log(illness_type_id);
// //                             for (const i of illness_type_id) { // Use for...of loop
// //                                 const nt_data = {
// //                                     illness_symptom_id: id,
// //                                     illness_type_id: i,
// //                                     active: true,
// //                                     created_by: created_by,
// //                                     updated_by: updated_by
// //                                 }
// //                                 console.log(nt_data);
// //                                 illness_symptoms_services.CreateIllnessSymptom(nt_data);

// //                             }
// //                         }

// //                         msg = "Updated successfully"
// //                         cache.DEL(req.user.id + '_illness_symptom_master')
// //                         res.status(200).json(success_func(msg))
// //                     } else {
// //                         msg = "ID doesn't exist"
// //                         res.status(400).json(failure_func(msg))
// //                     }
// //                 })
// //                 .catch(err => {
// //                     res.status(400).json(failure_func(err))
// //                 })
// //             //     }
// //             // })

// //         } else {
// //             msg = "illness_symptom_name and active is required";
// //             res.status(400).json(failure_func(msg))
// //         }
// //     } else {
// //         msg = "ID is required";
// //         res.status(400).json(failure_func(msg))
// //     }
// // }

// const UpdateIllnessSymptomsMaster = async(req,res,next) => {
//     img_data = req.body.logo_image
//     id = req.params.id;
//     if (id) {
//         illness_symptom_name = req.body.illness_symptom_name;
//         active = req.body.active;
//         if (img_data && img_data != 'undefined') {
//             logo_image_data = img_data
//         }
//         else {
//             logo_image = req.files.logo_image;
//             if (logo_image) {
//                 logo_image_data = logo_image.name;
//                 buffer = logo_image.data
//                 path = './media/' + logo_image.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//             }
//         }
//         updated_by = req.user.id;
//         updated_at = date();
//         if (illness_symptom_name) {
//             ht_data = {
//                 illness_symptom_name: illness_symptom_name,
//                 logo_image: logo_image_data,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             illness_symptom_master_services.UpdateIllnessSymptomsMaster(id, ht_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_hospital_type_master')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         } else {
//             msg = "illness_symptom_name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const DeleteIllnessSymptomsMaster = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await illness_symptom_master_services.DestroyIllnessSymptomsMaster(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_illness_symptom_master')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


// module.exports = {
//     NewIllnessSymptomsMaster,
//     FetchIllnessSymptomsMasters,
//     UpdateIllnessSymptomsMaster,
//     DeleteIllnessSymptomsMaster
// }


// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const illness_symptom_master_services = require('../services/illness_symptom_master_service');
// const illness_symptoms_services = require('../services/illness_symptoms_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');


// const FetchIllnessSymptomsMasters = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await illness_symptom_master_services.GetbyRelationsId(id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         data = await cache.GET(req.user.id + '_illness_symptom_master');
//         if (data) {
//             res.status(200).json(success_func(JSON.parse(data)))
//         } else {
//             await illness_symptom_master_services.GetbyRelations()
//                 .then(data => {
//                     cache.SET(req.user.id + '_illness_symptom_master', data)
//                     res.status(200).json(success_func(data))
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         }
//     }
// }

// const NewIllnessSymptomsMaster = async (req, res, next) => {
//     illness_symptom_name = req.body.illness_symptom_name;
//     illness_type_ids = req.body.illness_type_ids;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     if (illness_symptom_name && illness_type_ids && Array.isArray(illness_type_ids)) {

//         sm_data = {
//             illness_symptom_name: illness_symptom_name,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         //Check Duplicate values

//         await illness_symptom_master_services.GetbyName(illness_symptom_name)
//             .then(symptom_data => {
//                 if (symptom_data.length > 0) {
//                     msg = "Symptom Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     //insert portion
//                     illness_symptom_master_services.CreateIllnessSymptomsMaster(sm_data)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 symptompsdata = data.dataValues;
//                                 sysmid = symptompsdata.id;

//                                 if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
//                                     for (const i of illness_type_ids) { // Use for...of loop
//                                         const nt_data = {
//                                             illness_symptom_id: sysmid,
//                                             illness_type_id: i,
//                                             active: true,
//                                             created_by: created_by,
//                                             updated_by: updated_by
//                                         }
//                                         // console.log(nt_data);
//                                         illness_symptoms_services.CreateIllnessSymptom(nt_data);
//                                     }
//                                 }

//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_illness_symptom_master') // Check cache implementation
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                     //END insert portion
//                 }
//             })
//     } else {
//         // msg = "illness_symptom_name and active is required";
//         msg = "illness_symptom_name, illness_type_ids and active is required and illness_type_ids should be an array";
//         res.status(400).json(failure_func(msg))
//     }
// }


// const UpdateIllnessSymptomsMaster = async (req, res, next) => {
//     const id = req.params.id;
//     if (id) {

//         illness_symptom_name = req.body.illness_symptom_name;
//         illness_type_ids = req.body.illness_type_ids;
//         active = req.body.active;
//         const created_by = req.user.id;
//         const updated_by = req.user.id;
//         const updated_at = date();
//         if (illness_symptom_name) {
//             sm_data = {
//                 illness_symptom_name: illness_symptom_name, active: active,
//                 updated_by: updated_by, updated_at: updated_at
//             }

//             // await illness_symptom_master_services.GetbyName(illness_symptom_name)
//             //     .then(symptom_data => {
//             //         if (symptom_data.length > 0) {
//             //             msg = "Symptom Name already exists";
//             //             return res.status(200).json(failure_func(msg))
//             //         } else {
//             illness_symptom_master_services.UpdateIllnessSymptomsMaster(id, sm_data)
//                 .then(data => {
//                     if (data == 1) {

//                         if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
//                             illness_symptoms_services.DestroyIllnessSymptombymap(id);
//                             console.log(illness_type_ids);
//                             for (const i of illness_type_ids) { // Use for...of loop
//                                 const nt_data = {
//                                     illness_symptom_id: id,
//                                     illness_type_id: i,
//                                     active: true,
//                                     created_by: created_by,
//                                     updated_by: updated_by
//                                 }
//                                 console.log(nt_data);
//                                 illness_symptoms_services.CreateIllnessSymptom(nt_data);

//                             }
//                         }

//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_illness_symptom_master')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//             //     }
//             // })

//         } else {
//             msg = "illness_symptom_name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const DeleteIllnessSymptomsMaster = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await illness_symptom_master_services.DestroyIllnessSymptomsMaster(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_illness_symptom_master')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


// module.exports = {
//     NewIllnessSymptomsMaster,
//     FetchIllnessSymptomsMasters,
//     UpdateIllnessSymptomsMaster,
//     DeleteIllnessSymptomsMaster
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const illness_symptom_master_services = require('../services/illness_symptom_master_service');
const illness_symptoms_services = require('../services/illness_symptoms_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { log } = require('winston');

const FetchIllnessSymptomsMasters = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await illness_symptom_master_services.GetbyRelationsId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_illness_symptom_master');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await illness_symptom_master_services.GetbyRelations()
                .then(data => {
                    cache.SET(req.user.id + '_illness_symptom_master', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

// const NewIllnessSymptomsMaster = async (req, res, next) => {
// // console.log("haiiia", req.files);
// // console.log("haiiia", req.body);
//     illness_symptom_name = req.body.illness_symptom_name;
//     try {
//         logo_image = req.files.logo_image;

//     } catch {
//         logo_image = null
//     }
//     illness_type_id = req.body.illness_type_id;
//     // illness_type_id = illness_type_id.match(/\d+/g).map(illness_type_id => parseInt(illness_type_id,10));
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     if (illness_symptom_name && illness_type_id && Array.isArray(illness_type_id)) {
//         sm_data = {
//             illness_symptom_name: illness_symptom_name,
//             active: active,
//             //logo_image :  logo_image,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         if (logo_image) {
//             sm_data.logo_image = logo_image.name;
//             buffer = logo_image.data
//             path = './media/' + logo_image.name;
//             fs.writeFile(path.toString(), buffer, function (err) {
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         console.log(sm_data,"sm_data");
//         await illness_symptom_master_services.GetbyName(illness_symptom_name)
//             .then(symptom_data => {
//                 if (symptom_data.length > 0) {
//                     msg = "Symptom Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     //insert portion
//                     illness_symptom_master_services.CreateIllnessSymptomsMaster(sm_data)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 symptompsdata = data.dataValues;
//                                 sysmid = symptompsdata.id;

//                                 if (illness_type_id && Array.isArray(illness_type_id) && illness_type_id.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
//                                     for (const i of illness_type_id) { // Use for...of loop
//                                         const nt_data = {
//                                             illness_symptom_id: sysmid,
//                                             illness_type_id: parseInt(i),
//                                             active: active,
//                                             created_by: created_by,
//                                             updated_by: updated_by
//                                         }
//                                         console.log(typeof illness_type_id,"illness_type_id");
//                                         console.log(nt_data,"nt_data")
//                                         illness_symptoms_services.CreateIllnessSymptom(nt_data);
//                                     }
//                                 }

//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_illness_symptom_master') // Check cache implementation
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                     //END insert portion
//                 }
//             })
//     } else {
//         // msg = "illness_symptom_name and active is required";
//         msg = "illness_symptom_name, illness_type_ids and active is required and illness_type_ids should be an array";
//         res.status(400).json(failure_func(msg))
//     }
// }

const NewIllnessSymptomsMaster = async (req, res, next) => {
    // console.log(req.files,"filesdd");
    illness_symptom_name = req.body.illness_symptom_name;
    const illness_type_id = req.body.illness_type_ids;
    const illness_type_ids = illness_type_id.split(',');
    try {
        logo_image = req.files.logo_image;
    } catch {
        logo_image = null
    }
    console.log('s', logo_image);
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (illness_symptom_name && illness_type_ids && Array.isArray(illness_type_ids)) {

        sm_data = {
            illness_symptom_name: illness_symptom_name,
            logo_image: logo_image,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        if (logo_image) {
            sm_data.logo_image = logo_image.name;
            buffer = logo_image.data
            path = './media/' + logo_image.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });
        }
        console.log(logo_image, "logo_imagesss");
        //Check Duplicate values

        await illness_symptom_master_services.GetbyName(illness_symptom_name)
            .then(symptom_data => {
                if (symptom_data.length > 0) {
                    msg = "Symptom Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    //insert portion
                    illness_symptom_master_services.CreateIllnessSymptomsMaster(sm_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                symptompsdata = data.dataValues;
                                sysmid = symptompsdata.id;
                                if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
                                    for (const i of illness_type_ids) { // Use for...of loop
                                        const nt_data = {
                                            illness_symptom_id: sysmid,
                                            illness_type_id: parseInt(i),
                                            active: true,
                                            created_by: created_by,
                                            updated_by: updated_by
                                        }
                                        illness_symptoms_services.CreateIllnessSymptom(nt_data);
                                    }
                                }

                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_illness_symptom_master') // Check cache implementation
                                res.status(200).json(success_func(msg))
                            }
                        })
                    // .catch(err => {
                    //     res.status(400).json(failure_func(err))
                    // })
                    //END insert portion
                }
            })
    } else {
        // msg = "illness_symptom_name and active is required";
        msg = "illness_symptom_name, illness_type_ids and active is required and illness_type_ids should be an array";
        res.status(400).json(failure_func(msg))
    }
}


const UpdateIllnessSymptomsMaster = async(req,res,next) => {
    const id = req.params.id;
    if (id) {

        illness_symptom_name = req.body.illness_symptom_name;
        const illness_type_id = req.body.illness_type_ids;
       const illness_type_ids = illness_type_id.split(',');
        active = req.body.active;
        const created_by = req.user.id;
        const updated_by = req.user.id;
        const updated_at = date();

        try {
            logo_image = req.files.logo_image;
        } catch {
            logo_image = null
        }

        console.log('logo_image',logo_image);
        if (illness_symptom_name) {
            sm_data = {
                illness_symptom_name: illness_symptom_name, active: active,
                updated_by: updated_by, updated_at: updated_at
            }
            if (logo_image) {
                sm_data.logo_image = logo_image.name;
                buffer = logo_image.data
                path = './media/' + logo_image.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });
            }

            // await illness_symptom_master_services.GetbyName(illness_symptom_name)
            //     .then(symptom_data => {
            //         if (symptom_data.length > 0) {
            //             msg = "Symptom Name already exists";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            illness_symptom_master_services.UpdateIllnessSymptomsMaster(id, sm_data)
                .then(data => {
                    if (data == 1) {

                        if (illness_type_ids && Array.isArray(illness_type_ids)) { // Use Array.isArray() to check if illness_type_ids is an array
                            illness_symptoms_services.DestroyIllnessSymptombymap(id);
                            console.log(illness_type_ids);
                            for (const i of illness_type_ids) { // Use for...of loop
                                const nt_data = {
                                    illness_symptom_id: id,
                                    illness_type_id:  parseInt(i),
                                    active: true,
                                    created_by: created_by,
                                    updated_by: updated_by
                                }
                                console.log(nt_data);
                                illness_symptoms_services.CreateIllnessSymptom(nt_data);

                            }
                        }

                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_illness_symptom_master')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
            //     }
            // })

        } else {
            msg = "illness_symptom_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
    
}

const DeleteIllnessSymptomsMaster = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await illness_symptom_master_services.DestroyIllnessSymptomsMaster(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_illness_symptom_master')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewIllnessSymptomsMaster,
    FetchIllnessSymptomsMasters,
    UpdateIllnessSymptomsMaster,
    DeleteIllnessSymptomsMaster
}