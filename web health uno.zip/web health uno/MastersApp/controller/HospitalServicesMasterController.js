const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const hospital_services_master_service = require('../services/hospital_services_master_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchHospitalServices = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospital_services_master_service.GetbyRelationsId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_hospital_services_master'); 
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await hospital_services_master_service.GetbyRelations()
            .then(data => {
                cache.SET(req.user.id + '_hospital_services_master', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        // }
    }
}

const NewHospitalService = async (req, res, next) => {
    service_name = req.body.service_name;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (service_name) {
        hs_data = {
            service_name: service_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await hospital_services_master_service.GetbyName(service_name)
            .then(service_data => {
                if (service_data.length > 0) {
                    msg = "Services Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    hospital_services_master_service.CreateHospitalService(hs_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_hospital_services_master')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "service_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateHospitalService = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        service_name = req.body.service_name;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (service_name) {
            hs_data = {
                service_name: service_name,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }

            hospital_services_master_service.UpdateHospitalService(id, hs_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_hospital_services_master')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        } else {
            msg = "service_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteHospitalService = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospital_services_master_service.DestroyHospitalService(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_hospital_services_master')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewHospitalService,
    FetchHospitalServices,
    UpdateHospitalService,
    DeleteHospitalService
}