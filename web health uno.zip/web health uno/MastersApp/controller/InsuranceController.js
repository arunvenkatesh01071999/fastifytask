const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const insurance_services = require('../services/insurance_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');

const FetchInsurances = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await insurance_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_insurance_services');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
            await insurance_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_insurance_services', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
// }

const NewInsurance = async (req, res, next) => {
    insurance_name = req.body.insurance_name;
    try {
        logo_image = req.files.logo_image;
    } catch {
        logo_image = null
    }
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;

    if (insurance_name) {
        datas = {
            insurance_name: insurance_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }

        if (logo_image) {
            datas.logo_image = logo_image.name;
            buffer = logo_image.data
            path = './media/' + logo_image.name;
            fs.writeFile(path.toString(), buffer, function (err) {
                if (err) {
                    return console.log(err);
                }
            });
        }
        // console.log(datas);
        await insurance_services.GetbyName(insurance_name)
            .then(insurance_data => {
                if (insurance_data.length > 0) {
                    msg = "Insurance Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    //insert portion
                    insurance_services.CreateInsurance(datas)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_insurance_services')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "insurance_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateInsurance = async (req, res, next) => {


    img_data = req.body.logo_image
    id = req.params.id;
    if (id) {
        insurance_name = req.body.insurance_name;
        if (img_data && img_data != 'undefined') {
            logo_image_data = img_data
        }
        else {
            logo_image = req.files.logo_image;
            if (logo_image) {
                logo_image_data = logo_image.name;
                buffer = logo_image.data
                path = './media/' + logo_image.name;
                fs.writeFile(path.toString(), buffer, function (err) {
                    if (err) {
                        return console.log(err);
                    }
                });
            }
        }
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (insurance_name) {
            i_data = {
                insurance_name: insurance_name,
                logo_image: logo_image_data,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }

            insurance_services.UpdateInsurance(id, i_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_insurance_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        } else {
            msg = "insurance_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteInsurance = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await insurance_services.DestroyInsurance(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_insurance_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewInsurance,
    FetchInsurances,
    UpdateInsurance,
    DeleteInsurance
}