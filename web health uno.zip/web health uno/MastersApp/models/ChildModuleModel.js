const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const MainModule = require('../models/MainModuleModel');
const ParentModule = require('../models/ParentModuleModel');
const logger = require('../../config/activity_logger');

const ChildModule = sequelize.define("child_module", {
    child_module_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "child_module_name is required"
            }
        }
    },
    parent_module_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "parent_module_id is required"
            }
        }
    },
    main_module_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "main_module_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

ChildModule.belongsTo(ParentModule, { foreignKey: 'parent_module_id' });
ChildModule.belongsTo(MainModule, { foreignKey: 'main_module_id' });

ChildModule.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'child_module',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

ChildModule.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'child_module',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = ChildModule;