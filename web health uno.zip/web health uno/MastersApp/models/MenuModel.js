// const sequelize = require('../../config/db1');
// const { Sequelize, DataTypes } = require("sequelize");
// const logger = require('../../config/activity_logger');

// const menu = sequelize.define("m_menu", {
//     module_id: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: "module_id is required"
//             }
//         }
//     },
//     menu_name: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: "menu_name is required"
//             }
//         }
//     },
//     menu_url: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: "menu_url is required"
//             }
//         }
//     },
//     menu_icon: {
//         type: DataTypes.STRING,
//         allowNull: false,
//         validate: {
//             notEmpty: {
//                 msg: "menu_icon is required"
//             }
//         }
//     },
//     active: {
//         type: DataTypes.BOOLEAN,
//         allowNull: true,
//     },
//     order_row: {
//         type: DataTypes.INTEGER,
//         allowNull: true,
//     },
//     created_at: {
//         type: DataTypes.DATE,
//         allowNull: true,
//     },
//     updated_at: {
//         type: DataTypes.STRING,
//         allowNull: true,
//     },
//     created_by: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     },
//     updated_by: {
//         type: DataTypes.INTEGER,
//         allowNull: false,
//     }
// }, { freezeTableName: true });


// menu.addHook('afterUpdate', (data, options) => {
//     resp = JSON.stringify({
//         action: 'create',
//         table_name: 'm_menu',
//         record_id: data.id,
//         old_value: JSON.stringify(data._previousDataValues),
//         new_value: JSON.stringify(data)
//     });
//     logger.info(resp)
// });

// menu.addHook('afterDestroy', (data, options) => {
//     resp = JSON.stringify({
//         action: 'delete',
//         table_name: 'm_menu',
//         record_id: data.id,
//         old_value: JSON.stringify(data),
//         new_value: '',
//     });
//     logger.info(resp)
// });


// module.exports = menu;

const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const service_master = require('../../models/ServiceModel')

const menu = sequelize.define("m_menu", {
    module_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "module_id is required"
            }
        }
    },
    menu_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "menu_name is required"
            }
        }
    },
    menu_url: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "menu_url is required"
            }
        }
    },
    menu_icon: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "menu_icon is required"
            }
        }
    },
    sub_icon: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "sub_icon is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    order_row: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

menu.belongsTo(service_master, { foreignKey: 'module_id' })

menu.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'm_menu',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

menu.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'm_menu',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = menu;