const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const Services = require('../../models/ServiceModel');
const logger = require('../../config/activity_logger');


const TermsAndConditions = sequelize.define("terms_and_conditions", {
    terms_and_conditions: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "terms_and_conditions is required"
            }
        }
    },
    terms_and_conditions_title: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "terms_and_conditions_title is required"
            }
        }
    },
    is_for: {
        type: DataTypes.INTEGER,
        allowNull: true,
        defaultValue: 0,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });


TermsAndConditions.belongsTo(Services, { foreignKey: 'is_for' });

TermsAndConditions.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'terms_and_conditions',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

TermsAndConditions.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'terms_and_conditions',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = TermsAndConditions;