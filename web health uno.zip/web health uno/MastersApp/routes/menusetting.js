const express = require('express');
const router = express();
const MenuSettingController = require('../../MastersApp/controller/MenuSettingController')
const verify_token = require('../../services/verify_token');

router.get('/:id', verify_token, MenuSettingController.FetchRole);
router.get('/:user/:id', verify_token, MenuSettingController.FetchUser);
router.get('/:All/:Rollid/:userid', verify_token, MenuSettingController.FetchAllData);
router.post('/updatemenu', verify_token, MenuSettingController.updatemenu);
router.post('/loaddashboard', verify_token, MenuSettingController.loaddashboard);



module.exports = router;