const express = require('express');
const router = express();
const DocterSearchfastify = require('../controller/DocterSearchfastify');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, DocterSearchfastify.FetchSearchdata);


module.exports = router;