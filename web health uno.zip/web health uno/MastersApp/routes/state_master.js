const express = require('express');
const router = express();
const StateMasterController = require('../controller/StateController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, StateMasterController.FetchState);
// router.get('/:id', verify_token, StateMasterController.FetchState);
router.get('/:country_id', verify_token, StateMasterController.FetchByCountryId);

module.exports = router;