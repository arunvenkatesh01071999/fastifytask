const express = require('express');
const router = express();
const ScanTestController = require('../controller/ScanTestController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ScanTestController.FetchScanType);
router.get('/:id', verify_token, ScanTestController.FetchScanType);
router.post('/', verify_token, ScanTestController.NewLabTest);
router.put('/:id', verify_token, ScanTestController.UpdateScanType);
router.delete('/:id', verify_token, ScanTestController.DeleteScanType);

module.exports = router;