const express = require('express');
const router = express();
const LabSectorController = require('../controller/LabSectorController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabSectorController.FetchLabSector);
router.get('/:id', verify_token, LabSectorController.FetchLabSector);
router.post('/', verify_token, LabSectorController.NewLabSector);
router.put('/:id', verify_token, LabSectorController.UpdateLabSector);
router.delete('/:id', verify_token, LabSectorController.DeleteLabSector);

module.exports = router;