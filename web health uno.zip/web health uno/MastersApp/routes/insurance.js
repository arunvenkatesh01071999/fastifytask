const express = require('express');
const router = express();
const InsuranceController = require('../controller/InsuranceController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, InsuranceController.FetchInsurances);
router.get('/:id', verify_token, InsuranceController.FetchInsurances);
router.post('/', verify_token, InsuranceController.NewInsurance);
router.put('/:id', verify_token, InsuranceController.UpdateInsurance);
router.delete('/:id', verify_token, InsuranceController.DeleteInsurance);

module.exports = router;