const express = require('express');
const router = express();
const EhrTypeMasterController = require('../controller/EhrMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, EhrTypeMasterController.FetchEhrType);
router.get('/:id', verify_token, EhrTypeMasterController.FetchEhrType);
router.post('/', verify_token, EhrTypeMasterController.NewEhrType);
router.put('/:id', verify_token, EhrTypeMasterController.UpdateEhrType);
router.delete('/:id', verify_token, EhrTypeMasterController.DeleteEhrType);

module.exports = router;