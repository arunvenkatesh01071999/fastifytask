const express = require('express');
const router = express();
const TermsAndConditionsController = require('../controller/TermsAndConditionsController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, TermsAndConditionsController.FetchTermsandConditions);
router.get('/:id', verify_token, TermsAndConditionsController.FetchTermsandConditions);
router.post('/', verify_token, TermsAndConditionsController.NewTermsandConditions);
router.put('/:id', verify_token, TermsAndConditionsController.UpdateTermsandConditions);
router.delete('/:id', verify_token, TermsAndConditionsController.DeleteTermsandConditions);

module.exports = router;