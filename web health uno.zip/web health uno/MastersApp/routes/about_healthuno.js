const express = require('express');
const router = express();
const AboutHealthUnoController = require('../controller/AboutHealthUnoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, AboutHealthUnoController.FetchAboutHealthUnos);
router.get('/:id', verify_token, AboutHealthUnoController.FetchAboutHealthUnos);
router.post('/', verify_token, AboutHealthUnoController.NewAboutHealthUno);
router.put('/:id', verify_token, AboutHealthUnoController.UpdateAboutHealthUno);
router.delete('/:id', verify_token, AboutHealthUnoController.DeleteAboutHealthUno);

module.exports = router; 