const express = require('express');
const router = express();
const PrivacyPolicyController = require('../controller/PrivacyPolicyController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, PrivacyPolicyController.FetchPrivacyPolicies);
router.get('/:id', verify_token, PrivacyPolicyController.FetchPrivacyPolicies);
router.post('/', verify_token, PrivacyPolicyController.NewPrivacyPolicy);
router.put('/:id', verify_token, PrivacyPolicyController.UpdatePrivacyPolicy);
router.delete('/:id', verify_token, PrivacyPolicyController.DeletePrivacyPolicy);

module.exports = router;