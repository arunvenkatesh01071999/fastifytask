const express = require('express');
const router = express();
const SpecialitiesController = require('../controller/SpecialitiesController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, SpecialitiesController.FetchSpecialities);
router.get('/:id', verify_token, SpecialitiesController.FetchSpecialities);
router.post('/', verify_token, SpecialitiesController.NewSpeciality);
router.put('/:id', verify_token, SpecialitiesController.UpdateSpeciality);
router.delete('/:id', verify_token, SpecialitiesController.DeleteSpeciality);

module.exports = router;