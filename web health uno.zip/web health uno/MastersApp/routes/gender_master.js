const express = require('express');
const router = express();
const GenderMasterController = require('../controller/GenderController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, GenderMasterController.FetchGender);
router.get('/:id', verify_token, GenderMasterController.FetchGender);
router.post('/', verify_token, GenderMasterController.NewGender);
router.put('/:id', verify_token, GenderMasterController.UpdateGender);
router.delete('/:id', verify_token, GenderMasterController.DeleteGender);


module.exports = router;