const express = require('express');
const router = express();
const LabTestCategoryController = require('../controller/LabTestCategoryController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabTestCategoryController.FetchLabTestCategory);
router.get('/:id', verify_token, LabTestCategoryController.FetchLabTestCategory);
router.post('/', verify_token, LabTestCategoryController.NewLabTestCategory);
router.put('/:id', verify_token, LabTestCategoryController.UpdateLabTestCategory);
router.delete('/:id', verify_token, LabTestCategoryController.DeleteLabTestCategory);

module.exports = router;