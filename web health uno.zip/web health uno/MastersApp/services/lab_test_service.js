const LabTestModel = require('../models/LabTestModel');
const LabTestCategory = require('../../MastersApp/models/LabTestCategoryModel')
const LabTestModelId = require('../models/LabtestIdModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');


// const Get = async () => {
//     try {
//     const all_data = [];
//     const all_data_walking = [];
//     var newArray = [];
//     await LabTestModel.findAll({

//         include: [
//             {
//                 model: LabTestModelId,
//                 attributes: ['test_name_id', 'category_id']
//             }
//         ]
        
//     })
//     .then((result) => {
//         res = result
//         all_data.push(res);
//     })
//     .catch((err) => {
//         res = err
//     });
  
//     await LabTestModelId.findAll({

//         include: [
           
//             {
//                 model: LabTestCategory,
//                 attributes: ['lab_test_category_name']
//             }
//         ]
        
//     })

//     .then((result) => {
//         res = result
//         all_data_walking.push(res);
//         newArray = all_data.concat(all_data_walking);
//         res = newArray;
//     })
//     .catch((err) => {
//         res = err
//     });
// }
// catch (err) {
//     // Log Errors
//     throw Error('Error while getting lab test and lab test category data', err);
// }
// return res;

// }

// const Get = async () => {

// try{
//     const query1 = `SELECT * 
//     FROM [lab_test]
//     LEFT JOIN [lab_test_id]
//     ON [lab_test].id = [lab_test_id].test_name_id
//     LEFT JOIN lab_test_category
//     ON lab_test_category.id = [lab_test_id].category_id`;
//     await db1.query(query1, { type: Sequelize.QueryTypes })
//     .then((result) => {
//         res = result
//     })
//     .catch((err) => {
//         res = err
//     });
// }
// catch (err) {
    
//     throw Error('Error while getting lab test and lab test category data', err);
// }
// return res;

// }

const Get = async (id) => {
    let res;
    await LabTestModel.findAll({

        include: [{
            model: LabTestModelId,
            include: LabTestCategory
        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}
const GetbyId = async (id) => {
    let res;
    await LabTestModel.findAll({
        where: {
            id: id
        },
        include: [{
            model: LabTestModelId,
            include: LabTestCategory
        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}


const CreateLabTest = async (c_data) => {
    await LabTestModel.create(c_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateLabType = async (id, c_data) => {
    await LabTestModel.update(c_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyLabType = async (id) => {
    await LabTestModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (test_name) => {
    await LabTestModel.findAll({ where: { test_name: test_name } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    CreateLabTest,
    GetbyName,
    UpdateLabType,
    DestroyLabType,
    Get,
    GetbyId,
};