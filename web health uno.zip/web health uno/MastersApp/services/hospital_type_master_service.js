const HospitalTypeMaster = require('../models/HospitalTypeMasterModel');

const Get = async () => {
    await HospitalTypeMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await HospitalTypeMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await HospitalTypeMaster.findAll({ where: { hospital_type_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateHospitalType = async (ht_data) => {
    await HospitalTypeMaster.create(ht_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateHospitalType = async (id, ht_data) => {
    await HospitalTypeMaster.update(ht_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyHospitalType = async (id) => {
    await HospitalTypeMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateHospitalType,
    UpdateHospitalType,
    DestroyHospitalType
};
