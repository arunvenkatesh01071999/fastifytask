const IllnessTypes = require('../models/IllnessTypesModel');

const Get = async () => {
    await IllnessTypes.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await IllnessTypes.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await IllnessTypes.findAll({ where: { illness_type_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateIllnessType = async (it_data) => {
    await IllnessTypes.create(it_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateIllnessType = async (id, it_data) => {
    await IllnessTypes.update(it_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyIllnessType = async (id) => {
    await IllnessTypes.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateIllnessType,
    UpdateIllnessType,
    DestroyIllnessType,
    GetbyName
};
