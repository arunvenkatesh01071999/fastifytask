const SubMenuModel = require('../models/SubMenuModel');
const menu = require('../../MastersApp/models/MenuModel')

const Get = async () => {
    await SubMenuModel.findAll({ include: menu })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await SubMenuModel.findAll({ where: { id: id }, include: menu })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await SubMenuModel.findAll({ where: { submenu_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSubmenu = async (a_data) => {
    await SubMenuModel.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateSubMenu = async (id, a_data) => {
    await SubMenuModel.update(a_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroySubMenu = async (id) => {
    await SubMenuModel.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateSubmenu,
    UpdateSubMenu,
    DestroySubMenu
};