const QualificationMaster = require('../models/QualificationMasterModel');

const Get = async () => {
    await QualificationMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await QualificationMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateQualificationMaster = async (qm_data) => {
    await QualificationMaster.create(qm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateQualificationMaster = async (id, qm_data) => {
    await QualificationMaster.update(qm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyQualificationMaster = async (id) => {
    await QualificationMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateQualificationMaster,
    UpdateQualificationMaster,
    DestroyQualificationMaster
};
