const ScanTestModelId = require('../models/ScantestIdModel');

const CreateLabTestId = async (lt_data) => {
    await ScanTestModelId.create(lt_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const DestroyLabTypeId = async (id) => {
    await ScanTestModelId.destroy({ where: { test_name_id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    CreateLabTestId,
    DestroyLabTypeId

};