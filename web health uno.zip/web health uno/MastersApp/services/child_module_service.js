const ChildModule = require('../models/ChildModuleModel');
const MainModule = require('../models/MainModuleModel');
const ParentModule = require('../models/ParentModuleModel');

const Get = async () => {
    await ChildModule.findAll({ include: [MainModule, ParentModule] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await ChildModule.findAll({ where: { id: id }, include: [MainModule, ParentModule] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await ChildModule.findAll({ where: { child_module_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateChildModule = async (cm_data) => {
    await ChildModule.create(cm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateChildModule = async (id, cm_data) => {
    await ChildModule.update(cm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyChildModule = async (id) => {
    await ChildModule.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateChildModule,
    UpdateChildModule,
    DestroyChildModule
};
