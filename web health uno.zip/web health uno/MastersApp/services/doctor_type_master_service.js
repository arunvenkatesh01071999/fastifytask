const DoctorTypeMaster = require('../models/DoctorTypeMasterModel');

const Get = async () => {
    await DoctorTypeMaster.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await DoctorTypeMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await DoctorTypeMaster.findAll({ where: { doctor_type_name: doctor_type_name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateDoctorType = async (ht_data) => {
    await DoctorTypeMaster.create(ht_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateDoctorType = async (id, ht_data) => {
    await DoctorTypeMaster.update(ht_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyDoctorType = async (id) => {
    await DoctorTypeMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateDoctorType,
    UpdateDoctorType,
    DestroyDoctorType
};