const ScanTestMaster = require('../models/ScanTestMasterModel');

const Get = async () => {
    await ScanTestMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await ScanTestMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateScanTest = async (st_data) => {
    await ScanTestMaster.create(st_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateScanTest = async (id, st_data) => {
    await ScanTestMaster.update(st_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyScanTest = async (id) => {
    await ScanTestMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await ScanTestMaster.findAll({ where: { scan_test_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateScanTest,
    UpdateScanTest,
    DestroyScanTest
};
