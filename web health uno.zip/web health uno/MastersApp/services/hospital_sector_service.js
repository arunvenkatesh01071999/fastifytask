const HospitalSector = require('../models/HospitalSectorModel');

const Get = async () => {
    await HospitalSector.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await HospitalSector.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await HospitalSector.findAll({ where: { hospital_sector_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateHospitalSector = async (h_data) => {
    await HospitalSector.create(h_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateHospitalSector = async (id, h_data) => {
    await HospitalSector.update(h_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyHospitalSector = async (id) => {
    await HospitalSector.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateHospitalSector,
    UpdateHospitalSector,
    DestroyHospitalSector
};
