const db1 = require('../config/db1');

const addCheck = async (lab_name_id) => {
    const addCheck = 8;
    const query = `select addCheck from l_lab_basic_info where id =${lab_name_id}`;
    var customerFeedback = await db1.query(query);
    var menu_data = customerFeedback.flat();
    total_add = addCheck + menu_data[0].addCheck;

    const query1 = `UPDATE l_lab_basic_info SET addCheck = ${total_add} where id =${lab_name_id}`
    var customerFeedback1 = await db1.query(query1);
}

module.exports = addCheck;