const Role = require('../models/RoleModel');
const User = require('../models/UserModel');
const Services = require('../models/ServiceModel');
const NotificationMapping = require('../MastersApp/models/NotificationMappingModel');
const NotificationMaster = require('../MastersApp/models/NotificationMasterModel');


const Get = async () => {
    let res;
    await User.findAll({
        include: [{ model: Role, include: Services }, { model: NotificationMapping, as: 'notificationMappings', include: NotificationMaster }],
        attributes: { exclude: ['password', 'OTP'] },
        logging: console.log // add this line to log the SQL queries
    })
        .then(users => {
            res = users
        })
        .catch(err => {
            res = err
        });
    return res;
}

// const Get = async () => {
//     await User.findAll({ include: [{ model: Role, include: Services }, { model: NotificationMapping }], attributes: { exclude: ['password', 'OTP'] } })
//         .then(users => {
//             res = users
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

const GetbyId = async (id) => {
    await User.findAll({ include: [{ model: Role, include: Services }, { model: NotificationMapping, as: 'notificationMappings', include: NotificationMaster }], where: { id: id }, attributes: { exclude: ['password', 'OTP'] } })
        .then(users => {
            res = users
        })
        .catch(err => {
            res = err
        })
    return res
}
// const GetbyId = async (id) => {
//     await User.findAll({ include: [{ model: Role, include: Services }], where: { id: id }, attributes: { exclude: ['password', 'OTP'] } })
//         .then(users => {
//             res = users
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

const GetbyEmail = async (id) => {
    await User.findAll({ include: [{ model: Role, include: Services }], where: { email: email } })
        .then(users => {
            res = users
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyEmailCheck = async (id) => {
    await User.findAll({ where: { email: email } })
        .then(users => {
            res = users
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateUser = async (data) => {
    await User.create(data)
        .then(user => {
            res = user
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateUser = async (id, data) => {
    await User.update(data, { where: { id: id }, individualHooks: true })
        .then(user => {
            res = user[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyUser = async (id) => {
    await User.destroy({ where: { id: id }, individualHooks: true })
        .then(user => {
            res = user
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateUser,
    UpdateUser,
    DestroyUser,
    GetbyEmail,
    GetbyEmailCheck
};
