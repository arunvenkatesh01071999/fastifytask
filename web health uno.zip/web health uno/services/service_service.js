const Services = require('../models/ServiceModel');

const Get = async () => {
    await Services.findAll()
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await Services.findAll({ where: { id: id } })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await Services.findAll({ where: { service_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateService = async (s_data) => {
    await Services.create(s_data)
        .then(service => {
            res = service
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateService = async (id, data) => {
    await Services.update(data, { where: { id: id }, individualHooks: true })
        .then(service => {
            res = service[0]
        }).catch(err => {
            res = err
            console.log(err);
        })
    return res
}


const DestroyService = async (id) => {
    await Services.destroy({ where: { id: id }, individualHooks: true })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateService,
    UpdateService,
    DestroyService
};
