const date = require('date-and-time');

const datetimenow = () => {
    now = date.format(new Date(), 'YYYY-MM-DD HH:mm:ss');
    return now;
}

module.exports = datetimenow;