const db1 = require('../config/db1');
const failure_func = require('../api_responser').failure_func;

const addCheck = async (hospital_name_id) => {
    const addCheck = 8;
    if(hospital_name_id > 0){
        const query = `select addCheck from h_hospital_basic_info where id =${hospital_name_id}`;
    var customerFeedback = await db1.query(query);
    var menu_data = customerFeedback.flat();
    total_add = addCheck + menu_data[0].addCheck;

    const query1 = `UPDATE h_hospital_basic_info SET addCheck = ${total_add} where id =${hospital_name_id}`;
    var customerFeedback1 = await db1.query(query1);
    }else{
        msg = "hospital_name_id is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = addCheck;