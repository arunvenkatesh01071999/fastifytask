const jwt = require('jsonwebtoken');
const user_services = require('./login_service');
require('dotenv').config();

function verifyToken(req, res, next) {
  secret_key = process.env.jwt_secret_key
  // Get auth header value
  const bearerHeader = req.headers['authorization'];
  if (typeof bearerHeader !== 'undefined') {
    // Split at the space
    const bearer = bearerHeader.split(' ');
    // Get token from array
    const bearerToken = bearer[1];
    // Verify the JWT with the secret key
    jwt.verify(bearerToken, secret_key, async (err, decoded) => {
      if (decoded) {
        await user_services.VerifyUser(decoded.id, decoded.email, decoded.password)
          .then(data => {
            if (data.length != 1) {
              return res.status(401).json({ error: "user not found" })
            }
          })
      }
      if (err) {
        // If the JWT is invalid or expired, return an error response
        return res.status(401).json({ message: 'Invalid or expired token' });
      } else {
        // If the JWT is valid, store the decoded user ID in the request object and call the next middleware function
        req.user = decoded;
        next();
      }
    });
  } else {
    res.status(401).json({ "detail": "Authentication credentials were not provided." })
  }
}

module.exports = verifyToken