require('dotenv').config();
const Sequelize = require("sequelize");

const sequelize = new Sequelize(
  process.env.DB1_DBNAME,
  process.env.DB1_USER,
  process.env.DB1_PASSWORD,
  {
    host: process.env.DB1_HOST,
    dialect: 'mssql',
    dialectOptions: {
      options: {
        encrypt: false,
        trustServerCertificate: true,
        requestTimeout: 15000
      }
    },
    logging: true,
    define: {
      scopes: {
        excludeCreatedAtUpdateAt: {
          attributes: { exclude: ['createdAt', 'updatedAt'] }
        }
      },
      timestamps: false
    }
  },
);

sequelize.authenticate().then(() => {
  console.log('Database Connection has been established successfully');
}).catch((error) => {
  console.error('Unable to connect to the database: ', error);
});

module.exports = sequelize;