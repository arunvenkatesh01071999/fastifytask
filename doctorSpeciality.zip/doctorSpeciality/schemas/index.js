const getDoctorSpecialitiesSchema = require("./getDoctorSpecialitiesSchema");

module.exports = {
  getDoctorSpecialitiesSchema
};
