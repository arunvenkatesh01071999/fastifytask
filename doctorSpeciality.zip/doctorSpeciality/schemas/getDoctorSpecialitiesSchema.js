const { errorSchemas } = require("../../../commons/schemas/errorSchemas");

const bankSchema = {
  tags: ["Fetch doctorSpeciality"],
  summary: "This API is used to fetch doctorSpeciality",
  headers: { $ref: "request-headers#" },
  response: {
    200: {
      type: "array",
      items: {
        type: "object",
        properties: {
          
          count: { type: "integer" }, 
          specialityID: { type: "integer" }
          
        }
      }
    },
    ...errorSchemas
  }
};

module.exports = bankSchema;
