const getSpecialitiesInfoRepo = require("../repository/getSpecialitiesInfoRepo");

function getSpecialitiesInfoService(fastify) {
  const { getSpecialitiesInfo } = getSpecialitiesInfoRepo(fastify);

  return async ({ logTrace }) => {
    const knex = fastify.knexMaster;

    const response = await getSpecialitiesInfo.call(knex, {
      logTrace
    });

    return response;
  };
}



module.exports = getSpecialitiesInfoService;
