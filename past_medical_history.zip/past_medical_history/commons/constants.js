const PASTMEDICALHISTORY = {
  NAME: "e_past_medical_history",
  COLUMNS: {
    ID: "id",
    DOCTOR_ID: "doctor_id",
    PATIENT_ID: "patient_id",
    ISALLOPATHY_OR_AUYRVEDIC: "isallopathy_or_auyrvedic",
    APPOINTMENT_ID: "appointment_id",
    UPLOAD_DOCUMENT_PATH: "upload_document_path",
    PAST_ILLNESS: "past_illness",
    PAST_MEDICINE: "past_medicine",
    PAST_SURGERY: "past_surgery",
    HISTORY_OF_ALLERGY: "history_of_allergy",
    PREVIOUS_VACINATION: "previous_vacination",
    IS_PREGNANCY: "is_pregnancy",
    IS_TRIMSTERS: "is_trimsters",
    IS_LACTATION: "is_lactation",
    CREATED_AT: "created_at",
    UPDATED_AT: "updated_at",
    CREATED_BY: "created_by",
    UPDATED_BY: "updated_by"
  }
};

module.exports = {
  PASTMEDICALHISTORY
};
