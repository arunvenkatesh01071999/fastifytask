const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { PASTMEDICALHISTORY } = require("../commons/constants");
// const { CustomError } = require("../../../errorHandler");

function postPastMedicalHistoryRepositoryBasic(fastify) {
  async function PastMedicalHistoryAdd({ logTrace, body }) {
    const knex = this;
    const query = await knex(`${PASTMEDICALHISTORY.NAME}`).insert({



      [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: body.patient_id,
      [PASTMEDICALHISTORY.COLUMNS.ISALLOPATHY_OR_AUYRVEDIC]: body.isallopathy_or_auyrvedic,
      [PASTMEDICALHISTORY.COLUMNS.APPOINTMENT_ID]: body.appointment_id,
      [PASTMEDICALHISTORY.COLUMNS.UPLOAD_DOCUMENT_PATH]: body.upload_document_path,
      [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: body.past_illness,
      [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: body.past_medicine,
      [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERY]: body.past_surgery,
      [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: body.history_of_allergy,
      [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: body.previous_vacination,
      [PASTMEDICALHISTORY.COLUMNS.IS_PREGNANCY]: body.is_pregnancy,
      [PASTMEDICALHISTORY.COLUMNS.IS_TRIMSTERS]: body.is_trimsters,
      [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: body.is_lactation,
      [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: body.created_by



    });

    const response = await query;

    return { success: true, message: "Insert successfully" };
  }


  return {
    PastMedicalHistoryAdd

  };
}

function updatePastMedicalHistoryRepository(fastify) {
  async function PastMedicalHistoryUpdate({ logTrace, body, params }) {
    const knex = this;
    const { id } = params;
    const query = await knex(`${PASTMEDICALHISTORY.NAME}`)
      .where(`${PASTMEDICALHISTORY.COLUMNS.ID}`, id)
      .update({
        [PASTMEDICALHISTORY.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [PASTMEDICALHISTORY.COLUMNS.PATIENT_ID]: body.patient_id,
        [PASTMEDICALHISTORY.COLUMNS.ISALLOPATHY_OR_AUYRVEDIC]: body.isallopathy_or_auyrvedic,
        [PASTMEDICALHISTORY.COLUMNS.APPOINTMENT_ID]: body.appointment_id,
        [PASTMEDICALHISTORY.COLUMNS.UPLOAD_DOCUMENT_PATH]: body.upload_document_path,
        [PASTMEDICALHISTORY.COLUMNS.PAST_ILLNESS]: body.past_illness,
        [PASTMEDICALHISTORY.COLUMNS.PAST_MEDICINE]: body.past_medicine,
        [PASTMEDICALHISTORY.COLUMNS.PAST_SURGERY]: body.past_surgery,
        [PASTMEDICALHISTORY.COLUMNS.HISTORY_OF_ALLERGY]: body.history_of_allergy,
        [PASTMEDICALHISTORY.COLUMNS.PREVIOUS_VACINATION]: body.previous_vacination,
        [PASTMEDICALHISTORY.COLUMNS.IS_PREGNANCY]: body.is_pregnancy,
        [PASTMEDICALHISTORY.COLUMNS.IS_TRIMSTERS]: body.is_trimsters,
        [PASTMEDICALHISTORY.COLUMNS.IS_LACTATION]: body.is_lactation,
        [PASTMEDICALHISTORY.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    PastMedicalHistoryUpdate,
  };
}

function getPastMedicalHistoryRepository(fastify) {

  async function PastMedicalHistoryGetAlls({ logTrace }) {

    const knex = this;
    const query = knex.select('*').from(`${PASTMEDICALHISTORY.NAME}`)
    logQuery({
      logger: fastify.log,
      query,
      context: "Get FINAL_DIAGNOSIS details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "FINAL_DIAGNOSIS info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    PastMedicalHistoryGetAlls
  };

}


function getPastMedicalHistoryRepositoryId(fastify) {

  async function PastMedicalHistoryGetOne({ logTrace, params }) {

    const knex = this;
    const { id } = params;
    const query = knex.select('*').from(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get FINAL_DIAGNOSIS details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "FINAL_DIAGNOSIS info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    PastMedicalHistoryGetOne
  };

}

function deletePastMedicalHistoryRepositoryId(fastify) {
  async function PastMedicalHistoryDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${PASTMEDICALHISTORY.NAME}`).where(`${PASTMEDICALHISTORY.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    PastMedicalHistoryDelete
  };
}


module.exports = {
  postPastMedicalHistoryRepositoryBasic,
  updatePastMedicalHistoryRepository,
  getPastMedicalHistoryRepository,
  getPastMedicalHistoryRepositoryId,
  deletePastMedicalHistoryRepositoryId

};
