const schemas = require("../schemas");
const handlers = require("../handlers");

module.exports = async fastify => {

  

  fastify.route({
    method: "POST",
    url: "/cheif-complaints",
    // schema: schemas.getCheifComplaintsSchema.createCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.createCheifComplaintsHandler(fastify)
  });

  fastify.route({
    method: "PUT",
    url: "/cheif-complaints/:id",
    // schema: schemas.getCheifComplaintsSchema.updateCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.updateCheifComplaintsHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/cheif-complaints",
    // schema: schemas.getCheifComplaintsSchema.getCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.getCheifComplaintsHandler(fastify)
  });

  fastify.route({
    method: "GET",
    url: "/cheif-complaints/:id",
  //  schema: schemas.getCheifComplaintsSchema.getCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.getCheifComplaintsHandlerId(fastify)
  });

  fastify.route({
    method: "DELETE",
    url: "/cheif-complaints/:id",
  //  schema: schemas.getCheifComplaintsSchema.deleteCheifComplaintsSchema,
    handler: handlers.getCheifComplaintsHandler.deleteCheifComplaintsHandler(fastify)
  });

};
