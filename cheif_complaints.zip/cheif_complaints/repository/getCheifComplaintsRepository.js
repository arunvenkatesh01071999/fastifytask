const { StatusCodes } = require("http-status-codes");
const { logQuery } = require("../../../../commons/helpers");
const { CHEIFCOMPLAINTS } = require("../commons/constants");
const { CustomError } = require("../../../../errorHandler");

function postCheifComplaintsRepositoryBasic(fastify) {
  async function CheifComplaintsAdd({ logTrace, body }) {
    console.log(body,"body");
    const knex = this;

    



    const query = await knex(`${CHEIFCOMPLAINTS.NAME}`).insert({
      [CHEIFCOMPLAINTS.COLUMNS.DOCTOR_ID]: body.doctor_id,
      [CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID]: body.patient_id,
      [CHEIFCOMPLAINTS.COLUMNS.ISALLO_OR_AUYR]: body.isallo_or_auyr,
      [CHEIFCOMPLAINTS.COLUMNS.APPOINT_ID]: body.appoint_id,
      [CHEIFCOMPLAINTS.COLUMNS.ILLNESS_TYPE_ID]: body.illness_type_id,
      [CHEIFCOMPLAINTS.COLUMNS.ACTIVE]: body.active,
      [CHEIFCOMPLAINTS.COLUMNS.CREATED_BY]: body.created_by
    });

    const response = await query;
    console.log(response,"response.");

    return { success: true, message: "Insert successfully" };
  }


  return {
    CheifComplaintsAdd

  };
}

function updateCheifComplaintsRepository(fastify) {
  async function CheifComplaintsUpdate({ logTrace, body, params }) {
    const knex = this;
    const { id } = params;
    const query = await knex(`${CHEIFCOMPLAINTS.NAME}`)
      .where(`${CHEIFCOMPLAINTS.COLUMNS.ID}`, id)
      .update({
        [CHEIFCOMPLAINTS.COLUMNS.DOCTOR_ID]: body.doctor_id,
        [CHEIFCOMPLAINTS.COLUMNS.PATIENT_ID]: body.patient_id,
        [CHEIFCOMPLAINTS.COLUMNS.ISALLO_OR_AUYR]: body.isallo_or_auyr,
        [CHEIFCOMPLAINTS.COLUMNS.APPOINT_ID]: body.appoint_id,
        [CHEIFCOMPLAINTS.COLUMNS.ILLNESS_TYPE_ID]: body.illness_type_id,
        [CHEIFCOMPLAINTS.COLUMNS.CREATED_BY]: body.created_by
      });

    return { success: true, message: "Update successfully" };
  }

  return {
    CheifComplaintsUpdate,
  };
}

function getCheifComplaintsRepository(fastify) {
  
  async function CheifComplaintsGetAlls({ logTrace }) {
  
    const knex = this;
  
    const query = knex
    .select('e.doctor_id','e.patient_id','e.isallo_or_auyr','e.appoint_id','e.illness_type_id', 'i.illness_type_name')
    .from('e_cheif_complaints as e')
    .leftJoin('illness_types as i', 'e.illness_type_id', 'i.id');
  
  const response = await query;
  
    return response;
  }

  return {
    CheifComplaintsGetAlls
  };

}


function getCheifComplaintsRepositoryId(fastify) {
  
  async function CheifComplaintsGetOne({ logTrace, params }) {
    
    const knex = this;
    const { id } = params;
    const query = knex.select('*').from(`${CHEIFCOMPLAINTS.NAME}`).where(`${CHEIFCOMPLAINTS.COLUMNS.ID}`, id);
    logQuery({
      logger: fastify.log,
      query,
      context: "Get Cheif Complaints Details",
      logTrace
    });
    const response = await query;
    if (!response.length) {
      throw CustomError.create({
        httpCode: StatusCodes.NOT_FOUND,
        message: "Cheif Complaints info not found",
        property: "",
        code: "NOT_FOUND"
      });
    }
    return response;
  }

  return {
    CheifComplaintsGetOne
  };

}

function deleteCheifComplaintsRepositoryId(fastify) {
  async function CheifComplaintsDelete({
    logTrace,
    params
  }) {
    const knex = this;

    const { id } = params;

    const query = await knex(`${CHEIFCOMPLAINTS.NAME}`).where(`${CHEIFCOMPLAINTS.COLUMNS.ID}`, id)
      .del();

    const response = await query;

    return { success: true, message: "Deleted successfully" };
  }

  return {
    CheifComplaintsDelete
  };
}


module.exports = {
  postCheifComplaintsRepositoryBasic,
  updateCheifComplaintsRepository,
  getCheifComplaintsRepository,
  getCheifComplaintsRepositoryId,
  deleteCheifComplaintsRepositoryId

};
