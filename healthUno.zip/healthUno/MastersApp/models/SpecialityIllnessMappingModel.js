const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const IllnessTypes = require('../models/IllnessTypesModel');
const Specialities = require('../models/SpecialitiesModel');
const logger = require('../../config/activity_logger');


const SpecialityIllnessMapping = sequelize.define("speciality_illness_mapping", {
    speciality_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "speciality_id is required"
            }
        }
    },
    illness_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "illness_type_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });


SpecialityIllnessMapping.belongsTo(IllnessTypes, { foreignKey: 'illness_type_id' });
// SpecialityIllnessMapping.belongsTo(Specialities, {foreignKey:'speciality_id'});

SpecialityIllnessMapping.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'speciality_illness_mapping',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

SpecialityIllnessMapping.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'speciality_illness_mapping',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = SpecialityIllnessMapping;