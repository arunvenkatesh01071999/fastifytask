const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const ScanTestCategory = require('../../MastersApp/models/ScanTestMasterModel')

const ScanTestId = sequelize.define("scan_test_id", {
    test_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    category_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

ScanTestId.belongsTo(ScanTestCategory, { foreignKey: 'category_id' });

ScanTestId.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'scan_test_id',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

ScanTestId.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'scan_test_id',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = ScanTestId;