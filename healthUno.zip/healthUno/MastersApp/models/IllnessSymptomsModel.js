const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const IllnessTypes = require('../models/IllnessTypesModel');
const IllnessSymptomsMaster = require('../models/IllnessSymptomsMasterModel');
const logger = require('../../config/activity_logger');

const IllnessSymptoms = sequelize.define("illness_symptoms", {
    illness_symptom_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "illness_symptom_id is required"
            }
        }
    },
    illness_type_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "illness_type_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });


IllnessSymptoms.belongsTo(IllnessTypes, { foreignKey: 'illness_type_id' });
// IllnessSymptoms.belongsTo(IllnessSymptomsMaster,{foreignKey:'illness_symptom_id'});


IllnessSymptoms.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'illness_symptoms',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

IllnessSymptoms.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'illness_symptoms',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});



module.exports = IllnessSymptoms;