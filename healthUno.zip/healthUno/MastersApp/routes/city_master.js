const express = require('express');
const router = express();
const CityMasterController = require('../controller/CityController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, CityMasterController.FetchCity);
router.get('/:state_id', verify_token, CityMasterController.FetchByStateId);

module.exports = router;