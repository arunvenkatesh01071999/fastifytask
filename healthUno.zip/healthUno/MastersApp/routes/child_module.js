const express = require('express');
const router = express();
const ChildModuleController = require('../controller/ChildModuleController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ChildModuleController.FetchChildModules);
router.get('/:id', verify_token, ChildModuleController.FetchChildModules);
router.post('/', verify_token, ChildModuleController.NewChildModule);
router.put('/:id', verify_token, ChildModuleController.UpdateChildModule);
router.delete('/:id', verify_token, ChildModuleController.DeleteChildModule);

module.exports = router;