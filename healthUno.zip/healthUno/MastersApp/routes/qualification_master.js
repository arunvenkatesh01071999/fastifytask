const express = require('express');
const router = express();
const QualificationMasterController = require('../controller/QualificationMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, QualificationMasterController.FetchQualificationMasters);
router.get('/:id', verify_token, QualificationMasterController.FetchQualificationMasters);
router.post('/', verify_token, QualificationMasterController.NewQualificationMasters);
router.put('/:id', verify_token, QualificationMasterController.UpdateQualificationMasters);
router.delete('/:id', verify_token, QualificationMasterController.DeleteQualificationMasters);

module.exports = router;