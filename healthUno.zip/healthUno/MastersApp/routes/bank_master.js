const express = require('express');
const router = express();

const BankMasterController = require('../controller/BankMasterController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, BankMasterController.FetchBankMaster);
router.get('/:id', verify_token, BankMasterController.FetchBankMaster);
router.post('/', verify_token, BankMasterController.NewBankMaster);
router.put('/:id', verify_token, BankMasterController.UpdateBankMaster);
router.delete('/:id', verify_token, BankMasterController.DeleteBankMaster);

module.exports = router;