const express = require('express');
const router = express();
const MenuController = require('../controller/MenuController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, MenuController.FetchMenu);
router.get('/:id', verify_token, MenuController.FetchMenu);
router.post('/', verify_token, MenuController.NewMenu);
router.put('/:id', verify_token, MenuController.UpdateMenu);
router.delete('/:id', verify_token, MenuController.DeleteMenu);

module.exports = router;