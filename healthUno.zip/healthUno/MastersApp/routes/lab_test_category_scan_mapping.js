const express = require('express');
const router = express();
const LabTestCategoryScanMappingController = require('../controller/LabTestCategoryScanMappingController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, LabTestCategoryScanMappingController.FetchLabTestCategoryScanMapping);
router.get('/:lab_test_category_id', verify_token, LabTestCategoryScanMappingController.FetchLabTestCategoryScanMapping);
router.post('/', verify_token, LabTestCategoryScanMappingController.NewLabTestCategoryScanMapping);
router.put('/:id', verify_token, LabTestCategoryScanMappingController.UpdateLabTestCategoryScanMapping);
router.delete('/:id', verify_token, LabTestCategoryScanMappingController.DeleteLabTestCategoryScanMapping);

module.exports = router;