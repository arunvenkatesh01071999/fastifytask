// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const hospital_service_details_service = require('../services/hospital_services_detail_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');

// const FetchHospitalServiceDetails = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await hospital_service_details_service.GetbyRelationsId(id)  // servicesMaster fetch api
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         // data = await cache.GET(req.user.id + '_hospital_service_details');
//         // if (data) {
//         //     res.status(200).json(success_func(JSON.parse(data)))
//         // } else {
//         await hospital_service_details_service.GetbyRelations()
//             .then(data => {
//                 cache.SET(req.user.id + '_hospital_service_details', data)
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//         // }
//     }
// }

// const CreateHospitalServiceDetails = async (req, res, next) => {
//     const hospital_services_id = req.body.hospital_services_id;
//     const services_name = req.body.services_name;
//     const active = req.body.active;
//     const created_by = req.user.id;
//     const updated_by = req.user.id;

//     if (hospital_services_id && services_name && Array.isArray(services_name) && services_name.length > 0) {
//         // console.log(services_name);
//         for (const i of services_name) {
//             const h_data = {
//                 hospital_services_id: hospital_services_id,
//                 services_name: i,
//                 active: active,
//                 created_by: created_by,
//                 updated_by: updated_by
//             }
//             console.log(h_data)
//             hospital_service_details_service.CreateHospitalServiceDetails(h_data)
//         }
//         msg = "Created Successfully"
//         res.status(200).json(success_func(msg))


//     } else {
//         const msg = "hospital_services_id,services_name and active is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// // const UpdateHospitalServiceDetails = async (req, res, next) => {
// //     id = req.params.id;
// //     if (id) {
// //         const services_name = req.body.services_name;
// //         const active = req.body.active;
// //         const updated_by = req.user.id;
// //         const created_by = req.user.id;
// //         const updated_at = date();

// //         if (id && services_name && Array.isArray(services_name) && services_name.length > 0) {

// //             hospital_service_details_service.DestroyHospitalServiceMap(id);
// //             for (const i of services_name) {
// //                 const h_data = {
// //                     hospital_services_id: id,
// //                     services_name: i,
// //                     active: active,
// //                     created_by: created_by,
// //                     updated_by: updated_by,
// //                     updated_at: updated_at
// //                 }
// //                 console.log(h_data)
// //                 hospital_service_details_service.CreateHospitalServiceDetails(h_data)
// //             }
// //             msg = "Updated Successfully"
// //             res.status(200).json(success_func(msg))


// //         } else {
// //             const msg = "hospital_services_id,services_name and active is required";
// //             res.status(400).json(failure_func(msg))
// //         }
// //     } else {
// //         msg = "ID is required";
// //         res.status(400).json(failure_func(msg))
// //     }
// // }

// // const UpdateHospitalServiceDetails = async (req, res, next) => {
// //     hospital_services_id = req.params.hospital_services_id;
// //     if (hospital_services_id) {
// //         const hospital_services_id = req.body.hospital_services_id;
// //         const services_name = req.body.services_name;
// //         const active = req.body.active;
// //         const updated_by = req.user.id;
// //         const created_by = req.user.id;
// //         const updated_at = date();

// //         if (hospital_services_id && services_name && Array.isArray(services_name) && services_name.length > 0) {

// //             hospital_service_details_service.DestroyHospitalServiceMap(hospital_services_id);
// //             for (const i of services_name) {
// //                 const h_data = {
// //                     hospital_services_id: hospital_services_id,
// //                     services_name: i,
// //                     active: active,
// //                     created_by: created_by,
// //                     updated_by: updated_by,
// //                     updated_at: updated_at
// //                 }
// //                 console.log(h_data)
// //                 hospital_service_details_service.CreateHospitalServiceDetails(h_data)
// //             }
// //             msg = "Updated Successfully"
// //             res.status(200).json(success_func(msg))


// //         } else {
// //             const msg = "hospital_services_id,service_name and active is required";
// //             res.status(400).json(failure_func(msg))
// //         }
// //     } else {
// //         msg = "ID is required";
// //         res.status(400).json(failure_func(msg))
// //     }
// // }
// const UpdateHospitalServiceDetails = async (req, res, next) => {
//     hospital_services_id = req.params.hospital_services_id;
//     if (hospital_services_id) {

//         const hospital_services_id = req.body.hospital_services_id;
//         const services_name = req.body.services_name;
//         const active = req.body.active;
//         const updated_by = req.user.id;
//         const created_by = req.user.id;
//         const updated_at = date();

//         if (hospital_services_id && services_name && Array.isArray(services_name) && services_name.length > 0) {
//             let results = [];
//                 console.log("if for.........");
//             hospital_service_details_service.DestroyHospitalServiceMap(hospital_services_id);
//             for (const i of services_name) {
//                 const h_data = {
//                     hospital_services_id: hospital_services_id,
//                     services_name: i,
//                     active: active,
//                     created_by: created_by,
//                     updated_by: updated_by,
//                     updated_at: updated_at
//                 }
//                 console.log(h_data)
//                 try {


//                     const data = await hospital_service_details_service.CreateHospitalServiceDetails(h_data);
//                     if (data.errors) {
//                         results.push({
//                             service: i, 
//                             status: 'failed', 
//                             reason: data.errors[0].message
//                         });
//                     } else {
//                         results.push({
//                             service: i, 
//                             status: 'success', 
//                             message: 'Updated Successfully'
//                         });
//                     }
//                 } catch (err) {
//                     results.push({
//                         service: i, 
//                         status: 'failed', 
//                         reason: err.message
//                     });
//                 }
//             }
//             res.status(200).json(results);

//             }

//         else {
//             msg = "hospital_services_id,service_name and active is required"
//             res.status(400).json(failure_func(msg))
//         }
//     } 
//     else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }

// }

// const DeleteHospitalServiceDetails = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await hospital_service_details_service.DestroyHospitalServiceMap(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_hospital_service_details')
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// module.exports = {
//     CreateHospitalServiceDetails,
//     UpdateHospitalServiceDetails,
//     FetchHospitalServiceDetails,
//     DeleteHospitalServiceDetails
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const hospital_service_details_service = require('../services/hospital_services_detail_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchHospitalServiceDetails = async (req, res, next) => {
    const hospital_services_id = req.params.hospital_services_id;
    if (hospital_services_id) {
        await hospital_service_details_service.GetbyRelationsId(hospital_services_id)  // servicesMaster fetch api
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {

        await hospital_service_details_service.GetbyRelations()
            .then(data => {
                // cache.SET(req.user.id + '_hospital_service_details', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })

    }
}

const CreateHospitalServiceDetails = async (req, res, next) => {
    const hospital_services_id = req.body.hospital_services_id;
    const services_name = req.body.services_name;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;

    if (hospital_services_id && services_name && Array.isArray(services_name) && services_name.length > 0) {

        for (const i of services_name) {
            const h_data = {
                hospital_services_id: hospital_services_id,
                services_name: i,
                active: active,
                created_by: created_by,
                updated_by: updated_by
            }
            console.log(h_data)
            hospital_service_details_service.CreateHospitalServiceDetails(h_data)
        }
        msg = "Created Successfully"
        res.status(200).json(success_func(msg))


    } else {
        const msg = "hospital_services_id,services_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateHospitalServiceDetails = async (req, res, next) => {
    hospital_services_id = req.params.hospital_services_id;
    if (hospital_services_id) {

        const hospital_services_id = req.body.hospital_services_id;
        const services_name = req.body.services_name;
        const active = req.body.active;
        const updated_by = req.user.id;
        const created_by = req.user.id;
        const updated_at = date();
        hospital_service_details_service.DestroyHospitalServiceMap(hospital_services_id);
        if (hospital_services_id && services_name && Array.isArray(services_name) && services_name.length > 0) {

            //  hospital_service_details_service.DestroyHospitalServiceMap(hospital_services_id);
            for (const i of services_name) {
                const h_data = {
                    hospital_services_id: hospital_services_id,
                    services_name: i,
                    active: active,
                    created_by: created_by,
                    updated_by: updated_by,
                    updated_at: updated_at
                }
                console.log(h_data)
                await hospital_service_details_service.CreateHospitalServiceDetails(h_data)
            }

            msg = 'Updated Successfully'
            res.status(200).json(success_func(msg))

        }

        else {
            msg = "hospital_services_id,service_name and active is required"
            res.status(400).json(failure_func(msg))
        }
    }
    else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }

}

const DeleteHospitalServiceDetails = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await hospital_service_details_service.DestroyHospitalServiceMap(id)
            .then(data => {
                if (data == 1) {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "Deleted successfully"
                    // cache.DEL(req.user.id + '_hospital_service_details')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    CreateHospitalServiceDetails,
    UpdateHospitalServiceDetails,
    FetchHospitalServiceDetails,
    DeleteHospitalServiceDetails
}