const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const city_services = require('../services/city_service');
const cache = require('../../services/redis_cache_service');


const FetchCity = async (req, res, next) => {
    // id = req.params.id;
    // if (id) {
    //     await city_services.GetbyId(id)
    //         .then(data => {
    //             res.status(200).json(success_func(data))
    //         })
    //         .catch(err => {
    //             res.status(400).json(failure_func(err))
    //         })
    // } else {
    data = await cache.GET(req.user.id + '_city_services');
    if (data) {
        res.status(200).json(success_func(JSON.parse(data)))
    } else {
        await city_services.Get()
            .then(data => {
                cache.SET(req.user.id + '_city_services', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const FetchByStateId = async (req, res, next) => {
    state_id = req.params.state_id;
    if (state_id) {
        await city_services.FetchByStateId(state_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(500).json(failure_func(err))
            })
    } else {

        msg = "ID Not found";
        res.status(401).json(failure_func(msg))

    }
}

module.exports = {
    FetchCity,
    FetchByStateId
}