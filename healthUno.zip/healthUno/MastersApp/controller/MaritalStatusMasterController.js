const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const marital_status_master_service = require('../services/marital_status_master_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchMaritalSatatus = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await marital_status_master_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        //data = await cache.GET(req.user.id + '_hospital_type_master');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await marital_status_master_service.Get()
            .then(data => {
                //cache.SET(req.user.id + '_hospital_type_master', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        //}
    }
}

const NewMaritalSatatus = async (req, res, next) => {
    m_name = req.body.m_name;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (m_name) {
        ms_data = {
            m_name: m_name,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await marital_status_master_service.GetbyName(m_name)
            .then(marital_status_data => {
                if (marital_status_data.length > 0) {
                    msg = "Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    marital_status_master_service.createMaritalStatus(ms_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                //cache.DEL(req.user.id + '_hospital_type_master')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "m_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateMaritalSatatus = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        m_name = req.body.m_name;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (m_name) {
            ms_data = {
                m_name: m_name,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }

            marital_status_master_service.UpdateMaritalSatatus(id, ms_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        //cache.DEL(req.user.id + '_hospital_type_master')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        } else {
            msg = "fees_type_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteMaritalSatatus = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await marital_status_master_service.DestroyMaritalSatatus(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewMaritalSatatus,
    FetchMaritalSatatus,
    UpdateMaritalSatatus,
    DeleteMaritalSatatus
}