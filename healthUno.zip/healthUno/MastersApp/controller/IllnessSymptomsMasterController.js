const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const illness_symptom_master_services = require('../services/illness_symptom_master_service');
const illness_symptoms_services = require('../services/illness_symptoms_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchIllnessSymptomsMasters = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await illness_symptom_master_services.GetbyRelationsId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_illness_symptom_master');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await illness_symptom_master_services.GetbyRelations()
                .then(data => {
                    // cache.SET(req.user.id + '_illness_symptom_master', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewIllnessSymptomsMaster = async (req, res, next) => {
    console.log(req.files, "filesdd");
    illness_symptom_name = req.body.illness_symptom_name;
    illness_type_id = req.body.illness_type_ids;
    illness_type_ids = illness_type_id.split(',');
    logo_image = req.files.logo_image;

    console.log('s', logo_image);

    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (illness_symptom_name && illness_type_ids && Array.isArray(illness_type_ids)) {

        sm_data = {
            illness_symptom_name: illness_symptom_name,
            logo_image: logo_image,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        if (logo_image) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = logo_image.name;
            const buffer = logo_image.data;
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Upload the image to GCS
            await file.save(buffer);

            sm_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
        } else {
            sm_data.logo_image = null; // Set logo_image to null if not provided
        }
        console.log(logo_image, "logo_imagesss");
        //Check Duplicate values

        await illness_symptom_master_services.GetbyName(illness_symptom_name)
            .then(symptom_data => {
                if (symptom_data.length > 0) {
                    msg = "Symptom Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    //insert portion
                    illness_symptom_master_services.CreateIllnessSymptomsMaster(sm_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                symptompsdata = data.dataValues;
                                sysmid = symptompsdata.id;
                                if (illness_type_ids && Array.isArray(illness_type_ids) && illness_type_ids.length > 0) { // Use Array.isArray() to check if illness_type_ids is an array
                                    for (const i of illness_type_ids) { // Use for...of loop
                                        const nt_data = {
                                            illness_symptom_id: sysmid,
                                            illness_type_id: parseInt(i),
                                            active: true,
                                            created_by: created_by,
                                            updated_by: updated_by
                                        }
                                        illness_symptoms_services.CreateIllnessSymptom(nt_data);
                                    }
                                }

                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_illness_symptom_master') // Check cache implementation
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                    //END insert portion
                }
            })
    } else {
        // msg = "illness_symptom_name and active is required";
        msg = "illness_symptom_name, illness_type_ids and active is required and illness_type_ids should be an array";
        res.status(400).json(failure_func(msg))
    }
}

// const UpdateIllnessSymptomsMaster = async (req, res, next) => {
//     const id = req.params.id;
//     if (id) {

//         illness_symptom_name = req.body.illness_symptom_name;
//         const illness_type_id = req.body.illness_type_ids;
//         const illness_type_ids = illness_type_id.split(',');
//         active = req.body.active;
//         const created_by = req.user.id;
//         const updated_by = req.user.id;
//         const updated_at = date();
//         // logo_image = req.files.logo_image;
//         try {
//             logo_image = req.files.logo_image;
//         } catch {
//             logo_image = null
//         }

//         console.log('logo_image', logo_image);
//         if (illness_symptom_name) {
//             sm_data = {
//                 illness_symptom_name: illness_symptom_name,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             if (logo_image) {
//                 const bucketName = process.env.GCP_BUCKET_NAME;
//                 const fileName = logo_image.name;
//                 const buffer = logo_image.data;
//                 const path = `images/${fileName}`;

//                 const file = storage.bucket(bucketName).file(path);

//                 // Upload the image to GCS
//                 await file.save(buffer);

//                 sm_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;
//             } else {
//                 sm_data.logo_image = null; // Set logo_image to null if not provided
//             }

//             // await illness_symptom_master_services.GetbyName(illness_symptom_name)
//             //     .then(symptom_data => {
//             //         if (symptom_data.length > 0) {
//             //             msg = "Symptom Name already exists";
//             //             return res.status(200).json(failure_func(msg))
//             //         } else {
//             illness_symptom_master_services.UpdateIllnessSymptomsMaster(id, sm_data)
//                 .then(data => {
//                     if (data == 1) {

//                         if (illness_type_ids && Array.isArray(illness_type_ids)) { // Use Array.isArray() to check if illness_type_ids is an array
//                             illness_symptoms_services.DestroyIllnessSymptombymap(id);
//                             console.log(illness_type_ids);
//                             for (const i of illness_type_ids) { // Use for...of loop
//                                 const nt_data = {
//                                     illness_symptom_id: id,
//                                     illness_type_id: parseInt(i),
//                                     active: true,
//                                     created_by: created_by,
//                                     updated_by: updated_by
//                                 }
//                                 console.log(nt_data);
//                                 illness_symptoms_services.CreateIllnessSymptom(nt_data);

//                             }
//                         }

//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_illness_symptom_master')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//             //     }
//             // })

//         } else {
//             msg = "illness_symptom_name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }

// }

const UpdateIllnessSymptomsMaster = async (req, res, next) => {
    const id = req.params.id;
    if (id) {
        illness_symptom_name = req.body.illness_symptom_name;
        illness_type_id = req.body.illness_type_ids;
        illness_type_ids = illness_type_id.split(',');
        active = req.body.active;
        created_by = req.user.id;
        updated_by = req.user.id;
        updated_at = date();

        // try {
        //     logo_image = req.files.logo_image;
        // } catch {
        //     logo_image = req.body.logo_image;
        // }
        if (req.files && req.files.logo_image && req.files.logo_image.name) {
            logo_image = req.files.logo_image;
        } else {

            logo_image = req.body.logo_image;
        }

        console.log('logo_image', logo_image);

        if (illness_symptom_name) {
            sm_data = {
                illness_symptom_name: illness_symptom_name,
                logo_image: logo_image,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            };
            if (typeof logo_image === "string") {
                sm_data.logo_image = logo_image;
            }
            else {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = logo_image.name;
                const buffer = logo_image.data;
                const path = `images/${fileName}`;

                const file = storage.bucket(bucketName).file(path);

                // Upload the image to GCS
                await file.save(buffer);

                sm_data.logo_image = `https://storage.googleapis.com/${bucketName}/${path}`;

            }

            illness_symptom_master_services.UpdateIllnessSymptomsMaster(id, sm_data)
                .then(data => {
                    if (data == 1) {
                        if (illness_type_ids && Array.isArray(illness_type_ids)) {
                            illness_symptoms_services.DestroyIllnessSymptombymap(id);
                            console.log(illness_type_ids);
                            for (const i of illness_type_ids) {
                                const nt_data = {
                                    illness_symptom_id: id,
                                    illness_type_id: parseInt(i),
                                    active: true,
                                    created_by: created_by,
                                    updated_by: updated_by
                                };
                                console.log(nt_data);
                                illness_symptoms_services.CreateIllnessSymptom(nt_data);
                            }
                        }

                        msg = "Updated successfully";
                        cache.DEL(req.user.id + '_illness_symptom_master');
                        res.status(200).json(success_func(msg));
                    } else {
                        msg = "ID doesn't exist";
                        res.status(400).json(failure_func(msg));
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err));
                });
        } else {
            msg = "illness_symptom_name and active are required";
            res.status(400).json(failure_func(msg));
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg));
    }
};

const DeleteIllnessSymptomsMaster = async (req, res, next) => {
    try {
        const id = req.params.id;

        if (!id) {
            const msg = "ID is required";
            return res.status(400).json(failure_func(msg));
        }

        // Fetch insurance data by ID
        const symptomsdata = await illness_symptom_master_services.GetbyId(id);

        if (!symptomsdata) {
            const msg = "ID doesn't exist";
            return res.status(400).json(failure_func(msg));
        }

        // Delete the image from GCS
        if (symptomsdata.logo_image) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = symptomsdata.logo_image.split('/').pop(); // Extract file name from URL
            const path = `images/${fileName}`;

            const file = storage.bucket(bucketName).file(path);

            // Delete the image from GCS
            await file.delete();
        }

        // Delete insurance entry
        const deletedRows = await illness_symptom_master_services.DestroyIllnessSymptomsMaster(id);

        if (deletedRows === 1) {
            const msg = "Deleted successfully";
            cache.DEL(req.user.id + '_illness_symptom_master_services');
            res.status(200).json(success_func(msg));
        } else {
            const msg = "Failed to delete. ID may not exist";
            res.status(400).json(failure_func(msg));
        }
    } catch (err) {
        const msg = err.message || "An error occurred";
        res.status(400).json(failure_func(msg));
    }
};


module.exports = {
    NewIllnessSymptomsMaster,
    FetchIllnessSymptomsMasters,
    UpdateIllnessSymptomsMaster,
    DeleteIllnessSymptomsMaster
}