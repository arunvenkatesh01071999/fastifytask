// const success_func = require('../../api_responser').success_func;
// const failure_func = require('../../api_responser').failure_func;
// const date = require('../../services/datetime_service');
// const menu_service = require('../services/menu_service');
// const logger = require('../../config/logger');
// const cache = require('../../services/redis_cache_service');
// const fs = require('fs');

// const FetchMenu = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await menu_service.GetbyId(id)
//             .then(data => {
//                 res.status(200).json(success_func(data))
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         data = await cache.GET(req.user.id + '_menu_service');
//         if (data) {
//             res.status(200).json(success_func(JSON.parse(data)))
//         } else {
//             await menu_service.Get()
//                 .then(data => {
//                     cache.SET(req.user.id + '_menu_service', data)
//                     res.status(200).json(success_func(data))
//                 })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         }
//     }
// }

// const NewMenu = async (req, res, next) => {
//     menu_name = req.body.menu_name;
//     menu_url = req.body.menu_url;
//     menu_icon = req.body.menu_icon;
//     module_id = req.body.module_id;
//     order = req.body.order_row;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;

//     if (menu_name) {
//         a_data = {
//             menu_name: menu_name,
//             menu_url: menu_url,
//             menu_icon: menu_icon,
//             order_row: order,
//             module_id: module_id,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         await menu_service.GetbyName(menu_name)
//             .then(submenu_data => {
//                 if (submenu_data.length > 0) {
//                     msg = " Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     menu_service.Createmenu(a_data)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_menu_service')
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     }
//     else {
//         msg = "Name and active is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateMenu = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         menu_name = req.body.menu_name;
//         menu_url = req.body.menu_url;
//         menu_icon = req.body.menu_icon;
//         module_id = req.body.module_id;
//         order = req.body.order_row;
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (menu_name) {
//             a_data = {
//                 menu_name: menu_name,
//                 menu_url: menu_url,
//                 menu_icon: menu_icon,
//                 order_row: order,
//                 module_id: module_id,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             // await menu_service.GetbyName(accredation_name)
//             //     .then(accredation_data => {
//             //         if (accredation_data.length > 0) {
//             //             msg = " Name already exists";
//             //             return res.status(200).json(failure_func(msg))
//             //         } else {
//             menu_service.UpdateMenu(id, a_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_menu_service')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 //     }
//                 // })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         } else {
//             msg = "Name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const DeleteMenu = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await menu_service.DestroyMenu(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_menu_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


// module.exports = {
//     NewMenu,
//     FetchMenu,
//     UpdateMenu,
//     DeleteMenu
// }

const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const menu_service = require('../services/menu_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const { Storage } = require('@google-cloud/storage');
const storage = new Storage();

const FetchMenu = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await menu_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_menu_service');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await menu_service.Get()
            .then(data => {
                cache.SET(req.user.id + '_menu_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        // }
    }
}

const NewMenu = async (req, res, next) => {
    menu_name = req.body.menu_name;
    menu_url = req.body.menu_url;
    // try{
    //     menu_icon = req.files.menu_icon;
    //     sub_icon = req.files.sub_icon;
    // }
    // //menu_icon = req.body.menu_icon;
    // catch{
    //     menu_icon = null
    //     sub_icon = null
    // }
    let menu_icon = req.files ? req.files.menu_icon : null;
    let sub_icon = req.files ? req.files.sub_icon : null;
    module_id = req.body.module_id;
    order = req.body.order_row;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (menu_name) {
        a_data = {
            menu_name: menu_name,
            menu_url: menu_url,
            menu_icon: menu_icon,
            sub_icon: sub_icon,
            order_row: order,
            module_id: module_id,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        // if(menu_icon){
        //     a_data.menu_icon = menu_icon.name;
        //     buffer = menu_icon.data
        //     path = './media/'+ menu_icon.name
        //     fs.writeFile(path.toString(), buffer, function (err){
        //         if (err) {
        //             return console.log(err);
        //         }
        //     });
        // }
        if (menu_icon) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = menu_icon.name;
            const buffer = menu_icon.data;
            const path = `images/${fileName}`;
            const file = storage.bucket(bucketName).file(path);
            await file.save(buffer);
            a_data.menu_icon = `https://storage.googleapis.com/${bucketName}/${path}`;
        }
        else {
            a_data.menu_icon = null;
        }
        // if(sub_icon){
        //     a_data.sub_icon = sub_icon.name;
        //     buffer = sub_icon.data
        //     path = './media/'+ sub_icon.name
        //     fs.writeFile(path.toString(), buffer, function (err){
        //         if (err) {
        //             return console.log(err);
        //         }
        //     });
        // }
        if (sub_icon) {
            const bucketName = process.env.GCP_BUCKET_NAME;
            const fileName = sub_icon.name;
            const buffer = sub_icon.data;
            const path = `images/${fileName}`;
            const file = storage.bucket(bucketName).file(path);
            await file.save(buffer);
            a_data.sub_icon = `https://storage.googleapis.com/${bucketName}/${path}`;
        }
        else {
            a_data.sub_icon = null;
        }
        await menu_service.GetbyName(menu_name)
            .then(submenu_data => {
                if (submenu_data.length > 0) {
                    msg = " Name already exists";
                    return res.status(200).json(failure_func(msg))
                } else {
                    menu_service.Createmenu(a_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully"
                                cache.DEL(req.user.id + '_menu_service')
                                res.status(200).json(success_func(msg))
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    }
    else {
        msg = "Name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateMenu = async (req, res, next) => {
    id = req.params.id;
    let menu_icon = req.files ? req.files.menu_icon : null;
    let sub_icon = req.files ? req.files.sub_icon : null;
    menu_name = req.body.menu_name;
    if (id) {
        if (menu_name) {
            menu_url = req.body.menu_url;
            module_id = req.body.module_id;
            order = req.body.order_row;
            active = req.body.active;
            updated_by = req.user.id;
            updated_at = date();
            a_data = {
                menu_name: menu_name,
                menu_url: menu_url,
                order_row: order,
                module_id: module_id,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            // if (menu_icon && menu_icon != 'undefined') {
            //     menu_icon_data = menu_icon
            // }
            // else {
            // menu_icon = req.files.menu_icon;
            // if (menu_icon) {
            //     menu_icon_data = menu_icon.name;
            //     buffer = menu_icon.data
            //     path = './media/' + menu_icon.name;
            //     fs.writeFile(path.toString(), buffer, function (err) {
            //         if (err) {
            //             return console.log(err);
            //         }
            //     });
            // }
            // let menu_icon = req.files ? req.files.menu_icon : null;
            if (menu_icon) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = menu_icon.name;
                const buffer = menu_icon.data;
                const path = `images/${fileName}`;
                const file = storage.bucket(bucketName).file(path);
                await file.save(buffer);
                a_data.menu_icon = `https://storage.googleapis.com/${bucketName}/${path}`;
            }
            // else {
            //     a_data.menu_icon = null;
            // }
            // }
            // if (sub_icon && sub_icon != 'undefined') {
            //     sub_icon_data = sub_icon
            // }
            // else {
            // sub_icon = req.files.sub_icon;
            // if (sub_icon) {
            //     sub_icon_data = sub_icon.name;
            //     buffer = sub_icon.data
            //     path = './media/' + sub_icon.name;
            //     fs.writeFile(path.toString(), buffer, function (err) {
            //         if (err) {
            //             return console.log(err);
            //         }
            //     });
            // }
            if (sub_icon) {
                const bucketName = process.env.GCP_BUCKET_NAME;
                const fileName = sub_icon.name;
                const buffer = sub_icon.data;
                const path = `images/${fileName}`;
                const file = storage.bucket(bucketName).file(path);
                await file.save(buffer);
                a_data.sub_icon = `https://storage.googleapis.com/${bucketName}/${path}`;
            }
            // else {
            //     a_data.sub_icon = null;
            // }
            // }
            await menu_service.UpdateMenu(id, a_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        // cache.DEL(req.user.id + '_menu_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        else {
            msg = "Name and active is required";
            res.status(400).json(failure_func(msg))
        }
    }
    else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

// const NewMenu = async (req, res, next) => {
//     menu_name = req.body.menu_name;
//     menu_url = req.body.menu_url;
//     try{
//         menu_icon = req.files.menu_icon;
//         sub_icon = req.files.sub_icon;
//     }
//     //menu_icon = req.body.menu_icon;
//     catch{
//         menu_icon = null
//         sub_icon = null
//     }
//     module_id = req.body.module_id;

//     order = req.body.order_row;
//     active = req.body.active;
//     created_by = req.user.id;
//     updated_by = req.user.id;

//     if (menu_name) {
//         a_data = {
//             menu_name: menu_name,
//             menu_url: menu_url,
//             menu_icon: menu_icon,
//             sub_icon: sub_icon,
//             order_row: order,
//             module_id: module_id,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
//         if(menu_icon){
//             a_data.menu_icon = menu_icon.name;
//             buffer = menu_icon.data
//             path = './media/'+ menu_icon.name
//             fs.writeFile(path.toString(), buffer, function (err){
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         if(sub_icon){
//             a_data.sub_icon = sub_icon.name;
//             buffer = sub_icon.data
//             path = './media/'+ sub_icon.name
//             fs.writeFile(path.toString(), buffer, function (err){
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//         await menu_service.GetbyName(menu_name)
//             .then(submenu_data => {
//                 if (submenu_data.length > 0) {
//                     msg = " Name already exists";
//                     return res.status(200).json(failure_func(msg))
//                 } else {
//                     menu_service.Createmenu(a_data)
//                         .then(data => {
//                             if (data.errors) {
//                                 msg = data.errors[0].message;
//                                 res.status(400).json(failure_func(msg))
//                             } else {
//                                 msg = "Created Successfully"
//                                 cache.DEL(req.user.id + '_menu_service')
//                                 res.status(200).json(success_func(msg))
//                             }
//                         })
//                         .catch(err => {
//                             res.status(400).json(failure_func(err))
//                         })
//                 }
//             })
//     }
//     else {
//         msg = "Name and active is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

// const UpdateMenu = async (req, res, next) => {
//     id = req.params.id;
//     menu_icon = req.body.menu_icon
//     sub_icon = req.body.sub_icon
//     if (id) {
//         menu_name = req.body.menu_name;
//         menu_url = req.body.menu_url;
//         if (menu_icon && menu_icon != 'undefined') {
//             menu_icon_data = menu_icon
//         }
//         else {
//             menu_icon = req.files.menu_icon;
//             if (menu_icon) {
//                 menu_icon_data = menu_icon.name;
//                 buffer = menu_icon.data
//                 path = './media/' + menu_icon.name;
//                 fs.writeFile(path.toString(), buffer, function (err) {
//                     if (err) {
//                         return console.log(err);
//                     }
//                 });
//             }
//         }
//        // menu_icon = req.body.menu_icon;
//        if (sub_icon && sub_icon != 'undefined') {
//         sub_icon_data = sub_icon
//     }
//     else {
//         sub_icon = req.files.sub_icon;
//         if (sub_icon) {
//             sub_icon_data = sub_icon.name;
//             buffer = sub_icon.data
//             path = './media/' + sub_icon.name;
//             fs.writeFile(path.toString(), buffer, function (err) {
//                 if (err) {
//                     return console.log(err);
//                 }
//             });
//         }
//     }
//         module_id = req.body.module_id;
//         order = req.body.order_row;
//         active = req.body.active;
//         updated_by = req.user.id;
//         updated_at = date();
//         if (menu_name) {
//             a_data = {
//                 menu_name: menu_name,
//                 menu_url: menu_url,
//                 menu_icon: menu_icon_data,
//                 sub_icon: sub_icon_data,
//                 order_row: order,
//                 module_id: module_id,
//                 active: active,
//                 updated_by: updated_by,
//                 updated_at: updated_at
//             }
//             // await menu_service.GetbyName(accredation_name)
//             //     .then(accredation_data => {
//             //         if (accredation_data.length > 0) {
//             //             msg = " Name already exists";
//             //             return res.status(200).json(failure_func(msg))
//             //         } else {
//             menu_service.UpdateMenu(id, a_data)
//                 .then(data => {
//                     if (data == 1) {
//                         msg = "Updated successfully"
//                         cache.DEL(req.user.id + '_menu_service')
//                         res.status(200).json(success_func(msg))
//                     } else {
//                         msg = "ID doesn't exist"
//                         res.status(400).json(failure_func(msg))
//                     }
//                 })
//                 //     }
//                 // })
//                 .catch(err => {
//                     res.status(400).json(failure_func(err))
//                 })
//         } else {
//             msg = "Name and active is required";
//             res.status(400).json(failure_func(msg))
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const DeleteMenu = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await menu_service.DestroyMenu(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_menu_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewMenu,
    FetchMenu,
    UpdateMenu,
    DeleteMenu
}