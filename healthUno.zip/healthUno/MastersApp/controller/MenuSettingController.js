const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const menusetting_service = require('../../MastersApp/services/menusetting_service')
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');

const FetchRole = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await menusetting_service.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }

}
const FetchUser = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await menusetting_service.GetbyUserId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }

}
const FetchAllData = async (req, res, next) => {
    roll_id = req.params.Rollid;
    user_id = req.params.userid;
    if (user_id) {
        await menusetting_service.GetbyAllData(roll_id, user_id)
            .then(data => {
                // console.log(data,'sddd');
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }

}

const updatemenu = async (req, res, next) => {

    roll_id = req.body.roll_id;
    user_id = req.body.user_id;
    module_id = req.body.module_id;
    id = req.body.id;
    m_id = req.body.m_id;
    value = req.body.value;
    updated_by = req.user.id;
    updated_at = date();
    if (user_id) {
        const submenuexist = await menusetting_service.updatemenu(roll_id, user_id, id, m_id, module_id);
        if (submenuexist.length > 0 && value === 0) {
            await menusetting_service.destroymenu(roll_id, user_id, id, m_id, module_id)
                .then(data => {
                    if (data == 1) {
                        msg = "Deleted successfully"
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(200).json(success_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        } else if (submenuexist.length === 0 && value === 1) {
            const insertData = {
                submenu_id: parseInt(id),
                menu_id: parseInt(m_id),
                user_id: parseInt(user_id),
                role_id: parseInt(roll_id),
                module_id: parseInt(module_id),
                value: parseInt(value),
                created_by: req.user.id,
                updated_by: updated_by

            };

            await menusetting_service.Createmenu(insertData)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                        res.status(400).json(failure_func(msg))
                    } else {

                        data.msg = "Created Successfully"
                        res.status(200).json(success_func(data))
                    }
                })
        }
    }
}

const loaddashboard = async (req, res, next) => {
    roll_id = req.body.roll_id;
    user_id = req.body.user_id;
    if (user_id) {
         menusetting_service.loaddashboardservices(roll_id, user_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }

}

module.exports = {
    FetchRole,
    FetchUser,
    FetchAllData,
    updatemenu,
    loaddashboard
}