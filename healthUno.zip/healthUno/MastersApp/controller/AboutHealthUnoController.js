const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const about_healthuno_services = require('../services/about_healthuno_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchAboutHealthUnos = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await about_healthuno_services.GetbyId(id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_about_healthuno');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await about_healthuno_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_about_healthuno', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

// const NewAboutHealthUno = async (req, res, next) => {
//     const { healthuno_content, healthuno_title, active } = req.body
//     created_by = req.user.id;
//     updated_by = req.user.id;
//     if (healthuno_content) {
//         a_data = {
//             healthuno_content: healthuno_content.trim(),
//             healthuno_title: healthuno_title,
//             active: active,
//             created_by: created_by,
//             updated_by: updated_by
//         }
        
//         await about_healthuno_services.CreateAboutHealthUno(a_data)
//             .then(data => {
//                 console.log("sdfghjkl", data);
//                 if (data.errors) {
//                     msg = data.errors[0].message;
//                     res.status(401).json(failure_func(msg))
//                 } else {
//                     msg = "Created Successfully"
//                     cache.DEL(req.user.id + '_about_healthuno')
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(msg => {
//                 msg = "Healthuno is required";
//                 res.status(400).json(failure_func(msg))
//             })
//     } else {
//         msg = "Healthuno_content and active is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const NewAboutHealthUno = async (req, res, next) => {
    const { healthuno_content, healthuno_title, active } = req.body
    created_by = req.user.id;
    updated_by = req.user.id;
    const  healthuno_content_result=healthuno_content.trim().replace(/\s+/g, ' ');
    if (healthuno_content_result) {
        a_data = {
            healthuno_content: healthuno_content_result,
            healthuno_title: healthuno_title,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        await about_healthuno_services.CreateAboutHealthUno(a_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(401).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_about_healthuno')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(msg => {
                msg = "Healthuno is required";
                res.status(400).json(failure_func(msg))
            })
    } else {
        msg = "Healthuno_content and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateAboutHealthUno = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        const { healthuno_content, healthuno_title, active } = req.body
        updated_by = req.user.id;
        updated_at = date();
        if (healthuno_content) {
            a_data = {
                healthuno_content: healthuno_content,
                healthuno_title: healthuno_title,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await about_healthuno_services.UpdateAboutHealthUno(id, a_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_about_healthuno')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "healthuno_content and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteAboutHealthUno = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await about_healthuno_services.DestroyAboutHealthUno(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_about_healthuno')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewAboutHealthUno,
    FetchAboutHealthUnos,
    UpdateAboutHealthUno,
    DeleteAboutHealthUno
}