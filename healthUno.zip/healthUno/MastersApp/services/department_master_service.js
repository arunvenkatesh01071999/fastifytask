const DepartmentMaster = require('../models/DepartmentMasterModel');

const Get = async () => {
    await DepartmentMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await DepartmentMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await DepartmentMaster.findAll({ where: { department_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}


const CreateDepartmentMaster = async (dm_data) => {
    await DepartmentMaster.create(dm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateDepartmentMaster = async (id, dm_data) => {
    await DepartmentMaster.update(dm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyDepartmentMaster = async (id) => {
    await DepartmentMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    GetbyName,
    CreateDepartmentMaster,
    UpdateDepartmentMaster,
    DestroyDepartmentMaster
};
