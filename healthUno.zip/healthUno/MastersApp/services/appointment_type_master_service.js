const AppointmentTypeMaster = require('../models/AppointmentTypesModel');

const Get = async () => {
    await AppointmentTypeMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await AppointmentTypeMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await AppointmentTypeMaster.findAll({ where: { appointment_type_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateAppointmentType = async (am_data) => {
    await AppointmentTypeMaster.create(am_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateAppointmentType = async (id, am_data) => {
    await AppointmentTypeMaster.update(am_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyAppointmentType = async (id) => {
    await AppointmentTypeMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateAppointmentType,
    UpdateAppointmentType,
    DestroyAppointmentType,
    GetbyName
};
