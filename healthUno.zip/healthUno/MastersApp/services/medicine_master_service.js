const MedicineMaster = require('../models/MedicineMasterModel');
const MedicineIllnessMapping = require('../models/MedicineIllnessMappingModel');
const IllnessTypes = require('../models/IllnessTypesModel');

const Get = async () => {
    let res;
    await MedicineMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    let res;
    await MedicineMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyName = async (name) => {
    let res;
    await MedicineMaster.findAll({ where: { medicine_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateMedicine = async (m_data) => {
    let res;
    await MedicineMaster.create(m_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateMedicine = async (id, m_data) => {
    let res;
    await MedicineMaster.update(m_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyMedicine = async (id) => {
    let res;
    await MedicineMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const GetbyRelations = async () => {
    let res;
    await MedicineMaster.findAll({

        include: [{
            model: MedicineIllnessMapping,
            as: 'a',
            include: IllnessTypes

        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}
const GetbyRelationsId = async (id) => {
    let res;
    await MedicineMaster.findAll({
        where: { id: id },
        include: [{
            model: MedicineIllnessMapping,
            as: 'a',
            // attributes: ['id', 'illness_type_id'],
            include: {
                model: IllnessTypes,
                // attributes: ['id', 'illness_type_name']
            }

        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}

module.exports = {
    Get,
    GetbyId,
    CreateMedicine,
    UpdateMedicine,
    DestroyMedicine,
    GetbyRelations,
    GetbyRelationsId,
    GetbyName
};
