const HospitalServicesMaster = require('../models/HospitalServicesMasterModel');
const HospitalServiceDetails = require('../models/HospitalServiceDetailsModel')

const CreateHospitalService = async (hs_data) => {
    await HospitalServicesMaster.create(hs_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateHospitalService = async (id, hs_data) => {
    await HospitalServicesMaster.update(hs_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (name) => {
    await HospitalServicesMaster.findAll({ where: { service_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const DestroyHospitalService = async (id) => {
    await HospitalServicesMaster.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const GetbyRelations = async (id) => {
    let res;
    await HospitalServicesMaster.findAll({

        include: [{
            model: HospitalServiceDetails,
            as: 'details'

        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}

const GetbyRelationsId = async (id) => {
    let res;
    await HospitalServicesMaster.findAll({
        where: {
            id: id
        },
        include: [{
            model: HospitalServiceDetails,
            as: 'details'
        }]
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}

const Get = async () => {
    await HospitalServicesMaster.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await HospitalServicesMaster.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    CreateHospitalService,
    UpdateHospitalService,
    DestroyHospitalService,
    GetbyRelations,
    GetbyRelationsId,
    GetbyName,
    GetbyId,
    Get
};
