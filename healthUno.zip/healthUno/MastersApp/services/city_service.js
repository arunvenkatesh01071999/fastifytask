const City = require('../models/CityModel');
const stateMaster = require('../../MastersApp/models/StateModel');

const Get = async () => {
    await City.findAll({ include: stateMaster })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await City.findAll({ where: { id: id }, include: [stateMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateCity = async (c_data) => {
    await City.create(c_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateCity = async (id, c_data) => {
    await City.update(c_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyCity = async (id) => {
    await City.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const FetchByStateId = async (state_id) => {
    await City.findAll({ where: { state_id: state_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    CreateCity,
    UpdateCity,
    DestroyCity,
    FetchByStateId
};
