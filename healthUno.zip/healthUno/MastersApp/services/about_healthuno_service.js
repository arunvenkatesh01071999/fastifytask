const AboutHealthUno = require('../models/AboutHealthUnoModel');

const Get = async () => {
    await AboutHealthUno.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await AboutHealthUno.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateAboutHealthUno = async (a_data) => {
    await AboutHealthUno.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateAboutHealthUno = async (id, a_data) => {
    await AboutHealthUno.update(a_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyAboutHealthUno = async (id) => {
    await AboutHealthUno.destroy({ where: { id: id }, individualHooks: true })

        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateAboutHealthUno,
    UpdateAboutHealthUno,
    DestroyAboutHealthUno
};
