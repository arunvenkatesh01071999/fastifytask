// const HospitalServicesDetails = require('../models/HospitalServiceDetailsModel');
// const HospitalServicesMasterModel = require('../models/HospitalServicesMasterModel');

// const Get = async () => {
//     await HospitalServicesDetails.findAll({ raw: true })
//         .then(data => {
//             res = data
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

// const GetbyId = async (id) => {
//     await HospitalServicesDetails.findAll({ where: { id: id }, raw: true })
//         .then(data => {
//             res = data
//         })
//         .catch(err => {
//             res = err
//         })
//     return res
// }

// // const CreateHospitalServiceDetails = async (hd_data) => {
// //     await HospitalServicesDetails.create(hd_data)
// //         .then(data => {
// //             res = data
// //         }).catch(err => {
// //             res = err
// //         })

// //     return res
// // }
// // const DestroyHospitalServiceMap = async (hospital_services_id) => {
// //     await HospitalServicesDetails.destroy({ where: { hospital_services_id: hospital_services_id } })
// //         .then(data => {
// //             res = data
// //         }).catch(err => {
// //             res = err
// //         })
// //     return res
// // }

// const CreateHospitalServiceDetails = async (h_data) => {
//     await HospitalServicesDetails.create(h_data)
//         .then(data => {
//             res = data
//         }).catch(err => {
//             res = err
//         })

//     return res
// }
// const DestroyHospitalServiceMap = async (hospital_services_id) => {
//     await HospitalServicesDetails.destroy({ where: { hospital_services_id: hospital_services_id } })
//         .then(data => {
//             res = data
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

// const UpdateHospitalServiceDetails = async (id, h_data) => {
//     await HospitalServicesDetails.update(h_data, { where: { id: id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// }
// const GetbyRelations = async (id) => {
//     let res;
//     await HospitalServicesDetails.findAll({

//         // include: [{model:HospitalServicesMasterModel}] 
//     })
//         .then(data => {
//             res = data;
//         })
//         .catch(err => {
//             res = err;
//         });
//     return res;
// }

// const GetbyRelationsId = async (id) => {
//     let res;
//     await HospitalServicesDetails.findAll({
//         where: {
//             id: id
//         },
//         // include: [{
//         //     model: HospitalServicesMasterModel,
//         //     as: 'details'
//         // }] 
//     })
//         .then(data => {
//             res = data;
//         })
//         .catch(err => {
//             res = err;
//         });
//     return res;
// }

// module.exports = {
//     CreateHospitalServiceDetails,
//     GetbyId,
//     Get,
//     UpdateHospitalServiceDetails,
//     DestroyHospitalServiceMap,
//     GetbyRelations,
//     GetbyRelationsId
// }

const HospitalServicesDetails = require('../models/HospitalServiceDetailsModel');
const HospitalServicesMasterModel = require('../models/HospitalServicesMasterModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const CreateHospitalServiceDetails = async (h_data) => {
    console.log("create service");
    await HospitalServicesDetails.create(h_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyHospitalServiceMap = async (hospital_services_id) => {

    await HospitalServicesDetails.destroy({ where: { hospital_services_id: hospital_services_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateHospitalServiceDetails = async (id, h_data) => {
    await HospitalServicesDetails.update(h_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}
const GetbyRelations = async (id) => {
    let res;
    await HospitalServicesDetails.findAll({

        // include: [{model:HospitalServicesMasterModel}] 
    })
        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}

const GetbyRelationsId = async (hospital_services_id) => {

    const query = `select * from hospital_services_details where hospital_services_id =${hospital_services_id}`;
    await db1.query(query, { type: Sequelize.QueryTypes })

        .then(data => {
            res = data;
        })
        .catch(err => {
            res = err;
        });
    return res;
}

module.exports = {
    CreateHospitalServiceDetails,
    UpdateHospitalServiceDetails,
    DestroyHospitalServiceMap,
    GetbyRelations,
    GetbyRelationsId
}
