const NotificationMapping = require('../models/NotificationMappingModel');

const Get = async () => {
    await NotificationMapping.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await NotificationMapping.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateNotificationMapping = async (nm_data) => {
    await NotificationMapping.create(nm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateNotificationMapping = async (id, nm_data) => {
    await NotificationMapping.update(nm_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyNotificationMapping = async (id) => {
    await NotificationMapping.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetbyUserid = async (user_id) => {
    await NotificationMapping.findAll({ where: { user_id: user_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateNotificationMapping,
    UpdateNotificationMapping,
    DestroyNotificationMapping,
    GetbyUserid
};
