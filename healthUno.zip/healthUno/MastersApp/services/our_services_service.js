const OurServices = require('../models/OurServicesModel');

const Get = async () => {
    await OurServices.findAll({ raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await OurServices.findAll({ where: { id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyName = async (name) => {
    await OurServices.findAll({ where: { services_name: name }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateOurServices = async (datas) => {
    await OurServices.create(datas)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateOurServices = async (id, datas) => {
    await OurServices.update(datas, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyOurServices = async (id) => {
    await OurServices.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateOurServices,
    UpdateOurServices,
    DestroyOurServices,
    GetbyName
};
