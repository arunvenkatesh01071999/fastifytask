const HospitalBasicInfo = require('../models/HospitalBasicInfoModel');
const AddressInfo = require('../models/AddressInfoModel');
const ContactInfo = require('../models/ContactInfoModel');
const HospitalType = require('../../MastersApp/models/HospitalTypeMasterModel');
const SectorType = require('../../MastersApp/models/HospitalSectorModel');
const Accredation = require('../../MastersApp/models/AccredationModel')
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');

const Get = async () => {

    const query = `select a.id,a.hospital_name,g.hospital_image,a.certicate_path,a.regNo,
    a.addCheck,a.hospital_user,a.rating,
    a.isApproved,a.approve_date,a.approved_by,a.created_at,b.hospital_type_name,c.accredation_name,
    e.hospital_sector_name,
    d.hospital_name_id,d.address1,d.address2,d.pincode,d.location,f.mobile_no,
    f.telephone_no,f.email_address_1,f.email_address_2,h.username
    from h_hospital_basic_info as a
    left join hospital_type_master as b on a.hospital_type_id=b.id
    left join [dbo].[accredation] as c on a.accredation_id=c.id
    left join [dbo].[h_address_info] as d on a.id=d.hospital_name_id
    left join hospital_sector as e on a.sector_id=e.id
    left join [dbo].[h_hospital_image] as g on g.hospital_name_id = a.id
    left join [dbo].[users] as h on h.id = a.hospital_user
    left join [dbo].[h_contact_info] as f on f.hospital_name_id = a.id`;

    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((error) => {
            res = err
        });

    return res

}

const GetbyId = async (hospital_name_id) => {

    const query = `select a.id,a.hospital_name,g.hospital_image,a.certicate_path,a.regNo,
    a.addCheck,a.hospital_user,a.rating,
    a.isApproved,a.approve_date,a.approved_by,a.created_at,b.hospital_type_name,c.accredation_name,
    e.hospital_sector_name,
    d.hospital_name_id,d.address1,d.address2,d.pincode,d.location,f.mobile_no,
    f.telephone_no,f.email_address_1,f.email_address_2,h.username
    from h_hospital_basic_info as a
    left join hospital_type_master as b on a.hospital_type_id=b.id
    left join [dbo].[accredation] as c on a.accredation_id=c.id
    left join [dbo].[h_address_info] as d on a.id=d.hospital_name_id
    left join hospital_sector as e on a.sector_id=e.id
    left join [dbo].[h_hospital_image] as g on g.hospital_name_id = a.id
    left join [dbo].[users] as h on h.id = a.hospital_user
    left join [dbo].[h_contact_info] as f on f.hospital_name_id = a.id where a.id=${hospital_name_id}`;

    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((error) => {
            res = err
        });

    return res

    // await HospitalBasicInfo.findAll({
    //     include: [
    //         {
    //             model: HospitalType,
    //             required: false,
    //             attributes: ['hospital_type_name']
    //         },
    //         {
    //             model: Accredation,
    //             required: false,
    //             attributes: ['accredation_name']
    //         },
    //         {
    //             model: SectorType,
    //             required: false,
    //             attributes: ['hospital_sector_name']
    //         },
    // {
    //     model: AddressInfo,
    //     as: 'address',
    //     attributes: ['hospital_name_id', 'address1', 'address2', 'pincode', 'location']

    // },
    //         {
    //             model: ContactInfo,
    //             as: 'contact',
    //             attributes: ['mobile_no', 'telephone_no', 'email_address_1', 'email_address_2']

    //         }

    //     ],
    //     where: {
    //         id: hospital_name_id
    //     },
    //     attributes: ['id', 'hospital_name', 'hospital_image', 'certicate_path', 'regNo', 'created_at']
    // })
    //     .then(data => {
    //         res = data
    //     })
    //     .catch(err => {
    //         res = err

    //     })
    // return res
}


module.exports = {
    Get,
    GetbyId
};