const HospitalImgInfo = require('../models/HospitalImgModel');

const CreateHospitalmgBasicInfo = async (i_data_img) => {
    await HospitalImgInfo.create(i_data_img)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const DestoryHospitalmgBasicInfo = async (hosp_id) => {
    await HospitalImgInfo.destroy({ where: { hospital_name_id: hosp_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}
const CheckHospitalmgBasicInfo = async (hosp_id) => {
    await HospitalImgInfo.findAll({ where: { hospital_name_id: hosp_id }, raw: true })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

module.exports = {
    CreateHospitalmgBasicInfo,
    DestoryHospitalmgBasicInfo,
    CheckHospitalmgBasicInfo
};