const HospitalBasicInfo = require('../models/HospitalBasicInfoModel');
const HospitalType = require('../../MastersApp/models/HospitalTypeMasterModel');
const SectorType = require('../../MastersApp/models/HospitalSectorModel');
const Accredation = require('../../MastersApp/models/AccredationModel');
const HospitalImg = require('../models/HospitalImgModel');
const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');
const moment = require('moment/moment');

const Get = async () => {
    await HospitalBasicInfo.findAll({
        include: [HospitalType, Accredation,
            SectorType,
            {
                model: HospitalImg,
                as: 'Image',
                attributes: ['hospital_name_id', 'hospital_image']
            }
        ]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetuserId = async (user_id) => {
    // console.log("serviceeeeeeeeeeeeeeeeeee");
    await HospitalBasicInfo.findAll({ where: { user_id: user_id }, raw: true })

        .then(data => {
            // console.log("serviceeeeeeeeeeeeeeeeeee",data)
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (id) => {
    await HospitalBasicInfo.findAll({
        where: { id: id },
        include: [HospitalType, Accredation,
            SectorType,
            {
                model: HospitalImg,
                as: 'Image',
                attributes: ['hospital_name_id', 'hospital_image']

            }

        ]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyName = async (regNo) => {
    await HospitalBasicInfo.findAll({ where: { regNo: regNo }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateHospitalBasicInfo = async (i_data) => {
    await HospitalBasicInfo.create(i_data, { include: [HospitalType, SectorType, Accredation] })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

// const UpdateHospitalBasicInfo = async (hospital_id, updateData) => {
//     // console.log(id)
//     const query = `UPDATE [dbo].[h_hospital_basic_info] SET isApproved = 0`
//     await db1.query(query, { type: Sequelize.QueryTypes })
//     await HospitalBasicInfo.update(i_data, { where: { hospital_id: hospital_id } })
//         .then(data => {
//             res = data[0]
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

const UpdateHospitalBasicInfo = async (hospital_id, updateData) => {
    // console.log(id)
    const query = `UPDATE [dbo].[h_hospital_basic_info] SET isApproved = 0`
    await db1.query(query, { type: Sequelize.QueryTypes })
    await HospitalBasicInfo.update(updateData, { where: { id: hospital_id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyHospitalBasicInfo = async (id) => {
    await HospitalBasicInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const CreateApprove = async (id, a_data) => {
    const approve = moment(a_data.approve_date).format('L');
    const query = `UPDATE h_hospital_basic_info 
    SET isApproved = ${a_data.isApproved}, approve_date = '${approve}', 
    approved_by = ${a_data.approved_by} , reason = '${a_data.reason}'
    WHERE id = ${id}`;

    // console.log("query", query);
    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((err) => {
            res = err
        });

    return res
}

const UpdateIsApprove = async (id) => {
    var query = `UPDATE [dbo].[h_hospital_basic_info] SET isApproved = 0
    where isApproved = 1 or isApproved = 2 and id = ${id} `
    await db1.query(query, { type: Sequelize.QueryTypes })
        .then((result) => {
            res = result
        })
        .catch((err) => {
            res = err
        });
    return res
}

const GetbyHospitalRegNoAll = async (regNo) => {
    await HospitalBasicInfo.findAll({ where: { regNo: regNo }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}
const GetbyHospitalRegNoId = async (id) => {
    // console.log('regNo',regNo);
    // console.log(typeof regNo);
    const query = `select * from h_hospital_basic_info where id = ${id} `;
    await db1.query(query, { type: Sequelize.QueryTypes })
        .then(data => {
            res = data
            // console.log('res',res);
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    CreateHospitalBasicInfo,
    UpdateHospitalBasicInfo,
    DestroyHospitalBasicInfo,
    GetbyName,
    CreateApprove,
    UpdateIsApprove,
    GetuserId,
    GetbyHospitalRegNoAll,
    GetbyHospitalRegNoId
};