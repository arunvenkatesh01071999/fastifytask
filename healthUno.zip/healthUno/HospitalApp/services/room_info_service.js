const RoomInfo = require('../models/RoomInfoModel');
const RoomTypeModel = require('../../MastersApp/models/RoomTypeMasterModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const Get = async () => {
    await RoomInfo.findAll({ include: [RoomTypeModel, HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (hospital_name_id) => {
    await RoomInfo.findAll({
        where: { hospital_name_id: hospital_name_id },
        include: [RoomTypeModel, HospitalInfo]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (room_type_id) => {
    await RoomInfo.findAll({ where: { room_type_id: room_type_id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateRoomInfo = async (of_data) => {
    await RoomInfo.create(of_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateRoomInfo = async (id, of_data) => {
    await RoomInfo.update(of_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyRoomInfo = async (id) => {
    await RoomInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const GetRoomId = async (room_type_id) => {
    await RoomInfo.findAll({ where: { room_type_id: room_type_id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateRoomInfo,
    UpdateRoomInfo,
    DestroyRoomInfo,
    GetRoomId
};
