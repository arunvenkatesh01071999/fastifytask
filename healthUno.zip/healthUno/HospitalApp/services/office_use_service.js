const OfficeUse = require('../models/OfficeUseModel');
const Hospitalinfo = require('../models/HospitalBasicInfoModel');

const Get = async () => {
    await OfficeUse.findAll({ include: [Hospitalinfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (hospital_name_id) => {
    await OfficeUse.findAll({ where: { hospital_name_id: hospital_name_id }, include: [Hospitalinfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await OfficeUse.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateOfficeUse = async (s_data) => {
    await OfficeUse.create(s_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateOfficeUse = async (id, s_data) => {
    await OfficeUse.update(s_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyOfficeUse = async (id) => {
    await OfficeUse.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateOfficeUse,
    UpdateOfficeUse,
    DestroyOfficeUse
};
