const AddressInfo = require('../models/AddressInfoModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');
const CityMaster = require('../../MastersApp/models/CityModel');
const StateMaster = require('../../MastersApp/models/StateModel');
const CountryMaster = require('../../MastersApp/models/CountryModel');


const Get = async () => {
    await AddressInfo.findAll({ include: [HospitalInfo, CityMaster, StateMaster, CountryMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (hospital_name_id) => {
    await AddressInfo.findAll({
        where: { hospital_name_id: hospital_name_id }, include: [HospitalInfo, CityMaster, StateMaster, CountryMaster]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetId = async (id) => {
    await AddressInfo.findAll({ where: { hospital_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateAddress = async (a_data) => {
    await AddressInfo.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateAddress = async (hospital_name_id, a_data) => {
    await AddressInfo.update(a_data, { where: { hospital_name_id: hospital_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyAddress = async (id) => {
    await AddressInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    CreateAddress,
    UpdateAddress,
    DestroyAddress,
    GetId
};
