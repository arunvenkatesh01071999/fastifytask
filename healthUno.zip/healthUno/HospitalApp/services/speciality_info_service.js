const SpecialityInfo = require('../models/SpecialityInfo');
const Specialities = require('../../MastersApp/models/SpecialitiesModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const Get = async () => {
    await SpecialityInfo.findAll({ include: [Specialities, HospitalInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (hospital_name_id) => {
    await SpecialityInfo.findAll({
        where: { hospital_name_id: hospital_name_id },
        include: [Specialities, HospitalInfo]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (hospital_name_id) => {
    await SpecialityInfo.findAll({ where: { hospital_name_id: hospital_name_id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateSpecialityInfo = async (sm_data) => {
    await SpecialityInfo.create(sm_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

// const UpdateSpecialityInfo = async (sm_data) => {
//     await SpecialityInfo.create(sm_data)
//         .then(data => {
//             res = data
//         }).catch(err => {
//             res = err
//         })
//     return res
// }

const DestroySpeciality = async (hospital_name_id) => {
    await SpecialityInfo.destroy({ where: { hospital_name_id: hospital_name_id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetId,
    GetbyId,
    CreateSpecialityInfo,
    // UpdateSpecialityInfo,
    DestroySpeciality
};
