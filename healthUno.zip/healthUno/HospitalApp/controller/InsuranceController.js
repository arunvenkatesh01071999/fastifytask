const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const insurance_info_service = require('../services/insurance_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');

const FetchInsuranceInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await insurance_info_service.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_insurance_info_service');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await insurance_info_service.Get()
                .then(data => {
                    cache.SET(req.user.id + '_insurance_info_service', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewInsuranceInfo = async (req, res, next) => {
    const hospital_name_id = req.body.hospital_name_id;
    const insurance_name_id = req.body.insurance_name_id;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.hospital_name_id);

    if (hospital_name_id && insurance_name_id && Array.isArray(insurance_name_id) && insurance_name_id.length > 0) {
        for (const i of insurance_name_id) {
            const s_data = {
                hospital_name_id: parseInt(hospital_name_id),
                insurance_name_id: parseInt(i),
                addCheck: addCheck,
                active: active,
                created_by: created_by,
                updated_by: updated_by
            }
            // console.log(s_data);
            // await insurance_info_service.GetId(hospital_name_id)
            //     .then(data => {
            //         if (data.length > 0) {
            //             msg = "Hospital Address Already Exist";
            //             return res.status(200).json(failure_func(msg))
            //         } else {
            insurance_info_service.CreateInsuranceInfo(s_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                    } else {
                        msg = "Created Successfully"
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
            //     }
            // })
        }
        msg = "Created Successfully"
        res.status(200).json(success_func(msg))

    } else {
        msg = "hospital_name_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateInsuranceInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        insurance_info_service.DestroyInsuranceInfo(hospital_name_id)
        insurance_name_id = req.body.insurance_name_id;
        hospital_name_id = req.body.hospital_name_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (hospital_name_id && insurance_name_id && Array.isArray(insurance_name_id) && insurance_name_id.length > 0) {
            for (const i of insurance_name_id) {
                s_data = {
                    insurance_name_id: parseInt(i),
                    hospital_name_id: hospital_name_id,
                    active: active,
                    created_by: req.user.id,
                    updated_by: updated_by
                }
                await insurance_info_service.CreateInsuranceInfo(s_data)
                    .then(data => {
                        if (data.errors) {
                            msg = data.errors[0].message;
                        } else {
                            msg = "Updated Successfully"
                        }
                    })
                    .catch(err => {
                        res.status(400).json(failure_func(err))
                    })
            }
        }
        msg = "Updated Successfully"
        res.status(200).json(success_func(msg))
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

// const DeleteInsuranceInfo = async (req, res, next) => {
//     id = req.params.id;
//     if (id) {
//         await insurance_info_service.DestroyInsuranceInfo(id)
//             .then(data => {
//                 if (data == 1) {
//                     msg = "Deleted successfully"
//                     cache.DEL(req.user.id + '_insurance_info_service')
//                     res.status(200).json(success_func(msg))
//                 } else {
//                     msg = "ID doesn't exist"
//                     res.status(200).json(success_func(msg))
//                 }
//             })
//             .catch(err => {
//                 res.status(400).json(failure_func(err))
//             })
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }


module.exports = {
    NewInsuranceInfo,
    FetchInsuranceInfo,
    UpdateInsuranceInfo,
    // DeleteInsuranceInfo
}