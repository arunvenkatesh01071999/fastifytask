const success_func = require("../../api_responser").success_func;
const failure_func = require("../../api_responser").failure_func;
const date = require("../../services/datetime_service");
const room_info_service = require("../services/room_info_service");
const logger = require("../../config/logger");
const cache = require("../../services/redis_cache_service");
const RoomInfo = require("../models/RoomInfoModel");

const FetchRoomInfo = async (req, res, next) => {
  hospital_name_id = req.params.hospital_name_id;
  if (hospital_name_id) {
    await room_info_service
      .GetbyId(hospital_name_id)
      .then((data) => {
        res.status(200).json(success_func(data));
      })
      .catch((err) => {
        res.status(400).json(failure_func(err));
      });
  } else {
    // data = await cache.GET(req.user.id + '_room_info_service');
    // if (data) {
    //     res.status(200).json(success_func(JSON.parse(data)))
    // } else {
    await room_info_service
      .Get()
      .then((data) => {
        cache.SET(req.user.id + "_room_info_service", data);
        res.status(200).json(success_func(data));
      })
      .catch((err) => {
        res.status(400).json(failure_func(err));
      });
  }
};
// }

const NewRoomInfo = async (req, res, next) => {
  hospital_name_id = req.body.hospital_name_id;
  room_type_id = req.body.room_type_id;
  cost = req.body.cost;
  no_of_days = req.body.no_of_days;
  active = req.body.active;
  created_by = req.user.id;
  updated_by = req.user.id;
  if (hospital_name_id) {
    of_data = {
      hospital_name_id: parseInt(hospital_name_id),
      room_type_id: room_type_id,
      cost: cost,
      no_of_days: no_of_days,
      active: active,
      created_by: created_by,
      updated_by: updated_by,
    };

    await room_info_service.GetRoomId(room_type_id)
      .then((room_data) => {
        // if (room_data.length > 0) {
        //   msg = " Room Type already exists";
        //   return res.status(200).json(failure_func(msg));
        // } else {
        room_info_service.CreateRoomInfo(of_data)
          .then((data) => {
            // console.log('data',data);
            if (data.errors) {
              msg = data.errors[0].message;
              res.status(400).json(failure_func(msg));
            } else {
              msg = "Created Successfully";
              cache.DEL(req.user.id + "_room_info_service");
              res.status(200).json(success_func(msg));
            }
          })
          .catch((err) => {
            res.status(400).json(failure_func(err));
          });
        // }
      });
  } else {
    msg = "room_type_id and active is required";
    res.status(400).json(failure_func(msg));
  }
};

const UpdateRoomInfo = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    hospital_name_id = req.body.hospital_name_id;
    room_type_id = req.body.room_type_id;
    cost_id = req.body.cost_id;
    no_of_days = req.body.no_of_days;
    active = req.body.active;
    updated_by = req.user.id;
    updated_at = date();
    if (hospital_name_id) {
      of_data = {
        hospital_name_id: parseInt(hospital_name_id),
        room_type_id: room_type_id,
        cost_id: cost_id,
        no_of_days: no_of_days,
        active: active,
        updated_by: updated_by,
        updated_at: updated_at,
      };
      await room_info_service
        .UpdateRoomInfo(id, of_data)
        .then((data) => {
          if (data == 1) {
            msg = "Updated successfully";
            cache.DEL(req.user.id + "_room_info_service");
            res.status(200).json(success_func(msg));
          } else {
            msg = "ID doesn't exist";
            res.status(400).json(failure_func(msg));
          }
        })
        .catch((err) => {
          res.status(400).json(failure_func(err));
        });
    } else {
      msg = "room_type_id and active is required";
      res.status(400).json(failure_func(msg));
    }
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg));
  }
};

const DeleteRoomInfo = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await room_info_service
      .DestroyRoomInfo(id)
      .then((data) => {
        if (data == 1) {
          msg = "Deleted successfully";
          cache.DEL(req.user.id + "_room_info_service");
          res.status(200).json(success_func(msg));
        } else {
          msg = "ID doesn't exist";
          res.status(200).json(success_func(msg));
        }
      })
      .catch((err) => {
        res.status(400).json(failure_func(err));
      });
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg));
  }
};

module.exports = {
  NewRoomInfo,
  FetchRoomInfo,
  UpdateRoomInfo,
  DeleteRoomInfo,
};
