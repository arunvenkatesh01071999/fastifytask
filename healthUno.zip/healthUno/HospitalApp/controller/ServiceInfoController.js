const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const service_services = require('../services/service_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');


const FetchServiceInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await service_services.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_service_services');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await service_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_service_services', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
}

const NewServiceInfo = async (req, res, next) => {
    const hospital_name_id = req.body.hospital_name_id;
    const service_name_id = req.body.service_name_id;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.hospital_name_id);

    if (hospital_name_id && service_name_id && Array.isArray(service_name_id) && service_name_id.length > 0) {
        for (const i of service_name_id) {
            const l_data = {
                hospital_name_id: parseInt(hospital_name_id),
                service_name_id: parseInt(i),
                active: active,
                created_by: created_by,
                updated_by: updated_by
            }
            console.log(l_data);
            service_services.CreateService(l_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                    } else {
                        msg = "Created Successfully"
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })

        }
        msg = "Created Successfully"
        res.status(200).json(success_func(msg))

    } else {
        msg = "hospital_name_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

// const UpdateServiceInfo = async (req, res, next) => {
//     id = req.params.hospital_name_id;
//     if (id) {
//         const hospital_name_id = req.body.hospital_name_id;
//         const service_name_id = req.body.service_name_id;
//         const active = req.body.active;
//         const updated_by = req.user.id;
//         const updated_at = date();
//         if (hospital_name_id && service_name_id && Array.isArray(service_name_id) && service_name_id.length > 0) {
//             for (const i of service_name_id) {
//                 const l_data = {
//                     hospital_name_id: parseInt(hospital_name_id),
//                     service_name_id: parseInt(i),
//                     active: active,
//                     created_by: req.user.id,
//                     updated_by: updated_by
//                 }
//                 await service_services.CreateService(l_data)
//                     .then(data => {
//                         if (data.errors) {
//                             msg = data.errors[0].message;
//                         } else {
//                             msg = "Updated Successfully"
//                         }
//                     })
//                     .catch(err => {
//                         res.status(400).json(failure_func(err))
//                     })
//                 msg = "Updated Successfully"
//                 res.status(200).json(success_func(msg))
//             }
//         }
//     } else {
//         msg = "ID is required";
//         res.status(400).json(failure_func(msg))
//     }
// }

const UpdateServiceInfo = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        service_services.DestroyService(hospital_name_id)
        service_name_id = req.body.service_name_id;
        hospital_name_id = req.body.hospital_name_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        for (const i of service_name_id) {
            const l_data = {
                hospital_name_id: parseInt(hospital_name_id),
                service_name_id: parseInt(i),
                // addCheck:addCheck,
                active: active,
                created_by: req.user.id,
                updated_by: updated_by
            }
            console.log(l_data);
            await service_services.CreateService(l_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                    } else {
                        msg = "Updated Successfully"
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        msg = "Updated Successfully"
        res.status(200).json(success_func(msg))
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteServiceInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await service_services.DestroyService(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_service_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewServiceInfo,
    FetchServiceInfo,
    UpdateServiceInfo,
    DeleteServiceInfo
}