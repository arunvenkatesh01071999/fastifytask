const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const office_use_service = require('../services/office_use_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/hospital_addCheck_service');


const FetchOfficeUse = async (req, res, next) => {
    hospital_name_id = req.params.hospital_name_id;
    if (hospital_name_id) {
        await office_use_service.GetbyId(hospital_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_office_use_service');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await office_use_service.Get()
            .then(data => {
                cache.SET(req.user.id + '_office_use_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewOfficeUse = async (req, res, next) => {
    hospital_name_id = req.body.hospital_name_id;
    person_name = req.body.person_name;
    person_email_id = req.body.person_email_id;
    designation = req.body.designation;
    mobile = req.body.mobile;
    telephone = req.body.telephone ? req.body.telephone : "";
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    addCheck = 8;
    query = AddCheck(req.body.hospital_name_id);

    if (person_name) {
        of_data = {
            hospital_name_id: parseInt(hospital_name_id),
            person_name: person_name,
            person_email_id: person_email_id,
            designation: designation,
            mobile: mobile,
            telephone: telephone,
            addCheck: addCheck,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        console.log(of_data)
        await office_use_service.GetId(hospital_name_id)
            .then(data => {
                if (data.length > 0) {
                    msg = "Hospital Address Already Exist";
                    return res.status(200).json(failure_func(msg))
                } else {
                    office_use_service.CreateOfficeUse(of_data)
                        .then(data => {
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                office_use_service.GetId(hospital_name_id)
                                    .then(datas => {
                                        datas.msg = "Created Successfully"
                                        cache.DEL(req.user.id + '_office_use_service')
                                        res.status(200).json(success_func(datas))
                                    })
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                }
            })
    } else {
        msg = "person_name and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateOfficeUse = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        hospital_name_id = req.body.hospital_name_id;
        person_name = req.body.person_name;
        person_email_id = req.body.person_email_id;
        designation = req.body.designation;
        telephone =  req.body.telephone ? req.body.telephone : "";
        mobile = req.body.mobile;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (person_name) {
            of_data = {
                hospital_name_id: parseInt(hospital_name_id),
                person_name: person_name,
                person_email_id: person_email_id,
                designation: designation,
                mobile: mobile,
                telephone: telephone,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await office_use_service.UpdateOfficeUse(id, of_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_office_use_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "person_name and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteOfficeUse = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await office_use_service.DestroyOfficeUse(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_office_use_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewOfficeUse,
    FetchOfficeUse,
    UpdateOfficeUse,
    DeleteOfficeUse
}