const express = require('express');
const router = express();
const DepartmentInfoController = require('../controller/DepartmentInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, DepartmentInfoController.FetchDepartmentInfo);
router.get('/:hospital_name_id', verify_token, DepartmentInfoController.FetchDepartmentInfo);
router.post('/', verify_token, DepartmentInfoController.NewDepartmentInfo);
router.put('/:hospital_name_id', verify_token, DepartmentInfoController.UpdateDepartmentInfo);
// router.delete('/:id', verify_token, DepartmentInfoController.DeleteDepartmentInfo);

module.exports = router;