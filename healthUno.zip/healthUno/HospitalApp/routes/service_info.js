const express = require('express');
const router = express();
const ServiceInfoController = require('../controller/ServiceInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, ServiceInfoController.FetchServiceInfo);
router.get('/:hospital_name_id', verify_token, ServiceInfoController.FetchServiceInfo);
router.post('/', verify_token, ServiceInfoController.NewServiceInfo);
router.put('/:hospital_name_id', verify_token, ServiceInfoController.UpdateServiceInfo);
// router.delete('/:id', verify_token, ServiceInfoController.DeleteServiceInfo);


module.exports = router; 