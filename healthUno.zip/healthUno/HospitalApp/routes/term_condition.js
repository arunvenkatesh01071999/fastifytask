const express = require('express');
const router = express();
const TermConditionController = require('../controller/TermsConditionController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, TermConditionController.FetchTermCondition);
router.get('/:hospital_name_id', verify_token, TermConditionController.FetchTermCondition);
router.post('/', verify_token, TermConditionController.NewTermCondition);
router.put('/:id', verify_token, TermConditionController.UpdateTermCondition);
// router.delete('/:id', verify_token, TermConditionController.DeleteTermCondition);

module.exports = router;