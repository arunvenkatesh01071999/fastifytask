const express = require('express');
const router = express();
const ScanInfoController = require('../controller/ScanInfoController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ScanInfoController.FetchScanInfo);
router.get('/:hospital_name_id', verify_token, ScanInfoController.FetchScanInfo);
router.post('/', verify_token, ScanInfoController.NewScanInfo);
router.put('/:hospital_name_id', verify_token, ScanInfoController.UpdateScanInfo);
// router.delete('/:id', verify_token, ScanInfoController.DeleteScanInfo);

module.exports = router;