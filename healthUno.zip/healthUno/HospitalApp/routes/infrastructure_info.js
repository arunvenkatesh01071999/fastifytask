const express = require('express');
const router = express();
const InfraStructureController = require('../../HospitalApp/controller/InfrastructureController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, InfraStructureController.FetchInfraStructure);
router.get('/:hospital_name_id', verify_token, InfraStructureController.FetchInfraStructure);
router.post('/', verify_token, InfraStructureController.NewInfraStructure);
router.put('/:id', verify_token, InfraStructureController.UpdateInfraStructure);
// router.delete('/:id', verify_token, InfraStructureController.DeleteInfraStructure);


module.exports = router; 