const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const Specialities = require('../../MastersApp/models/SpecialitiesModel');
const HospitalInfo = require('./HospitalBasicInfoModel');
const logger = require('../../config/activity_logger');


const SpecialityInfo = sequelize.define("h_speciality_info", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "service_name_id is required"
            }
        }
    },
    speciality_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "speciality_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

SpecialityInfo.belongsTo(Specialities, { foreignKey: 'speciality_name_id' });
SpecialityInfo.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' })

SpecialityInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_speciality_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

SpecialityInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_speciality_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = SpecialityInfo;