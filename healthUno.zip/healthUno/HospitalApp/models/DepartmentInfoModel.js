const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const DepartmentMasterModel = require('../../MastersApp/models/DepartmentMasterModel');
const HospitalInfo = require('../models/HospitalBasicInfoModel');
const logger = require('../../config/activity_logger');


const DepartmentInfo = sequelize.define("h_department_info", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    department_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

DepartmentInfo.belongsTo(DepartmentMasterModel, { foreignKey: 'department_name_id' });
DepartmentInfo.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' })

DepartmentInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_department_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

DepartmentInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_department_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = DepartmentInfo;