const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
// const HospitalInfoModel = require('../models/HospitalBasicInfoModel');
const logger = require('../../config/activity_logger');

const HospitalImg = sequelize.define("h_hospital_image", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    hospital_image: {
        type: DataTypes.STRING,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
    }
}, { freezeTableName: true });

// HospitalImg.belongsTo(HospitalInfoModel, { foreignKey: 'hospital_name_id' });


HospitalImg.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_hospital_image',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

HospitalImg.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_hospital_image',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = HospitalImg;