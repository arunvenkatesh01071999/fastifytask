const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const HospitalInfo = require('../models/HospitalBasicInfoModel');


const ScanInfo = sequelize.define("h_office_use", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Address is required"
            }
        }
    },
    person_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "person_name is required"
            }
        }
    },
    person_email_id: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    designation: {
        type: DataTypes.STRING,
        allowNull: false,
    },
    mobile: {
        type: DataTypes.NUMBER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "Mobile Number is required"
            },
            len: {
                args: [10, 15],
                msg: "Please enter 10 digit Mobile Number"
            }
        }
    },
    telephone: {
        type: DataTypes.NUMBER,
        allowNull: false,
      
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

ScanInfo.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' })

ScanInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_office_use',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

ScanInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_office_use',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = ScanInfo;