const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const HospitalInfo = require('../models/HospitalBasicInfoModel');
const logger = require('../../config/activity_logger');


const LabInfo = sequelize.define("h_lab_info", {
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "hospital_name_id is required"
            }
        }
    },
    lab_name_id: {
        type: DataTypes.INTEGER,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "lab_name_id is required"
            }
        }
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    created_at: {
        type: DataTypes.DATE,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

LabInfo.belongsTo(HospitalInfo, { foreignKey: 'hospital_name_id' })

LabInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'h_lab_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

LabInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'h_lab_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});


module.exports = LabInfo;