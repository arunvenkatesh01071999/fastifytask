const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const contactInfo_services = require('../services/lab_contact_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const AddCheck = require('../../services/lab_addCheck_service');

const FetchLabContactInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        await contactInfo_services.GetbyId(lab_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        data = await cache.GET(req.user.id + '_contactInfo_services');
        if (data) {
            res.status(200).json(success_func(JSON.parse(data)))
        } else {
            await contactInfo_services.Get()
                .then(data => {
                    cache.SET(req.user.id + '_contactInfo_services', data)
                    res.status(200).json(success_func(data))
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
    }
};

const NewLabContactInfo = async (req, res, next) => {
    const lab_name_id = req.body.lab_name_id;
    const telephone = req.body.telephone;
    const mobile_no = req.body.mobile_no;
    const emergency_no = req.body.emergency_no;
    const toll_free_no = req.body.toll_free_no;
    const helpline_no = req.body.helpline_no;
    const fax_no = req.body.fax_no;
    const webiste_URL = req.body.webiste_URL;
    const email_address_1 = req.body.email_address_1;
    const email_address_2 = req.body.email_address_2;
    const established_in = req.body.established_in;
    const active = req.body.active;
    const created_by = req.user.id;
    const updated_by = req.user.id;
    const addCheck = 8;
    const query = AddCheck(req.body.lab_name_id)
    

    if (mobile_no) {
        const l_data = {
            lab_name_id: lab_name_id,
            telephone: telephone,
            mobile_no: mobile_no,
            emergency_no: emergency_no,
            toll_free_no: toll_free_no,
            helpline_no: helpline_no,
            fax_no: fax_no,
            webiste_URL: webiste_URL,
            email_address_1: email_address_1,
            email_address_2: email_address_2,
            established_in: established_in,
            active: active,
            addCheck: addCheck,
            created_by: created_by,
            updated_by: updated_by
        };
        console.log(l_data);

        await contactInfo_services.CreateContact(l_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    // cache.DEL(req.user.id + '_contactInfo_services')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
    else {
        msg = "Mobile Number is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateLabContactInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        const lab_name_id = req.body.lab_name_id;
        const telephone = req.body.telephone;
        const mobile_no = req.body.mobile_no;
        const emergency_no = req.body.emergency_no;
        const toll_free_no = req.body.toll_free_no;
        const helpline_no = req.body.helpline_no;
        const fax_no = req.body.fax_no;
        const webiste_URL = req.body.webiste_URL;
        const email_address_1 = req.body.email_address_1;
        const email_address_2 = req.body.email_address_2;
        const established_in = req.body.established_in;
        const active = req.body.active;
        const updated_by = req.user.id;
        const updated_at = date();
        if (lab_name_id) {
            const l_data = {
                lab_name_id: lab_name_id,
                telephone: telephone,
                mobile_no: mobile_no,
                emergency_no: emergency_no,
                toll_free_no: toll_free_no,
                helpline_no: helpline_no,
                fax_no: fax_no,
                webiste_URL: webiste_URL,
                email_address_1: email_address_1,
                email_address_2: email_address_2,
                established_in: established_in,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            console.log(l_data);
            await contactInfo_services.UpdateContact(id, l_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_contactInfo_services')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "Contact Number is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteLabContactInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await contactInfo_services.DestroyContact(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_contactInfo_services')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

module.exports = {
    FetchLabContactInfo,
    NewLabContactInfo,
    UpdateLabContactInfo,
    DeleteLabContactInfo
}