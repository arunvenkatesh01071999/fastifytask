const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const lab_basic_service = require('../services/lab_basic_info_service');
const lab_img_service = require('../services/lab_image_info_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const fs = require('fs');
const labimginfomodel = require('../models/LabImageInfoModel');
const { Storage } = require('@google-cloud/storage');
const { log } = require('util');
const storage = new Storage();

const FetchLabBasicInfo = async (req, res, next) => {
  lab_name_id = req.params.lab_name_id;
  if (lab_name_id) {
    await lab_basic_service.GetbyId(lab_name_id)
      .then(data => {
        res.status(200).json(success_func(data))
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    data = await cache.GET(req.user.id + '_lab_basic_service');
    if (data) {
      res.status(200).json(success_func(JSON.parse(data)))
    } else {
      await lab_basic_service.Get()
        .then(data => {
          cache.SET(req.user.id + '_lab_basic_service', data)
          res.status(200).json(success_func(data))
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })
    }
  }
};

// const NewLabBasicInfo = async (req, res, next) => {
//   lab_name = req.body.lab_name;
//   lab_type_id = req.body.lab_type_id;
//   sector_id = req.body.sector_id;
//   accredation_id = req.body.accredation_id;
//   lab_regNo = req.body.lab_regNo;
//   about = req.body.about;
//   active = req.body.active;
//   isApproved = 0;
//   approved_by = '';
//   created_by = req.user.id;
//   created_at = date();
//   updated_at = date();
//   updated_by = req.user.id;
//   addCheck = 8;
//   // lab_or_scan = req.body.lab_or_scan || 0;

//   try {
//     lab_or_scan = req.body.lab_or_scan;
//   } catch {
//     lab_or_scan = 0
//   }
//   try {
//     lab_image = req.files.lab_image;
//   } catch {
//     lab_image = null
//   }
//   // try {
//   //   certicate_path = req.files.certicate_path
//   // } catch {
//   //   certicate_path = null
//   // }
//   certicate_path = req.files ? req.files.certicate_path : null;
//   if (lab_name) {
//     l_data = {
//       lab_name: lab_name,
//       lab_type_id: parseInt(lab_type_id),
//       sector_id: parseInt(sector_id),
//       accredation_id: parseInt(accredation_id),
//       certicate_path: certicate_path,
//       lab_image: 'null',
//       lab_regNo: lab_regNo,
//       about: about,
//       addCheck: addCheck,
//       isApproved: isApproved,
//       approve_date: null,
//       active: parseInt(active),
//       created_by: created_by,
//       created_at: created_at,
//       updated_at: updated_at,
//       updated_by: updated_by,
//       lab_or_scan: lab_or_scan
//     }

//     // if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//     //   l_data.certicate_path = certicate_path.name;
//     //   buffer = certicate_path.data;
//     //   path = './media/' + certicate_path.name;
//     //   fs.writeFile(path.toString(), buffer, function (err) {
//     //     if (err) {
//     //       return console.log(err);
//     //     }
//     //   });
//     // } else {

//     //   certicate_path = req.body.certicate_path;
//     //   l_data.certicate_path = certicate_path;
//     // }

//     if (certicate_path) {
//       const bucketName = process.env.GCP_BUCKET_NAME;
//       const fileName = certicate_path.name;
//       const buffer = certicate_path.data;
//       const path = `images/${fileName}`;
//       const file = storage.bucket(bucketName).file(path);
//       // Upload the image to GCS
//       await file.save(buffer);
//       l_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//     }
//     else {
//       // If no image is provided, you may want to handle null or default values
//       l_data.certicate_path = null; // or set a default image URL
//     }

//     // console.log('certicate_path', typeof (certicate_path), certicate_path);
//     await lab_basic_service.GetbyName(lab_regNo)
//       .then(basic_data => {
//         if (basic_data.length > 0) {
//           msg = "Register Number already exists";
//           return res.status(200).json(failure_func(msg));
//         } else {
//           lab_basic_service.CreateLabBasicInfo(l_data)
//             .then(data => {
//               if (data.errors) {
//                 msg = data.errors[0].message;
//                 res.status(400).json(failure_func(msg));
//               } else {
//                 if (data.dataValues.id && lab_image.length) {
//                   const bucketName = process.env.GCP_BUCKET_NAME;
//                   const uploadImagePromises = lab_image.map(async (element) => {
//                     const fileName = element.name;
//                     const buffer = element.data;

//                     // Upload image to GCS
//                     const file = storage.bucket(bucketName).file(`images/${fileName}`);
//                     await file.save(buffer);

//                     const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//                     // Create image data for your database
//                     const l_data_img = {
//                       lab_name_id: data.dataValues.id,
//                       lab_image: imageUrl,
//                       active: active,
//                       created_by: created_by,
//                       updated_by: updated_by,
//                     };

//                     // Save lab image data to your database
//                     await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//                   });

//                   // Wait for all image uploads and database inserts to complete
//                   Promise.all(uploadImagePromises);
//                 }

//                 lab_basic_service.GetbyName(lab_regNo)
//                   .then(datas => {
//                     datas.msg = "Created Successfully";
//                     // cache.DEL(req.user.id + '_lab_basic_service')
//                     res.status(200).json(success_func(datas));
//                   })
//                   .catch(err => {
//                     res.status(400).json(failure_func(err));
//                   });
//               }
//             })
//             .catch(err => {
//               res.status(400).json(failure_func(err));
//             });
//         }
//       })
//   }
//   else {
//     msg = "lab_name is required";
//     res.status(400).json(failure_func(msg))
//   }
// }

const NewLabBasicInfo = async (req, res, next) => {
  var lab_name = req.body.lab_name;
  lab_type_id = req.body.lab_type_id;
  sector_id = req.body.sector_id;
  accredation_id = req.body.accredation_id;
  lab_regNo = req.body.lab_regNo;
  about = req.body.about;
  active = req.body.active;
  created_by = req.user.id;
  created_at = date();
  updated_at = date();
  updated_by = req.user.id;
  isApproved = 0;
  approve_date = null;
  addCheck = 8;
  try {
    lab_or_scan = req.body.lab_or_scan;
  } catch {
    lab_or_scan = 0
  }
  certicate_path = req.files ? req.files.certicate_path : null;
  var lab_image = req.files ? req.files.lab_image : null;
  if (lab_regNo) {
    l_data = {
      lab_name: lab_name,
      lab_type_id: parseInt(lab_type_id),
      sector_id: parseInt(sector_id),
      accredation_id: parseInt(accredation_id),
      certicate_path: certicate_path,
      lab_image: 'null',
      lab_regNo: lab_regNo,
      about: about,
      addCheck: addCheck,
      isApproved: isApproved,
      approve_date: null,
      active: parseInt(active),
      created_by: created_by,
      created_at: created_at,
      updated_at: updated_at,
      updated_by: updated_by,
      lab_or_scan: lab_or_scan
    }
    if (certicate_path) {
      const bucketName = process.env.GCP_BUCKET_NAME;
      const fileName = certicate_path.name;
      const buffer = certicate_path.data;
      const path = `images/${fileName}`;
      const file = storage.bucket(bucketName).file(path);
      await file.save(buffer);
      l_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
    }
    else {
      l_data.certicate_path = null;
    }
    await lab_basic_service.GetbyName(lab_regNo)
      .then(basic_data => {
        if (basic_data.length > 0) {
          msg = "Invalid Registration Number";
          return res.status(200).json(failure_func(msg))
        } else {
          lab_basic_service.CreateLabBasicInfo(l_data)
            .then(data => {
              if (data.errors) {
                msg = data.errors[0].message;
                res.status(400).json(failure_func(msg))
              }
              else {
                if (data.dataValues.id) {
                  const bucketName = process.env.GCP_BUCKET_NAME;
                  if (lab_image.name) {
                    const value = [];
                    value.push(lab_image);
                    const uploadImagePromises = value.map(async (element) => {
                      const fileName = element.name;
                      const buffer = element.data;
                      const file = storage.bucket(bucketName).file(`images/${fileName}`);
                      await file.save(buffer);
                      const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
                      const l_data_img = {
                        lab_name_id: data.dataValues.id,
                        lab_image: imageUrl,
                        active: active,
                        created_by: created_by,
                        updated_by: updated_by,
                      };
                      await lab_img_service.CreateLablmgBasicInfo(l_data_img);
                    });
                    Promise.all(uploadImagePromises);
                  }
                  else {
                    console.log("hi,else");
                    const uploadImagePromises = lab_image.map(async (element) => {
                      const fileName = element.name;
                      const buffer = element.data;
                      // Upload image to GCS
                      const file = storage.bucket(bucketName).file(`images/${fileName}`);
                      await file.save(buffer);
                      const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
                      // Create image data for your database
                      const l_data_img = {
                        lab_name_id: data.dataValues.id,
                        lab_image: imageUrl,
                        active: active,
                        created_by: created_by,
                        updated_by: updated_by,
                      };
                      // Save hospital image data to your database
                      await lab_img_service.CreateLablmgBasicInfo(l_data_img);
                    });
                    // Wait for all image uploads and database inserts to complete
                    Promise.all(uploadImagePromises);
                    // console.log("asddDff");
                  }
                }
                lab_basic_service.GetbyName(lab_regNo)
                  .then(datas => {
                    datas.msg = "Created Successfully"
                    res.status(200).json(success_func(datas))
                  })
                  .catch(err => {
                    res.status(400).json(failure_func(err))
                  })
              }
            })
            .catch(err => {
              msg = "Failed"
              res.status(400).json(failure_func(msg))
            })
        }
      })
  }
  else {
    msg = "lab_name is required";
    res.status(400).json(failure_func(msg))
  }
}


const UpdateLabBasicInfo = async (req, res, next) => {
  // console.log('enter', req.body.lab_image);
  // const t=["https://storage.googleapis.com/uno-bucket-stag/images/doctor.jpg","https://storage.googleapis.com/uno-bucket-stag/images/doctor.jpg",]
  // console.log("asdrscghjk", req.files.certicate_path);
  // console.log("asdfghjk", req.body.certicate_path);
  // console.log("asdfghjkssss", req.body.lab_image);
  console.log("ee", req.files);

  id = req.params.id;
  if (id) {
    const lab_name = req.body.lab_name;
    const lab_type_id = req.body.lab_type_id;
    const sector_id = req.body.sector_id;
    const accredation_id = req.body.accredation_id;
    const lab_regNo = req.body.lab_regNo;
    const about = req.body.about;
    if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
      certicate_path = req.files.certicate_path;
    } else {

      certicate_path = req.body.certicate_path;
    }

    if (req.files && req.files.lab_image && req.files.lab_image.name) {
      lab_image = req.files.lab_image;
      console.log("lab_imagelab_image", lab_image);
    } else {
      lab_image_body = req.body.lab_image;
      console.log("lab_image_body", lab_image_body);
    }
    try {
      lab_or_scan = req.body.lab_or_scan;
    } catch {
      lab_or_scan = 0
    }
    const active = req.body.active;
    const updated_by = req.user.id;
    const updated_at = date();
    if (lab_name) {

      const l_data = {
        lab_name: lab_name,
        lab_type_id: parseInt(lab_type_id),
        sector_id: parseInt(sector_id),
        accredation_id: parseInt(accredation_id),
        lab_regNo: lab_regNo,
        certicate_path: certicate_path,
        about: about,
        lab_or_scan: lab_or_scan,
        active: active,
        updated_by: updated_by,
        updated_at: updated_at
      }
      if (typeof certicate_path === "string") {
        l_data.certicate_path = certicate_path;
      }
      else {

        const bucketName = process.env.GCP_BUCKET_NAME;
        const fileName = certicate_path.name;
        const buffer = certicate_path.data;
        const path = `images/${fileName}`;
        const file = storage.bucket(bucketName).file(path);
        // Upload the image to GCS
        await file.save(buffer);
        l_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;

      }
      await lab_basic_service.UpdateLabBasicInfo(id, l_data)
        .then(data => {
          if (data == 1) {
            const lab_id = req.params.id;
            lab_img_service.CheckLabImgBasicInfo(lab_id)
              .then(result => {
                var image_body = req.body.lab_image
                console.log("qwesdfghjkrty", image_body);
                if (image_body) {
                  const lab_image_body = req.body.lab_image.toString()
                  var req_array = lab_image_body.split(',');
                  console.log("req_arrayreq_array", req_array);
                  var exist_array = [];
                  result.forEach((element) => {
                    exist_array.push(element.lab_image)
                  });
                  var uncommonElements = [];

                  // Create sets for faster lookup
                  const set1 = new Set(req_array);
                  console.log("req_arrayreq_array", set1);
                  const set2 = new Set(exist_array);
                  console.log("req_arrayreq_array", set2);
                  for (const item of set1) {
                    if (!set2.has(item)) {
                      uncommonElements.push(item);
                    }
                  }
                  // Check for uncommon elements in arr2
                  for (const item of set2) {
                    if (!set1.has(item)) {
                      uncommonElements.push(item);
                    }
                  }
                  // console.log('uncommonElements', uncommonElements);
                  if (uncommonElements.length > 0) {
                    const filteredData = result.filter((item) => uncommonElements.includes(item.lab_image));
                    filteredData.forEach((element) => {
                      lab_img_service.DestoryLabImgBasicInfo({ where: { lab_image: element.lab_image } })
                        .then(data => {
                          res = data
                        }).catch(err => {
                          res = err
                        })
                    });
                  }

                }
                var file_image = req.files;
                console.log("file_imagefile_image", req.files);
                var as = []
                as.push(file_image)
                console.log("zxcvbnm,", as);
                const bucketName = process.env.GCP_BUCKET_NAME;
                // if (Array.isArray(file_image)) {
                const uploadImagePromises = as.map(async (element) => {
                  console.log("elementelement", element);
                  try {
                    const imgKey = Object.keys(element)[0];
                    const imgData = element[imgKey];
                    const fileName = imgData.name;
                    const buffer = element.data;
                    const file = storage.bucket(bucketName).file(`images/${fileName}`);
                    // Use createWriteStream to upload the file
                    const stream = file.createWriteStream();
                    // Write the buffer to the stream
                    stream.end(buffer);
                    // Wait for the upload to complete
                    await new Promise((resolve, reject) => {
                      stream.on('finish', resolve);
                      stream.on('error', reject);
                    });

                    const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

                    const l_data_img = {
                      lab_name_id: parseInt(lab_id),
                      lab_image: imageUrl,
                      active: 1,
                      created_by: req.user.id,
                      updated_by: req.user.id,
                    };

                    console.log("l_data_imgl_data_img", l_data_img);

                    await lab_img_service.CreateLablmgBasicInfo(l_data_img);
                  } catch (error) {
                    console.error("Error uploading image:", error);
                  }
                });

                // Wait for all promises to complete
                Promise.all(uploadImagePromises);
              })
            // if (lab_id) {
            //   const bucketName = process.env.GCP_BUCKET_NAME;
            //   if (lab_image.name) {
            //     const value = [];
            //     value.push(lab_image);
            //     const uploadImagePromises = value.map(async (element) => {
            //       const fileName = element.name;
            //       const buffer = element.data;
            //       const file = storage.bucket(bucketName).file(`images/${fileName}`);
            //       await file.save(buffer);
            //       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
            //       const l_data_img = {
            //         lab_name_id: lab_id,
            //         lab_image: imageUrl,
            //         active: active,
            //         created_by: req.user.id,
            //         updated_by: req.user.id,
            //       };
            //       await lab_img_service.CreateLablmgBasicInfo(l_data_img);
            //     });
            //     Promise.all(uploadImagePromises);
            //   }
            //   else {
            //     const uploadImagePromises = lab_image.map(async (element) => {
            //       const fileName = element.name;
            //       const buffer = element.data;
            //       const file = storage.bucket(bucketName).file(`images/${fileName}`);
            //       await file.save(buffer);
            //       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

            //       const l_data_img = {
            //         lab_name_id: lab_id,
            //         lab_image: imageUrl,
            //         active: active,
            //         created_by: req.user.id,
            //         updated_by: req.user.id,
            //       };

            //       await lab_img_service.CreateLablmgBasicInfo(l_data_img);
            //     });

            //     Promise.all(uploadImagePromises);
            //   }
            msg = "Updated successfully"
            cache.DEL(req.user.id + '_lab_basic_service')
            res.status(200).json(success_func(msg))
            // }
          }
          else {
            msg = "ID doesn't exist"
            res.status(400).json(failure_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })
    }
    else {
      msg = "lab_name is required";
      res.status(400).json(failure_func(msg))
    }
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg))
  }
}

// const UpdateLabBasicInfo = async (req, res, next) => {

//   id = req.params.id;
//   if (id) {
//     const lab_name = req.body.lab_name;
//     const lab_type_id = req.body.lab_type_id;
//     const sector_id = req.body.sector_id;
//     const accredation_id = req.body.accredation_id;
//     const lab_regNo = req.body.lab_regNo;
//     const about = req.body.about;
//     if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//       certicate_path = req.files.certicate_path;
//     } else {
//       certicate_path = req.body.certicate_path;
//     }
//     if (req.files && req.files.lab_image && req.files.lab_image.name) {
//       lab_image = req.files.lab_image;
//     } else {
//       lab_image = req.body.lab_image;
//     }
//     // try {
//     //   lab_image = req.files.lab_image;
//     // } catch {
//     //   lab_image_body = req.body.lab_image;
//     // }
//     try {
//       lab_or_scan = req.body.lab_or_scan;
//     } catch {
//       lab_or_scan = 0
//     }
//     const active = req.body.active;
//     const updated_by = req.user.id;
//     const updated_at = date();
//     if (lab_name) {
//       const l_data = {
//         lab_name: lab_name,
//         lab_type_id: parseInt(lab_type_id),
//         sector_id: parseInt(sector_id),
//         accredation_id: parseInt(accredation_id),
//         lab_regNo: lab_regNo,
//         certicate_path: certicate_path,
//         about: about,
//         lab_or_scan: lab_or_scan,
//         active: active,
//         updated_by: updated_by,
//         updated_at: updated_at
//       }
//       if (certicate_path) {
//         const bucketName = process.env.GCP_BUCKET_NAME;
//         const fileName = certicate_path.name;
//         const buffer = certicate_path.data;
//         const path = `images/${fileName}`;
//         const file = storage.bucket(bucketName).file(path);
//         // Upload the image to GCS
//         await file.save(buffer);
//         l_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//       }
//       else {
//         // If no image is provided, you may want to handle null or default values
//         certicate_path = req.body.certicate_path;
//         l_data.certicate_path = certicate_path;
//       }
//       await lab_basic_service.UpdateLabBasicInfo(id, l_data)
//         .then(data => {
//           if (data == 1) {
//             const lab_id = req.params.id;
//             lab_img_service.DestoryLablmgBasicInfo(lab_id)
//             if (lab_id) {
//               const bucketName = process.env.GCP_BUCKET_NAME;
//               if (lab_image.name) {
//                 const value = [];
//                 value.push(lab_image);
//                 const uploadImagePromises = value.map(async (element) => {
//                   const fileName = element.name;
//                   const buffer = element.data;
//                   const file = storage.bucket(bucketName).file(`images/${fileName}`);
//                   await file.save(buffer);
//                   const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
//                   const l_data_img = {
//                     lab_name_id: lab_id,
//                     lab_image: imageUrl,
//                     active: active,
//                     created_by: req.user.id,
//                     updated_by: req.user.id,
//                   };
//                   await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//                 });
//                 Promise.all(uploadImagePromises);
//               }
//               else {
//                 const uploadImagePromises = lab_image.map(async (element) => {
//                   const fileName = element.name;
//                   const buffer = element.data;
//                   const file = storage.bucket(bucketName).file(`images/${fileName}`);
//                   await file.save(buffer);
//                   const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//                   const l_data_img = {
//                     lab_name_id: lab_id,
//                     lab_image: imageUrl,
//                     active: active,
//                     created_by: req.user.id,
//                     updated_by: req.user.id,
//                   };

//                   await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//                 });

//                 Promise.all(uploadImagePromises);
//               }
//               msg = "Updated successfully"
//               cache.DEL(req.user.id + '_lab_basic_service')
//               res.status(200).json(success_func(msg))
//             }
//           } else {
//             msg = "ID doesn't exist"
//             res.status(400).json(failure_func(msg))
//           }
//         })
//         .catch(err => {
//           res.status(400).json(failure_func(err))
//         })
//     }
//     else {
//       msg = "lab_name is required";
//       res.status(400).json(failure_func(msg))
//     }
//   } else {
//     msg = "ID is required";
//     res.status(400).json(failure_func(msg))
//   }
// }

// const UpdateLabBasicInfo = async (req, res, next) => {
//   id = req.params.id;
//   if (id) {
//     const lab_name = req.body.lab_name;
//     const lab_type_id = req.body.lab_type_id;
//     const sector_id = req.body.sector_id;
//     const accredation_id = req.body.accredation_id;
//     const lab_regNo = req.body.lab_regNo;
//     const about = req.body.about;
//     if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//       certicate_path = req.files.certicate_path;
//     } else {
//       certicate_path = req.body.certicate_path;
//     }
//     try {
//       var lab_image = req.files.lab_image;
//     } catch {
//       lab_image_body = req.body.lab_image;
//     }
//     try {
//       lab_or_scan = req.body.lab_or_scan;
//     } catch {
//       lab_or_scan = 0
//     }
//     const active = req.body.active;
//     var created_by = req.user.id;
//     var updated_by = req.user.id;
//     const updated_at = date();
//     if (lab_name) {
//       const l_data = {
//         lab_name: lab_name,
//         lab_type_id: parseInt(lab_type_id),
//         sector_id: parseInt(sector_id),
//         accredation_id: parseInt(accredation_id),
//         lab_regNo: lab_regNo,
//         lab_or_scan: lab_or_scan,
//         about: about,
//         active: active,
//         updated_by: updated_by,
//         updated_at: updated_at
//       }
//       if (certicate_path) {
//         const bucketName = process.env.GCP_BUCKET_NAME;
//         const fileName = certicate_path.name;
//         const buffer = certicate_path.data;
//         const path = `images/${fileName}`;
//         const file = storage.bucket(bucketName).file(path);
//         // Upload the image to GCS
//         await file.save(buffer);
//         l_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//       }
//       else {
//         certicate_path = req.body.certicate_path;
//         l_data.certicate_path = certicate_path;
//       }
//       await lab_basic_service.UpdateLabBasicInfo(id, l_data)
//         .then(data => {
//           if (data == 1) {
//             const lab_id = req.params.id;
//             lab_img_service.DestoryLablmgBasicInfo(lab_id)
//               .then(result => {
//                 if (lab_id) {
//                   const bucketName = process.env.GCP_BUCKET_NAME;
//                   if (lab_image.name) {
//                     const value = [];
//                     value.push(lab_image);
//                     const uploadImagePromises = value.map(async (element) => {
//                       const fileName = element.name;
//                       const buffer = element.data;
//                       const file = storage.bucket(bucketName).file(`images/${fileName}`);
//                       await file.save(buffer);
//                       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
//                       const l_data_img = {
//                         lab_name_id: lab_id,
//                         lab_image: imageUrl,
//                         active: active,
//                         created_by: created_by,
//                         updated_by: updated_by,
//                       };
//                       await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//                     });
//                     Promise.all(uploadImagePromises);
//                   }
//                   else {
//                     const uploadImagePromises = lab_image.map(async (element) => {
//                       const fileName = element.name;
//                       const buffer = element.data;
//                       const file = storage.bucket(bucketName).file(`images/${fileName}`);
//                       await file.save(buffer);
//                       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
//                       const l_data_img = {
//                         lab_name_id: lab_id,
//                         lab_image: imageUrl,
//                         active: active,
//                         created_by: created_by,
//                         updated_by: created_by,
//                       };
//                       await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//                     });
//                     Promise.all(uploadImagePromises);
//                   }
//                 }
//             // const lab_id = req.params.id;
//             // lab_img_service.DestoryLablmgBasicInfo(lab_id)
//             //   .then(result => {
//             //     if (lab_id) {
//             //       const bucketName = process.env.GCP_BUCKET_NAME;
//             //       if (lab_image.name) {
//             //         const value = [];
//             //         value.push(lab_image);
//             //         const uploadImagePromises = value.map(async (element) => {
//             //           const fileName = element.name;
//             //           const buffer = element.data;
//             //           const file = storage.bucket(bucketName).file(`images/${fileName}`);
//             //           await file.save(buffer);
//             //           const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
//             //           const l_data_img = {
//             //             lab_name_id: lab_id,
//             //             lab_image: imageUrl,
//             //             active: active,
//             //             created_by: created_by,
//             //             updated_by: updated_by,
//             //           };
//             //           await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//             //         });
//             //         Promise.all(uploadImagePromises);
//             //       }
//             //       else {
//             //         const uploadImagePromises = lab_image.map(async (element) => {
//             //           const fileName = element.name;
//             //           const buffer = element.data;
//             //           const file = storage.bucket(bucketName).file(`images/${fileName}`);
//             //           await file.save(buffer);
//             //           const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;
//             //           const l_data_img = {
//             //             lab_name_id: lab_id,
//             //             lab_image: imageUrl,
//             //             active: active,
//             //             created_by: created_by,
//             //             updated_by: created_by,
//             //           };
//             //           await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//             //         });
//             //         Promise.all(uploadImagePromises);
//             //       }
//             //     }
//               })
//               .then(() => {
//                 msg = "Updated successfully";
//                 cache.DEL(req.user.id + '_lab_basic_service');
//                 res.status(200).json(success_func(msg));
//               })
//               .catch((error) => {
//                 console.error('Error:', error);
//                 res.status(500).json(failure_func("Internal Server Error"));
//               });
//           }
//           else {
//             msg = "ID doesn't exist"
//             res.status(400).json(failure_func(msg))
//           }
//         })
//         .catch(err => {
//           res.status(400).json(failure_func(err))
//         })
//     }
//     else {
//       msg = "lab_name is required";
//       res.status(400).json(failure_func(msg))
//     }
//   }
//   else {
//     msg = "ID is required";
//     res.status(400).json(failure_func(msg))
//   }
// }

// const UpdateLabBasicInfo = async (req, res, next) => {
//   id = req.params.id;
//   // console.log(req.files, "asdghjkl;'sdfgjiko");
//   if (id) {
//     lab_name = req.body.lab_name;
//     lab_type_id = req.body.lab_type_id;
//     sector_id = req.body.sector_id;
//     accredation_id = req.body.accredation_id;
//     lab_regNo = req.body.lab_regNo;
//     about = req.body.about;
//     if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//       certicate_path = req.files.certicate_path;
//     } else {
//       certicate_path = req.body.certicate_path;
//     }
//     try {
//       lab_image = req.files.lab_image;
//     } catch {
//       lab_image_body = req.body.lab_image;
//     }
//     isApproved = req.body.isApproved;
//     approve_date = req.body.approve_date;
//     approved_by = req.body.approved_by;
//     active = req.body.active;
//     updated_by = req.user.id;
//     updated_at = date();
//     if (lab_name) {
//       const l_data = {
//         lab_name: lab_name,
//         lab_type_id: parseInt(lab_type_id),
//         sector_id: parseInt(sector_id),
//         accredation_id: parseInt(accredation_id),
//         lab_regNo: lab_regNo,
//         certicate_path: certicate_path,
//         about: about,
//         active: parseInt(active),
//         updated_by: updated_by,
//         updated_at: updated_at,
//         isApproved: 0
//       }
//       if (req.files && req.files.certicate_path && req.files.certicate_path.name) {
//         l_data.certicate_path = certicate_path.name;
//         buffer = certicate_path.data;
//         path = './media/' + certicate_path.name;
//         fs.writeFile(path.toString(), buffer, function (err) {
//           if (err) {
//             return console.log(err);
//           }
//         });
//       } else {
//         certicate_path = req.body.certicate_path;
//         l_data.certicate_path = certicate_path;
//       }

//       await lab_basic_service.GetbyName(lab_regNo)
//         .then(basic_data => {
//           if (basic_data.length > 0) {
//             msg = "Register Number already exists";
//             return res.status(200).json(failure_func(msg))
//           } else {
//             lab_basic_service.UpdateLabBasicInfo(id, l_data)
//               .then(data => {
//                 if (data == 1) {
//                   const lab_id = req.params.id;
//                   lab_img_service.CheckLabImgmgBasicInfo(lab_id)
//                     .then(result => {
//                       // console.log(req.files, "req.filesadsfg");
//                       if (req.files == null) {
//                         // console.log(req.body.lab_image, "req.body.lab_image");
//                         const lab_image_body_data = req.body.lab_image.toString();
//                         var req_array = lab_image_body_data.split(',');
//                         var exist_array = [];
//                         result.forEach((element) => {
//                           exist_array.push(element.lab_image)
//                         });
//                         var uncommonElements = [];


//                         const set1 = new Set(req_array);
//                         const set2 = new Set(exist_array);
//                         for (const item of set1) {
//                           if (!set2.has(item)) {
//                             uncommonElements.push(item);
//                           }
//                         }

//                         // Check for uncommon elements in arr2
//                         for (const item of set2) {
//                           if (!set1.has(item)) {
//                             uncommonElements.push(item);
//                           }
//                         }

//                         if (uncommonElements.length > 0) {
//                           const filteredData = result.filter((item) => uncommonElements.includes(item.lab_image));
//                           filteredData.forEach((element) => {
//                             labimginfomodel.destroy({ where: { lab_image: element.lab_image } })
//                               .then(data => {
//                                 res = data
//                               }).catch(err => {
//                                 res = err
//                               })
//                           });
//                         }
//                       }
//                       else {
//                         // console.log('else');
//                         const lab_image = req.files.lab_image;
//                         const check_file = lab_image.length;
//                         if (check_file == undefined) {
//                           const dummy = [];
//                           dummy.push(lab_image);
//                           dummy.forEach((element) => {
//                             const lab_image = element.name;
//                             const record = element.data
//                             path = './media/' + element.name;
//                             fs.writeFile(path.toString(), buffer, function (err) {
//                               if (err) {
//                                 return console.log(err);
//                               }
//                             });
//                             l_data_img = {
//                               lab_name_id: req.params.id,
//                               lab_image: record,
//                               active: active,
//                               created_by: updated_by,
//                               updated_by: updated_by
//                             }
//                             // console.log('i_data_img', l_data_img);
//                             lab_img_service.CreateLablmgBasicInfo(l_data_img)
//                           });
//                         } else {
//                           lab_image.forEach((element) => {
//                             const lab_image = element.name;
//                             const record = element.data;
//                             buffer = element.data
//                             path = './media/' + element.name;
//                             fs.writeFile(path.toString(), buffer, function (err) {
//                               if (err) {
//                                 return console.log(err);
//                               }
//                             });
//                             l_data_img = {
//                               lab_name_id: req.params.id,
//                               lab_image: record,
//                               active: active,
//                               created_by: updated_by,
//                               updated_by: updated_by
//                             }
//                             // console.log('i_data_img', l_data_img);
//                             lab_img_service.CreateLablmgBasicInfo(l_data_img)

//                           });
//                         }
//                       }
//                     })
//                   msg = "Updated successfully"
//                   cache.DEL(req.user.id + '_lab_basic_service')
//                   res.status(200).json(success_func(msg))
//                 } else {
//                   msg = "ID doesn't exist"
//                   res.status(400).json(failure_func(msg))
//                 }
//               })
//               .catch(err => {
//                 res.status(400).json(failure_func(err))
//               })
//           }
//         })
//     }
//     else {
//       msg = "lab_name is required";
//       res.status(400).json(failure_func(msg))
//     }
//   } else {
//     msg = "ID is required";
//     res.status(400).json(failure_func(msg))
//   }
// };

// const UpdateLabBasicInfo = async (req, res, next) => {
//   id = req.params.id;
//   // console.log(req.files, "asdghjkl;'sdfgjiko");
//   if (id) {
//     lab_name = req.body.lab_name;
//     lab_type_id = req.body.lab_type_id;
//     sector_id = req.body.sector_id;
//     accredation_id = req.body.accredation_id;
//     lab_regNo = req.body.lab_regNo;
//     about = req.body.about;
//     certicate_path = req.files ? req.files.certicate_path : null;
//     try {
//       lab_image = req.files.lab_image;
//     } catch {
//       lab_image_body = req.body.lab_image;
//     }
//     isApproved = req.body.isApproved;
//     approve_date = req.body.approve_date;
//     approved_by = req.body.approved_by;
//     active = req.body.active;
//     updated_by = req.user.id;
//     updated_at = date();
//     if (lab_name) {
//       const l_data = {
//         lab_name: lab_name,
//         lab_type_id: parseInt(lab_type_id),
//         sector_id: parseInt(sector_id),
//         accredation_id: parseInt(accredation_id),
//         lab_regNo: lab_regNo,
//         certicate_path: certicate_path,
//         about: about,
//         active: parseInt(active),
//         updated_by: updated_by,
//         updated_at: updated_at,
//         isApproved: 0
//       }
//       if (certicate_path) {
//         const bucketName = process.env.GCP_BUCKET_NAME;
//         const fileName = certicate_path.name;
//         const buffer = certicate_path.data;
//         const path = `images/${fileName}`;
//         const file = storage.bucket(bucketName).file(path);
//         // Upload the image to GCS
//         await file.save(buffer);
//         l_data.certicate_path = `https://storage.googleapis.com/${bucketName}/${path}`;
//       }
//       else {
//         // If no image is provided, you may want to handle null or default values
//         l_data.certicate_path = null; // or set a default image URL
//       }
//       await lab_basic_service.GetbyLabRegNoId(id)
//         // .then(data => {
//         //   let existingRegNo = data[0].lab_regNo
//         //   let isLabRegNoExist = l_data.lab_regNo == existingRegNo
//         //   if (isLabRegNoExist) {
//         //     if (data.length > 0) {
//         //       lab_basic_service.UpdateLabBasicInfo(id, l_data)
//         //         .then(data => {
//         //           if (data == 1) {
//         //             const lab_id = req.params.id;
//         //             lab_img_service.CheckLabImgmgBasicInfo(lab_id)
//         //               .then(result => {
//         //                 // console.log(req.files, "req.filesadsfg");
//         //                 if (req.files == null) {
//         //                   // console.log(req.body.lab_image, "req.body.lab_image");
//         //                   const lab_image_body_data = req.body.lab_image.toString();
//         //                   var req_array = lab_image_body_data.split(',');
//         //                   var exist_array = [];
//         //                   result.forEach((element) => {
//         //                     exist_array.push(element.lab_image)
//         //                   });
//         //                   var uncommonElements = [];


//         //                   const set1 = new Set(req_array);
//         //                   const set2 = new Set(exist_array);
//         //                   for (const item of set1) {
//         //                     if (!set2.has(item)) {
//         //                       uncommonElements.push(item);
//         //                     }
//         //                   }

//         //                   // Check for uncommon elements in arr2
//         //                   for (const item of set2) {
//         //                     if (!set1.has(item)) {
//         //                       uncommonElements.push(item);
//         //                     }
//         //                   }

//         //                   if (uncommonElements.length > 0) {
//         //                     const filteredData = result.filter((item) => uncommonElements.includes(item.lab_image));
//         //                     filteredData.forEach((element) => {
//         //                       labimginfomodel.destroy({ where: { lab_image: element.lab_image } })
//         //                         .then(data => {
//         //                           res = data
//         //                         }).catch(err => {
//         //                           res = err
//         //                         })
//         //                     });
//         //                   }
//         //                 }
//         //                 else {
//         //                   console.log('else');
//         //                   const lab_image = req.files.lab_image;
//         //                   const check_file = lab_image.length;
//         //                   if (check_file == undefined) {
//         //                     const dummy = [];
//         //                     dummy.push(lab_image);
//         //                     dummy.forEach((element) => {
//         //                       const lab_image = element.name;
//         //                       const record = element.data
//         //                       path = './media/' + element.name;
//         //                       fs.writeFile(path.toString(), buffer, function (err) {
//         //                         if (err) {
//         //                           return console.log(err);
//         //                         }
//         //                       });
//         //                       l_data_img = {
//         //                         lab_name_id: req.params.id,
//         //                         lab_image: record,
//         //                         active: active,
//         //                         created_by: updated_by,
//         //                         updated_by: updated_by
//         //                       }
//         //                       console.log('i_data_img', l_data_img);
//         //                       lab_img_service.CreateLablmgBasicInfo(l_data_img)
//         //                     });
//         //                   }
//         //                   else {
//         //                     lab_image.forEach((element) => {
//         //                       const lab_image = element.name;
//         //                       const record = element.data;
//         //                       buffer = element.data
//         //                       path = './media/' + element.name;
//         //                       fs.writeFile(path.toString(), buffer, function (err) {
//         //                         if (err) {
//         //                           return console.log(err);
//         //                         }
//         //                       });
//         //                       l_data_img = {
//         //                         lab_name_id: req.params.id,
//         //                         lab_image: record,
//         //                         active: active,
//         //                         created_by: updated_by,
//         //                         updated_by: updated_by
//         //                       }
//         //                       // console.log('i_data_img', l_data_img);
//         //                       lab_img_service.CreateLablmgBasicInfo(l_data_img)

//         //                     });
//         //                   }
//         //                 }
//         //               })
//         //             msg = "Updated successfully"
//         //             cache.DEL(req.user.id + '_lab_basic_service')
//         //             res.status(200).json(success_func(msg))
//         //           } else {
//         //             msg = "ID doesn't exist"
//         //             res.status(400).json(failure_func(msg))
//         //           }
//         //         })
//         //         .catch(err => {
//         //           res.status(400).json(failure_func(err))
//         //         })

//         //     }
//         //   }
//         //   else {
//         //     lab_basic_service.GetbyLabRegNoAll(lab_regNo)
//         //       .then(data => {
//         //         if (data.length > 0) {
//         //           msg = "Register Number already exists";
//         //           return res.status(200).json(failure_func(msg))
//         //         }
//         //         else {
//         //           lab_basic_service.UpdateLabBasicInfo(id, l_data)
//         //             .then(data => {
//         //               if (data == 1) {
//         //                 const lab_id = req.params.id;
//         //                 lab_img_service.CheckLabImgmgBasicInfo(lab_id)
//         //                   .then(result => {
//         //                     // console.log(req.files, "req.filesadsfg");
//         //                     if (req.files == null) {
//         //                       // console.log(req.body.lab_image, "req.body.lab_image");
//         //                       const lab_image_body_data = req.body.lab_image.toString();
//         //                       var req_array = lab_image_body_data.split(',');

//         //                       var exist_array = [];
//         //                       result.forEach((element) => {
//         //                         exist_array.push(element.lab_image)
//         //                       });
//         //                       var uncommonElements = [];

//         //                       const set1 = new Set(req_array);
//         //                       const set2 = new Set(exist_array);
//         //                       for (const item of set1) {
//         //                         if (!set2.has(item)) {
//         //                           uncommonElements.push(item);
//         //                         }
//         //                       }

//         //                       // Check for uncommon elements in arr2
//         //                       for (const item of set2) {
//         //                         if (!set1.has(item)) {
//         //                           uncommonElements.push(item);
//         //                         }
//         //                       }

//         //                       if (uncommonElements.length > 0) {
//         //                         const filteredData = result.filter((item) => uncommonElements.includes(item.lab_image));
//         //                         filteredData.forEach((element) => {
//         //                           labimginfomodel.destroy({ where: { lab_image: element.lab_image } })
//         //                             .then(data => {
//         //                               res = data
//         //                             }).catch(err => {
//         //                               res = err
//         //                             })
//         //                         });
//         //                       }
//         //                     }
//         //                     else {
//         //                       // console.log('else');
//         //                       const lab_image = req.files.lab_image;
//         //                       const check_file = lab_image.length;
//         //                       if (check_file == undefined) {
//         //                         const dummy = [];
//         //                         dummy.push(lab_image);
//         //                         dummy.forEach((element) => {
//         //                           const lab_image = element.name;
//         //                           const record = element.data
//         //                           path = './media/' + element.name;
//         //                           fs.writeFile(path.toString(), buffer, function (err) {
//         //                             if (err) {
//         //                               return console.log(err);
//         //                             }
//         //                           });
//         //                           l_data_img = {
//         //                             lab_name_id: req.params.id,
//         //                             lab_image: record,
//         //                             active: active,
//         //                             created_by: updated_by,
//         //                             updated_by: updated_by
//         //                           }
//         //                           // console.log('i_data_img', l_data_img);
//         //                           lab_img_service.CreateLablmgBasicInfo(l_data_img)
//         //                         });
//         //                       }
//         //                       else {
//         //                         lab_image.forEach((element) => {
//         //                           const lab_image = element.name;
//         //                           const record = element.data;
//         //                           buffer = element.data
//         //                           path = './media/' + element.name;
//         //                           fs.writeFile(path.toString(), buffer, function (err) {
//         //                             if (err) {
//         //                               return console.log(err);
//         //                             }
//         //                           });
//         //                           l_data_img = {
//         //                             lab_name_id: req.params.id,
//         //                             lab_image: record,
//         //                             active: active,
//         //                             created_by: updated_by,
//         //                             updated_by: updated_by
//         //                           }
//         //                           // console.log('i_data_img', l_data_img);
//         //                           lab_img_service.CreateLablmgBasicInfo(l_data_img)

//         //                         });
//         //                       }
//         //                     }
//         //                   })
//         //                 msg = "Updated successfully"
//         //                 cache.DEL(req.user.id + '_lab_basic_service')
//         //                 res.status(200).json(success_func(msg))
//         //               } else {
//         //                 msg = "ID doesn't exist"
//         //                 res.status(400).json(failure_func(msg))
//         //               }
//         //             })
//         //             .catch(err => {
//         //               res.status(400).json(failure_func(err))
//         //             })

//         //         }

//         //       })
//         //   }
//         // })

// .then(data => {
//   let existingRegNo = data[0].lab_regNo;
//   let isLabRegNoExist = l_data.lab_regNo == existingRegNo;
//   if (isLabRegNoExist) {
//     if (data.length > 0) {
//       lab_basic_service.UpdateLabBasicInfo(id, l_data)
//         .then(data => {
//           if (data == 1) {
//             const lab_id = req.params.id;
//             lab_img_service.DestoryLablmgBasicInfo(lab_id)
//               .then(result => {
//                 if (lab_id) {
//                   if (req.body.lab_image == undefined) {
//                     if (lab_image.length) {
//                       lab_image.forEach((element) => {
//                         // ... existing code ...
//                         const bucketName = process.env.GCP_BUCKET_NAME;
//                         const fileName = element.name;
//                         const file = storage.bucket(bucketName).file(fileName);

//                         // Upload file to GCS
//                         file.createWriteStream()
//                           .end(element.data, 'base64', () => {
//                             // File uploaded successfully.
//                             l_data_img = {
//                               lab_name_id: data.dataValues.id,
//                               lab_image: `https://storage.googleapis.com/${bucketName}/${fileName}`,
//                               active: active,
//                               created_by: created_by,
//                               updated_by: updated_by
//                             };

//                             lab_img_service.CreateLablmgBasicInfo(l_data_img);
//                           });
//                       });
//                     }
//                   } else {
//                     const lab_image_body_data = req.body.lab_image;
//                     l_data.lab_image = lab_image_body_data;
//                     var a = lab_image_body_data.split(",");
//                     a.forEach(element => {
//                       // ... existing code ...
//                       const bucketName = process.env.GCP_BUCKET_NAME;
//                       const fileName = generateUniqueFileName(); // Implement a function to generate a unique filename
//                       const file = storage.bucket(bucketName).file(fileName);

//                       // Upload file to GCS
//                       file.createWriteStream()
//                         .end(Buffer.from(element, 'base64'), () => {
//                           // File uploaded successfully.
//                           l_data_img = {
//                             lab_name_id: lab_id,
//                             lab_image: `https://storage.googleapis.com/${bucketName}/${fileName}`,
//                             active: active,
//                             created_by: req.user.id,
//                             updated_by: req.user.id
//                           };

//                           lab_img_service.CreateLablmgBasicInfo(l_data_img);
//                         });
//                     });
//                   }
//                 }
//               })
//             msg = "Updated successfully";
//             cache.DEL(req.user.id + '_lab_basic_service');
//             res.status(200).json(success_func(msg));
//           } else {
//             msg = "ID doesn't exist";
//             res.status(400).json(failure_func(msg));
//           }

//         })
//         .catch(err => {
//           res.status(400).json(failure_func(err));
//         });
//     }
//   } else {
//     lab_basic_service.GetbyLabRegNoAll(lab_regNo)
//       .then(data => {
//         if (data.length > 0) {
//           msg = "Register Number already exists";
//           return res.status(200).json(failure_func(msg));
//         } else {
//           lab_basic_service.UpdateLabBasicInfo(id, l_data)
//             .then(data => {
//               if (data == 1) {
//                 const lab_id = req.params.id;
//                 lab_img_service.CheckLabImgmgBasicInfo(lab_id)
//                   .then(result => {
//                     if (req.files == null) {
//                       handleNoNewFiles(result);
//                     } else {
//                       handleNewFiles(result, req.files.lab_image);
//                     }
//                   })
//                   .then(() => {
//                     msg = "Updated successfully";
//                     cache.DEL(req.user.id + '_lab_basic_service');
//                     res.status(200).json(success_func(msg));
//                   })
//                   .catch(err => {
//                     res.status(400).json(failure_func(err));
//                   });
//               } else {
//                 msg = "ID doesn't exist";
//                 res.status(400).json(failure_func(msg));
//               }
//             })
//             .catch(err => {
//               res.status(400).json(failure_func(err));
//             });
//         }
//       });
//   }
// });

// function handleNoNewFiles(result) {
//   // Handle logic when no new files are uploaded
//   // You can implement any additional logic based on your requirements
// }

// async function handleNewFiles(result, labImages) {
//   const bucketName = process.env.GCP_BUCKET_NAME;

//   const uploadImagePromises = labImages.map(async (element) => {
//     try {
//       const fileName = element.name;
//       const buffer = element.data;

//       if (!buffer) {
//         throw new Error('File buffer is undefined or empty.');
//       }

//       // Upload image to GCS
//       const file = storage.bucket(bucketName).file(`images/${fileName}`);
//       await file.save(buffer);

//       const imageUrl = `https://storage.googleapis.com/${bucketName}/images/${fileName}`;

//       // Create image data for your database
//       const l_data_img = {
//         lab_name_id: req.params.id,
//         lab_image: imageUrl,
//         active: active,
//         created_by: updated_by,
//         updated_by: updated_by
//       };

//       // Save image data to your database
//       await lab_img_service.CreateLablmgBasicInfo(l_data_img);
//     } catch (error) {
//       console.error('Error uploading image:', error.message);
//       // Handle error as needed
//     }
//   });

//   // Wait for all image uploads and database inserts to complete
//   await Promise.all(uploadImagePromises);

//   // You can implement additional logic here if needed
// }

//     }
//     else {
//       msg = "lab_name is required";
//       res.status(400).json(failure_func(msg))
//     }
//   } else {
//     msg = "ID is required";
//     res.status(400).json(failure_func(msg))
//   }
// };

const LabApprove = async (req, res, next) => {
  const id = req.params.id;
  if (id) {
    const { isApproved, approve_date, approved_by, reason, id } = req.body;
    // if (isApproved) {
    if (isApproved === 1) {
      const a_data = {
        id: parseInt(id),
        isApproved: isApproved,
        approve_date: approve_date,
        approved_by: approved_by,
        reason: reason
      }
      lab_basic_service.CreateApprove(id, a_data)
        .then(data => {
          if (data.errors) {
            msg = data.errors[0].message;
            res.status(400).json(failure_func(msg))
          } else {
            msg = "Approved Successfully"
            // cache.DEL(req.user.id + '_lab_basic_service')
            res.status(200).json(success_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })
    }
    else {
      const a_data = {
        id: parseInt(id),
        isApproved: isApproved,
        approve_date: approve_date,
        approved_by: approved_by,
        reason: reason
      }
      lab_basic_service.CreateApprove(id, a_data)
        .then(data => {
          if (data.errors) {
            msg = data.errors[0].message;
            res.status(400).json(failure_func(msg))
          } else {
            msg = "Rejected Successfully"
            // cache.DEL(req.user.id + '_lab_basic_service')
            res.status(200).json(success_func(msg))
          }
        })
        .catch(err => {
          res.status(400).json(failure_func(err))
        })

    }
    // }
  }
}

const DeleteLabBasicInfo = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await lab_basic_service.DestroyLabBasicInfo(id)
      .then(data => {
        if (data == 1) {
          msg = "Deleted successfully"
          cache.DEL(req.user.id + '_lab_basic_service')
          res.status(200).json(success_func(msg))
        } else {
          msg = "ID doesn't exist"
          res.status(200).json(success_func(msg))
        }
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg))
  }
}

const updateIsapprove = async (req, res, next) => {
  id = req.params.id;
  if (id) {
    await lab_basic_service.UpdateIsapprove(id)
      .then(data => {
        if (data == 1) {
          msg = "Updated successfully"
          res.status(200).json(success_func(msg))
        }
        else {
          msg = "ID doesn't exist"
          res.status(200).json(success_func(msg))
        }
      })
      .catch(err => {
        res.status(400).json(failure_func(err))
      })
  } else {
    msg = "ID is required";
    res.status(400).json(failure_func(msg))
  }
}

module.exports = {
  FetchLabBasicInfo,
  NewLabBasicInfo,
  UpdateLabBasicInfo,
  DeleteLabBasicInfo,
  LabApprove,
  updateIsapprove
}