const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const lab_service_info = require('../services/lab_service_info');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/lab_addCheck_service');

const FetchLabServiceInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        await lab_service_info.GetbyId(lab_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        // data = await cache.GET(req.user.id + '_lab_service_info');
        // if (data) {
        //     res.status(200).json(success_func(JSON.parse(data)))
        // } else {
        await lab_service_info.Get()
            .then(data => {
                // cache.SET(req.user.id + '_lab_service_info', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}
// }

const NewLabServiceInfo = async (req, res, next) => {
    const lab_name_id = req.body.lab_name_id;
    const service_name_id = req.body.service_name_id;
    const active = req.body.active;
    const addCheck = 8;
    const query = AddCheck(req.body.lab_name_id)
    const created_by = req.user.id;
    const updated_by = req.user.id;

    if (lab_name_id && service_name_id && Array.isArray(service_name_id) && service_name_id.length > 0) {

        for (const i of service_name_id) {
            const l_data = {
                lab_name_id: lab_name_id,
                service_name_id: i,
                active: active,
                // addCheck: addCheck,
                created_by: created_by,
                updated_by: updated_by
            }
            console.log(l_data,'l_data');
            await lab_service_info.CreateLabService(l_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;

                    } else {
                        msg = "Created Successfully"

                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        msg = "Created Successfully"
        res.status(200).json(success_func(msg))

    } else {
        msg = "lab_name_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateLabServiceInfo = async (req, res, next) => {
    lab_name_id = req.params.lab_name_id;
    if (lab_name_id) {
        lab_service_info.DestroyLabService(lab_name_id)
        service_name_id = req.body.service_name_id;
        lab_name_id = req.body.lab_name_id;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        for (const i of service_name_id) {
            const l_data = {
                lab_name_id: parseInt(lab_name_id),
                service_name_id: parseInt(i),
                active: active,
                created_by: req.user.id,
                updated_by: updated_by
            }
            console.log(l_data);
            await lab_service_info.CreateLabService(l_data)
                .then(data => {
                    if (data.errors) {
                        msg = data.errors[0].message;
                    } else {
                        msg = "Updated Successfully"
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        }
        msg = "Updated Successfully"
        res.status(200).json(success_func(msg))
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteLabServiceInfo = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await lab_service_info.DestroyLabService(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_lab_service_info')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewLabServiceInfo,
    FetchLabServiceInfo,
    UpdateLabServiceInfo,
    DeleteLabServiceInfo
}