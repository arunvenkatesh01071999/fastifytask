const TermsInfo = require('../models/LabTermsInfoModel');
const labInfo = require('../models/LabBasicInfoModel');


const Get = async () => {
    await TermsInfo.findAll({ include: [labInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetbyId = async (lab_name_id) => {
    await TermsInfo.findAll({ where: { lab_name_id: lab_name_id }, include: [labInfo] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const GetId = async (id) => {
    await TermsInfo.findAll({ where: { lab_name_id: id }, raw: true })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
}

const CreateTermCondition = async (tc_data) => {
    await TermsInfo.create(tc_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}

const UpdateTermsInfo = async (id, tc_data) => {
    await TermsInfo.update(tc_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
}

const DestroyTermsInfo = async (id) => {
    await TermsInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
}


module.exports = {
    Get,
    GetbyId,
    GetId,
    CreateTermCondition,
    UpdateTermsInfo,
    DestroyTermsInfo
};
