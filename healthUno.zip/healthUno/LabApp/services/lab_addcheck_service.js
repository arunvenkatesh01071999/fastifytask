const db1 = require('../../config/db1');
const { Sequelize } = require('sequelize');
const moment = require('moment/moment');
const lab_info_pass_model = require('../models/LabAddcheckModel')



const lab_info = async (u_data) => {
    await lab_info_pass_model.create(u_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = lab_info;