const AddressInfo = require('../models/LabAddressInfoModel');
const LabInfo = require('../models/LabBasicInfoModel');
const CityMaster = require('../../MastersApp/models/CityModel');
const StateMaster = require('../../MastersApp/models/StateModel');
const CountryMaster = require('../../MastersApp/models/CountryModel');


const Get = async () => {
    await AddressInfo.findAll({ include :[LabInfo,CityMaster,StateMaster,CountryMaster] })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const GetbyId = async (lab_name_id) => {
    await AddressInfo.findAll({
        where: { lab_name_id: lab_name_id },include :[LabInfo,CityMaster,StateMaster,CountryMaster]
    })
        .then(data => {
            res = data
        })
        .catch(err => {
            res = err
        })
    return res
};

const CreateAddress = async (a_data) => {
    console.log(a_data,"a_data");
    await AddressInfo.create(a_data)
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

const UpdateAddress = async (id, a_data) => {
    await AddressInfo.update(a_data, { where: { id: id } })
        .then(data => {
            res = data[0]
        }).catch(err => {
            res = err
        })
    return res
};

const DestroyAddress = async (id) => {
    await AddressInfo.destroy({ where: { id: id } })
        .then(data => {
            res = data
        }).catch(err => {
            res = err
        })
    return res
};

module.exports = {
    Get,
    GetbyId,
    CreateAddress,
    UpdateAddress,
    DestroyAddress,
};
