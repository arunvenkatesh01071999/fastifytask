const express = require('express');
const router = express();
const LabAddressInfoController = require('../../LabApp/controller/LabAddressInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabAddressInfoController.FetchLabAddressInfo);
router.get('/:lab_name_id', verify_token, LabAddressInfoController.FetchLabAddressInfo);
router.post('/', verify_token, LabAddressInfoController.NewLabAddressInfo);
router.put('/:id', verify_token, LabAddressInfoController.UpdateLabAddressInfo);
router.delete('/:id', verify_token, LabAddressInfoController.DeleteLabAddressInfo);


module.exports = router; 