const express = require('express');
const router = express();
const LabInchargeInfoController = require('../../LabApp/controller/LabInchargeInfoController')
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabInchargeInfoController.FetchLabInchargeInfo);
router.get('/:lab_name_id', verify_token, LabInchargeInfoController.FetchLabInchargeInfo);
router.post('/', verify_token, LabInchargeInfoController.NewLabInchargeInfo);
router.put('/:id', verify_token, LabInchargeInfoController.UpdateLabinChargeInfo);
router.delete('/:id', verify_token, LabInchargeInfoController.DeleteLabInChargeInfo);


module.exports = router; 