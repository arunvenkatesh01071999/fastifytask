const express = require('express');
const router = express();
const ServiceOfferController = require('../controller/LabServiceOfferController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, ServiceOfferController.FetchOfferInfo);
router.get('/:lab_name_id', verify_token, ServiceOfferController.FetchOfferInfo);
router.post('/', verify_token, ServiceOfferController.NewLabOffer);
router.put('/:lab_name_id', verify_token, ServiceOfferController.UpdateLabOffer);
router.put('/:lab_name_id', verify_token, ServiceOfferController.DeleteOfferInfo);

module.exports = router;