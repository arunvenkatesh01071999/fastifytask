const express = require('express');
const router = express();
const LabRepositoryInfoController = require('../../LabApp/controller/LabRepoInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, LabRepositoryInfoController.FetchLabRepositoryInfo);
router.get('/:lab_name_id', verify_token, LabRepositoryInfoController.FetchLabRepositoryInfo);



module.exports = router; 