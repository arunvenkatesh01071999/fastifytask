require('dotenv').config();
const Bull = require('bull');

const connectQueue = new Bull('email', {
    redis: {
        port: process.env.REDIS_QUEUE_PORT,
        host: process.env.REDIS_HOST_NAME
    }
})

module.exports = connectQueue;  