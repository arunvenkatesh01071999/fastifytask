// const redis = require('redis');
// require('dotenv').config();

// // Get the Redis host and port from environment variables
// const REDIS_HOST = process.env.REDIS_HOST_NAME || 'redis';
// const REDIS_PORT = process.env.REDIS_CACHE_PORT || 6379;

// // Create the Redis client with the specified host and port
// const client = redis.createClient({
//   host: REDIS_HOST,
//   port: REDIS_PORT,
// });

// client.on('error', function (err) {
//   console.log("Redis not connected", err);
// });

// client.on('connect', function () {
//   console.log("Redis Cache connected");
// });

// module.exports = client;

const redis = require('redis');
require('dotenv').config()
REDIS_PORT = process.env.REDIS_CACHE_PORT
const client = redis.createClient(REDIS_PORT)

client.connect();
client.on('error', function (err) {
    console.log("Redis not connected");
})
client.on('connect', function (err) {
    console.log("Redis Cache connected");
})

module.exports = client;