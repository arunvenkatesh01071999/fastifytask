require('dotenv').config();
const connectQueue = require('../config/redis_queue');
const EmailProcess = require('./email_process');

const { ExpressAdapter, createBullBoard, BullAdapter, BullMQAdapter } = require('@bull-board/express');
const serverAdapter = new ExpressAdapter();
serverAdapter.setBasePath('/admin/queues');
const { addQueue, removeQueue, setQueues, replaceQueues } = createBullBoard({
    queues: [new BullAdapter(connectQueue)],
    serverAdapter: serverAdapter,
});
path = serverAdapter.getRouter();

connectQueue.process(EmailProcess);

const add_to_queue = (data) => {
    connectQueue.add(data, {
        // attempts:5,
        // repeat:{
        //     cron:"50 * * * * *"
        // }
    })
}

module.exports = {
    add_to_queue,
    path,
};