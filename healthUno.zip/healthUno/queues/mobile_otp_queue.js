require('dotenv').config();
const ConnectMOTPQueue = require('../config/redis_queue').ConnectMOTPQueue;
const MObileOTPProcess = require('./mobile_otp_process');

ConnectMOTPQueue.process(MObileOTPProcess);

const add_to_mobile_otp_queue = (data) => {
    ConnectMOTPQueue.add(data, {
        // attempts:5,
        // repeat:{`
        //     cron:"50 * * * * *"
        // }
    })
}

module.exports = {
    add_to_mobile_otp_queue
};