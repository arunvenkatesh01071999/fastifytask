const sequelize = require('../../config/db1');
const { Sequelize, DataTypes } = require("sequelize");
const logger = require('../../config/activity_logger');
const speciality = require('../../MastersApp/models/SpecialitiesModel');
const gender = require('../../MastersApp/models/GenderModel');
const doctor_type = require('../../MastersApp/models/DoctorTypeMasterModel');
const HospitalBasic = require('../../HospitalApp/models/HospitalBasicInfoModel');


const DoctorBasicInfo = sequelize.define("d_doctor_basic_info", {
    doctor_name: {
        type: DataTypes.STRING,
        allowNull: false,
        validate: {
            notEmpty: {
                msg: "doctor_name is required"
            }
        }
    },
    doctor_type_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    hospital_name_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    gender_id: {
        type: DataTypes.INTEGER,
        allowNull: true,
    },
    email: {
        type: DataTypes.STRING,
        allowNull: true
    },
    phone_no: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    dob: {
        type: DataTypes.DATE,
        allowNull: true
    },
    age: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    about: {
        type: DataTypes.STRING,
        allowNull: true
    },
    speciality_id: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    image_path: {
        type: DataTypes.STRING,
        allowNull: true
    },
    signature_path: {
        type: DataTypes.STRING,
        allowNull: true
    },
    last_otp: {
        type: DataTypes.STRING,
        allowNull:true,
        // default :0
    },
    isApproved: {
        type: DataTypes.INTEGER,
        allowNull: true,
        default :0
    },
    approve_date: {
        type: DataTypes.DATE,
        allowNull: true,
        // default :''
        // default :''
    },
    approved_by: {
        type: DataTypes.INTEGER,
        allowNull: true,
        // default :0
    },
    addCheck: {
        type: DataTypes.INTEGER,
        allowNull: false
    },
    reason: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    workplacetype:{
        type: DataTypes.INTEGER,
        allowNull: true
    },
    update_on_whatsapp:{
        type: DataTypes.INTEGER,
        allowNull: true
    },
    active: {
        type: DataTypes.INTEGER,
        allowNull: true
    },
    created_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    updated_at: {
        type: DataTypes.STRING,
        allowNull: true,
    },
    created_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    },
    updated_by: {
        type: DataTypes.INTEGER,
        allowNull: false,
    }
}, { freezeTableName: true });

DoctorBasicInfo.belongsTo(doctor_type, { foreignKey: 'doctor_type_id' });
DoctorBasicInfo.belongsTo(speciality, { foreignKey: 'speciality_id' });
DoctorBasicInfo.belongsTo(gender, { foreignKey: 'gender_id' });
DoctorBasicInfo.belongsTo(HospitalBasic, { foreignKey: 'hospital_name_id', as: 'HospitalBasic' });
//DoctorBasicInfo.belongsTo(HospitalBasic, { foreignKey: 'hospital_name_id' });
// DoctorBasicInfo.hasMany(ExperienceInfo, { foreignKey: 'doctor_name_id', as: 'exprience' });

DoctorBasicInfo.addHook('afterUpdate', (data, options) => {
    resp = JSON.stringify({
        action: 'create',
        table_name: 'd_doctor_basic_info',
        record_id: data.id,
        old_value: JSON.stringify(data._previousDataValues),
        new_value: JSON.stringify(data)
    });
    logger.info(resp)
});

DoctorBasicInfo.addHook('afterDestroy', (data, options) => {
    resp = JSON.stringify({
        action: 'delete',
        table_name: 'd_doctor_basic_info',
        record_id: data.id,
        old_value: JSON.stringify(data),
        new_value: '',
    });
    logger.info(resp)
});

module.exports = DoctorBasicInfo;