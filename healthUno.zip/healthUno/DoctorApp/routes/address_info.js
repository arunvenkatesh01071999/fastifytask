const express = require('express');
const router = express();
const AddressInfoController = require('../controller/DoctorAddressInfoController');
const verify_token = require('../../services/verify_token')

router.get('/', verify_token, AddressInfoController.FetchDoctorAddressInfo);
router.get('/:doctor_name_id', verify_token, AddressInfoController.FetchDoctorAddressInfo);
router.post('/', verify_token, AddressInfoController.NewDoctorAddressInfo);
router.put('/:id', verify_token, AddressInfoController.UpdateDoctorAddressInfo);
router.delete('/:id', verify_token, AddressInfoController.DeleteDoctorAddressInfo);


module.exports = router;