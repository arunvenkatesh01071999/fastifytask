const express = require('express');
const router = express();
const SecondOpinionController = require('../../DoctorApp/controller/SecondOpinionController');
const verify_token = require('../../services/verify_token');

router.get('/', verify_token, SecondOpinionController.FetchSecondOpinion);
router.get('/:doctor_name_id', verify_token, SecondOpinionController.FetchSecondOpinion);
router.post('/', verify_token, SecondOpinionController.NewSecondOpinion);
router.put('/:id', verify_token, SecondOpinionController.UpdateSecondOpinion);
router.delete('/:id', verify_token, SecondOpinionController.DeleteSecondOpinion);

module.exports = router;