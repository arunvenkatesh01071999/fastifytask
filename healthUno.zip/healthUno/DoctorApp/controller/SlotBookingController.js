const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const slot_booking_service = require('../services/slot_booking_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');
const AddCheck = require('../../services/doctor_addCheck_service');

const FetchSlotBooking = async (req, res, next) => {
    doctor_name_id = req.params.doctor_name_id;
    if (doctor_name_id) {
        await slot_booking_service.GetbyId(doctor_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {

        await slot_booking_service.Get()
            .then(data => {
                cache.SET(req.user.id + '_slot_booking_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}

const NewSlotBooking = async (req, res, next) => {
    const { virtual, day, walking, active, doctor_name_id, day_id } = req.body;
    var data = req.body;
    var get_pass_d_id = data[0].doctor_name_id;
// console.log('fii',req.body.day_id);
    // console.log("qwerqty",data[0].day,"qwerqty");
    const addCheck = 11;
    const query = AddCheck(get_pass_d_id);
    var data = req.body;

    data.forEach((element) => {

        if (element.virtual == 1 && element.walking == 0) {

            created_by = req.user.id;
            updated_by = req.user.id;
            data = element.day;

            Object.keys(data).forEach((day) => {

                const timings = data[day];
                const fnTimings = timings.fn;
                const anTimings = timings.an;
                const day_ids = timings.day_id;

                sl_data = {
                    doctor_name_id: parseInt(element.doctor_name_id),
                    day: `${day}`,
                    fn: `${fnTimings.join(', ')}`,
                    an: `${anTimings.join(', ')}`,
                    day_id: day_ids,
                    virtual: element.virtual,
                    walking: element.walking,
                    active: element.active,
                    created_by: created_by,
                    updated_by: updated_by
                }
                slot_booking_service.CreateSlotBookingInfo(sl_data);
            });
        }
        if (element.virtual == 0 && element.walking == 1) {
            console.log('WALKINF', data);

            created_by = req.user.id;
            updated_by = req.user.id;
            data = element.day;
            Object.keys(data).forEach((day) => {
                const timings = data[day];
                const fnTimings = timings.fn;
                const anTimings = timings.an;
                const day_ids =timings.day_id;

                sl_data = {
                    doctor_name_id: parseInt(element.doctor_name_id),
                    day: `${day}`,
                    fn: `${fnTimings.join(', ')}`,
                    an: `${anTimings.join(', ')}`,
                    virtual: element.virtual,
                    walking: element.walking,
                    day_id: day_ids,
                    active: element.active,
                    created_by: created_by,
                    updated_by: updated_by
                }
                slot_booking_service.CreateSlotBookingInfo(sl_data)
                    .then(data => {
                        console.log('data', data);
                        if (data.errors) {
                            msg = data.errors[0].message;
                            res.status(400).json(failure_func(msg))
                        } else {
                            msg = "Created Successfully";
                        }
                    })
                    .catch(err => {
                        res.status(400).json(failure_func(err))
                    })
            });
        }
    })
    msg = "Created Successfully"
    res.status(200).json(success_func(msg))

    // .catch(err => {
    //     res.status(400).json(failure_func(err))
    // })

}

const UpdateSlotBooking = async (req, res, next) => {
    id = req.params.doctor_name_id;
    if (id) {
        doctor_name_ids = req.params.doctor_name_id;
        const v = slot_booking_service.DestroySlot(doctor_name_ids);
        var customerFeedback2 = await v;


        const { virtual, day, walking, active, doctor_name_id, day_id } = req.body;
        var data = req.body;
        data.forEach((element) => {

            if (element.virtual == 1 && element.walking == 0) {

                created_by = req.user.id;
                updated_by = req.user.id;
                data = element.day;

                Object.keys(data).forEach((day) => {

                    const timings = data[day];
                    const fnTimings = timings.fn;
                    const anTimings = timings.an;
                    const day_ids =timings.day_id;
                    sl_data = {
                        doctor_name_id: parseInt(element.doctor_name_id),
                        day: `${day}`,
                        fn: `${fnTimings.join(', ')}`,
                        an: `${anTimings.join(', ')}`,
                        day_id: day_ids,
                        virtual: element.virtual,
                        walking: element.walking,
                        active: element.active,
                        created_by: created_by,
                        updated_by: updated_by
                    }
                    slot_booking_service.CreateSlotBookingInfo(sl_data);
                });
            }
            if (element.virtual == 0 && element.walking == 1) {
                console.log('WALKING', data);

                created_by = req.user.id;
                updated_by = req.user.id;
                data = element.day;
                Object.keys(data).forEach((day) => {
                    const timings = data[day];
                    const fnTimings = timings.fn;
                    const anTimings = timings.an;
                    const day_ids =timings.day_id;
                    sl_data = {
                        doctor_name_id: parseInt(element.doctor_name_id),
                        day: `${day}`,
                        fn: `${fnTimings.join(', ')}`,
                        an: `${anTimings.join(', ')}`,
                        day_id: day_ids,
                        virtual: element.virtual,
                        walking: element.walking,
                        active: element.active,
                        created_by: created_by,
                        updated_by: updated_by
                    }
                    slot_booking_service.CreateSlotBookingInfo(sl_data)
                        .then(data => {
                            console.log('data', data);
                            if (data.errors) {
                                msg = data.errors[0].message;
                                res.status(400).json(failure_func(msg))
                            } else {
                                msg = "Created Successfully";
                            }
                        })
                        .catch(err => {
                            res.status(400).json(failure_func(err))
                        })
                });
            }
        })
        msg = "Updated Successfully"
        res.status(200).json(success_func(msg))

    }
}

const DeleteSlotBooking = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await slot_booking_service.DestroySlotBooking(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_slot_booking_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewSlotBooking,
    FetchSlotBooking,
    UpdateSlotBooking,
    DeleteSlotBooking
}