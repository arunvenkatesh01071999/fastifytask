const success_func = require('../../api_responser').success_func;
const failure_func = require('../../api_responser').failure_func;
const date = require('../../services/datetime_service');
const second_opinion_service = require('../services/second_opinion_service');
const logger = require('../../config/logger');
const cache = require('../../services/redis_cache_service');


const FetchSecondOpinion = async (req, res, next) => {
    doctor_name_id = req.params.doctor_name_id;
    if (doctor_name_id) {
        await second_opinion_service.GetbyId(doctor_name_id)
            .then(data => {
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {

        await second_opinion_service.Get()
            .then(data => {
                cache.SET(req.user.id + '_second_opinion_service', data)
                res.status(200).json(success_func(data))
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    }
}


const NewSecondOpinion = async (req, res, next) => {
    doctor_name_id = req.body.doctor_name_id;
    period_id = req.body.period_id;
    fees = req.body.fees;
    active = req.body.active;
    created_by = req.user.id;
    updated_by = req.user.id;
    if (period_id) {
        so_data = {
            doctor_name_id: doctor_name_id,
            period_id: period_id,
            fees: fees,
            active: active,
            created_by: created_by,
            updated_by: updated_by
        }
        // console.log(sm_data)
        // await second_opinion_service.GetId(doctor_name_id)
        //     .then(data => {
        //         if (data.length > 0) {
        //             msg = "Doctor Id Already Exist";
        //             return res.status(200).json(failure_func(msg))
        //         } else {
        second_opinion_service.CreateSecondOpinionInfo(so_data)
            .then(data => {
                if (data.errors) {
                    msg = data.errors[0].message;
                    res.status(400).json(failure_func(msg))
                } else {
                    msg = "Created Successfully"
                    cache.DEL(req.user.id + '_second_opinion_service')
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
        //       
    } else {
        msg = "period_id and active is required";
        res.status(400).json(failure_func(msg))
    }
}

const UpdateSecondOpinion = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        doctor_name_id = req.body.doctor_name_id;
        period_id = req.body.period_id;
        fees = req.body.fees;
        active = req.body.active;
        updated_by = req.user.id;
        updated_at = date();
        if (period_id) {
            so_data = {
                doctor_name_id: doctor_name_id,
                period_id: period_id,
                fees: fees,
                active: active,
                updated_by: updated_by,
                updated_at: updated_at
            }
            await second_opinion_service.UpdateSecondOpinionInfo(id, so_data)
                .then(data => {
                    if (data == 1) {
                        msg = "Updated successfully"
                        cache.DEL(req.user.id + '_second_opinion_service')
                        res.status(200).json(success_func(msg))
                    } else {
                        msg = "ID doesn't exist"
                        res.status(400).json(failure_func(msg))
                    }
                })
                .catch(err => {
                    res.status(400).json(failure_func(err))
                })
        } else {
            msg = "period_id and active is required";
            res.status(400).json(failure_func(msg))
        }
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}

const DeleteSecondOpinion = async (req, res, next) => {
    id = req.params.id;
    if (id) {
        await second_opinion_service.DestroySecondOpinion(id)
            .then(data => {
                if (data == 1) {
                    msg = "Deleted successfully"
                    cache.DEL(req.user.id + '_slot_booking_service')
                    res.status(200).json(success_func(msg))
                } else {
                    msg = "ID doesn't exist"
                    res.status(200).json(success_func(msg))
                }
            })
            .catch(err => {
                res.status(400).json(failure_func(err))
            })
    } else {
        msg = "ID is required";
        res.status(400).json(failure_func(msg))
    }
}


module.exports = {
    NewSecondOpinion,
    FetchSecondOpinion,
    UpdateSecondOpinion,
    DeleteSecondOpinion
}